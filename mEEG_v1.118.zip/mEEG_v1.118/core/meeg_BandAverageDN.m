function outFile = meeg_BandAverageDN(inFile, dayStart, dayEnd)
% Compute Day/Night averages from a *_bands.xlsx file produced by qEEG.
%
% inFile:  *_bands.xlsx (sheets: delta/theta/alpha/beta/gamma/fastGamma)
% dayStart/dayEnd: hours (0-24). Day = [dayStart, dayEnd). Night = complement.
%
% Output:  *_DN.xlsx (same folder), each sheet is 10x2 matrix [dayAvg, nightAvg]

    if nargin < 2, dayStart = 6.5; end
    if nargin < 3, dayEnd   = 18.5; end

    sheetnames = ["delta", "theta", "alpha", "beta", "gamma", "fastGamma"];
    average = struct();

    for m = 1:length(sheetnames)
        data = readmatrix(inFile, 'Sheet', sheetnames(m));
        if size(data,1) > 1 && size(data,2) > 1
            header = data(1, :);
            values = data(2:end, :);

            if dayStart == 0 && dayEnd == 0
                dayCols = true(size(header));
                nightCols = true(size(header));
            elseif dayStart <= dayEnd
                dayCols = (header >= dayStart) & (header < dayEnd);
                nightCols = ~dayCols;
            else
                dayCols = (header >= dayStart) | (header < dayEnd);
                nightCols = ~dayCols;
            end

            dayAvg = mean(values(:, dayCols), 2, "omitnan");
            nightAvg = mean(values(:, nightCols), 2, "omitnan");
            average.(sheetnames(m)) = [dayAvg, nightAvg];
        else
            average.(sheetnames(m)) = [];
        end
    end

    [folder, base, ~] = fileparts(inFile);
    outFile = fullfile(folder, [base, '_DN.xlsx']);

    for k = 1:length(sheetnames)
        if ~isempty(average.(sheetnames(k)))
            writematrix(average.(sheetnames(k)), outFile, 'Sheet', sheetnames(k));
        end
    end
end
