function meeg_EEG_RunAll_fromFiles(fs, hourStart, outputPrefix, corr_window_sec, files, varargin)
% EEG_RunAll variant that uses explicit .dat file paths (10-electrode system).
%
% Outputs (if enabled):
%   [outputPrefix '_bands.xlsx'] sheets: delta theta alpha beta gamma fastGamma
%   [outputPrefix '_ps_avg.xlsx'], [outputPrefix '_ps_std.xlsx'] sheets per region
%   [outputPrefix '_corr.xlsx'] sheets: delta theta alpha beta gamma fastGamma amp
%
% Name-value options:
%   'runBand' (true/false)  - Band analysis
%   'runPSD'  (true/false)  - Power spectrum analysis
%   'runCorr' (true/false)  - Correlation analysis

    % ---- input parsing (compatible with older MATLAB) ----
    p = inputParser;
    p.FunctionName = 'meeg_EEG_RunAll_fromFiles';
    addRequired(p, 'fs', @(x) isnumeric(x) && isscalar(x) && x > 0);
    addRequired(p, 'hourStart', @(x) isnumeric(x) && isscalar(x));
    addRequired(p, 'outputPrefix', @(x) ischar(x) || isstring(x));
    addRequired(p, 'corr_window_sec', @(x) isnumeric(x) && isscalar(x) && x > 0);
    addRequired(p, 'files', @(x) iscell(x) && ~isempty(x));

    addParameter(p, 'runBand', true, @(x) islogical(x) || (isnumeric(x) && isscalar(x)));
    addParameter(p, 'runPSD',  true, @(x) islogical(x) || (isnumeric(x) && isscalar(x)));
    addParameter(p, 'runCorr', true, @(x) islogical(x) || (isnumeric(x) && isscalar(x)));
    addParameter(p, 'runCoh', false, @(x) islogical(x) || (isnumeric(x) && isscalar(x)));
    addParameter(p, 'saveCohSpec', false, @(x) islogical(x) || (isnumeric(x) && isscalar(x)));
    addParameter(p, 'coh_window_sec', 2, @(x) isnumeric(x) && isscalar(x) && x > 0);
    addParameter(p, 'coh_overlap', 0.5, @(x) isnumeric(x) && isscalar(x) && x >= 0 && x < 1);
    addParameter(p, 'coh_fmax', 50, @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 50);
    addParameter(p, 'coh_resample_500', false, @(x) islogical(x) || (isnumeric(x) && isscalar(x)));
    addParameter(p, 'coh_resample_target_hz', 500, @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 100);
    addParameter(p, 'usePreprocMasks', true, @(x) islogical(x) || (isnumeric(x) && isscalar(x)));
    addParameter(p, 'dayStart', 6.5, @(x) isnumeric(x) && isscalar(x) && isfinite(x));
    addParameter(p, 'dayEnd', 18.5, @(x) isnumeric(x) && isscalar(x) && isfinite(x));
    addParameter(p, 'preprocMaskDir', '', @(x) ischar(x) || isstring(x));
    addParameter(p, 'notchEnabled', true, @(x) islogical(x) || (isnumeric(x) && isscalar(x)));
    addParameter(p, 'notchF1', 59, @(x) isnumeric(x) && isscalar(x) && isfinite(x));
    addParameter(p, 'notchF2', 61, @(x) isnumeric(x) && isscalar(x) && isfinite(x));
    addParameter(p, 'channelLabels', {}, @(x) iscell(x) || isstring(x));
    addParameter(p, 'stopFile', '', @(x) ischar(x) || isstring(x));

    parse(p, fs, hourStart, outputPrefix, corr_window_sec, files, varargin{:});
    opts = p.Results;

    fs = double(fs);
    hourStart = double(hourStart);
    corr_window_sec = double(corr_window_sec);
    outputPrefix = char(outputPrefix);
    opts.runBand = logical(opts.runBand);
    opts.runPSD  = logical(opts.runPSD);
    opts.runCorr = logical(opts.runCorr);
    opts.runCoh = logical(opts.runCoh);
    opts.saveCohSpec = logical(opts.saveCohSpec);
    opts.coh_window_sec = double(opts.coh_window_sec);
    opts.coh_overlap = double(opts.coh_overlap);
    opts.coh_fmax = double(opts.coh_fmax);
    opts.coh_resample_500 = logical(opts.coh_resample_500);
    opts.coh_resample_target_hz = double(opts.coh_resample_target_hz);
    opts.usePreprocMasks = logical(opts.usePreprocMasks);
    opts.dayStart = mod(double(opts.dayStart), 24);
    opts.dayEnd = mod(double(opts.dayEnd), 24);
    opts.preprocMaskDir = char(opts.preprocMaskDir);
    opts.notchEnabled = logical(opts.notchEnabled);
    opts.notchF1 = double(opts.notchF1);
    opts.notchF2 = double(opts.notchF2);
    if opts.notchEnabled && ~(opts.notchF1 > 0 && opts.notchF2 > opts.notchF1 && opts.notchF2 < fs/2)
        error('Invalid notch band [%.6g %.6g] Hz for sampling rate %.6g Hz. Require 0 < lower < upper < Nyquist.', ...
            opts.notchF1, opts.notchF2, fs);
    end
    opts.stopFile = char(opts.stopFile);

    function tf = localStopRequested()
        tf = ~isempty(opts.stopFile) && isfile(opts.stopFile);
    end

    function cleanupPartialOutputs()
        try
            outDirLocal = fileparts(outputPrefix);
            if ~isempty(outDirLocal) && isfolder(outDirLocal)
                try
                    rmdir(outDirLocal, 's');
                catch
                    delete(fullfile(outDirLocal, '*'));
                end
            end
        catch
        end
    end

    if localStopRequested()
        cleanupPartialOutputs();
        error('mEEG:StopRequested', 'qEEG stop requested before processing started.');
    end

    numCh = numel(files);
    if numCh < 1
        error('No channel files were provided.');
    end

    if isempty(opts.channelLabels)
        if numCh == 10
            channelLabels = {'auditory_R','visual_R','hippocampus_R','barrel_R','motor_R','auditory_L','visual_L','hippocampus_L','barrel_L','motor_L'};
        else
            channelLabels = arrayfun(@(k) sprintf('Ch%d', k), 1:numCh, 'UniformOutput', false);
        end
    else
        channelLabels = cellstr(string(opts.channelLabels(:))');
        if numel(channelLabels) ~= numCh
            error('Number of channel labels (%d) does not match number of files (%d).', numel(channelLabels), numCh);
        end
    end

    % Labels may come from older saved projects or Intan XML custom names.
    % Never use raw labels like "auditory.R" as struct fields; sanitize once
    % here so qEEG is robust on all MATLAB versions/platforms.
    channelLabels = cellstr(string(meeg_sanitize_lead_label(channelLabels(:)))');

    % --------- constants ----------
    secondsInWindow  = 30*60;              % 30 minutes
    sampsPerWindow   = fs * secondsInWindow;
    sampsPerSec      = fs;
    sampsPer5s       = fs * 5;
    nEpochs5s        = secondsInWindow/5;  % 360
    bytesPerSample   = 2;                  % int16
    scale_uV         = 0.195;              % preserve original behavior

    % --------- compute recPeriods robustly across channels ----------
    samplesPerFile = zeros(1,numCh);
    for k = 1:numCh
        info = dir(files{k});
        if isempty(info), error('Missing file: %s', files{k}); end
        samplesPerFile(k) = floor(double(info.bytes) / bytesPerSample);
    end
    samplesPerFileMin = min(samplesPerFile);
    recPeriods = floor(samplesPerFileMin / sampsPerWindow);
    if recPeriods < 1
        error('Computed recPeriods < 1. Check fs and file sizes.');
    end


    % --------- optional: load pre-processing masks (from Pre-processing tab) ----------
    haveMasks = false;
    if opts.usePreprocMasks && ~isempty(opts.preprocMaskDir) && isfolder(opts.preprocMaskDir)
        badPath  = fullfile(opts.preprocMaskDir, 'lowQEpochMask.mat');
        goodPath = fullfile(opts.preprocMaskDir, 'goodQChannelMask.mat');
        if isfile(badPath) && isfile(goodPath)
            Sbad = load(badPath);
            Sgood = load(goodPath);
            if isfield(Sbad, 'badEpochAll') && isfield(Sgood, 'goodChByPeriod')
                badEpochAll = logical(Sbad.badEpochAll);
                goodChByPeriod = logical(Sgood.goodChByPeriod);

                % Basic sanity checks
                if size(badEpochAll,1) == numCh && size(goodChByPeriod,1) == numCh
                    maskPeriods = min(size(goodChByPeriod,2), floor(size(badEpochAll,2) / nEpochs5s));
                    if maskPeriods >= 1
                        recPeriods = min(recPeriods, maskPeriods);
                        haveMasks = true;
                    end
                end
            end
        end
    end
    % --------- configurable notch filter (with fallback) ----------
    if opts.notchEnabled
        applyNotch = meeg_buildNotch(fs, opts.notchF1, opts.notchF2);
        fprintf('[qEEG] Applying notch band %.3f-%.3f Hz.\n', opts.notchF1, opts.notchF2);
    else
        applyNotch = @(x) x;
        fprintf('[qEEG] Notch filtering disabled.\n');
    end

    % --------- preallocate outputs ----------
    bandNames = {'delta','theta','alpha','beta','gamma','fastGamma'};
    Bands = struct();
    for bn = bandNames, Bands.(bn{1}) = zeros(numCh, recPeriods); end

    % PSAnalysis
    N = sampsPer5s;
    pfreq = linspace(0, fs/2, floor(N/2)+1).';   % column vector
    regionNames = channelLabels;
    PS_avg = struct(); PS_std = struct();
    for rn = regionNames
        PS_avg.(rn{1}) = zeros(numel(pfreq), recPeriods);
        PS_std.(rn{1}) = zeros(numel(pfreq), recPeriods);
    end
    ch2reg = regionNames;

    % CorrelationAnalysis
    Corr = struct('delta', zeros(numCh,numCh,recPeriods), ...
                  'theta', zeros(numCh,numCh,recPeriods), ...
                  'alpha', zeros(numCh,numCh,recPeriods), ...
                  'beta',  zeros(numCh,numCh,recPeriods), ...
                  'gamma', zeros(numCh,numCh,recPeriods), ...
                  'fastGamma', zeros(numCh,numCh,recPeriods), ...
                  'amp',   zeros(numCh,numCh,recPeriods));

    

% Coherence (lead x lead, band-averaged; kept individual like correlation)
cohBandNames = {'delta','theta','alpha','beta','gamma','fastGamma'};
cohLabels = regionNames; % {'auditory_R','visual_R','hippocampus_R','barrel_R','motor_R','auditory_L','visual_L','hippocampus_L','barrel_L','motor_L'}
nCoh = numel(cohLabels);
nCohBands = numel(cohBandNames);
Coh = nan(nCohBands, nCoh, nCoh, recPeriods);   % band x lead x lead x period
CohHours = nan(1, recPeriods);
cohEngine = 'shared_fft_v1.114d';
cohSharedFFTFallbackWindows = 0;

% Coherence-only sampling-rate configuration. The original EEG remains
% untouched for band power, PSD, correlation, and all non-coherence modules.
cohOriginalFs = fs;
cohResampleRequested = logical(opts.coh_resample_500);
cohResampleTargetHz = double(opts.coh_resample_target_hz);
cohResampleApplied = false;
cohResampleFallbackReason = '';
cohResampleP = 1;
cohResampleQ = 1;
cohProcessingFs = fs;
if opts.runCoh && cohResampleRequested && fs > cohResampleTargetHz * (1 + 1e-12)
    % Use a bounded rational approximation so unusual non-integer EDF
    % rates do not create an impractically long polyphase resampling filter.
    [cohResampleP, cohResampleQ] = rat(cohResampleTargetHz / fs, 1e-5);
    if max(cohResampleP, cohResampleQ) > 10000
        [cohResampleP, cohResampleQ] = rat(cohResampleTargetHz / fs, 1e-4);
    end
    if cohResampleP < 1 || cohResampleQ < 1 || max(cohResampleP, cohResampleQ) > 10000
        error('mEEG:InvalidCoherenceResampleRatio', ...
            ['Could not construct a practical coherence resampling ratio for %.6g Hz to %.6g Hz. ' ...
             'Disable coherence-only resampling for this recording.'], fs, cohResampleTargetHz);
    end
    cohProcessingFs = fs * double(cohResampleP) / double(cohResampleQ);
    if cohProcessingFs < fs * (1 - 1e-12)
        cohResampleApplied = true;
    else
        cohProcessingFs = fs;
        cohResampleP = 1;
        cohResampleQ = 1;
    end
end
if opts.runCoh && cohResampleApplied
    % Preflight the resampler before any 30-minute window is processed. If
    % the current MATLAB worker type cannot execute resample(), use the
    % original rate consistently for the entire animal rather than mixing
    % sampling rates across windows.
    try
        resample(zeros(max(32, round(fs)), 1), cohResampleP, cohResampleQ);
    catch MEresamplePreflight
        warning('mEEG:CoherenceResampleUnavailable', ...
            ['Coherence-only resampling is unavailable on this worker (%s). ' ...
             'Using the original %.3f Hz sampling rate for this animal.'], ...
            MEresamplePreflight.message, fs);
        cohResampleApplied = false;
        cohResampleFallbackReason = MEresamplePreflight.message;
        cohProcessingFs = fs;
        cohResampleP = 1;
        cohResampleQ = 1;
    end
end
cohRequestedFmax = opts.coh_fmax;
cohActualFmax = min(cohRequestedFmax, cohProcessingFs/2);
if opts.runCoh && cohProcessingFs/2 < 50
    error('mEEG:CoherenceNyquistTooLow', ...
        ['The recording sampling rate (%.3f Hz; Nyquist %.3f Hz) cannot support the minimum ' ...
         'coherence fmax of 50 Hz. The recording is not upsampled because upsampling adds no new information.'], ...
        cohProcessingFs, cohProcessingFs/2);
end

% Optional coherence spectra accumulation (lead x lead x f)
CohF = [];
CohSpecDay = [];
CohSpecNight = [];
CohSpecDayN = [];
CohSpecNightN = [];
if opts.runCoh && opts.saveCohSpec
    CohSpecDay = zeros(nCoh,nCoh,1);
    CohSpecNight = zeros(nCoh,nCoh,1);
    CohSpecDayN = zeros(nCoh,nCoh);
    CohSpecNightN = zeros(nCoh,nCoh);
end


% --------- main loop over 30-min periods ----------
    v = zeros(numCh, sampsPerWindow);
    [~, outputLabel, ~] = fileparts(outputPrefix);
    for t = 1:recPeriods
        if localStopRequested()
            cleanupPartialOutputs();
            error('mEEG:StopRequested', 'qEEG stop requested by user.');
        end
        if opts.runCoh && (t == 1 || t == recPeriods || mod(t, max(1, ceil(recPeriods/12))) == 0)
            fprintf('[Coherence] %s window %d/%d\n', outputLabel, t, recPeriods);
        end
        % --- read 30-min block per channel with correct byte seek ---
        for ch = 1:numCh
            fid = fopen(files{ch}, 'r');
            if fid == -1, error('Could not open %s', files{ch}); end
            offsetBytes = int64(t-1) * int64(sampsPerWindow) * int64(bytesPerSample);
            if fseek(fid, offsetBytes, 'bof') ~= 0
                fclose(fid); error('fseek failed: %s @ byte %s', files{ch}, string(offsetBytes));
            end
            raw = fread(fid, sampsPerWindow, 'int16=>double'); fclose(fid);
            if numel(raw) < sampsPerWindow
                error('Short read in %s: expected %d, got %d', files{ch}, sampsPerWindow, numel(raw));
            end
            v(ch,:) = applyNotch(raw(:)' * scale_uV);
        end

                if haveMasks
            goodCh = goodChByPeriod(:, t);
            badEpoch = badEpochAll(:, (t-1)*nEpochs5s + 1 : t*nEpochs5s);
        else
        % --- per-second RMS & skewness ---
                skwAvg = zeros(numCh,1); rmsAvg = zeros(numCh,1);
                zscore_rms = zeros(numCh, secondsInWindow);
                for ch = 1:numCh
                    X = reshape(v(ch,:), sampsPerSec, secondsInWindow);
                    r = sqrt(mean(X.^2, 1));
                    mu = mean(X,1); sd = std(X,0,1);
                    s = mean(((X - mu)./max(sd, eps)).^3, 1);
                    skwAvg(ch) = mean(s);
                    rmsAvg(ch) = mean(r);
                    zscore_rms(ch,:) = (r - mean(r)) / max(std(r), eps);
                end
        
                % --- channel quality ---
                goodCh = ~( (rmsAvg > 200) | (rmsAvg < 30) | (skwAvg > 0.4) );
        
                % --- detect bad 5-s epochs by max |z| ---
                maxZ = zeros(numCh, nEpochs5s);
                for ch = 1:numCh
                    for e = 1:nEpochs5s
                        idxS = (e-1)*5 + (1:5);
                        maxZ(ch,e) = max(abs(zscore_rms(ch, idxS)));
                    end
                end
                badEpoch = maxZ >= 3;
        
                
        end

% --- optional coherence-only anti-alias resampling ---
% Resample the unmodified, notch-filtered signal before bad epochs are
% zeroed for the other qEEG modules. The validity mask below excludes the
% rejected epochs at the coherence processing rate.
        cohSignalsResampled = [];
        cohValidSampleCount = [];
        if opts.runCoh && cohResampleApplied
            expectedCohSamples = max(1, round(size(v,2) * double(cohResampleP) / double(cohResampleQ)));
            cohSignalsResampled = zeros(nCoh, expectedCohSamples);
            cohValidSampleCount = zeros(nCoh,1);
            for ch = 1:nCoh
                if ~goodCh(ch)
                    continue;
                end
                yCoh = resample(v(ch,:).', cohResampleP, cohResampleQ); % includes anti-alias FIR filtering
                yCoh = double(yCoh(:).');
                nCopy = min(expectedCohSamples, numel(yCoh));
                cohSignalsResampled(ch,1:nCopy) = yCoh(1:nCopy);
                cohValidSampleCount(ch) = nCopy;
            end
        end

% --- zero-out bad epochs in v ---
        for ch = 1:numCh
            for e = 1:nEpochs5s
                if badEpoch(ch,e)
                    idx = (e-1)*sampsPer5s + (1:sampsPer5s);
                    v(ch, idx) = 0;
                end
            end
        end

        
% ----------------- COHERENCE (lead-level) -----------------
if opts.runCoh
    CohHours(t) = mod(hourStart + (t-1)*0.5, 24); % 30-min windows

    if cohResampleApplied
        cohSignals = cohSignalsResampled;
    else
        % No copy is made until MATLAB needs one. Bad epochs have already
        % been zeroed, and the validity mask excludes them from coherence.
        cohSignals = v;
    end
    cohSamplesThisWindow = size(cohSignals, 2);

    winSec = opts.coh_window_sec;
    overlap = opts.coh_overlap;
    nwin = max(16, round(winSec * cohProcessingFs));
    nover = round(overlap * nwin);
    nfft = 2^nextpow2(nwin);

    % Build the validity mask directly on the coherence time grid. Rejected
    % five-second epochs remain in their correct temporal positions after
    % optional resampling; lower-rate EDFs are never upsampled.
    leadMask = false(nCoh, cohSamplesThisWindow);
    for ch = 1:nCoh
        if ~goodCh(ch)
            continue;
        end
        leadMask(ch,:) = true;
        if cohResampleApplied && cohValidSampleCount(ch) < cohSamplesThisWindow
            leadMask(ch, (cohValidSampleCount(ch)+1):end) = false;
        end
        for e = 1:nEpochs5s
            if badEpoch(ch,e)
                s0 = floor((e-1) * 5 * cohProcessingFs) + 1;
                s1 = min(cohSamplesThisWindow, round(e * 5 * cohProcessingFs));
                if s0 <= s1 && s0 <= cohSamplesThisWindow
                    leadMask(ch, s0:s1) = false;
                end
            end
        end
    end

    % Set diagonal coherence to 1 without spectral calculation.
    for rr = 1:nCoh
        Coh(:, rr, rr, t) = 1;
    end

    % Respect the user-defined fmax. The only automatic adjustment is a
    % Nyquist cap at the actual coherence processing rate.
    cohCalcFmax = cohActualFmax;

    try
        [fcoh, cohAllPairs, pairSegmentCount, cohInfo] = ...
            meeg_coherence_shared_fft(cohSignals, leadMask, cohProcessingFs, nwin, nover, nfft, cohCalcFmax, 64);
        if t == 1
            if cohResampleApplied
                fprintf(['[Coherence] Coherence-only anti-alias resampling for %s: original fs=%.3f Hz, ' ...
                    'processing fs=%.3f Hz, target=%.1f Hz, ratio=%d/%d.\n'], ...
                    outputLabel, cohOriginalFs, cohProcessingFs, cohResampleTargetHz, cohResampleP, cohResampleQ);
            elseif cohResampleRequested && ~isempty(cohResampleFallbackReason)
                fprintf(['[Coherence] Coherence-only resampling requested for %s but was unavailable; ' ...
                    'using original fs=%.3f Hz for the entire animal. Reason: %s\n'], ...
                    outputLabel, cohOriginalFs, cohResampleFallbackReason);
            elseif cohResampleRequested
                fprintf(['[Coherence] Coherence-only resampling requested for %s, but original fs=%.3f Hz ' ...
                    'is not above the %.1f Hz target; using the original rate (no upsampling).\n'], ...
                    outputLabel, cohOriginalFs, cohResampleTargetHz);
            else
                fprintf('[Coherence] Coherence-only resampling disabled for %s; using original fs=%.3f Hz.\n', ...
                    outputLabel, cohOriginalFs);
            end
            if cohActualFmax < cohRequestedFmax
                fprintf(['[Coherence] Requested fmax=%.1f Hz was capped to %.3f Hz by the processing ' ...
                    'Nyquist frequency (%.3f Hz).\n'], ...
                    cohRequestedFmax, cohActualFmax, cohProcessingFs/2);
            else
                fprintf('[Coherence] Requested fmax=%.1f Hz; actual calculation fmax=%.1f Hz.\n', ...
                    cohRequestedFmax, cohActualFmax);
            end
            fprintf(['[Coherence] Shared-FFT engine enabled for %s: %d leads, ' ...
                '%d Welch segments/window, batch=%d, fmax=%.1f Hz.\n'], ...
                outputLabel, nCoh, cohInfo.TotalSegments, cohInfo.BatchSegments, cohCalcFmax);
        end
    catch MEshared
        cohSharedFFTFallbackWindows = cohSharedFFTFallbackWindows + 1;
        warning('mEEG:CoherenceSharedFFTFallback', ...
            ['Shared-FFT coherence failed for %s window %d (%s). ' ...
             'Falling back to legacy pairwise mscohere for this window.'], ...
             outputLabel, t, MEshared.message);
        [fcoh, cohAllPairs, pairSegmentCount] = ...
            meeg_coherence_legacy_pairwise(cohSignals, leadMask, cohProcessingFs, nwin, nover, nfft, cohCalcFmax);
    end

    if ~isempty(fcoh) && ~isempty(cohAllPairs)
        % Determine if this 30-minute window is day or night once.
        hrWin = CohHours(t);
        isDayWin = local_is_day_hour(hrWin, opts.dayStart, opts.dayEnd);

        hasFinitePair = false;
        for rr1 = 1:nCoh
            for rr2 = (rr1+1):nCoh
                if any(isfinite(cohAllPairs(:,rr1,rr2)))
                    hasFinitePair = true;
                    break;
                end
            end
            if hasFinitePair, break; end
        end

        % Initialize optional day/night pair-spectrum accumulation only when
        % at least one off-diagonal pair has usable coherence data.
        if opts.saveCohSpec && isempty(CohF) && hasFinitePair
            selFInit = fcoh <= cohActualFmax;
            CohF = fcoh(selFInit);
            CohSpecDay = zeros(nCoh,nCoh,numel(CohF));
            CohSpecNight = zeros(nCoh,nCoh,numel(CohF));
            CohSpecDayN = zeros(nCoh,nCoh);
            CohSpecNightN = zeros(nCoh,nCoh);
            for rr = 1:nCoh
                CohSpecDay(rr,rr,:) = 1;
                CohSpecNight(rr,rr,:) = 1;
                CohSpecDayN(rr,rr) = 1;
                CohSpecNightN(rr,rr) = 1;
            end
        end

        fastGammaUpper = min([cohActualFmax, 100, cohProcessingFs/2]);
        bandsHz = [0.4 4; 4 8; 8 13; 13 30; 30 50; 50 fastGammaUpper];

        for r1 = 1:nCoh
            for r2 = (r1+1):nCoh
                if pairSegmentCount(r1,r2) < 1
                    continue;
                end

                cxy = cohAllPairs(:,r1,r2);
                if ~any(isfinite(cxy))
                    continue;
                end

                % Accumulate coherence spectrum up to the actual fmax.
                if opts.saveCohSpec && ~isempty(CohF)
                    selF = fcoh <= cohActualFmax;
                    csel = cxy(selF);
                    nUse = min(numel(CohF), numel(csel));
                    csel = csel(1:nUse);

                    if isDayWin
                        CohSpecDay(r1,r2,1:nUse) = reshape(squeeze(CohSpecDay(r1,r2,1:nUse)) + csel(:), 1, 1, []);
                        CohSpecDay(r2,r1,1:nUse) = reshape(squeeze(CohSpecDay(r2,r1,1:nUse)) + csel(:), 1, 1, []);
                        CohSpecDayN(r1,r2) = CohSpecDayN(r1,r2) + 1;
                        CohSpecDayN(r2,r1) = CohSpecDayN(r2,r1) + 1;
                    else
                        CohSpecNight(r1,r2,1:nUse) = reshape(squeeze(CohSpecNight(r1,r2,1:nUse)) + csel(:), 1, 1, []);
                        CohSpecNight(r2,r1,1:nUse) = reshape(squeeze(CohSpecNight(r2,r1,1:nUse)) + csel(:), 1, 1, []);
                        CohSpecNightN(r1,r2) = CohSpecNightN(r1,r2) + 1;
                        CohSpecNightN(r2,r1) = CohSpecNightN(r2,r1) + 1;
                    end
                end

                % Band averages use the same boundaries and arithmetic mean
                % as the legacy mscohere implementation. A band whose upper
                % boundary equals its lower boundary (for example fast gamma
                % when fmax=50 Hz) is intentionally left as NaN.
                for b = 1:nCohBands
                    f0 = bandsHz(b,1); f1 = bandsHz(b,2);
                    if f1 <= f0
                        continue;
                    end
                    sel = (fcoh >= f0) & (fcoh < f1);
                    if any(sel)
                        val = mean(cxy(sel), 'omitnan');
                        Coh(b, r1, r2, t) = val;
                        Coh(b, r2, r1, t) = val;
                    end
                end
            end
        end
    end
end

% ----------------- BAND ANALYSIS -----------------
        if opts.runBand
            for ch = 1:numCh
                if ~goodCh(ch)
                    for bi = 1:numel(bandNames), Bands.(bandNames{bi})(ch,t) = NaN; end
                    continue;
                end
                tmp = nonzeros(v(ch,:).');  % column
                nWin = floor(numel(tmp)/sampsPer5s);
                if nWin == 0
                    for bi = 1:numel(bandNames), Bands.(bandNames{bi})(ch,t) = NaN; end
                else
                    acc = zeros(nWin, numel(bandNames));
                    for e = 1:nWin
                        idx = (e-1)*sampsPer5s + (1:sampsPer5s);
                        acc(e,:) = bandPowers5s(tmp(idx), fs);
                    end
                    m = mean(acc,1,'omitnan');
                    for bi = 1:numel(bandNames), Bands.(bandNames{bi})(ch,t) = m(bi); end
                end
            end
        end

        % ----------------- POWER SPECTRA -----------------
        if opts.runPSD
            for ch = 1:numCh
                if ~goodCh(ch)
                    PS_avg.(ch2reg{ch})(:,t) = NaN;
                    PS_std.(ch2reg{ch})(:,t) = NaN;
                    continue;
                end
                tmp = nonzeros(v(ch,:).');
                nWin = floor(numel(tmp)/sampsPer5s);
                if nWin == 0
                    PS_avg.(ch2reg{ch})(:,t) = NaN;
                    PS_std.(ch2reg{ch})(:,t) = NaN;
                else
                    acc = zeros(numel(pfreq), nWin);
                    for e = 1:nWin
                        idx = (e-1)*sampsPer5s + (1:sampsPer5s);
                        acc(:,e) = psd5s(tmp(idx), fs);
                    end
                    PS_avg.(ch2reg{ch})(:,t) = mean(acc, 2, 'omitnan');
                    PS_std.(ch2reg{ch})(:,t) = std(acc, 0, 2, 'omitnan');
                end
            end
        end

        % ----------------- CORRELATION ANALYSIS -----------------
        if opts.runCorr
            % Correlation uses a NaN-masked copy of the signal so bad 5-s
            % epochs are omitted pairwise rather than contributing zeros.
            % Keep v itself zero-masked for legacy band power/PSD behavior.
            epoch_Data = v;
            for ch = 1:numCh
                for e = 1:nEpochs5s
                    if badEpoch(ch,e)
                        idx = (e-1)*sampsPer5s + (1:sampsPer5s);
                        epoch_Data(ch, idx) = NaN;
                    end
                end
            end
            epoch_Data(~goodCh, :) = NaN;
            epoch_Data(:, ~any(isfinite(epoch_Data),1)) = [];
            if ~isempty(epoch_Data)
                win = min(corr_window_sec, size(epoch_Data,2)/fs);
                W = max(1, floor(win*fs));
                epochLen = floor(size(epoch_Data,2)/W);
                if epochLen >= 1
                    AMP = NaN(numCh,numCh,epochLen);
                    DEL=AMP; THE=AMP; ALP=AMP; BET=AMP; GAM=AMP; HIF=AMP;
                    for e = 1:epochLen
                        cols = (e-1)*W + (1:W);
                        seg = epoch_Data(:, cols);
                        AMP(:,:,e) = local_corrcoef_rows(seg);
                        [dBand,tBand,aBand,bBand,gBand,hfBand] = bandSignalsFromSeg(seg, fs);
                        DEL(:,:,e) = local_corrcoef_rows(dBand);
                        THE(:,:,e) = local_corrcoef_rows(tBand);
                        ALP(:,:,e) = local_corrcoef_rows(aBand);
                        BET(:,:,e) = local_corrcoef_rows(bBand);
                        GAM(:,:,e) = local_corrcoef_rows(gBand);
                        HIF(:,:,e) = local_corrcoef_rows(hfBand);
                    end
                    Corr.delta(:,:,t)     = mean(DEL,3,'omitnan');
                    Corr.theta(:,:,t)     = mean(THE,3,'omitnan');
                    Corr.alpha(:,:,t)     = mean(ALP,3,'omitnan');
                    Corr.beta(:,:,t)      = mean(BET,3,'omitnan');
                    Corr.gamma(:,:,t)     = mean(GAM,3,'omitnan');
                    Corr.fastGamma(:,:,t) = mean(HIF,3,'omitnan');
                    Corr.amp(:,:,t)       = mean(AMP,3,'omitnan');
                end
            end

            badIdx = find(~goodCh);
            fields = fieldnames(Corr);
            for bi = 1:numel(badIdx)
                b = badIdx(bi);
                for ff = 1:numel(fields)
                    Corr.(fields{ff})(b,:,t) = NaN;
                    Corr.(fields{ff})(:,b,t) = NaN;
                end
            end
        end
    end

    % --------- timestamps (hours) per 30-min period ----------
    timeStamps = mod(hourStart + 0.5*(0:recPeriods-1), 24);

    if localStopRequested()
        cleanupPartialOutputs();
        error('mEEG:StopRequested', 'qEEG stop requested before writing outputs.');
    end

    % ==================== WRITE OUTPUTS ====================
    if opts.runBand
        outBands = sprintf('%s_bands.xlsx', outputPrefix);
        for bn = bandNames
            sheetMat = [timeStamps; Bands.(bn{1})];
            writematrix(sheetMat, outBands, 'Sheet', bn{1});
        end
    end

    if opts.runPSD
        % Write a compact MAT cache before the Excel workbooks.  The PSD
        % post-processing and GUI readers prefer this cache because repeated
        % per-sheet XLSX reads can be extremely slow on macOS.  The XLSX files
        % are still written exactly as before for user inspection/export.
        try
            psValues = nan(numel(pfreq), recPeriods, numCh, 'single');
            for ch = 1:numCh
                psValues(:,:,ch) = single(PS_avg.(regionNames{ch}));
            end
            psFreq = single(pfreq(:));
            psTimeHours = double(timeStamps(:).');
            psLabels = string(regionNames(:));
            outPScache = sprintf('%s_ps_avg_cache.mat', outputPrefix);
            save(outPScache, 'psValues', 'psFreq', 'psTimeHours', 'psLabels', '-v7');
        catch MEpsCache
            warning('Could not save PSD post-processing cache for %s: %s', outputPrefix, MEpsCache.message);
        end

        outPSavg = sprintf('%s_ps_avg.xlsx', outputPrefix);
        outPSstd = sprintf('%s_ps_std.xlsx', outputPrefix);
        for rn = regionNames
            avgMat = [timeStamps; PS_avg.(rn{1})];
            stdMat = [timeStamps; PS_std.(rn{1})];
            writematrix(avgMat, outPSavg, 'Sheet', rn{1});
            writematrix(stdMat, outPSstd, 'Sheet', rn{1});
        end
    end

    if opts.runCorr
        outCorr = sprintf('%s_corr.xlsx', outputPrefix);
        corrSheets = fieldnames(Corr);
        extTime = zeros(1, recPeriods*numCh);
        for i = 1:recPeriods, extTime(1, (i-1)*numCh+1) = timeStamps(i); end
        for s = 1:numel(corrSheets)
            M = [];
            for t = 1:recPeriods
                M = cat(2, M, Corr.(corrSheets{s})(:,:,t));
            end
            M = [extTime; M];
            writematrix(M, outCorr, 'Sheet', corrSheets{s});
        end
    end

% ----------------- WRITE COHERENCE OUTPUTS -----------------
if opts.runCoh
    cohMatFile = [outputPrefix '_coh.mat'];
    animalPrefix = string(regexp(outputPrefix, '[^/\\]+$', 'match', 'once'));
    try
        save(cohMatFile, 'Coh', 'CohHours', 'cohBandNames', 'cohLabels', 'animalPrefix', 'channelLabels', ...
            'cohEngine', 'cohSharedFFTFallbackWindows', ...
            'cohOriginalFs', 'cohProcessingFs', 'cohResampleRequested', 'cohResampleApplied', ...
            'cohResampleFallbackReason', 'cohResampleTargetHz', 'cohResampleP', 'cohResampleQ', ...
            'cohRequestedFmax', 'cohActualFmax');
        fprintf('[Coherence] Saved per-animal MAT: %s\n', cohMatFile);
        fprintf('[Coherence] Shared-FFT fallback windows for %s: %d/%d\n', ...
            outputLabel, cohSharedFFTFallbackWindows, recPeriods);
    catch MEcohSave
        warning('Failed to save coherence MAT for %s: %s', outputPrefix, MEcohSave.message);
    end

    % coherence spectra outputs (day/night averages)
    if opts.saveCohSpec
        try
            if ~isempty(CohF)
                CohSpecDayAvg = nan(size(CohSpecDay));
                CohSpecNightAvg = nan(size(CohSpecNight));
                for rr1 = 1:nCoh
                    for rr2 = 1:nCoh
                        if CohSpecDayN(rr1,rr2) > 0
                            CohSpecDayAvg(rr1,rr2,:) = squeeze(CohSpecDay(rr1,rr2,:)) ./ CohSpecDayN(rr1,rr2);
                        end
                        if CohSpecNightN(rr1,rr2) > 0
                            CohSpecNightAvg(rr1,rr2,:) = squeeze(CohSpecNight(rr1,rr2,:)) ./ CohSpecNightN(rr1,rr2);
                        end
                    end
                end
                cohSpecFile = [outputPrefix '_cohSpec.mat'];
                cohSpecDayStart = opts.dayStart;
                cohSpecDayEnd = opts.dayEnd;
                save(cohSpecFile, 'CohF', 'CohSpecDayAvg', 'CohSpecNightAvg', 'cohLabels', 'animalPrefix', ...
                    'cohSpecDayStart', 'cohSpecDayEnd', ...
                    'cohOriginalFs', 'cohProcessingFs', 'cohResampleRequested', 'cohResampleApplied', ...
                    'cohResampleFallbackReason', 'cohResampleTargetHz', 'cohRequestedFmax', 'cohActualFmax');
                fprintf('[Coherence] Saved per-animal spectra MAT: %s\n', cohSpecFile);
            else
                fprintf('[Coherence] No spectra accumulated for %s (CohF empty).\n', outputPrefix);
            end
        catch MEcohSpec
            warning('Failed to save coherence spectra for %s: %s', outputPrefix, MEcohSpec.message);
        end
    else
        fprintf('[Coherence] Pair-spectrum saving disabled for %s (skipping *_cohSpec.mat).\n', outputPrefix);
    end

    % Day/Night band-avg lead-by-lead matrices (one sheet per band)
    try
        cohXlsx = [outputPrefix '_coh_daynight.xlsx'];
        isDay = false(1, recPeriods);
        for t2 = 1:recPeriods
            isDay(t2) = local_is_day_hour(CohHours(t2), opts.dayStart, opts.dayEnd);
        end

        for b = 1:nCohBands
            if any(isDay)
                dayBlock = Coh(b,:,:,isDay);
                dayM = mean(reshape(dayBlock, nCoh, nCoh, []), 3, 'omitnan');
            else
                dayM = nan(nCoh, nCoh);
            end
            if any(~isDay)
                nightBlock = Coh(b,:,:,~isDay);
                nightM = mean(reshape(nightBlock, nCoh, nCoh, []), 3, 'omitnan');
            else
                nightM = nan(nCoh, nCoh);
            end
            Tday = array2table(dayM, 'VariableNames', matlab.lang.makeValidName(cohLabels), 'RowNames', matlab.lang.makeValidName(cohLabels));
            Tnight = array2table(nightM, 'VariableNames', matlab.lang.makeValidName(cohLabels), 'RowNames', matlab.lang.makeValidName(cohLabels));
            writetable(Tday, cohXlsx, 'Sheet', [cohBandNames{b} '_day'], 'WriteRowNames', true);
            writetable(Tnight, cohXlsx, 'Sheet', [cohBandNames{b} '_night'], 'WriteRowNames', true);
        end
        fprintf('[Coherence] Saved per-animal day/night Excel: %s\n', cohXlsx);
    catch MEcohXlsx
        warning('Failed to save coherence Excel for %s: %s', outputPrefix, MEcohXlsx.message);
    end
end
end

% ==================== HELPERS ====================

function pow = bandPowers5s(data, fs)
    [B,A] = butter(6, ((100/fs)*2));
    x = filter(B, A, data(:).');
    N = numel(x);
    X = real(fft(x));
    X = X(1:floor(N/2)+1);
    pxx = (1/(fs*N)) * abs(X).^2;
    if numel(pxx) > 2, pxx(2:end-1) = 2*pxx(2:end-1); end
    pf = linspace(0, fs/2, numel(pxx));
    npxx = pxx / max(trapz(pxx), eps);
    pow = zeros(1,6);
    pow(1) = trapz(npxx(pf >= 0.4 & pf < 4));
    pow(2) = trapz(npxx(pf >= 4   & pf < 8));
    pow(3) = trapz(npxx(pf >= 8   & pf < 13));
    pow(4) = trapz(npxx(pf >= 13  & pf < 30));
    pow(5) = trapz(npxx(pf >= 30  & pf < 50));
    pow(6) = trapz(npxx(pf >= 50  & pf <= 100));
end

function pxx = psd5s(data, fs)
    [B,A] = butter(6, ((100/fs)*2));
    x = filter(B, A, data(:).');
    N = numel(x);
    X = real(fft(x));
    X = X(1:floor(N/2)+1);
    pxx = (1/(fs*N)) * abs(X).^2;
    if numel(pxx) > 2, pxx(2:end-1) = 2*pxx(2:end-1); end
    pxx = pxx(:);
end

function [dBand,tBand,aBand,bBand,gBand,hfBand] = bandSignalsFromSeg(seg, fs)
    [nCh, ~] = size(seg);
    dBand  = local_bandpass_rows(seg, fs, [0.4 4.0]);
    tBand  = local_bandpass_rows(seg, fs, [4.0 8.0]);
    aBand  = local_bandpass_rows(seg, fs, [8.0 13.0]);
    bBand  = local_bandpass_rows(seg, fs, [13.0 30.0]);
    gBand  = local_bandpass_rows(seg, fs, [30.0 50.0]);
    hfBand = local_bandpass_rows(seg, fs, [50.0 100.0]);
    if isempty(dBand),  dBand  = NaN(nCh, size(seg,2)); end
    if isempty(tBand),  tBand  = NaN(nCh, size(seg,2)); end
    if isempty(aBand),  aBand  = NaN(nCh, size(seg,2)); end
    if isempty(bBand),  bBand  = NaN(nCh, size(seg,2)); end
    if isempty(gBand),  gBand  = NaN(nCh, size(seg,2)); end
    if isempty(hfBand), hfBand = NaN(nCh, size(seg,2)); end
end

function Y = local_bandpass_rows(seg, fs, bandHz)
    % Stable FFT-domain bandpass used for correlation matrices.
    % The previous direct-form IIR + filtfilt implementation could become
    % ill-conditioned for very low normalized frequencies on MATLAB/macOS,
    % producing floods of "close to singular" warnings and NaN matrices.
    [nCh, nSamp] = size(seg);
    lo = max(0.01, double(bandHz(1)));
    hi = min(double(bandHz(2)), double(fs)/2 - eps);
    Y = NaN(nCh, nSamp);
    if hi <= lo || nSamp < 8 || ~isfinite(fs) || fs <= 0
        return;
    end

    freq = (0:nSamp-1) .* (double(fs) / nSamp);
    freqAbs = min(freq, double(fs) - freq);
    mask = freqAbs >= lo & freqAbs <= hi;
    if ~any(mask)
        return;
    end

    for ch = 1:nCh
        x = double(seg(ch,:));
        good = isfinite(x);
        bad = ~good;
        if sum(good) < 4 || std(x(good), 0, 'omitnan') <= eps
            continue;
        end
        % Fill non-finite samples only so the FFT can run; restore the NaN
        % mask after filtering so bad epochs are omitted from correlations.
        if any(bad)
            medx = median(x(good), 'omitnan');
            x(bad) = medx;
        end
        x = x - mean(x, 'omitnan');
        X = fft(x);
        X(~mask) = 0;
        y = real(ifft(X));
        y(bad) = NaN;
        Y(ch,:) = y(:).';
    end
end

function tf = local_is_day_hour(hr, dayStart, dayEnd)
    hr = mod(double(hr), 24);
    dayStart = mod(double(dayStart), 24);
    dayEnd = mod(double(dayEnd), 24);
    if dayStart == dayEnd
        tf = true;
    elseif dayStart < dayEnd
        tf = (hr >= dayStart) && (hr < dayEnd);
    else
        tf = (hr >= dayStart) || (hr < dayEnd);
    end
end

function C = local_corrcoef_rows(X)
    % Pairwise-safe row correlation. Returns an nCh x nCh matrix and avoids
    % entire-matrix failure when one lead is flat, zeroed by QC, or contains NaNs.
    [nCh, ~] = size(X);
    C = NaN(nCh, nCh);
    for ii = 1:nCh
        xi = double(X(ii,:));
        for jj = ii:nCh
            xj = double(X(jj,:));
            ok = isfinite(xi) & isfinite(xj);
            if sum(ok) < 3
                continue;
            end
            a = xi(ok); b = xj(ok);
            a = a - mean(a, 'omitnan');
            b = b - mean(b, 'omitnan');
            denom = sqrt(sum(a.^2, 'omitnan') * sum(b.^2, 'omitnan'));
            if denom <= eps || ~isfinite(denom)
                continue;
            end
            c = sum(a .* b, 'omitnan') / denom;
            c = max(-1, min(1, c));
            C(ii,jj) = c;
            C(jj,ii) = c;
        end
    end
end
