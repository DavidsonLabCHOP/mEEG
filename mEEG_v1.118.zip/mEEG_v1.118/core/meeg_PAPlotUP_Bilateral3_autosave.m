function h = meeg_PAPlotUP_Bilateral3_autosave(F, dataDayByGroup, dataNightByGroup, groupLabels, groupColors, title1, title2, titleSuffix, regionNamesIn)
% Autosave-only high-frequency overview PSD figure using all groups/regions present.
% Supports legacy 5-region 10-lead datasets and variable-electrode EDF projects.

    if nargin < 8 || isempty(titleSuffix), titleSuffix = ''; end
    if nargin < 9 || isempty(regionNamesIn)
        nR = local_num_regions(dataDayByGroup, dataNightByGroup);
        regionNamesIn = arrayfun(@(k) string(sprintf('Region %d', k)), (1:nR).', 'UniformOutput', true);
    end
    regionNamesIn = string(regionNamesIn(:));
    nRegions = numel(regionNamesIn);
    if nRegions < 1, nRegions = local_num_regions(dataDayByGroup, dataNightByGroup); end
    if nRegions < 1, nRegions = 1; end

    if nRegions == 5 && local_is_canonical_region_set(regionNamesIn)
        regionOrder = [5 2 3 4 1];
        regionNames = local_pretty_names(regionNamesIn(regionOrder));
    else
        regionOrder = 1:nRegions;
        regionNames = local_pretty_names(regionNamesIn(regionOrder));
    end

    HzRan = [13 50];
    G = numel(groupLabels);

    statsDay = cell(1,G);
    statsNight = cell(1,G);
    for g = 1:G
        [statsDay{g}.m, statsDay{g}.se] = local_mean_sem(dataDayByGroup{g}, regionOrder);
        [statsNight{g}.m, statsNight{g}.se] = local_mean_sem(dataNightByGroup{g}, regionOrder);
    end

    win = 11;
    idx = F >= HzRan(1) & F <= HzRan(2);
    F = F(idx);
    statsDay = local_smooth_stats(statsDay, idx, win);
    statsNight = local_smooth_stats(statsNight, idx, win);

    h = gobjects(1,2);
    for cond = 1:2
        if cond == 1
            S = statsDay;
            plotTitle = char(title1);
        else
            S = statsNight;
            plotTitle = char(title2);
        end

        fig = figure('Color',[0.86 0.86 0.86], 'Visible','off', 'Units','normalized', 'Position',[0.03 0.30 0.94 0.38]);
        h(cond) = fig;
        t = tiledlayout(fig, 1, max(1,numel(regionOrder)), 'Padding','compact', 'TileSpacing','compact');

        globalMax = local_global_max(S);
        if isempty(globalMax) || isnan(globalMax) || globalMax <= 0, globalMax = 1; end
        globalMax = globalMax * 1.08;
        if globalMax < 50
            globalMax = max(1, ceil(globalMax/5)*5);
        elseif globalMax < 150
            globalMax = ceil(globalMax/10)*10;
        else
            globalMax = ceil(globalMax/20)*20;
        end

        ax = gobjects(numel(regionOrder),1);
        legendHandles = gobjects(1,G);
        idxBeta  = F >= 13 & F < 30;
        idxGamma = F >= 30 & F <= 50;

        for i = 1:numel(regionOrder)
            ax(i) = nexttile(t);
            hold(ax(i),'on');
            set(ax(i),'Color',[0.83 0.83 0.83]);
            if any(idxBeta),  area(ax(i), F(idxBeta),  ones(sum(idxBeta),1)*globalMax, 'FaceColor','k', 'FaceAlpha',0.12, 'LineStyle','none'); end
            if any(idxGamma), area(ax(i), F(idxGamma), ones(sum(idxGamma),1)*globalMax, 'FaceColor','w', 'FaceAlpha',0.10, 'LineStyle','none'); end

            % Draw all SEM ribbons first, then all mean lines, so the
            % translucent patch for one group never covers another curve.
            for g = 1:G
                M = S{g}.m; SE = S{g}.se;
                if isempty(M) || size(M,1) ~= numel(F) || size(M,2) < i, continue; end
                y = M(:,i); e = SE(:,i);
                if all(~isfinite(y)), continue; end
                meeg_ps_add_sem_ribbon(ax(i), F, y, e, groupColors(g,:));
            end
            for g = 1:G
                M = S{g}.m;
                if isempty(M) || size(M,1) ~= numel(F) || size(M,2) < i, continue; end
                y = M(:,i);
                if all(~isfinite(y)), continue; end
                legendHandles(g) = plot(ax(i), F, y, 'Color',groupColors(g,:), 'LineWidth',2.0, 'DisplayName',char(groupLabels(g)));
            end

            title(ax(i), char(regionNames(i)), 'FontSize',15, 'FontWeight','normal', 'Interpreter','none');
            xlim(ax(i), HzRan); ylim(ax(i), [0 globalMax]);
            xticks(ax(i), [13 30 50]); xticklabels(ax(i), {'13','30','50'});
            yticks(ax(i), [0 globalMax]);
            if i == 1
                ylabel(ax(i), 'Power (\muV^2)', 'FontSize',13, 'FontWeight','normal');
            else
                yticklabels(ax(i), {});
            end
            xlabel(ax(i), 'Frequency (Hz)', 'FontSize',13, 'FontWeight','normal');
            ax(i).FontSize = 12; ax(i).LineWidth = 1.0; ax(i).TickDir = 'out';
            ax(i).TickLength = [0.02 0.02]; ax(i).Layer = 'top'; box(ax(i),'off');
            grid(ax(i),'on'); ax(i).GridColor = [0.92 0.92 0.92]; ax(i).GridAlpha = 0.5;
        end

        ttl = sprintf('Power spectral density, high frequencies - %s', lower(plotTitle));
        if ~isempty(titleSuffix), ttl = sprintf('%s %s', ttl, titleSuffix); end
        title(t, ttl, 'FontSize',20, 'FontWeight','normal');

        valid = isgraphics(legendHandles);
        if any(valid)
            lgd = legend(ax(end), legendHandles(valid), cellstr(groupLabels(valid)), 'Location','northeast');
            lgd.FontSize = 12; lgd.Box = 'on'; lgd.Color = [0.92 0.92 0.92]; lgd.EdgeColor = [0.25 0.25 0.25];
        end
        drawnow;
    end
end


function tf = local_is_canonical_region_set(regionNames)
    vals = lower(regexprep(string(regionNames(:)), '[^a-z0-9]', ''));
    wanted = lower(["auditory";"visual";"hippocampus";"barrel";"motor"]);
    tf = numel(vals) == 5 && all(ismember(wanted, vals));
end

function [m, se] = local_mean_sem(data, regionOrder)
    if isempty(data)
        m = nan(0, numel(regionOrder));
        se = m;
        return;
    end
    data = local_ensure_3d(data);
    nR = size(data,2);
    regionOrder = regionOrder(regionOrder >= 1 & regionOrder <= nR);
    if isempty(regionOrder), regionOrder = 1:nR; end
    data = data(:, regionOrder, :);
    m = mean(data, 3, 'omitnan');
    n = sum(isfinite(data), 3);
    sd = std(data, 0, 3, 'omitnan');
    se = sd ./ sqrt(max(n,1));
    se(n < 2) = NaN;
end

function data = local_ensure_3d(data)
    sz = size(data);
    if numel(sz) > 3
        data = reshape(data, sz(1), sz(2), []);
    elseif numel(sz) < 3
        data = reshape(data, sz(1), sz(2), 1);
    end
end

function S = local_smooth_stats(S, idx, win)
    for k = 1:numel(S)
        if isempty(S{k}) || isempty(S{k}.m), continue; end
        S{k}.m = movmean(S{k}.m(idx,:), win, 1, 'omitnan');
        seRaw = S{k}.se(idx,:);
        seValid = isfinite(seRaw);
        S{k}.se = movmean(seRaw, win, 1, 'omitnan');
        S{k}.se(~seValid) = NaN;
    end
end

function nR = local_num_regions(dayCells, nightCells)
    nR = 0;
    allCells = [dayCells(:); nightCells(:)];
    for k = 1:numel(allCells)
        if ~isempty(allCells{k})
            sz = size(allCells{k});
            if numel(sz) >= 2
                nR = max(nR, sz(2));
            end
        end
    end
end

function names = local_pretty_names(names)
    names = string(names(:)).';
    for k = 1:numel(names)
        s = strrep(strrep(char(names(k)), '_', ' '), '-', ' ');
        s = regexprep(s, '\s+', ' ');
        names(k) = string(strtrim(s));
    end
end

function gmax = local_global_max(S)
    vals = [];
    for k = 1:numel(S)
        if isempty(S{k}) || isempty(S{k}.m), continue; end
        vals = [vals; S{k}.m(:) + S{k}.se(:)]; %#ok<AGROW>
    end
    gmax = max(vals, [], 'omitnan');
end
