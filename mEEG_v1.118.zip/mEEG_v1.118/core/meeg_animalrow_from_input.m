function row = meeg_animalrow_from_input(answ)
% Convert inputdlg answers into a scalar struct with manifest fields.
    row = struct();
    row.MouseID = string(answ{1});
    row.TreatmentGroup = string(answ{2});
    row.Genotype = string(answ{3});
    row.Sex = string(answ{4});
    row.DOB = string(answ{5});
    row.RecordingDate = string(answ{6});
    row.StartTime = string(answ{7});
    row.LitterID = string(answ{8});
    row.Notes = string(answ{9});
end
