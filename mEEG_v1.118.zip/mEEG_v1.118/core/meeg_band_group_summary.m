function [summary, perAnimal] = meeg_band_group_summary(project, includedIdxs, dayStart, dayEnd, opts)
% Create per-animal DN averages and then compute region-level group means/SE
% grouped by TreatmentGroup from the manifest.
%
% Optionally saves CSV (for backwards compatibility):
%   <outdir>/qEEG/_group_summary/band_region_summary.csv
%   <outdir>/qEEG/_group_summary/band_region_per_animal.csv
%
% This version avoids groupsummary() for maximum MATLAB compatibility.

    if nargin < 3, dayStart = 6.5; end
    if nargin < 4, dayEnd = 18.5; end
    if nargin < 5, opts = struct(); end

    writeCsv = true;
    if isfield(opts,'writeCsv')
        writeCsv = logical(opts.writeCsv);
    end

    outGroup = meeg_outdir(project,'qeeg', '_group_summary');
    if writeCsv
        if ~isfolder(outGroup), mkdir(outGroup); end
    end

    perAnimal = meeg_band_region_per_animal_table(project, includedIdxs, dayStart, dayEnd);
    if isempty(perAnimal) || height(perAnimal)==0
        summary = table();
        return;
    end
    if writeCsv
        writetable(perAnimal, fullfile(outGroup, 'band_region_per_animal.csv'));
    end

    % ---- group aggregation (TreatmentGroup × Band × Region) ----
    [GID, TG, BAND, REGION] = findgroups(perAnimal.TreatmentGroup, perAnimal.Band, perAnimal.Region);

    dayMean   = splitapply(@(x) mean(x,'omitnan'), perAnimal.DayAvg, GID);
    dayStd    = splitapply(@(x) std(x,'omitnan'),  perAnimal.DayAvg, GID);
    dayN      = splitapply(@(x) sum(~isnan(x)),     perAnimal.DayAvg, GID);
    daySE     = dayStd ./ sqrt(max(dayN,1));

    nightMean = splitapply(@(x) mean(x,'omitnan'), perAnimal.NightAvg, GID);
    nightStd  = splitapply(@(x) std(x,'omitnan'),  perAnimal.NightAvg, GID);
    nightN    = splitapply(@(x) sum(~isnan(x)),     perAnimal.NightAvg, GID);
    nightSE   = nightStd ./ sqrt(max(nightN,1));

    % N animals (rows) per group (should equal number of animals per treatment)
    nAnimals  = splitapply(@numel, perAnimal.Animal, GID);

    summary = table(TG, BAND, REGION, dayMean, daySE, nightMean, nightSE, nAnimals, dayN, nightN, ...
        'VariableNames', {'TreatmentGroup','Band','Region','DayMean','DaySE','NightMean','NightSE','N','DayN','NightN'});

    if writeCsv
        writetable(summary, fullfile(outGroup, 'band_region_summary.csv'));
    end
end
