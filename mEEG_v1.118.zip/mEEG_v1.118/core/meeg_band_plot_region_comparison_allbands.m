function hFig = meeg_band_plot_region_comparison_allbands(perAnimal, summary, whichTime)
% Figure: 2x3 subplots (bands) of Region Comparison (group bars + per-animal dots).
% Robust for one-region/one-group EDF projects.

    whichTime = lower(string(whichTime));
    if ~(whichTime=="day" || whichTime=="night")
        error('whichTime must be day or night');
    end

    bands = ["delta","theta","alpha","beta","gamma","fastGamma"];
    titleTime = char(whichTime);

    hFig = figure('Color','w','Name',sprintf('Region Comparison (%s)', titleTime));
    t = tiledlayout(hFig, 2, 3, 'TileSpacing','compact', 'Padding','compact');
    title(t, sprintf('Region Comparison (%s)', titleTime));

    for b = 1:numel(bands)
        nexttile(t);
        ax = gca; hold(ax,'on');
        [mu,se,regions,groups,Cg,valCol] = local_build_bar_mats(perAnimal, summary, bands(b), whichTime);

        if isempty(groups) || isempty(regions)
            text(ax, 0.5, 0.5, 'No data', 'Units','normalized', 'HorizontalAlignment','center');
            title(ax, char(bands(b)), 'Interpreter','none');
            axis(ax,'off');
            continue;
        end

        [bh, xPos] = meeg_grouped_bar_manual(ax, mu', Cg);
        bh = bh(:).';
        for gi = 1:numel(groups)
            if gi > size(xPos,2), continue; end
            errorbar(ax, xPos(:,gi), mu(gi,:).', se(gi,:).', 'k', 'LineStyle','none', 'LineWidth', 1);
        end

        % dots (colored by group)
        pa = perAnimal(perAnimal.Band==bands(b), :);
        rng(0);
        for ri = 1:numel(regions)
            for gi = 1:min(numel(groups), numel(bh))
                if gi > size(xPos,2) || ri > size(xPos,1), continue; end
                idx = string(pa.Region)==regions(ri) & string(pa.TreatmentGroup)==groups(gi);
                if ~any(idx), continue; end
                y = pa{idx, valCol};
                x0 = xPos(ri,gi);
                x = x0 + (rand(size(y))-0.5)*0.12;
                scatter(ax, x, y, 22, 'MarkerFaceColor', Cg(gi,:), 'MarkerEdgeColor','k', 'LineWidth', 0.5);
            end
        end

        ax.XTick = 1:numel(regions);
        ax.XTickLabel = cellstr(regions);
        ax.XTickLabelRotation = 30;
        ylabel(ax,'Power');
        title(ax, char(bands(b)), 'Interpreter','none');

        if b==numel(bands)
            legendGroups = groups(1:min(numel(groups), numel(bh)));
            bhLegend = bh(1:numel(legendGroups));
            valid = arrayfun(@(x) isgraphics(x), bhLegend);
            if any(valid)
                legend(ax, bhLegend(valid), cellstr(legendGroups(valid)), 'Location','northeast', 'Interpreter','none');
            end
        end
    end
end

function [mu,se,regions,groups,Cg,valCol] = local_build_bar_mats(perAnimal, summary, bandName, whichTime)
    bandName = lower(string(bandName));
    whichTime = lower(string(whichTime));

    sm = summary(lower(string(summary.Band)) == lower(string(bandName)), :);
    regions = unique(string(sm.Region), 'stable');
    groups  = unique(string(sm.TreatmentGroup), 'stable');
    regions(regions=="") = [];
    groups(groups=="") = [];
    Cg = meeg_get_group_colors(groups);

    if whichTime=="day"
        muCol = 'DayMean'; seCol = 'DaySE'; valCol = 'DayAvg';
    else
        muCol = 'NightMean'; seCol = 'NightSE'; valCol = 'NightAvg';
    end

    mu = nan(numel(groups), numel(regions));
    se = nan(numel(groups), numel(regions));
    for gi = 1:numel(groups)
        for ri = 1:numel(regions)
            idx = string(sm.TreatmentGroup)==groups(gi) & string(sm.Region)==regions(ri);
            if any(idx)
                k = find(idx,1,'first');
                mu(gi,ri) = sm{k, muCol};
                se(gi,ri) = sm{k, seCol};
            end
        end
    end
end
