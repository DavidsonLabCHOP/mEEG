function hFig = meeg_band_plot_region_subplots(perAnimal, summary, whichTime)
% Figure: one subplot per region with bands left-to-right.
% Robust for one-region/one-group EDF projects. Uses up to 5 columns x 2 rows for 10 regions.

    whichTime = lower(string(whichTime));
    if ~(whichTime=="day" || whichTime=="night")
        error('whichTime must be day or night');
    end

    bands = ["delta","theta","alpha","beta","gamma","fastGamma"];
    regions = unique(string(summary.Region), 'stable');
    regions(regions=="") = [];

    titleTime = char(whichTime);
    hFig = figure('Color','w','Name',sprintf('Region Subplots (%s): Bands left-to-right', titleTime));
    nRegions = max(1, numel(regions));
    nCols = min(5, nRegions);
    nRows = max(1, ceil(nRegions / nCols));
    t = tiledlayout(hFig, nRows, nCols, 'TileSpacing','compact', 'Padding','compact');
    title(t, sprintf('Region Subplots (%s): Bands left-to-right', titleTime));

    groups = unique(string(summary.TreatmentGroup), 'stable');
    groups(groups=="") = [];
    Cg = meeg_get_group_colors(groups);

    if whichTime=="day"
        muCol = 'DayMean'; seCol = 'DaySE'; valCol = 'DayAvg';
    else
        muCol = 'NightMean'; seCol = 'NightSE'; valCol = 'NightAvg';
    end

    if isempty(regions) || isempty(groups)
        ax = nexttile(t); axis(ax,'off');
        text(ax, 0.5, 0.5, 'No data', 'Units','normalized', 'HorizontalAlignment','center');
        return;
    end

    for r = 1:numel(regions)
        nexttile(t);
        ax = gca; hold(ax,'on');

        mu = nan(numel(groups), numel(bands));
        se = nan(numel(groups), numel(bands));
        for gi = 1:numel(groups)
            for bi = 1:numel(bands)
                idx = string(summary.TreatmentGroup)==groups(gi) & string(summary.Region)==regions(r) & string(summary.Band)==bands(bi);
                if any(idx)
                    k = find(idx,1,'first');
                    mu(gi,bi) = summary{k, muCol};
                    se(gi,bi) = summary{k, seCol};
                end
            end
        end

        [bh, xPos] = meeg_grouped_bar_manual(ax, mu', Cg);
        bh = bh(:).';

        for gi = 1:numel(groups)
            if gi > size(xPos,2), continue; end
            errorbar(ax, xPos(:,gi), mu(gi,:).', se(gi,:).', 'k', 'LineStyle','none', 'LineWidth', 1);
        end

        pa = perAnimal(string(perAnimal.Region)==regions(r), :);
        rng(0);
        for bi = 1:numel(bands)
            for gi = 1:min(numel(groups), numel(bh))
                if gi > size(xPos,2) || bi > size(xPos,1), continue; end
                idx = string(pa.Band)==bands(bi) & string(pa.TreatmentGroup)==groups(gi);
                if ~any(idx), continue; end
                y = pa{idx, valCol};
                x0 = xPos(bi,gi);
                x = x0 + (rand(size(y))-0.5)*0.12;
                scatter(ax, x, y, 22, 'MarkerFaceColor', Cg(gi,:), 'MarkerEdgeColor','k', 'LineWidth', 0.5);
            end
        end

        ax.XTick = 1:numel(bands);
        ax.XTickLabel = cellstr(bands);
        ax.XTickLabelRotation = 25;
        ylabel(ax,'Power');
        title(ax, char(regions(r)), 'Interpreter','none');

        if r==numel(regions)
            legendGroups = groups(1:min(numel(groups), numel(bh)));
            bhLegend = bh(1:numel(legendGroups));
            valid = arrayfun(@(x) isgraphics(x), bhLegend);
            if any(valid)
                legend(ax, bhLegend(valid), cellstr(legendGroups(valid)), 'Location','northeast', 'Interpreter','none');
            end
        end
    end
end
