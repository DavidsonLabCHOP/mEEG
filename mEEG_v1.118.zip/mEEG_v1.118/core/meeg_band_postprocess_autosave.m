function [summary, perAnimal, paths] = meeg_band_postprocess_autosave(project, includedIdxs, dayStart, dayEnd, opts)
% Post-process band outputs into per-animal and group-summary tables and
% auto-save the key Excel + figures that match the legacy pipeline outputs.
%
% Outputs folder:
%   <outdir>/qEEG/BandAnalysis/
% Files written:
%   BandAnalysis_RegionPerAnimal.xlsx  (sheet: RegionPerAnimal)
%   BandAnalysis_RegionSummary.xlsx    (sheets: RegionSummary, RegionSummary_Day, RegionSummary_Night)
%   RegionComparison_day/night.(png,fig)
%   RegionSubplots_day/night.(png,fig)
%
% opts fields (all optional):
%   outDir   : override output folder
%   saveFig  : true/false (default true)
%   savePNG  : true/false (default true)
%   saveFIG  : true/false (default true)
%   writeFiles : true/false (default true). When false, only builds tables in memory.

    if nargin < 3, dayStart = 6.5; end
    if nargin < 4, dayEnd = 18.5; end
    if nargin < 5, opts = struct(); end

    if ~isfield(opts,'saveFig'), opts.saveFig = true; end
    if ~isfield(opts,'savePNG'), opts.savePNG = true; end
    if ~isfield(opts,'saveFIG'), opts.saveFIG = true; end
    if ~isfield(opts,'writeFiles'), opts.writeFiles = true; end

    outDir = meeg_outdir(project,'qeeg', 'BandAnalysis');
    if isfield(opts,'outDir') && ~isempty(opts.outDir)
        outDir = char(opts.outDir);
    end
    if (opts.writeFiles || opts.saveFig) && ~isfolder(outDir), mkdir(outDir); end

    % ---- compute tables (re-use existing logic) ----
    [summary, perAnimal] = meeg_band_group_summary(project, includedIdxs, dayStart, dayEnd, struct('writeCsv', false));

    paths = struct();
    if isempty(perAnimal) || height(perAnimal)==0
        return;
    end

    paths.outDir = outDir;

    % ---- Write Excel (preferred for downstream use) ----
    perAnimalXlsx = fullfile(outDir, 'BandAnalysis_RegionPerAnimal.xlsx');
    summaryXlsx = fullfile(outDir, 'BandAnalysis_RegionSummary.xlsx');
    if opts.writeFiles
        try
            writetable(perAnimal, perAnimalXlsx, 'Sheet', 'RegionPerAnimal');
        catch
            % fall back to CSV
            writetable(perAnimal, fullfile(outDir,'BandAnalysis_RegionPerAnimal.csv'));
        end

        try
            writetable(summary, summaryXlsx, 'Sheet', 'RegionSummary');
            % Convenience sheets split by time
            dayTbl = summary(:, {'TreatmentGroup','Band','Region','DayMean','DaySE','DayN','N'});
            nightTbl = summary(:, {'TreatmentGroup','Band','Region','NightMean','NightSE','NightN','N'});
            writetable(dayTbl, summaryXlsx, 'Sheet', 'RegionSummary_Day');
            writetable(nightTbl, summaryXlsx, 'Sheet', 'RegionSummary_Night');
        catch
            writetable(summary, fullfile(outDir,'BandAnalysis_RegionSummary.csv'));
        end

        paths.perAnimalXlsx = perAnimalXlsx;
        paths.summaryXlsx = summaryXlsx;
    else
        paths.perAnimalXlsx = '';
        paths.summaryXlsx = '';
    end

    % ---- Auto-save the two "must-have" figures (day + night) ----
    if opts.saveFig
        try
            stamp = datestr(now, 'yyyymmdd_HHMMSS');
            h1 = meeg_band_plot_region_comparison_allbands(perAnimal, summary, 'day');
            h2 = meeg_band_plot_region_comparison_allbands(perAnimal, summary, 'night');
            h3 = meeg_band_plot_region_subplots(perAnimal, summary, 'day');
            h4 = meeg_band_plot_region_subplots(perAnimal, summary, 'night');

            if opts.savePNG
                    meeg_save_png_svg(h1, fullfile(outDir,['NormBandPower_RegionComparison_day_' stamp '.png']),'Resolution',150);
                meeg_save_png_svg(h2, fullfile(outDir,['NormBandPower_RegionComparison_night_' stamp '.png']),'Resolution',150);
                meeg_save_png_svg(h3, fullfile(outDir,['PerRegionNormBandPower_day_' stamp '.png']),'Resolution',150);
                meeg_save_png_svg(h4, fullfile(outDir,['PerRegionNormBandPower_night_' stamp '.png']),'Resolution',150);
            end
            if opts.saveFIG
                savefig(h1, fullfile(outDir,['NormBandPower_RegionComparison_day_' stamp '.fig']));
                savefig(h2, fullfile(outDir,['NormBandPower_RegionComparison_night_' stamp '.fig']));
                savefig(h3, fullfile(outDir,['PerRegionNormBandPower_day_' stamp '.fig']));
                savefig(h4, fullfile(outDir,['PerRegionNormBandPower_night_' stamp '.fig']));
            end
            close(h1); close(h2); close(h3); close(h4);
        catch ME
            warning('Band auto-figure export failed: %s', ME.message);
        end
    end
end
