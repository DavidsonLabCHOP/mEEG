function T = meeg_band_region_per_animal_table(project, includedIdxs, dayStart, dayEnd)
% Build a tidy per-animal table of region-level Day/Night band averages.
% Supports dynamic EDF-assigned region labels as well as legacy 10e layouts.

    if nargin < 3, dayStart = 6.5; end
    if nargin < 4, dayEnd = 18.5; end

    bandNames = ["delta","theta","alpha","beta","gamma","fastGamma"];
    rows = cell(0,13);

    for ii = 1:numel(includedIdxs)
        i = includedIdxs(ii);
        a = project.animals(i);
        prefix = string(a.prefix);

        tg = local_manifest_string(project.manifest,'TreatmentGroup',i);
        mid = local_manifest_string(project.manifest,'MouseID',i);
        geno = local_manifest_string(project.manifest,'Genotype',i);
        sex = local_manifest_string(project.manifest,'Sex',i);
        dob = local_manifest_string(project.manifest,'DOB',i);
        rdate = local_manifest_string(project.manifest,'RecordingDate',i);
        stime = local_manifest_string(project.manifest,'StartTime',i);
        litter = local_manifest_string(project.manifest,'LitterID',i);

        bandsFile = meeg_outdir(project,'qeeg', a.prefix, sprintf('%s_bands.xlsx', a.prefix));
        if ~isfile(bandsFile)
            warning('Missing bands file for %s: %s', prefix, bandsFile);
            continue;
        end
        dnFile = meeg_BandAverageDN(bandsFile, dayStart, dayEnd);

        channelRegions = local_channel_regions(a);

        for b = 1:numel(bandNames)
            try
                A = readmatrix(dnFile, 'Sheet', bandNames(b));
            catch
                continue;
            end
            A(A==0) = NaN;
            if isempty(A), continue; end
            if size(A,2) < 2
                A(:,2) = NaN;
            else
                A = A(:,1:2);
            end
            keepRows = any(isfinite(A), 2);
            A = A(keepRows, :);
            if isempty(A), continue; end
            regs = channelRegions;
            if ~isempty(regs) && numel(regs) >= numel(keepRows)
                regs = regs(keepRows);
            end
            nRows = size(A,1);
            if numel(regs) < nRows
                regs(end+1:nRows,1) = arrayfun(@(k) string(sprintf('Lead %d', k)), numel(regs)+1:nRows).';
            elseif numel(regs) > nRows
                regs = regs(1:nRows);
            end
            uniqRegs = unique(regs, 'stable');
            uniqRegs(uniqRegs=="") = [];
            for r = 1:numel(uniqRegs)
                idx = regs == uniqRegs(r);
                dayVal = mean(A(idx,1), 'omitnan');
                nightVal = mean(A(idx,2), 'omitnan');
                rows(end+1,:) = {tg, mid, prefix, geno, sex, dob, rdate, stime, litter, bandNames(b), char(uniqRegs(r)), dayVal, nightVal}; %#ok<AGROW>
            end
        end
    end

    if isempty(rows)
        T = table('Size',[0 13], 'VariableTypes', [{'string','string','string','string','string','string','string','string','string','string','string','double','double'}]);
        T.Properties.VariableNames = {'TreatmentGroup','MouseID','Animal','Genotype','Sex','DOB','RecordingDate','StartTime','LitterID','Band','Region','DayAvg','NightAvg'};
        return;
    end
    T = cell2table(rows, 'VariableNames', {'TreatmentGroup','MouseID','Animal','Genotype','Sex','DOB','RecordingDate','StartTime','LitterID','Band','Region','DayAvg','NightAvg'});
end

function regs = local_channel_regions(a)
    regs = strings(0,1);
    try
        if isfield(a,'assignedRegionLabels') && ~isempty(a.assignedRegionLabels)
            regs = string(a.assignedRegionLabels(:));
        elseif isfield(a,'fileOrder') && ~isempty(a.fileOrder)
            regs = string(a.fileOrder(:));
        end
    catch
    end
    if isempty(regs)
        regs = strings(0,1);
    end
    for k = 1:numel(regs)
        regs(k) = local_pretty_region(regs(k));
    end
    regs = local_collapse_template_lr_regions(regs);
end

function regs = local_collapse_template_lr_regions(regs)
    regs = string(regs(:));
    if numel(regs) ~= 10
        return;
    end
    [bases, sides, ok] = local_parse_template_bases(regs);
    if ~ok
        return;
    end
    wanted = ["Auditory";"Visual";"Hippocampus";"Barrel";"Motor"];
    hasPairs = true;
    for w = wanted(:)'
        idx = bases == w;
        hasPairs = hasPairs && sum(idx) == 2 && any(sides(idx) == "L") && any(sides(idx) == "R");
    end
    if hasPairs
        regs = bases;
    end
end

function [bases, sides, ok] = local_parse_template_bases(regs)
    bases = strings(size(regs));
    sides = strings(size(regs));
    ok = true;
    for ii = 1:numel(regs)
        s = string(regs(ii));
        tok = regexp(char(s), '^(Auditory|Visual|Hippocampus|Barrel|Motor)\s*\(([LR])\)$', 'tokens', 'once');
        if isempty(tok)
            ok = false;
            return;
        end
        bases(ii) = string(tok{1});
        sides(ii) = string(tok{2});
    end
end

function s = local_manifest_string(M, field, idx)
    s = "";
    try
        if ismember(field, M.Properties.VariableNames)
            s = string(M.(field)(idx));
        end
    catch
    end
end

function r = local_pretty_region(lbl)
    r = meeg_pretty_region_label(lbl);
end
