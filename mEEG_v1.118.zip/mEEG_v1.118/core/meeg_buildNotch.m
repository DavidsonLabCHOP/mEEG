function applyNotch = meeg_buildNotch(fs, f1, f2)
% Build a configurable band-stop filter with designfilt->butter fallback.
% The supplied lower/upper frequencies are used exactly as entered.

    fs = double(fs);
    f1 = double(f1);
    f2 = double(f2);
    if ~all(isfinite([fs f1 f2])) || fs <= 0 || f1 <= 0 || f2 <= f1 || f2 >= fs/2
        error('mEEG:InvalidNotchBand', ...
            'Invalid notch band [%.6g %.6g] Hz for sampling rate %.6g Hz. Require 0 < lower < upper < Nyquist.', ...
            f1, f2, fs);
    end

    try
        filtObj = designfilt('bandstopiir','FilterOrder',2, ...
            'HalfPowerFrequency1',f1,'HalfPowerFrequency2',f2, ...
            'DesignMethod','butter','SampleRate',fs);
        applyNotch = @(x) filter(filtObj, x);
    catch
        [b,a] = butter(2, [f1 f2]/(fs/2), 'stop');
        applyNotch = @(x) filter(b,a,x);
    end
end
