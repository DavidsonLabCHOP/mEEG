function [stack, animalIDs, files, labels] = meeg_coh_collect_group(project, bandName, dayStart, dayEnd, timePoint, groupName, varargin)
% Collect averaged coherence matrices for all included animals in a group.
    includeMask = local_include_mask(project.manifest);
    idx = find(includeMask & strcmp(string(project.manifest.TreatmentGroup), string(groupName)));
    animalIDs = cell(1,numel(idx));
    files = cell(1,numel(idx));
    labels = strings(0,1);

    forcedTargetN = [];
    if ~isempty(varargin) && ~isempty(varargin{1})
        forcedTargetN = varargin{1};
    end

    targetN = forcedTargetN;
    firstFile = '';
    if isempty(targetN)
        for k = 1:numel(idx)
            i = idx(k);
            prefixCandidates = local_prefix_candidates(project, i);
            cohFile = findCohFile(project, prefixCandidates);
            if ~isempty(cohFile) && isfile(cohFile)
                [M0, labels0] = meeg_coh_read_animal_avg(cohFile, bandName, dayStart, dayEnd, 'all');
                if ~isempty(M0)
                    targetN = size(M0,1);
                    labels = string(labels0(:));
                    firstFile = cohFile;
                    break;
                end
            end
        end
    end
    if isempty(targetN)
        targetN = local_nch(project);
        labels = local_default_display_labels(project, targetN);
    elseif numel(labels) ~= targetN
        labels = local_default_display_labels(project, targetN);
    end

    stack = nan(targetN,targetN,numel(idx));
    if ~isempty(firstFile)
        fprintf('[Coherence] Using matrix size %dx%d based on %s\n', targetN, targetN, firstFile);
    end
    for k = 1:numel(idx)
        i = idx(k);
        prefixCandidates = local_prefix_candidates(project, i);
        animalIDs{k} = char(prefixCandidates(1));

        cohFile = findCohFile(project, prefixCandidates);
        files{k} = cohFile;

        if isempty(cohFile) || ~isfile(cohFile)
            fprintf('[Coherence] Missing file for %s (%s)\n', char(groupName), animalIDs{k});
            stack(:,:,k) = nan(targetN,targetN);
            continue;
        end
        [M, labelsThis] = meeg_coh_read_animal_avg(cohFile, bandName, dayStart, dayEnd, timePoint);
        if (~isempty(labelsThis) && isempty(labels)) || numel(labels) ~= targetN
            labels = string(labelsThis(:));
        end
        if ~isequal(size(M,1), targetN) || ~isequal(size(M,2), targetN)
            fprintf('[Coherence] Size mismatch for %s (%s): expected %dx%d, got %dx%d from %s\n', ...
                char(groupName), animalIDs{k}, targetN, targetN, size(M,1), size(M,2), cohFile);
            stack(:,:,k) = nan(targetN,targetN);
            continue;
        end
        stack(:,:,k) = M;
        if ~any(isfinite(stack(:,:,k)), 'all')
            fprintf('[Coherence] File loaded but no finite data for %s (%s): %s [band=%s, time=%s]\n', ...
                char(groupName), animalIDs{k}, cohFile, char(string(bandName)), char(string(timePoint)));
        end
    end
end

function candidates = local_prefix_candidates(project, rowIdx)
    candidates = strings(0,1);
    try
        if isfield(project,'animals') && numel(project.animals) >= rowIdx && isfield(project.animals,'prefix')
            p = string(project.animals(rowIdx).prefix);
            if strlength(p) > 0, candidates(end+1,1) = p; end
        end
    catch
    end
    try
        raw = string(project.manifest.TreatmentGroup(rowIdx)) + "_" + string(project.manifest.MouseID(rowIdx));
        if strlength(raw) > 1, candidates(end+1,1) = raw; end
    catch
    end
    try
        [allPrefixes, ~] = meeg_manifest_get_animal_prefixes(project.manifest(rowIdx,:));
        if ~isempty(allPrefixes), candidates(end+1,1) = string(allPrefixes(1)); end
    catch
    end
    base = candidates;
    for ii = 1:numel(base)
        p = string(base(ii));
        variants = [p; string(matlab.lang.makeValidName(char(p))); replace(p,"-","_"); replace(p," ","_"); replace(replace(p,"-","_")," ","_")];
        candidates = [candidates; variants];
    end
    candidates = candidates(strlength(candidates) > 0);
    [~, ia] = unique(cellstr(candidates), 'stable');
    candidates = candidates(sort(ia));
end

function cohFile = findCohFile(project, prefixCandidates)
    cohFile = '';
    for ii = 1:numel(prefixCandidates)
        prefix = char(prefixCandidates(ii));
        baseDir = meeg_outdir(project,'qeeg', prefix);
        if ~isfolder(baseDir), continue; end

        exactMat = fullfile(baseDir, [prefix '_coh.mat']);
        if isfile(exactMat), cohFile = exactMat; return; end

        d = dir(fullfile(baseDir, '*_coh.mat'));
        if ~isempty(d), cohFile = fullfile(d(1).folder, d(1).name); return; end
        d = dir(fullfile(baseDir, 'Coherence', '*_coh.mat'));
        if ~isempty(d), cohFile = fullfile(d(1).folder, d(1).name); return; end
    end
end

function mask = local_include_mask(M)
    mask = true(height(M),1);
    try
        inc = M.Include;
        if islogical(inc)
            mask = inc;
        elseif isnumeric(inc)
            mask = inc ~= 0;
        else
            incs = lower(strtrim(string(inc)));
            mask = ismember(incs, ["true","1","yes","y"]);
        end
    catch
    end
end

function n = local_nch(project)
    n = 10;
    try
        if isfield(project,'profile') && isfield(project.profile,'channelLabels') && ~isempty(project.profile.channelLabels)
            n = numel(project.profile.channelLabels);
        elseif isfield(project,'profile') && isfield(project.profile,'nChannels') && project.profile.nChannels > 0
            n = project.profile.nChannels;
        end
    catch
    end
end


function labels = local_default_display_labels(project, n)
    canonical10 = {'auditory_R','visual_R','hippocampus_R','barrel_R','motor_R','auditory_L','visual_L','hippocampus_L','barrel_L','motor_L'};
    labels = strings(0,1);
    try
        if ~isempty(project) && isfield(project,'profile') && isfield(project.profile,'channelLabels') && ~isempty(project.profile.channelLabels)
            profLabels = string(project.profile.channelLabels(:));
            if numel(profLabels) == n && ~local_labels_are_generic(profLabels)
                labels = profLabels;
            end
        end
    catch
    end
    if isempty(labels)
        if n == 10
            labels = string(canonical10(:));
        else
            labels = compose('Lead %d', 1:n)';
        end
    end
    for ii = 1:numel(labels)
        labels(ii) = meeg_pretty_region_label(labels(ii));
    end
end

function tf = local_labels_are_generic(labels)
    tf = false;
    try
        s = lower(strtrim(string(labels(:))));
        if isempty(s), tf = true; return; end
        genericSet = lower([compose('r%d', 1:numel(s))'; compose('lead %d', 1:numel(s))'; compose('ch%d', 1:numel(s))']);
        tf = all(ismember(s, genericSet));
    catch
    end
end
