function [f, Y, animalIDs] = meeg_coh_collect_pair_spectra(project, groupName, reg1Name, reg2Name, timePoint)
% Collect coherence spectra for a lead pair across animals in a group.
% Reads <prefix>_cohSpec.mat produced by coherence analysis.
%
% Outputs:
%   f         : 1xF frequency vector
%   Y         : NxF spectra (N animals)
%   animalIDs : Nx1 cellstr

    includeMask = local_include_mask(project.manifest);
    idx = find(includeMask & strcmp(string(project.manifest.TreatmentGroup), string(groupName)));
    animalIDs = cell(0,1);

    f = [];
    Y = [];

    for k = 1:numel(idx)
        i = idx(k);
        prefixCandidates = local_prefix_candidates(project, i);
        animalLabel = char(prefixCandidates(1));

        specFile = findSpecFile(project, prefixCandidates);
        if isempty(specFile) || ~isfile(specFile)
            fprintf('[Coherence Pair] Missing file for %s (%s)\n', char(groupName), animalLabel);
            continue;
        end

        S = load(specFile);
        if ~isfield(S,'CohF') || ~isfield(S,'CohSpecDayAvg') || ~isfield(S,'CohSpecNightAvg')
            fprintf('[Coherence Pair] Invalid cohSpec file for %s (%s): %s\n', char(groupName), animalLabel, specFile);
            continue;
        end

        if isfield(S,'cohLabels')
            regLabels = string(S.cohLabels);
        elseif isfield(S,'region5')
            regLabels = string(S.region5);
        else
            regLabels = string(compose('Ch%d', 1:size(S.CohSpecDayAvg,1)));
        end
        r1 = find(regLabels == string(reg1Name), 1);
        r2 = find(regLabels == string(reg2Name), 1);
        if isempty(r1) || isempty(r2)
            fprintf('[Coherence Pair] Lead labels not found in %s\n', specFile);
            continue;
        end

        if isempty(f)
            f = S.CohF(:)';
        end

        switch lower(char(timePoint))
            case 'day'
                spec = squeeze(S.CohSpecDayAvg(r1,r2,:))';
            case 'night'
                spec = squeeze(S.CohSpecNightAvg(r1,r2,:))';
            otherwise
                spec = mean([squeeze(S.CohSpecDayAvg(r1,r2,:))'; squeeze(S.CohSpecNightAvg(r1,r2,:))'], 1, 'omitnan');
        end

        if isempty(spec) || all(isnan(spec))
            fprintf('[Coherence Pair] No finite spectrum for %s (%s): %s [%s-%s %s]\n', ...
                char(groupName), animalLabel, specFile, char(string(reg1Name)), char(string(reg2Name)), char(string(timePoint)));
            continue;
        end

        animalIDs{end+1,1} = animalLabel; %#ok<AGROW>
        if isempty(Y)
            Y = spec;
        else
            Y = [Y; spec]; %#ok<AGROW>
        end
    end
end

function specFile = findSpecFile(project, prefixCandidates)
    specFile = '';
    for ii = 1:numel(prefixCandidates)
        prefix = char(prefixCandidates(ii));
        baseDir = meeg_outdir(project,'qeeg', prefix);
        if ~isfolder(baseDir), continue; end

        exactMat = fullfile(baseDir, [prefix '_cohSpec.mat']);
        if isfile(exactMat), specFile = exactMat; return; end

        d = dir(fullfile(baseDir, '*_cohSpec.mat'));
        if ~isempty(d)
            specFile = fullfile(d(1).folder, d(1).name);
            return;
        end
        d = dir(fullfile(baseDir, 'Coherence', '*_cohSpec.mat'));
        if ~isempty(d)
            specFile = fullfile(d(1).folder, d(1).name);
            return;
        end
    end
end

function candidates = local_prefix_candidates(project, rowIdx)
    candidates = strings(0,1);
    try
        if isfield(project,'animals') && numel(project.animals) >= rowIdx && isfield(project.animals,'prefix')
            p = string(project.animals(rowIdx).prefix);
            if strlength(p) > 0, candidates(end+1,1) = p; end
        end
    catch
    end
    try
        raw = string(project.manifest.TreatmentGroup(rowIdx)) + "_" + string(project.manifest.MouseID(rowIdx));
        if strlength(raw) > 1, candidates(end+1,1) = raw; end
    catch
    end
    try
        [allPrefixes, ~] = meeg_manifest_get_animal_prefixes(project.manifest(rowIdx,:));
        if ~isempty(allPrefixes), candidates(end+1,1) = string(allPrefixes(1)); end
    catch
    end
    base = candidates;
    for ii = 1:numel(base)
        p = string(base(ii));
        variants = [p; string(matlab.lang.makeValidName(char(p))); replace(p,"-","_"); replace(p," ","_"); replace(replace(p,"-","_")," ","_")];
        candidates = [candidates; variants]; %#ok<AGROW>
    end
    candidates = candidates(strlength(candidates) > 0);
    [~, ia] = unique(cellstr(candidates), 'stable');
    candidates = candidates(sort(ia));
end

function mask = local_include_mask(M)
    mask = true(height(M),1);
    try
        inc = M.Include;
        if islogical(inc)
            mask = inc;
        elseif isnumeric(inc)
            mask = inc ~= 0;
        else
            incs = lower(strtrim(string(inc)));
            mask = ismember(incs, ["true","1","yes","y"]);
        end
    catch
    end
end
