function meeg_coh_plot_matrix(ax, M, modeName, leadLabels, climMax)
    if nargin < 5 || isempty(climMax), climMax = 0.6; end
    if nargin < 4 || isempty(leadLabels)
        leadLabels = local_default_display_labels([], size(M,1));
    end
    leadLabels = cellstr(string(leadLabels(:)'));

    cla(ax);
    n = size(M,1);
    mask = triu(true(n));
    D = M;
    D(mask) = NaN;

    set(ax, 'Color', [0.86 0.90 0.90]);
    hold(ax, 'on');

    switch lower(char(modeName))
        case {'group a','groupa','group b','groupb'}
            imagesc(ax, D, 'AlphaData', ~isnan(D));
            colormap(ax, parula(256));
            caxis(ax, [0 climMax]);
        case {'difference','diff','b-a','bminus a'}
            imagesc(ax, D, 'AlphaData', ~isnan(D));
            colormap(ax, parula(256));
            caxis(ax, [-climMax climMax]);
        case {'p-value','pvalue','p'}
            imagesc(ax, D, 'AlphaData', ~isnan(D));
            cmap = [linspace(0.35,0.85,128)' linspace(0.25,0.85,128)' ones(128,1); ...
                    linspace(0.85,0.78,128)' linspace(0.85,0.78,128)' linspace(0.85,0.78,128)'];
            colormap(ax, cmap);
            caxis(ax, [0 0.8]);
        otherwise
            imagesc(ax, D, 'AlphaData', ~isnan(D));
            colormap(ax, parula(256));
            caxis(ax, [0 climMax]);
    end

    axis(ax, 'image');
    xlim(ax, [0.5 n+0.5]); ylim(ax, [0.5 n+0.5]);
    set(ax, 'YDir', 'normal', 'XTick', 1:n, 'YTick', 1:n, ...
        'XTickLabel', leadLabels, 'YTickLabel', leadLabels, 'Layer', 'top', 'Box', 'on');
    ax.XTickLabelRotation = 90;
    xlabel(ax, 'Electrode / region');
    ylabel(ax, 'Electrode / region');
    for k = 0.5:1:(n+0.5)
        plot(ax, [0.5 n+0.5], [k k], '-', 'Color', [0.25 0.25 0.25], 'LineWidth', 0.8, 'HandleVisibility','off');
        plot(ax, [k k], [0.5 n+0.5], '-', 'Color', [0.25 0.25 0.25], 'LineWidth', 0.8, 'HandleVisibility','off');
    end
    hold(ax, 'off');
    colorbar(ax);
end


function labels = local_default_display_labels(project, n)
    canonical10 = {'auditory_R','visual_R','hippocampus_R','barrel_R','motor_R','auditory_L','visual_L','hippocampus_L','barrel_L','motor_L'};
    labels = strings(0,1);
    try
        if ~isempty(project) && isfield(project,'profile') && isfield(project.profile,'channelLabels') && ~isempty(project.profile.channelLabels)
            profLabels = string(project.profile.channelLabels(:));
            if numel(profLabels) == n && ~local_labels_are_generic(profLabels)
                labels = profLabels;
            end
        end
    catch
    end
    if isempty(labels)
        if n == 10
            labels = string(canonical10(:));
        else
            labels = compose('Lead %d', 1:n)';
        end
    end
end

function tf = local_labels_are_generic(labels)
    tf = false;
    try
        s = lower(strtrim(string(labels(:))));
        if isempty(s), tf = true; return; end
        genericSet = lower([compose('r%d', 1:numel(s))'; compose('lead %d', 1:numel(s))'; compose('ch%d', 1:numel(s))']);
        tf = all(ismember(s, genericSet));
    catch
    end
end
