function fig = meeg_coh_plot_overview(Sin, leadLabels, viewMode, climMax)
    if nargin < 4 || isempty(climMax), climMax = 0.6; end
    if nargin < 3 || isempty(viewMode), viewMode = 'frequency overview'; end
    if nargin < 2 || isempty(leadLabels)
        if iscell(Sin), S1 = Sin{1}; else, S1 = Sin(1); end
        leadLabels = local_default_display_labels([], size(S1.meanA,1));
    end

    viewMode = lower(char(viewMode));
    if iscell(Sin), S = [Sin{:}]; else, S = Sin; end

    if strcmp(viewMode, 'single-band overview')
        S = S(1);
        fig = figure('Color', [0.86 0.86 0.86], 'Units','pixels', 'Position', [50 80 1600 500]);
        t = tiledlayout(fig, 1, 3, 'TileSpacing', 'compact', 'Padding', 'compact');
        mats = {S.meanA, S.meanB, S.diff};
        titles = {char(S.groupA), char(S.groupB), 'Difference'};
        modes = {'Group A','Group B','Difference'};
        for i = 1:3
            ax = nexttile(t);
            meeg_coh_plot_matrix(ax, mats{i}, modes{i}, leadLabels, climMax);
            title(ax, titles{i}, 'Interpreter','none', 'FontSize', 18, 'FontWeight','bold');
        end
        title(t, sprintf('Coherence %s%s', local_band_name(S.bandName), local_cap_time(S.timePoint)), 'FontSize', 30, 'FontWeight', 'normal');
    else
        bands = {'Delta','Theta','Alpha','Beta','Gamma','Fast Gamma'};
        fig = figure('Color', [0.86 0.86 0.86], 'Units','pixels', 'Position', [40 40 2050 1100]);
        t = tiledlayout(fig, 3, 6, 'TileSpacing', 'compact', 'Padding', 'compact');
        rowNames = {char(S(1).groupA), char(S(1).groupB), 'Difference'};
        for i = 1:min(6, numel(S))
            mats = {S(i).meanA, S(i).meanB, S(i).diff};
            modes = {'Group A','Group B','Difference'};
            for r = 1:3
                ax = nexttile(t, (r-1)*6 + i);
                meeg_coh_plot_matrix(ax, mats{r}, modes{r}, leadLabels, climMax);
                if r == 1
                    title(ax, bands{i}, 'FontSize', 16, 'FontWeight', 'bold');
                end
                if i ~= 1
                    ax.YTickLabel = [];
                else
                    ylabel(ax, rowNames{r}, 'FontSize', 14, 'FontWeight', 'bold');
                end
                if r ~= 3
                    ax.XTickLabel = [];
                end
            end
        end
        title(t, sprintf('Coherence%s', local_cap_time(S(1).timePoint)), 'FontSize', 28, 'FontWeight', 'normal');
    end
end

function out = local_cap_time(tp)
    tp = char(tp);
    if isempty(tp)
        out = '';
    else
        out = [upper(tp(1)) tp(2:end)];
    end
end

function out = local_band_name(bn)
    bn = string(bn);
    switch lower(char(bn))
        case 'fastgamma'
            out = 'Fast Gamma';
        otherwise
            s = char(bn);
            out = [upper(s(1)) s(2:end) ' '];
    end
end


function labels = local_default_display_labels(project, n)
    canonical10 = {'auditory_R','visual_R','hippocampus_R','barrel_R','motor_R','auditory_L','visual_L','hippocampus_L','barrel_L','motor_L'};
    labels = strings(0,1);
    try
        if ~isempty(project) && isfield(project,'profile') && isfield(project.profile,'channelLabels') && ~isempty(project.profile.channelLabels)
            profLabels = string(project.profile.channelLabels(:));
            if numel(profLabels) == n && ~local_labels_are_generic(profLabels)
                labels = profLabels;
            end
        end
    catch
    end
    if isempty(labels)
        if n == 10
            labels = string(canonical10(:));
        else
            labels = compose('Lead %d', 1:n)';
        end
    end
end

function tf = local_labels_are_generic(labels)
    tf = false;
    try
        s = lower(strtrim(string(labels(:))));
        if isempty(s), tf = true; return; end
        genericSet = lower([compose('r%d', 1:numel(s))'; compose('lead %d', 1:numel(s))'; compose('ch%d', 1:numel(s))']);
        tf = all(ismember(s, genericSet));
    catch
    end
end
