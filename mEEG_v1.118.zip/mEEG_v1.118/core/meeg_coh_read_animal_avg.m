function [M, labels] = meeg_coh_read_animal_avg(cohMatFile, bandName, dayStart, dayEnd, timePoint)
% Read one animal's coherence mat (<prefix>_coh.mat) and return an averaged coherence matrix.

    labels = strings(0,1);
    if endsWith(string(cohMatFile), '.xlsx', 'IgnoreCase', true)
        warning('Expected a .mat coherence file but got: %s', cohMatFile);
        M = nan(0,0); return;
    end
    S = load(cohMatFile);
    if ~isfield(S,'Coh') || ~isfield(S,'CohHours') || ~isfield(S,'cohBandNames')
        M = nan(0,0); return;
    end
    Coh = S.Coh;
    if isfield(S,'cohLabels') && ~isempty(S.cohLabels)
        labels = string(S.cohLabels(:));
    elseif isfield(S,'channelLabels') && ~isempty(S.channelLabels)
        labels = string(S.channelLabels(:));
    end
    hours = S.CohHours(:)';
    bands = string(S.cohBandNames);
    bandName = string(bandName);
    timePoint = lower(string(timePoint));

    n = size(Coh,2);
    if isempty(n) || n < 1
        M = nan(0,0); return;
    end

    if numel(labels) ~= n
        labels = local_default_display_labels([], n);
    end
    labels = local_pretty_lead_labels(labels);

    bi = find(strcmpi(bands, bandName), 1);
    if isempty(bi), M = nan(n,n); return; end

    if dayStart == 0 && dayEnd == 0
        isDay = true(size(hours));
    else
        isDay = false(size(hours));
        for k = 1:numel(hours)
            hr = hours(k);
            if dayStart < dayEnd
                isDay(k) = (hr >= dayStart) && (hr < dayEnd);
            else
                isDay(k) = (hr >= dayStart) || (hr < dayEnd);
            end
        end
    end

    switch char(timePoint)
        case 'day'
            keep = isDay;
        case 'night'
            keep = ~isDay;
        otherwise
            keep = true(size(isDay));
    end

    if ~any(keep)
        M = nan(n,n); return;
    end

    M = mean(squeeze(Coh(bi,:,:,keep)), 3, 'omitnan');
    % Older/interrupted coherence files can have missing diagonals even when
    % off-diagonal pairs are sparse/NaN. Coherence of a signal with itself is 1;
    % restoring the diagonal prevents valid files from being reported as wholly
    % empty while preserving all off-diagonal analysis values.
    if ~isempty(M) && size(M,1) == size(M,2)
        for ii = 1:size(M,1)
            if ~isfinite(M(ii,ii))
                M(ii,ii) = 1;
            end
        end
    end
end



function labels = local_pretty_lead_labels(labels)
    labels = string(labels(:));
    for ii = 1:numel(labels)
        labels(ii) = meeg_pretty_region_label(labels(ii));
    end
end

function labels = local_default_display_labels(project, n)
    canonical10 = {'auditory_R','visual_R','hippocampus_R','barrel_R','motor_R','auditory_L','visual_L','hippocampus_L','barrel_L','motor_L'};
    labels = strings(0,1);
    try
        if ~isempty(project) && isfield(project,'profile') && isfield(project.profile,'channelLabels') && ~isempty(project.profile.channelLabels)
            profLabels = string(project.profile.channelLabels(:));
            if numel(profLabels) == n && ~local_labels_are_generic(profLabels)
                labels = profLabels;
            end
        end
    catch
    end
    if isempty(labels)
        if n == 10
            labels = string(canonical10(:));
        else
            labels = compose('Lead %d', 1:n)';
        end
    end
end

function tf = local_labels_are_generic(labels)
    tf = false;
    try
        s = lower(strtrim(string(labels(:))));
        if isempty(s), tf = true; return; end
        genericSet = lower([compose('r%d', 1:numel(s))'; compose('lead %d', 1:numel(s))'; compose('ch%d', 1:numel(s))']);
        tf = all(ismember(s, genericSet));
    catch
    end
end
