function [f, CohSpec, pairSegmentCount] = meeg_coherence_legacy_pairwise(signals, sampleMask, fs, nwin, nover, nfft, maxFrequency)
%MEEG_COHERENCE_LEGACY_PAIRWISE Compatibility fallback using mscohere.
% Reproduces the pre-v1.114 pair-by-pair path if the shared-FFT engine cannot
% execute on a particular MATLAB installation or dataset.

    validateattributes(signals, {'numeric'}, {'2d','real'});
    [nLead, nSamples] = size(signals);
    if isempty(sampleMask)
        sampleMask = true(nLead,nSamples);
    else
        sampleMask = logical(sampleMask);
        if ~isequal(size(sampleMask), [nLead,nSamples])
            error('mEEG:CoherenceMaskSize', ...
                'Coherence sample mask must match the signal matrix size.');
        end
    end

    leadAvailable = any(sampleMask,2);
    maxFrequency = min(double(maxFrequency), double(fs)/2);
    f = zeros(0,1);
    CohSpec = nan(0,nLead,nLead);
    pairSegmentCount = zeros(nLead,nLead);

    for ch1 = 1:nLead
        if leadAvailable(ch1)
            pairSegmentCount(ch1,ch1) = 1;
        end
        for ch2 = (ch1+1):nLead
            if ~leadAvailable(ch1) || ~leadAvailable(ch2)
                continue;
            end

            goodSamp = sampleMask(ch1,:) & sampleMask(ch2,:);
            x1 = double(signals(ch1,goodSamp));
            x2 = double(signals(ch2,goodSamp));

            if numel(x1) < nwin*4
                continue;
            end

            [cxy, fAll] = mscohere(x1, x2, hamming(nwin), nover, nfft, fs);
            keep = fAll <= maxFrequency + max(eps(maxFrequency), 1e-12);

            if isempty(f)
                f = fAll(keep);
                CohSpec = nan(numel(f),nLead,nLead);
                for rr = 1:nLead
                    CohSpec(:,rr,rr) = 1;
                end
            end

            cxy = cxy(keep);
            nUse = min(numel(f), numel(cxy));
            CohSpec(1:nUse,ch1,ch2) = cxy(1:nUse);
            CohSpec(1:nUse,ch2,ch1) = cxy(1:nUse);

            hop = max(1, nwin-nover);
            pairSegmentCount(ch1,ch2) = floor((numel(x1)-nwin)/hop) + 1;
            pairSegmentCount(ch2,ch1) = pairSegmentCount(ch1,ch2);
        end
    end
end
