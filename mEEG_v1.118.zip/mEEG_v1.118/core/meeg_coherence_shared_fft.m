function [f, CohSpec, pairSegmentCount, info] = meeg_coherence_shared_fft(signals, sampleMask, fs, nwin, nover, nfft, maxFrequency, batchSegments)
%MEEG_COHERENCE_SHARED_FFT Calculate all pairwise Welch coherence spectra.
%
% v1.114 shared-FFT coherence engine. Every lead is segmented on the same
% original time grid. The windowed FFT for a lead/segment is calculated once
% and reused for every electrode pair.
%
% Inputs
%   signals       lead x sample numeric matrix.
%   sampleMask    lead x sample logical matrix. A Welch segment is valid for
%                 a pair only when the complete segment is valid for both
%                 leads. A row containing no true values is unavailable.
%   fs            Sampling rate (Hz).
%   nwin          Welch window length in samples.
%   nover         Number of overlapping samples.
%   nfft          FFT length.
%   maxFrequency  Highest frequency that must be returned.
%   batchSegments Number of Welch segments processed together (optional).
%
% Outputs
%   f                 Frequency vector.
%   CohSpec           frequency x lead x lead coherence spectra.
%   pairSegmentCount  Number of valid Welch segments used for each pair.
%   info              Diagnostic metadata.
%
% Estimator:
%       |mean(X .* conj(Y))|^2 / (mean(|X|^2) * mean(|Y|^2))
% Constants used by one-sided PSD scaling cancel in this ratio.

    if nargin < 8 || isempty(batchSegments)
        batchSegments = 64;
    end

    validateattributes(signals, {'numeric'}, {'2d','real'});
    validateattributes(fs, {'numeric'}, {'scalar','real','finite','positive'});
    validateattributes(nwin, {'numeric'}, {'scalar','integer','>=',2});
    validateattributes(nover, {'numeric'}, {'scalar','integer','>=',0,'<',nwin});
    validateattributes(nfft, {'numeric'}, {'scalar','integer','>=',nwin});
    validateattributes(maxFrequency, {'numeric'}, {'scalar','real','finite','nonnegative'});
    validateattributes(batchSegments, {'numeric'}, {'scalar','integer','>=',1});

    [nLead, nSamples] = size(signals);
    if isempty(sampleMask)
        sampleMask = true(nLead, nSamples);
    else
        sampleMask = logical(sampleMask);
        if ~isequal(size(sampleMask), [nLead, nSamples])
            error('mEEG:CoherenceMaskSize', ...
                'Coherence sample mask must have the same lead-by-sample size as the signal matrix.');
        end
    end

    leadAvailable = any(sampleMask, 2);
    maxFrequency = min(double(maxFrequency), double(fs)/2);
    fAll = (0:floor(double(nfft)/2)).' .* (double(fs)/double(nfft));
    keepF = fAll <= maxFrequency + max(eps(maxFrequency), 1e-12);
    f = fAll(keepF);
    nF = numel(f);

    CohSpec = nan(nF, nLead, nLead);
    pairSegmentCount = zeros(nLead, nLead);

    info = struct();
    info.Engine = 'shared_fft';
    info.WindowSamples = double(nwin);
    info.OverlapSamples = double(nover);
    info.FFTLength = double(nfft);
    info.BatchSegments = double(batchSegments);
    info.TotalSegments = 0;
    info.MinimumRequiredSegments = 0;
    if isempty(f)
        info.ReturnedFrequencyMax = NaN;
    else
        info.ReturnedFrequencyMax = max(f);
    end

    if nLead < 1 || nSamples < nwin || nF < 1
        return;
    end

    hop = double(nwin - nover);
    starts = 1:hop:(double(nSamples) - double(nwin) + 1);
    nSegments = numel(starts);
    info.TotalSegments = nSegments;

    % Legacy code required at least four coherence-window lengths of usable
    % pair data. Translate that criterion into the corresponding number of
    % Welch segments for the selected overlap.
    minRequiredSegments = floor((4*double(nwin) - double(nwin)) / hop) + 1;
    minRequiredSegments = max(1, minRequiredSegments);
    info.MinimumRequiredSegments = minRequiredSegments;

    if nSegments < 1
        return;
    end

    % Segment validity is calculated with cumulative bad-sample counts so no
    % large sample-by-segment mask matrix is needed.
    validSegment = false(nSegments, nLead);
    stops = starts + double(nwin) - 1;
    for ch = 1:nLead
        if ~leadAvailable(ch)
            continue;
        end
        mask = sampleMask(ch,:).';
        badCum = [0; cumsum(double(~mask))];
        badCount = badCum(stops + 1) - badCum(starts);
        validSegment(:,ch) = (badCount(:) == 0);
    end

    sumCross = complex(zeros(nF, nLead, nLead));
    sumAuto1 = zeros(nF, nLead, nLead);
    sumAuto2 = zeros(nF, nLead, nLead);

    win = hamming(nwin);
    sampleOffsets = (0:(double(nwin)-1)).';

    for firstSeg = 1:double(batchSegments):nSegments
        lastSeg = min(nSegments, firstSeg + double(batchSegments) - 1);
        batchIdx = firstSeg:lastSeg;
        batchStarts = starts(batchIdx);
        nBatch = numel(batchIdx);

        sampleIndex = sampleOffsets + batchStarts;
        Fbatch = complex(zeros(nF, nBatch, nLead));

        for ch = 1:nLead
            if ~leadAvailable(ch) || ~any(validSegment(batchIdx,ch))
                continue;
            end

            segments = reshape(double(signals(ch, sampleIndex(:))), size(sampleIndex));
            segments = segments .* win;
            X = fft(segments, nfft, 1);
            Fbatch(:,:,ch) = X(keepF,:);
        end

        for ch1 = 1:nLead
            if ~leadAvailable(ch1)
                continue;
            end
            for ch2 = (ch1+1):nLead
                if ~leadAvailable(ch2)
                    continue;
                end

                use = validSegment(batchIdx,ch1) & validSegment(batchIdx,ch2);
                if ~any(use)
                    continue;
                end

                X1 = Fbatch(:,use,ch1);
                X2 = Fbatch(:,use,ch2);
                sumCross(:,ch1,ch2) = sumCross(:,ch1,ch2) + sum(X1 .* conj(X2), 2);
                sumAuto1(:,ch1,ch2) = sumAuto1(:,ch1,ch2) + sum(abs(X1).^2, 2);
                sumAuto2(:,ch1,ch2) = sumAuto2(:,ch1,ch2) + sum(abs(X2).^2, 2);
                pairSegmentCount(ch1,ch2) = pairSegmentCount(ch1,ch2) + nnz(use);
            end
        end
    end

    for ch = 1:nLead
        if leadAvailable(ch)
            CohSpec(:,ch,ch) = 1;
            pairSegmentCount(ch,ch) = nnz(validSegment(:,ch));
        end
    end

    for ch1 = 1:nLead
        for ch2 = (ch1+1):nLead
            nPair = pairSegmentCount(ch1,ch2);
            pairSegmentCount(ch2,ch1) = nPair;
            if nPair < minRequiredSegments
                continue;
            end

            denom = sumAuto1(:,ch1,ch2) .* sumAuto2(:,ch1,ch2);
            cxy = abs(sumCross(:,ch1,ch2)).^2 ./ denom;
            cxy(~isfinite(cxy) | denom <= 0) = NaN;
            finiteIdx = isfinite(cxy);
            cxy(finiteIdx) = min(max(real(cxy(finiteIdx)), 0), 1);

            CohSpec(:,ch1,ch2) = cxy;
            CohSpec(:,ch2,ch1) = cxy;
        end
    end
end
