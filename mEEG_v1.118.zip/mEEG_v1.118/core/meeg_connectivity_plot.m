function meeg_connectivity_plot(ax, M, style, opts)
%MEEG_CONNECTIVITY_PLOT Connectivity visualizations for correlation/coherence.
% style: 'Mouse network', 'Circular network', 'Matrix heatmap', '3D mouse brain network'

if nargin < 4 || isempty(opts)
    opts = struct();
elseif ~isstruct(opts)
    error('Fourth input must be an options struct.');
end

if ~isfield(opts,'sourceType'),   opts.sourceType   = 'Correlation'; end
if ~isfield(opts,'labels'),       opts.labels       = {}; end
if ~isfield(opts,'pValue'),       opts.pValue       = []; end
if ~isfield(opts,'filterByP'),    opts.filterByP    = true; end
if ~isfield(opts,'pThresh'),      opts.pThresh      = 0.05; end
if ~isfield(opts,'topN'),         opts.topN         = 12; end
if ~isfield(opts,'showLabels'),   opts.showLabels   = true; end
if ~isfield(opts,'contentName'),  opts.contentName  = 'Difference'; end
if ~isfield(opts,'titleText'),    opts.titleText    = ''; end
if ~isfield(opts,'climMax') || isempty(opts.climMax) || ~isfinite(opts.climMax)
    opts.climMax = 0.5;
end
opts.climMax = min(1, max(0.1, double(opts.climMax)));

try, colorbar(ax,'off'); catch, end
cla(ax);
hold(ax,'on');
axis(ax,'off');

labels = opts.labels;
if isempty(labels)
    labels = cellstr(string(1:size(M,1))');
else
    labels = cellstr(string(labels(:))');
end
n = size(M,1);
if size(M,2) ~= n
    error('Connectivity matrix must be square.');
end

style = string(style);
contentName = string(opts.contentName);
isP = strcmpi(contentName, 'P-Value');
is3D = style == "3D mouse brain network";

if style == "Matrix heatmap"
    axis(ax,'on');
    imagesc(ax, M);
    axis(ax,'image');
    set(ax, 'XTick', 1:n, 'YTick', 1:n, 'XTickLabel', labels, 'YTickLabel', labels, 'TickLabelInterpreter','none');
    xtickangle(ax, 90);
    [cLim, cmap] = local_network_color_settings(M, opts.pValue, contentName, opts.climMax, opts.sourceType);
    colormap(ax, cmap);
    caxis(ax, cLim);
    cb = colorbar(ax);
    cb.Label.String = local_colorbar_label(contentName, opts.sourceType);
    title(ax, opts.titleText, 'Interpreter','none', 'FontSize', 15);
    return;
end

if is3D
    [xyz, labels] = local_brain3d_layout(labels);
    local_draw_brain3d(ax);
    [cLim, cmap] = local_network_color_settings(M, opts.pValue, contentName, opts.climMax, opts.sourceType);
    colormap(ax, cmap); caxis(ax, cLim);
else
    if style == "Mouse network"
        [xy, labels] = local_mouse_layout(labels);
        local_draw_mouse(ax);
    elseif n == 5
        [xy, labels] = local_region_layout(labels, style);
        local_draw_circle(ax);
    else
        [xy, labels] = local_lead_layout(labels, style);
        local_draw_circle(ax);
    end
    [cLim, cmap] = local_network_color_settings(M, opts.pValue, contentName, opts.climMax, opts.sourceType);
    colormap(ax, cmap); caxis(ax, cLim);
end

maskLower = tril(true(n), -1);
[idxI, idxJ] = find(maskLower);
valsAll = M(maskLower);
if ~isempty(opts.pValue)
    pAll = opts.pValue(maskLower);
else
    pAll = nan(size(valsAll));
end
ok = ~isnan(valsAll);
if opts.filterByP && ~isP && ~isempty(opts.pValue)
    ok = ok & ~isnan(pAll) & pAll <= opts.pThresh;
end
idxI = idxI(ok); idxJ = idxJ(ok); vals = valsAll(ok); pvals = pAll(ok);

if isempty(vals)
    title(ax, sprintf('%s\n(no edges passed filters)', opts.titleText), 'Interpreter','none', 'FontSize', 15);
    if is3D
        local_draw_nodes3(ax, xyz, labels, opts.showLabels);
        local_enable_3d_interaction(ax);
    else
        local_draw_nodes(ax, xy, labels, opts.showLabels, style);
    end
    local_add_network_colorbar(ax, cLim, contentName, opts.sourceType);
    return;
end

if isP
    [~, ord] = sort(pvals, 'ascend', 'MissingPlacement','last');
else
    [~, ord] = sort(abs(vals), 'descend', 'MissingPlacement','last');
end
ord = ord(1:min(numel(ord), max(1, round(opts.topN))));
idxI = idxI(ord); idxJ = idxJ(ord); vals = vals(ord); pvals = pvals(ord);

allFiniteVals = valsAll(isfinite(valsAll));
allFiniteP = pAll(isfinite(pAll));

for k = 1:numel(idxI)
    i = idxI(k); j = idxJ(k);
    if is3D
        p1 = xyz(i,:); p2 = xyz(j,:);
    else
        p1 = xy(i,:); p2 = xy(j,:);
    end
    [col, lw] = local_edge_color_linewidth(vals(k), pvals(k), contentName, allFiniteVals, allFiniteP, opts.climMax, opts.sourceType);
    if is3D
        curve = local_edge_curve3(p1, p2);
        plot3(ax, curve(:,1), curve(:,2), curve(:,3), '-', 'Color', col, 'LineWidth', lw);
    elseif style == "Mouse network"
        ctr = [627, 650];
        mid = (p1+p2)/2;
        dirv = mid - ctr;
        nv = norm(dirv);
        if nv < eps
            dirv = [0, -1];
        else
            dirv = dirv / nv;
        end
        lift = 0.18 * norm(p2-p1);
        c1 = mid + lift * dirv;
        tt = linspace(0,1,70)';
        curve = (1-tt).^2 .* p1 + 2*(1-tt).*tt .* c1 + tt.^2 .* p2;
        plot(ax, curve(:,1), curve(:,2), '-', 'Color', col, 'LineWidth', lw);
    else
        plot(ax, [p1(1) p2(1)], [p1(2) p2(2)], '-', 'Color', col, 'LineWidth', lw);
    end
end

if is3D
    local_draw_nodes3(ax, xyz, labels, opts.showLabels);
    title(ax, opts.titleText, 'Interpreter','none', 'FontSize', 15);
    local_add_network_colorbar(ax, cLim, contentName, opts.sourceType);
    local_enable_3d_interaction(ax);
else
    local_draw_nodes(ax, xy, labels, opts.showLabels, style);
    title(ax, opts.titleText, 'Interpreter','none', 'FontSize', 15);
    local_add_network_colorbar(ax, cLim, contentName, opts.sourceType);
end
end

function local_draw_nodes(ax, xy, labels, showLabels, style)
if nargin < 5, style = "Circular network"; end
if style == "Mouse network"
    sz = 220;
else
    sz = 320;
end
scatter(ax, xy(:,1), xy(:,2), sz, 'w', 'filled', 'MarkerEdgeColor', [0.2 0.2 0.2], 'LineWidth', 1.5);
if showLabels
    for i = 1:size(xy,1)
        if style == "Mouse network"
            text(ax, xy(i,1), xy(i,2)-18, labels{i}, 'HorizontalAlignment','center', 'VerticalAlignment','bottom', ...
                'FontSize', 9, 'Interpreter','none', 'BackgroundColor','w', 'Margin', 1);
        else
            text(ax, xy(i,1), xy(i,2), labels{i}, 'HorizontalAlignment','center', 'VerticalAlignment','middle', ...
                'FontSize', 9, 'Interpreter','none');
        end
    end
end
end

function local_draw_nodes3(ax, xyz, labels, showLabels)
scatter3(ax, xyz(:,1), xyz(:,2), xyz(:,3), 150, 'w', 'filled', 'MarkerEdgeColor', [0.15 0.15 0.15], 'LineWidth', 1.3);
if showLabels
    for i = 1:size(xyz,1)
        lbl = string(labels{i});
        xoff = 0.08 * sign(xyz(i,1));
        if abs(xyz(i,1)) < 0.05, xoff = 0; end
        text(ax, xyz(i,1)+xoff, xyz(i,2), xyz(i,3)+0.08, char(lbl), ...
            'HorizontalAlignment','center', 'VerticalAlignment','bottom', ...
            'FontSize', 9, 'Interpreter','none', 'BackgroundColor','none', 'Color',[0.1 0.1 0.1]);
    end
end
end

function [xy, labelsOut] = local_lead_layout(labels, style)
labelsOut = labels;
% try semantic placement for common mEEG labels
xy = nan(numel(labels),2);
for i = 1:numel(labels)
    s = lower(regexprep(labels{i},'[^a-z0-9]',''));
    switch s
        case {'raud','rauditory'}
            xy(i,:) = [-0.82 0.42];
        case {'rvis','rvisual'}
            xy(i,:) = [-0.5 0.78];
        case {'rhip','rhippocampus'}
            xy(i,:) = [-0.32 -0.45];
        case {'rbar','rbarrel'}
            xy(i,:) = [-0.58 0.02];
        case {'rmot','rmotor'}
            xy(i,:) = [-0.22 0.35];
        case {'lmot','lmotor'}
            xy(i,:) = [0.22 0.35];
        case {'lbar','lbarrel'}
            xy(i,:) = [0.58 0.02];
        case {'lhip','lhippocampus'}
            xy(i,:) = [0.32 -0.45];
        case {'lvis','lvisual'}
            xy(i,:) = [0.5 0.78];
        case {'laud','lauditory'}
            xy(i,:) = [0.82 0.42];
    end
end
if any(isnan(xy(:))) || style == "Circular network"
    t = linspace(pi/2, pi/2+2*pi, numel(labels)+1)'; t(end)=[];
    xy = [0.92*cos(t), 0.92*sin(t)];
end
end

function [xy, labelsOut] = local_region_layout(labels, style)
labelsOut = labels;
if style == "Circular network"
    t = linspace(pi/2, pi/2+2*pi, numel(labels)+1)'; t(end)=[];
    xy = [0.82*cos(t), 0.82*sin(t)];
else
    xy = [ ...
        -0.75, 0.20; ... % Auditory
         0.00, 0.78; ... % Visual
         0.00,-0.28; ... % Hippocampus
        -0.48, 0.00; ... % Barrel
         0.48, 0.10];    % Motor
end
end

function [xy, labelsOut] = local_mouse_layout(labels)
labelsIn = cellstr(string(labels(:))');
labelsOut = labelsIn;
xy = nan(numel(labelsIn),2);
for i = 1:numel(labelsIn)
    [base, side] = local_parse_region_and_side(labelsIn{i});
    xy(i,:) = local_mouse_xy(base, side);
end
missing = any(isnan(xy),2);
if any(missing)
    k = sum(missing);
    t = linspace(pi/2, pi/2+2*pi, k+1)'; t(end)=[];
    ctr = [627, 650];
    rad = [260, 240];
    xy(missing,:) = [ctr(1) + rad(1)*cos(t), ctr(2) - rad(2)*sin(t)];
end
end

function xy = local_mouse_xy(base, side)
xy = [NaN NaN];
base = lower(string(base));
side = upper(string(side));
pts = struct();
pts.bregma = [627 580];
pts.motorL = [560 560]; pts.motorR = [694 560];
pts.striatumL = [528 600]; pts.striatumR = [726 600];
pts.barrelL = [505 635]; pts.barrelR = [749 635];
pts.thalamusL = [555 665]; pts.thalamusR = [695 665];
pts.hippocampusL = [548 710]; pts.hippocampusR = [706 710];
pts.auditoryL = [450 710]; pts.auditoryR = [804 710];
pts.visualL = [525 760]; pts.visualR = [730 760];
pts.medialprefrontal = [627 535];
pts.cingulate = [627 610];
pts.parietal = [627 690];
pts.retrosplenial = [627 745];
pts.areaa = [445 540];
pts.areab = [809 540];
pts.areac = [430 670];
pts.aread = [824 670];
pts.areae = [627 790];

switch base
    case 'bregma'
        xy = pts.bregma;
    case 'motor'
        xy = local_pick_lr(pts.motorL, pts.motorR, side);
    case 'striatum'
        xy = local_pick_lr(pts.striatumL, pts.striatumR, side);
    case 'barrel'
        xy = local_pick_lr(pts.barrelL, pts.barrelR, side);
    case 'thalamus'
        xy = local_pick_lr(pts.thalamusL, pts.thalamusR, side);
    case 'hippocampus'
        xy = local_pick_lr(pts.hippocampusL, pts.hippocampusR, side);
    case 'auditory'
        xy = local_pick_lr(pts.auditoryL, pts.auditoryR, side);
    case 'visual'
        xy = local_pick_lr(pts.visualL, pts.visualR, side);
    case 'medialprefrontal'
        xy = pts.medialprefrontal;
    case 'cingulate'
        xy = pts.cingulate;
    case 'parietal'
        xy = pts.parietal;
    case 'retrosplenial'
        xy = pts.retrosplenial;
    case 'areaa'
        xy = pts.areaa;
    case 'areab'
        xy = pts.areab;
    case 'areac'
        xy = pts.areac;
    case 'aread'
        xy = pts.aread;
    case 'areae'
        xy = pts.areae;
end
end

function xy = local_pick_lr(leftPt, rightPt, side)
if side == "L"
    xy = leftPt;
elseif side == "R"
    xy = rightPt;
else
    xy = (leftPt + rightPt) / 2;
end
end

function [xyz, labelsOut] = local_brain3d_layout(labels)
labelsIn = cellstr(string(labels(:))');
labelsOut = labelsIn;
n = numel(labelsIn);
xyz = nan(n,3);

bases = strings(n,1);
sides = strings(n,1);
for i = 1:n
    [bases(i), sides(i)] = local_parse_region_and_side(labelsIn{i});
end

uniqueBases = unique(bases, 'stable');
for b = 1:numel(uniqueBases)
    base = uniqueBases(b);
    if strlength(base) == 0 || base == "unknown"
        continue;
    end
    idx = find(bases == base);
    if numel(idx) == 2 && all(sides(idx) == "")
        sides(idx(1)) = "R";
        sides(idx(2)) = "L";
        labelsOut{idx(1)} = local_make_display_label(labelsOut{idx(1)}, base, "R");
        labelsOut{idx(2)} = local_make_display_label(labelsOut{idx(2)}, base, "L");
    end
end

for i = 1:n
    xyz(i,:) = local_region_xyz(bases(i), sides(i));
end

missing = any(isnan(xyz),2);
if any(missing)
    k = sum(missing);
    phi = (1 + sqrt(5))/2;
    tt = ((0:k-1)' + 0.5) / k;
    z = 0.55 - 0.9*tt;
    theta = 2*pi*(0:k-1)'/phi;
    r = sqrt(max(0,1-z.^2));
    fallback = [0.95*r.*cos(theta), 0.85*(0.15 + 0.75*r.*sin(theta)), 0.45*z + 0.05];
    xyz(missing,:) = fallback;
end
end

function [base, side] = local_parse_region_and_side(lbl)
% Parse anatomical base region and hemisphere side from labels such as:
%   Lbar, Rbar, Lbarrel, Rbarrel, Barrel (L), Barrel (R), Motor (L), etc.
% Important: do NOT infer side from any final letter in the region name itself
% because region names like Barrel and Motor end in L/R and caused side swaps.
raw = lower(strtrim(string(lbl)));
s = lower(regexprep(raw, '[^a-z0-9]', ''));
base = "unknown";
side = "";

% First parse region identity.
if contains(s, "mot") || contains(s, "motor")
    base = "motor";
elseif contains(s, "vis") || contains(s, "visual")
    base = "visual";
elseif contains(s, "aud") || contains(s, "auditory")
    base = "auditory";
elseif contains(s, "bar") || contains(s, "barrel") || contains(s, "somatosensory")
    base = "barrel";
elseif contains(s, "hip") || contains(s, "hippocampus")
    base = "hippocampus";
elseif contains(s, "medialprefrontal") || contains(s, "mpfc")
    base = "medialprefrontal";
elseif contains(s, "retrosplenial") || contains(s, "rsp")
    base = "retrosplenial";
elseif contains(s, "pariet")
    base = "parietal";
elseif contains(s, "cing")
    base = "cingulate";
elseif contains(s, "thal")
    base = "thalamus";
elseif contains(s, "stri")
    base = "striatum";
elseif contains(s, "bregma")
    base = "bregma";
elseif contains(s, "areaa")
    base = "areaa";
elseif contains(s, "areab")
    base = "areab";
elseif contains(s, "areac")
    base = "areac";
elseif contains(s, "aread")
    base = "aread";
elseif contains(s, "areae")
    base = "areae";
end

% Then parse hemisphere explicitly.
% Parentheses / words / separated side tokens.
if contains(raw, "left") || ~isempty(regexp(char(raw), '(^|[^a-z])l([^a-z]|$)', 'once'))
    side = "L";
elseif contains(raw, "right") || ~isempty(regexp(char(raw), '(^|[^a-z])r([^a-z]|$)', 'once'))
    side = "R";
end

% Compact mEEG labels with side prefix: Lbar/Rbar, Laud/Raud, etc.
if side == ""
    if startsWith(s, "l") && strlength(s) > 1
        side = "L";
    elseif startsWith(s, "r") && strlength(s) > 1
        side = "R";
    end
end
end

function out = local_make_display_label(lbl, base, side)
lbls = string(lbl);
low = lower(lbls);
if strlength(lbls) > 0 && (contains(low, "left") || contains(low, "right") || startsWith(low, "l") || startsWith(low, "r") || endsWith(low, "l") || endsWith(low, "r"))
    out = char(lbls);
    return;
end
pretty = string(base);
pretty = replace(pretty, "medialprefrontal", "mPFC");
pretty = replace(pretty, "retrosplenial", "RSP");
out = sprintf('%s (%s)', char(pretty), char(side));
end

function xyz = local_region_xyz(base, side)
xyz = [NaN NaN NaN];
base = lower(string(base));
side = upper(string(side));

switch base
    case "medialprefrontal"
        y = -0.7600; z = 0.3400; dx = 0.1000;
    case "motor"
        y = -0.6400; z = 0.4000; dx = 0.3000;
    case "cingulate"
        y = -0.5200; z = 0.3000; dx = 0.1600;
    case "striatum"
        y = -0.3000; z = 0.1800; dx = 0.4800;
    case "barrel"
        y = -0.0400; z = 0.4000; dx = 0.7400;
    case "thalamus"
        y = -0.0400; z = 0.1200; dx = 0.1200;
    case "hippocampus"
        y = 0.1200; z = 0.3400; dx = 0.3000;
    case "parietal"
        y = 0.2200; z = 0.4600; dx = 0.6400;
    case "auditory"
        y = 0.2800; z = 0.2400; dx = 0.9200;
    case "visual"
        y = 0.5000; z = 0.5400; dx = 0.4800;
    case "retrosplenial"
        y = 0.5000; z = 0.5800; dx = 0.1200;
    case "areaa"
        xyz = [-0.88, 0.56, 0.10]; return;
    case "areab"
        xyz = [ 0.88, 0.56, 0.10]; return;
    case "areac"
        xyz = [-0.88,-0.10, 0.02]; return;
    case "aread"
        xyz = [ 0.88,-0.10, 0.02]; return;
    case "areae"
        xyz = [ 0.00,-0.62,-0.04]; return;
    otherwise
        return;
end

if side == "L"
    x = -dx;
elseif side == "R"
    x = dx;
else
    x = 0;
end
xyz = [x, y, z];
end

function local_draw_mouse(ax)
img = local_mouse_background();
image(ax, [1 size(img,2)], [1 size(img,1)], img);
set(ax, 'YDir', 'reverse');
axis(ax, 'image');
axis(ax, [1 size(img,2) 1 size(img,1)]);
end

function img = local_mouse_background()
persistent cachedImg
if isempty(cachedImg)
    thisFile = mfilename('fullpath');
    coreDir = fileparts(thisFile);
    rootDir = fileparts(coreDir);
    imgPath = fullfile(rootDir, 'assets', 'connectivity_mouse_head_blank.png');
    cachedImg = imread(imgPath);
end
img = cachedImg;
end

function local_draw_circle(ax)
th = linspace(0,2*pi,300);
plot(ax, 0.97*cos(th), 0.97*sin(th), '-', 'Color', [0.6 0.6 0.6], 'LineWidth', 1.2);
axis(ax, [-1.15 1.15 -1.15 1.15]);
end

function local_draw_brain3d(ax)
mesh = local_load_brain_mesh();
if mesh.valid
    p = patch(ax, 'Faces', mesh.faces, 'Vertices', mesh.vertices, ...
        'FaceColor', [0.82 0.82 0.82], 'EdgeColor', 'none', 'FaceAlpha', 0.24, ...
        'AmbientStrength', 0.35, 'DiffuseStrength', 0.75, 'SpecularStrength', 0.08);
    %#ok<NASGU>
    plot3(ax, [0 0], [1.18 -1.18], [0.02 0.02], ':', 'Color', [0.55 0.55 0.55], 'LineWidth', 1.0);
    camlight(ax, 'headlight');
    camlight(ax, 'right');
    lighting(ax, 'gouraud');
    material(ax, 'dull');
    axis(ax, 'equal');
    limx = max(abs(mesh.vertices(:,1))); limy = max(abs(mesh.vertices(:,2))); limz = max(abs(mesh.vertices(:,3)));
    axis(ax, 1.25*[-limx limx -limy limy -limz limz]);
else
    [x1,y1,z1] = ellipsoid(0,0,0,1.00,1.24,0.72,36);
    surf(ax, x1, y1, z1, 'FaceColor', [0.92 0.88 0.82], 'EdgeColor', 'none', 'FaceAlpha', 0.20);
    [x2,y2,z2] = ellipsoid(0,-1.03,-0.03,0.45,0.34,0.30,24);
    surf(ax, x2, y2, z2, 'FaceColor', [0.90 0.85 0.80], 'EdgeColor', 'none', 'FaceAlpha', 0.18);
    plot3(ax, [0 0], [1.12 -1.15], [0.02 0.02], ':', 'Color', [0.55 0.55 0.55], 'LineWidth', 1.0);
    camlight(ax, 'headlight');
    lighting(ax, 'gouraud');
    axis(ax, 'equal');
    axis(ax, [-1.70 1.70 -1.45 1.08 -0.85 0.85]);
end
try, set(ax, 'Projection', 'perspective'); catch, end
view(ax, [24 22]);
grid(ax, 'off');
set(ax, 'Visible','off');
end

function mesh = local_load_brain_mesh()
persistent cachedMesh
if ~isempty(cachedMesh)
    mesh = cachedMesh;
    return;
end
mesh = struct('valid', false, 'vertices', [], 'faces', [], 'colors', []);
try
    thisFile = mfilename('fullpath');
    coreDir = fileparts(thisFile);
    rootDir = fileparts(coreDir);
    matPath = fullfile(rootDir, 'assets', 'davidson1_mouse_brain_mesh.mat');
    if ~isfile(matPath)
        cachedMesh = mesh;
        return;
    end
    S = load(matPath);
    if ~isfield(S,'vertices') || ~isfield(S,'faces')
        cachedMesh = mesh;
        return;
    end
    V = double(S.vertices);
    F = double(S.faces);
    if isempty(V) || isempty(F)
        cachedMesh = mesh;
        return;
    end
    if min(F(:)) == 0
        F = F + 1;
    end
    % Datoviz mesh axes are approximately [AP, DV, ML]. Reorder to mEEG coordinates [ML, AP, DV].
    V = [-V(:,3), V(:,1), -V(:,2)];
    ctr = (min(V,[],1) + max(V,[],1)) / 2;
    V = V - ctr;
    vr = max(V,[],1) - min(V,[],1);
    targetRange = [2.00 2.48 1.44]; % match prior stylized brain extents approximately
    sf = min(targetRange ./ max(vr, eps));
    if ~isfinite(sf) || sf <= 0
        sf = 1;
    end
    V = V * sf;
    C = [];
    if isfield(S,'vertex_color') && size(S.vertex_color,2) >= 3
        C = double(S.vertex_color(:,1:3));
    elseif isfield(S,'vertex_color_original') && size(S.vertex_color_original,2) >= 3
        C = double(S.vertex_color_original(:,1:3));
        if max(C(:)) > 1, C = C / 255; end
    end
    if ~isempty(C)
        C = max(0, min(1, C));
    end
    mesh = struct('valid', true, 'vertices', V, 'faces', F, 'colors', C);
catch
    % keep invalid and fall back to placeholder geometry
end
cachedMesh = mesh;
end

function curve = local_edge_curve3(p1, p2)
t = linspace(0,1,90)';
mid = (p1+p2)/2;
d = norm(p2-p1);
up = [0 0 1];
lift = 0.12 + 0.18*d;
ctrl = mid + lift*up + 0.05*[0, sign(mid(2)+eps), 0];
curve = (1-t).^2 .* p1 + 2*(1-t).*t .* ctrl + t.^2 .* p2;
end

function [cLim, cmap] = local_network_color_settings(M, P, contentName, climMax, sourceType)
% Use parula (blue-to-yellow) with metric-appropriate limits:
%   Correlation: symmetric around zero for all views.
%   Coherence Group A/B: 0 to the user-selected maximum because
%       magnitude-squared coherence cannot be negative.
%   Coherence Difference: symmetric because A-B can be negative.
if nargin < 4 || isempty(climMax) || ~isfinite(climMax)
    climMax = 0.5;
end
if nargin < 5 || isempty(sourceType)
    sourceType = 'Correlation';
end
climMax = min(1, max(0.1, double(climMax)));
if nargin < 2 || isempty(P), P = []; end

if strcmpi(contentName,'P-Value')
    cmap = flipud(gray(256));
    if isempty(P)
        lo = 0; hi = 0.2;
    else
        pvals = P(tril(true(size(P,1)),-1));
        pvals = pvals(isfinite(pvals));
        lo = 0; hi = max([0.2; pvals(:)]);
    end
    if ~isfinite(hi) || hi <= lo, hi = lo + 0.2; end
    cLim = [lo hi];
else
    cmap = parula(256);
    isCoherence = strcmpi(sourceType,'Coherence');
    isDifference = strcmpi(contentName,'Difference');
    if isCoherence && ~isDifference
        cLim = [0 climMax];
    else
        cLim = [-climMax climMax];
    end
end
end

function [col, lw] = local_edge_color_linewidth(val, pval, contentName, allVals, allP, climMax, sourceType)
if nargin < 4 || isempty(allVals), allVals = val; end
if nargin < 5 || isempty(allP), allP = pval; end
if nargin < 6 || isempty(climMax) || ~isfinite(climMax), climMax = 0.5; end
if nargin < 7 || isempty(sourceType), sourceType = 'Correlation'; end
climMax = min(1, max(0.1, double(climMax)));

if strcmpi(contentName,'P-Value')
    pvals = allP(isfinite(allP));
    if isempty(pvals)
        lo = 0; hi = 0.2;
    else
        lo = 0; hi = max([0.2; pvals(:)]);
    end
    if ~isfinite(hi) || hi <= lo, hi = lo + 0.2; end
    t = min(1,max(0,(pval-lo)/(hi-lo)));
    cmap = flipud(gray(256));
    ii = max(1,min(256,round(1+t*255)));
    col = cmap(ii,:);
    lw = 0.8 + 2.8*(1-t);
else
    isCoherence = strcmpi(sourceType,'Coherence');
    isDifference = strcmpi(contentName,'Difference');
    if isCoherence && ~isDifference
        % Magnitude-squared coherence is bounded from 0 to 1.
        t = min(1,max(0,val/climMax));
        strength = min(1,max(0,val/climMax));
    else
        % Correlation and between-group differences are signed.
        t = min(1,max(0,(val + climMax)/(2*climMax)));
        strength = min(1,abs(val)/climMax);
    end
    cmap = parula(256);
    ii = max(1,min(256,round(1+t*255)));
    col = cmap(ii,:);
    lw = 1.0 + 3.0*strength;
end
end

function local_add_network_colorbar(ax, cLim, contentName, sourceType)
try, colorbar(ax,'off'); catch, end
cb = colorbar(ax);
cb.Label.String = local_colorbar_label(contentName, sourceType);
if nargin >= 2 && ~isempty(cLim)
    caxis(ax, cLim);
end
end

function lbl = local_colorbar_label(contentName, sourceType)
if strcmpi(contentName,'Difference')
    lbl = sprintf('%s difference', sourceType);
elseif strcmpi(contentName,'P-Value')
    lbl = 'P-value';
else
    lbl = sourceType;
end
end

function local_enable_3d_interaction(ax)
try
    rotate3d(ancestor(ax,'figure'),'on');
catch
end
end

function c = local_diverging_color(v, vmax)
if nargin < 2 || isempty(vmax) || vmax <= 0, vmax = 1; end
v = max(-vmax, min(vmax, v));
t = (v + vmax) / (2*vmax);
cmap = local_bwr(256);
ii = max(1,min(256,round(1+t*255)));
c = cmap(ii,:);
end

function cmap = local_bwr(n)
if nargin < 1, n = 256; end
half = floor(n/2);
r1 = linspace(0,1,half)';
g1 = linspace(0,1,half)';
b1 = ones(half,1);
r2 = ones(n-half,1);
g2 = linspace(1,0,n-half)';
b2 = linspace(1,0,n-half)';
cmap = [r1 g1 b1; r2 g2 b2];
end
