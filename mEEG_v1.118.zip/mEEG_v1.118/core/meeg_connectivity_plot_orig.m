function meeg_connectivity_plot(ax, M, style, opts)
%MEEG_CONNECTIVITY_PLOT Fancy connectivity visualizations for correlation/coherence.
% style: 'Mouse network', 'Circular network', 'Matrix heatmap'

arguments
    ax
    M double
    style
    opts.sourceType char = 'Correlation'
    opts.labels cell = {}
    opts.pValue double = []
    opts.filterByP logical = true
    opts.pThresh double = 0.05
    opts.topN double = 12
    opts.showLabels logical = true
    opts.contentName char = 'Difference'
    opts.titleText char = ''
end

cla(ax);
hold(ax,'on');
axis(ax,'off');

labels = opts.labels;
if isempty(labels)
    labels = cellstr(string(1:size(M,1))');
end
n = size(M,1);
if size(M,2) ~= n
    error('Connectivity matrix must be square.');
end

style = string(style);
contentName = string(opts.contentName);
isP = strcmpi(contentName, 'P-Value');

if style == "Matrix heatmap"
    axis(ax,'on');
    imagesc(ax, M);
    axis(ax,'image');
    set(ax, 'XTick', 1:n, 'YTick', 1:n, 'XTickLabel', labels, 'YTickLabel', labels, 'TickLabelInterpreter','none');
    xtickangle(ax, 90);
    finiteVals = M(isfinite(M));
    if isP
        colormap(ax, flipud(gray(256)));
        hi = 0.2; if ~isempty(finiteVals), hi = max(hi, max(finiteVals)); end
        caxis(ax, [0 hi]);
    elseif strcmpi(contentName,'Difference')
        lim = 1; if ~isempty(finiteVals), lim = max(abs(finiteVals)); end; if isempty(lim) || ~isfinite(lim) || lim==0, lim=1; end
        colormap(ax, local_bwr(256));
        caxis(ax, [-lim lim]);
    else
        colormap(ax, parula(256));
        if isempty(finiteVals)
            lo = 0; hi = 1;
        else
            lo = min(finiteVals); hi = max(finiteVals);
        end
        if ~isfinite(lo), lo = 0; end
        if ~isfinite(hi) || hi<=lo, hi = lo + 1; end
        caxis(ax, [lo hi]);
    end
    colorbar(ax);
    title(ax, opts.titleText, 'Interpreter','none', 'FontSize', 15);
    return;
end

if n == 5
    [xy, labels] = local_region_layout(labels, style);
else
    [xy, labels] = local_lead_layout(labels, style);
end

% draw base schematic
if style == "Mouse network"
    local_draw_mouse(ax, n);
else
    local_draw_circle(ax);
end

% build edge list from lower triangle
[idxI, idxJ] = find(tril(true(n), -1));
vals = arrayfun(@(k) M(idxI(k), idxJ(k)), 1:numel(idxI))';
if ~isempty(opts.pValue)
    pvals = arrayfun(@(k) opts.pValue(idxI(k), idxJ(k)), 1:numel(idxI))';
else
    pvals = nan(size(vals));
end
ok = ~isnan(vals);
if opts.filterByP && ~isP && ~isempty(opts.pValue)
    ok = ok & ~isnan(pvals) & pvals <= opts.pThresh;
end
idxI = idxI(ok); idxJ = idxJ(ok); vals = vals(ok); pvals = pvals(ok);

if isempty(vals)
    title(ax, sprintf('%s\n(no edges passed filters)', opts.titleText), 'Interpreter','none', 'FontSize', 15);
    local_draw_nodes(ax, xy, labels, opts.showLabels);
    return;
end

if isP
    score = -log10(max(pvals, 1e-6));
    [~, ord] = sort(pvals, 'ascend', 'MissingPlacement','last');
else
    score = abs(vals);
    [~, ord] = sort(score, 'descend', 'MissingPlacement','last');
end
ord = ord(1:min(numel(ord), max(1, round(opts.topN))));
idxI = idxI(ord); idxJ = idxJ(ord); vals = vals(ord); pvals = pvals(ord); score = score(ord);

if isP
    smin = min(score); smax = max(score);
    if ~isfinite(smin), smin = 0; end
    if ~isfinite(smax) || smax <= smin, smax = smin + 1; end
else
    smax = max(score); if ~isfinite(smax) || smax==0, smax = 1; end
end

for k = 1:numel(idxI)
    i = idxI(k); j = idxJ(k);
    p1 = xy(i,:); p2 = xy(j,:);
    if isP
        t = (score(k)-smin)/(smax-smin);
        col = [0.2+0.6*t, 0.2, 0.8-0.6*t];
        lw = 0.8 + 2.4*t;
    elseif strcmpi(contentName,'Difference')
        vmax = max(abs(vals)); if ~isfinite(vmax) || vmax==0, vmax=1; end
        col = local_diverging_color(vals(k), vmax);
        lw = 1 + 3*(abs(vals(k))/vmax);
    else
        vmax = max(vals); vmin = min(vals);
        if ~isfinite(vmin), vmin = 0; end
        if ~isfinite(vmax) || vmax<=vmin, vmax = vmin + 1; end
        t = (vals(k)-vmin)/(vmax-vmin);
        cmap = parula(256); ii = max(1,min(256,round(1+t*255))); col = cmap(ii,:);
        lw = 1 + 3*t;
    end
    if style == "Mouse network"
        ctr = [0, 0.1];
        mid = (p1+p2)/2;
        curv = 0.18 * sign(p1(1)-p2(1) + 0.01);
        c1 = mid + [curv, 0.12] + 0.12*(mid-ctr);
        tt = linspace(0,1,70)';
        curve = (1-tt).^2 .* p1 + 2*(1-tt).*tt .* c1 + tt.^2 .* p2;
        plot(ax, curve(:,1), curve(:,2), '-', 'Color', col, 'LineWidth', lw);
    else
        plot(ax, [p1(1) p2(1)], [p1(2) p2(2)], '-', 'Color', col, 'LineWidth', lw);
    end
end

local_draw_nodes(ax, xy, labels, opts.showLabels);
title(ax, opts.titleText, 'Interpreter','none', 'FontSize', 15);
end

function local_draw_nodes(ax, xy, labels, showLabels)
scatter(ax, xy(:,1), xy(:,2), 320, 'w', 'filled', 'MarkerEdgeColor', [0.2 0.2 0.2], 'LineWidth', 1.5);
if showLabels
    for i = 1:size(xy,1)
        text(ax, xy(i,1), xy(i,2), labels{i}, 'HorizontalAlignment','center', 'VerticalAlignment','middle', 'FontSize', 9, 'Interpreter','none');
    end
end
end

function [xy, labelsOut] = local_lead_layout(labels, style)
labelsOut = labels;
% try semantic placement for common mEEG labels
xy = nan(numel(labels),2);
for i = 1:numel(labels)
    s = lower(regexprep(labels{i},'[^a-z0-9]',''));
    switch s
        case {'raud','rauditory'}
            xy(i,:) = [-0.82 0.42];
        case {'rvis','rvisual'}
            xy(i,:) = [-0.5 0.78];
        case {'rhip','rhippocampus'}
            xy(i,:) = [-0.32 -0.45];
        case {'rbar','rbarrel'}
            xy(i,:) = [-0.58 0.02];
        case {'rmot','rmotor'}
            xy(i,:) = [-0.22 0.35];
        case {'lmot','lmotor'}
            xy(i,:) = [0.22 0.35];
        case {'lbar','lbarrel'}
            xy(i,:) = [0.58 0.02];
        case {'lhip','lhippocampus'}
            xy(i,:) = [0.32 -0.45];
        case {'lvis','lvisual'}
            xy(i,:) = [0.5 0.78];
        case {'laud','lauditory'}
            xy(i,:) = [0.82 0.42];
    end
end
if any(isnan(xy(:))) || style == "Circular network"
    t = linspace(pi/2, pi/2+2*pi, numel(labels)+1)'; t(end)=[];
    xy = [0.92*cos(t), 0.92*sin(t)];
end
end

function [xy, labelsOut] = local_region_layout(labels, style)
labelsOut = labels;
if style == "Circular network"
    t = linspace(pi/2, pi/2+2*pi, numel(labels)+1)'; t(end)=[];
    xy = [0.82*cos(t), 0.82*sin(t)];
else
    xy = [ ...
        -0.75, 0.20; ... % Auditory
         0.00, 0.78; ... % Visual
         0.00,-0.28; ... % Hippocampus
        -0.48, 0.00; ... % Barrel
         0.48, 0.10];    % Motor
end
end

function local_draw_mouse(ax, n)
th = linspace(0,2*pi,300);
headX = 0.95*cos(th); headY = 1.08*sin(th) + 0.05;
patch(ax, headX, headY, [0.96 0.92 0.82], 'EdgeColor', [0.25 0.2 0.18], 'LineWidth', 1.8, 'FaceAlpha', 0.9);
patch(ax, -0.62+0.24*cos(th), 1.0+0.24*sin(th), [0.92 0.82 0.82], 'EdgeColor', [0.35 0.25 0.25], 'LineWidth', 1);
patch(ax,  0.62+0.24*cos(th), 1.0+0.24*sin(th), [0.92 0.82 0.82], 'EdgeColor', [0.35 0.25 0.25], 'LineWidth', 1);
plot(ax, [0 -0.05 0 0.05 0], [1.12 1.27 1.18 1.27 1.12], '-', 'Color', [0.25 0.2 0.18], 'LineWidth', 1.6);
plot(ax, [-0.18 0 0.18], [0.92 0.99 0.92], '.', 'Color', [0.3 0.2 0.2], 'MarkerSize', 10);
axis(ax, [-1.2 1.2 -1.15 1.45]);
if n <= 5
    plot(ax, [-0.2 0.2], [0.63 0.63], ':', 'Color', [0.7 0.7 0.7]);
end
end

function local_draw_circle(ax)
th = linspace(0,2*pi,300);
plot(ax, 0.97*cos(th), 0.97*sin(th), '-', 'Color', [0.6 0.6 0.6], 'LineWidth', 1.2);
axis(ax, [-1.15 1.15 -1.15 1.15]);
end

function c = local_diverging_color(v, vmax)
if v >= 0
    t = min(1, abs(v)/vmax);
    c = [1.0, 0.3+0.5*(1-t), 0.3+0.5*(1-t)];
else
    t = min(1, abs(v)/vmax);
    c = [0.3+0.5*(1-t), 0.45+0.45*(1-t), 1.0];
end
end

function cmap = local_bwr(n)
if nargin<1, n=256; end
x = linspace(-1,1,n)';
r = max(0,x);
b = max(0,-x);
g = 1-abs(x);
cmap = [r+g, g, b+g];
cmap = min(cmap,1);
end
