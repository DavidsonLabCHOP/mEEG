function [stack, animalIDs, files, labels] = meeg_corr_collect_group(project, bandName, dayStart, dayEnd, timePoint, groupName, varargin)
% Collect averaged correlation matrices for all included animals in a group.
% Robust to variable-electrode EDF projects and older projects whose saved
% *_corr.xlsx matrix size does not match project.profile.channelLabels.

    includeMask = local_include_mask(project.manifest);
    idx = find(includeMask & strcmp(string(project.manifest.TreatmentGroup), string(groupName)));
    animalIDs = cell(1,numel(idx));
    files = cell(1,numel(idx));
    labels = strings(0,1);

    forcedTargetN = [];
    if ~isempty(varargin) && ~isempty(varargin{1})
        forcedTargetN = varargin{1};
    end

    targetN = forcedTargetN;
    firstFile = '';
    if isempty(targetN)
        for k = 1:numel(idx)
            i = idx(k);
            prefixCandidates = local_prefix_candidates(project, i);
            corrFile = findCorrFile(project, prefixCandidates);
            if ~isempty(corrFile) && isfile(corrFile)
                M0 = meeg_corr_read_animal_avg(corrFile, bandName, dayStart, dayEnd, 'all');
                if ~isempty(M0) && ndims(M0) == 2 && size(M0,1) == size(M0,2) && size(M0,1) > 0
                    targetN = size(M0,1);
                    firstFile = corrFile;
                    labels = local_labels_for_animal(project, i, targetN);
                    break;
                end
            end
        end
    end
    if isempty(targetN)
        targetN = local_nch(project);
    end
    if isempty(labels) || numel(labels) ~= targetN
        labels = local_default_display_labels(project, targetN);
    end

    stack = nan(targetN,targetN,numel(idx));
    if ~isempty(firstFile)
        fprintf('[Correlation] Using matrix size %dx%d based on %s\n', targetN, targetN, firstFile);
    end

    for k = 1:numel(idx)
        i = idx(k);
        prefixCandidates = local_prefix_candidates(project, i);
        animalIDs{k} = char(prefixCandidates(1));

        corrFile = findCorrFile(project, prefixCandidates);
        files{k} = corrFile;

        if isempty(corrFile) || ~isfile(corrFile)
            stack(:,:,k) = nan(targetN,targetN);
            continue;
        end
        M = meeg_corr_read_animal_avg(corrFile, bandName, dayStart, dayEnd, timePoint);
        if ~isequal(size(M,1), targetN) || ~isequal(size(M,2), targetN)
            fprintf('[Correlation] Size mismatch for %s (%s): expected %dx%d, got %dx%d from %s\n', ...
                char(groupName), animalIDs{k}, targetN, targetN, size(M,1), size(M,2), corrFile);
            stack(:,:,k) = nan(targetN,targetN);
            continue;
        end
        stack(:,:,k) = M;
    end
end

function candidates = local_prefix_candidates(project, rowIdx)
    candidates = strings(0,1);

    try
        if isfield(project,'animals') && numel(project.animals) >= rowIdx && isfield(project.animals,'prefix')
            p = string(project.animals(rowIdx).prefix);
            if strlength(p) > 0
                candidates(end+1,1) = p; %#ok<AGROW>
            end
        end
    catch
    end

    try
        tg = string(project.manifest.TreatmentGroup(rowIdx));
        id = string(project.manifest.MouseID(rowIdx));
        raw = tg + "_" + id;
        if strlength(raw) > 1
            candidates(end+1,1) = raw; %#ok<AGROW>
        end
    catch
    end

    try
        [allPrefixes, ~] = meeg_manifest_get_animal_prefixes(project.manifest(rowIdx,:));
        if ~isempty(allPrefixes)
            candidates(end+1,1) = string(allPrefixes(1)); %#ok<AGROW>
        end
    catch
    end

    base = candidates;
    for ii = 1:numel(base)
        p = string(base(ii));
        variants = [p; string(matlab.lang.makeValidName(char(p))); ...
                    replace(p,"-","_"); replace(p," ","_"); replace(replace(p,"-","_")," ","_")];
        candidates = [candidates; variants]; %#ok<AGROW>
    end

    candidates = candidates(strlength(candidates) > 0);
    [~, ia] = unique(cellstr(candidates), 'stable');
    candidates = candidates(sort(ia));
end

function corrFile = findCorrFile(project, prefixCandidates)
    corrFile = '';

    for ii = 1:numel(prefixCandidates)
        prefix = char(prefixCandidates(ii));
        baseDir = meeg_outdir(project,'qeeg', prefix);
        if ~isfolder(baseDir), continue; end

        d = dir(fullfile(baseDir, '*_corr.xlsx'));
        if ~isempty(d)
            corrFile = fullfile(d(1).folder, d(1).name);
            return;
        end
        d = dir(fullfile(baseDir, 'Correlation', '*_corr.xlsx'));
        if ~isempty(d)
            corrFile = fullfile(d(1).folder, d(1).name);
            return;
        end
    end

    try
        qroot = meeg_outdir(project,'qeeg');
        if ~isfolder(qroot), return; end

        dirs = dir(qroot);
        dirs = dirs([dirs.isdir]);
        dirNames = string({dirs.name});
        dirNames = dirNames(~ismember(dirNames, [".",".."]));

        for ii = 1:numel(prefixCandidates)
            p = string(prefixCandidates(ii));
            normP = lower(regexprep(char(p), '[^a-zA-Z0-9]', ''));
            for jj = 1:numel(dirNames)
                dn = dirNames(jj);
                normD = lower(regexprep(char(dn), '[^a-zA-Z0-9]', ''));
                if strcmp(normP, normD)
                    d = dir(fullfile(qroot, char(dn), '*_corr.xlsx'));
                    if ~isempty(d)
                        corrFile = fullfile(d(1).folder, d(1).name);
                        return;
                    end
                    d = dir(fullfile(qroot, char(dn), 'Correlation', '*_corr.xlsx'));
                    if ~isempty(d)
                        corrFile = fullfile(d(1).folder, d(1).name);
                        return;
                    end
                end
            end
        end
    catch
    end
end

function mask = local_include_mask(M)
    mask = true(height(M),1);
    try
        inc = M.Include;
        if islogical(inc)
            mask = inc;
        elseif isnumeric(inc)
            mask = inc ~= 0;
        else
            incs = lower(strtrim(string(inc)));
            mask = ismember(incs, ["true","1","yes","y"]);
        end
    catch
    end
end

function n = local_nch(project)
    n = 10;
    try
        if isfield(project,'profile') && isfield(project.profile,'channelLabels') && ~isempty(project.profile.channelLabels)
            n = numel(project.profile.channelLabels);
        elseif isfield(project,'profile') && isfield(project.profile,'nChannels') && project.profile.nChannels > 0
            n = project.profile.nChannels;
        end
    catch
    end
end

function labels = local_labels_for_animal(project, rowIdx, n)
    labels = strings(0,1);
    try
        if isfield(project,'animals') && numel(project.animals) >= rowIdx
            a = project.animals(rowIdx);
            if isfield(a,'fileOrder') && numel(a.fileOrder) == n
                labels = string(a.fileOrder(:));
            elseif isfield(a,'assignedLabels') && numel(a.assignedLabels) == n
                labels = string(a.assignedLabels(:));
            end
        end
    catch
    end
    if numel(labels) ~= n
        labels = local_default_display_labels(project, n);
    end
    labels = local_pretty_lead_labels(labels);
end

function labels = local_default_display_labels(project, n)
    canonical10 = {'auditory_R','visual_R','hippocampus_R','barrel_R','motor_R','auditory_L','visual_L','hippocampus_L','barrel_L','motor_L'};
    labels = strings(0,1);
    try
        if ~isempty(project) && isfield(project,'profile') && isfield(project.profile,'channelLabels') && ~isempty(project.profile.channelLabels)
            profLabels = string(project.profile.channelLabels(:));
            if numel(profLabels) == n && ~local_labels_are_generic(profLabels)
                labels = profLabels;
            end
        end
    catch
    end
    if isempty(labels)
        if n == 10
            labels = string(canonical10(:));
        else
            labels = compose('Lead %d', 1:n)';
        end
    end
    labels = local_pretty_lead_labels(labels);
end

function labels = local_pretty_lead_labels(labels)
    labels = string(labels(:));
    for ii = 1:numel(labels)
        labels(ii) = meeg_pretty_region_label(labels(ii));
    end
end

function tf = local_labels_are_generic(labels)
    tf = false;
    try
        s = lower(strtrim(string(labels(:))));
        if isempty(s), tf = true; return; end
        genericSet = lower([compose('r%d', 1:numel(s))'; compose('lead %d', 1:numel(s))'; compose('ch%d', 1:numel(s))']);
        tf = all(ismember(s, genericSet));
    catch
    end
end
