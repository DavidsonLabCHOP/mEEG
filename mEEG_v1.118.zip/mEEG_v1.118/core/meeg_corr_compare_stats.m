function S = meeg_corr_compare_stats(project, bandName, dayStart, dayEnd, timePoint, groupA, groupB)
% Compute correlation summary matrices and per-edge p-values for two groups.
% Uses the actual shared matrix size from saved *_corr.xlsx outputs, so
% variable-electrode EDF projects do not get forced into a stale 10x10 layout.

    targetN = local_pick_shared_target_size(project, bandName, dayStart, dayEnd, groupA, groupB);
    [stackA, animalIDsA, filesA, labelsA] = meeg_corr_collect_group(project, bandName, dayStart, dayEnd, timePoint, groupA, targetN);
    [stackB, animalIDsB, filesB, labelsB] = meeg_corr_collect_group(project, bandName, dayStart, dayEnd, timePoint, groupB, targetN);

    S = struct();
    S.groupA = char(groupA);
    S.groupB = char(groupB);
    S.bandName = char(bandName);
    S.timePoint = char(timePoint);
    S.dayStart = dayStart;
    S.dayEnd = dayEnd;
    S.stackA = stackA;
    S.stackB = stackB;
    S.animalIDsA = animalIDsA;
    S.animalIDsB = animalIDsB;
    S.filesA = filesA;
    S.filesB = filesB;
    if ~isempty(labelsA)
        S.labels = cellstr(labelsA(:));
    elseif ~isempty(labelsB)
        S.labels = cellstr(labelsB(:));
    else
        S.labels = cellstr(local_default_display_labels(project, size(stackA,1)));
    end
    S.meanA = mean(stackA, 3, 'omitnan');
    S.meanB = mean(stackB, 3, 'omitnan');
    S.diff = S.meanB - S.meanA;
    S.pValue = nan(size(S.meanA));
    S.nA = zeros(size(S.meanA));
    S.nB = zeros(size(S.meanA));

    nCh = size(S.meanA,1);
    for i = 1:nCh
        for j = 1:nCh
            xa = squeeze(stackA(i,j,:));
            xb = squeeze(stackB(i,j,:));
            xa = xa(~isnan(xa));
            xb = xb(~isnan(xb));
            S.nA(i,j) = numel(xa);
            S.nB(i,j) = numel(xb);
            if numel(xa) >= 2 && numel(xb) >= 2
                try
                    [~, p] = ttest2(xa, xb, 'Vartype', 'unequal');
                catch
                    p = local_welch_pvalue(xa, xb);
                end
                S.pValue(i,j) = p;
            end
        end
    end

    S.edgeTable = local_make_edge_table(S);
end

function targetN = local_pick_shared_target_size(project, bandName, dayStart, dayEnd, groupA, groupB)
    sizesA = local_group_sizes(project, bandName, dayStart, dayEnd, groupA);
    sizesB = local_group_sizes(project, bandName, dayStart, dayEnd, groupB);
    common = intersect(sizesA, sizesB);
    if ~isempty(common)
        targetN = local_best_size_from_pool([sizesA(:); sizesB(:)], common);
    elseif ~isempty([sizesA(:); sizesB(:)])
        targetN = local_best_size_from_pool([sizesA(:); sizesB(:)], unique([sizesA(:); sizesB(:)]));
    else
        targetN = [];
    end
end

function sizes = local_group_sizes(project, bandName, dayStart, dayEnd, groupName)
    includeMask = local_include_mask(project.manifest);
    idx = find(includeMask & strcmp(string(project.manifest.TreatmentGroup), string(groupName)));
    sizes = [];
    for k = 1:numel(idx)
        prefixCandidates = local_prefix_candidates(project, idx(k));
        corrFile = findCorrFile(project, prefixCandidates);
        if ~isempty(corrFile) && isfile(corrFile)
            M0 = meeg_corr_read_animal_avg(corrFile, bandName, dayStart, dayEnd, 'all');
            if ~isempty(M0) && ndims(M0) == 2 && size(M0,1) == size(M0,2) && size(M0,1) > 0
                sizes(end+1,1) = size(M0,1); %#ok<AGROW>
            end
        end
    end
end

function targetN = local_best_size_from_pool(allSizes, allowedSizes)
    allowedSizes = allowedSizes(:)';
    counts = zeros(size(allowedSizes));
    for i = 1:numel(allowedSizes)
        counts(i) = sum(allSizes == allowedSizes(i));
    end
    [~, ord] = sortrows([counts(:), -allowedSizes(:)], [-1, -2]);
    targetN = allowedSizes(ord(1));
end

function candidates = local_prefix_candidates(project, rowIdx)
    candidates = strings(0,1);
    try
        if isfield(project,'animals') && numel(project.animals) >= rowIdx && isfield(project.animals,'prefix')
            p = string(project.animals(rowIdx).prefix);
            if strlength(p) > 0, candidates(end+1,1) = p; end
        end
    catch
    end
    try
        raw = string(project.manifest.TreatmentGroup(rowIdx)) + "_" + string(project.manifest.MouseID(rowIdx));
        if strlength(raw) > 1, candidates(end+1,1) = raw; end
    catch
    end
    try
        [allPrefixes, ~] = meeg_manifest_get_animal_prefixes(project.manifest(rowIdx,:));
        if ~isempty(allPrefixes), candidates(end+1,1) = string(allPrefixes(1)); end
    catch
    end
    base = candidates;
    for ii = 1:numel(base)
        p = string(base(ii));
        variants = [p; string(matlab.lang.makeValidName(char(p))); replace(p,"-","_"); replace(p," ","_"); replace(replace(p,"-","_")," ","_")];
        candidates = [candidates; variants]; %#ok<AGROW>
    end
    candidates = candidates(strlength(candidates) > 0);
    [~, ia] = unique(cellstr(candidates), 'stable');
    candidates = candidates(sort(ia));
end

function corrFile = findCorrFile(project, prefixCandidates)
    corrFile = '';
    for ii = 1:numel(prefixCandidates)
        prefix = char(prefixCandidates(ii));
        baseDir = meeg_outdir(project,'qeeg', prefix);
        if ~isfolder(baseDir), continue; end
        d = dir(fullfile(baseDir, '*_corr.xlsx'));
        if ~isempty(d), corrFile = fullfile(d(1).folder, d(1).name); return; end
        d = dir(fullfile(baseDir, 'Correlation', '*_corr.xlsx'));
        if ~isempty(d), corrFile = fullfile(d(1).folder, d(1).name); return; end
    end

    % Fallback for projects loaded after label/prefix sanitization changed.
    try
        qroot = meeg_outdir(project,'qeeg');
        if ~isfolder(qroot), return; end
        dirs = dir(qroot);
        dirs = dirs([dirs.isdir]);
        dirNames = string({dirs.name});
        dirNames = dirNames(~ismember(dirNames, [".",".."]));
        for ii = 1:numel(prefixCandidates)
            p = string(prefixCandidates(ii));
            normP = lower(regexprep(char(p), '[^a-zA-Z0-9]', ''));
            for jj = 1:numel(dirNames)
                dn = dirNames(jj);
                normD = lower(regexprep(char(dn), '[^a-zA-Z0-9]', ''));
                if strcmp(normP, normD)
                    d = dir(fullfile(qroot, char(dn), '*_corr.xlsx'));
                    if ~isempty(d), corrFile = fullfile(d(1).folder, d(1).name); return; end
                    d = dir(fullfile(qroot, char(dn), 'Correlation', '*_corr.xlsx'));
                    if ~isempty(d), corrFile = fullfile(d(1).folder, d(1).name); return; end
                end
            end
        end
    catch
    end
end

function mask = local_include_mask(M)
    mask = true(height(M),1);
    try
        inc = M.Include;
        if islogical(inc)
            mask = inc;
        elseif isnumeric(inc)
            mask = inc ~= 0;
        else
            incs = lower(strtrim(string(inc)));
            mask = ismember(incs, ["true","1","yes","y"]);
        end
    catch
    end
end

function T = local_make_edge_table(S)
    nCh = size(S.meanA,1);
    rows = cell(0,8);
    for i = 2:nCh
        for j = 1:(i-1)
            rows(end+1,:) = {i, j, S.meanA(i,j), S.meanB(i,j), S.diff(i,j), S.pValue(i,j), S.nA(i,j), S.nB(i,j)}; %#ok<AGROW>
        end
    end
    T = cell2table(rows, 'VariableNames', ...
        {'RowLeadIdx','ColLeadIdx','GroupA_Mean','GroupB_Mean','Difference_BminusA','PValue','N_GroupA','N_GroupB'});
end

function p = local_welch_pvalue(xa, xb)
    ma = mean(xa); mb = mean(xb);
    va = var(xa);  vb = var(xb);
    na = numel(xa); nb = numel(xb);
    se = sqrt(va/na + vb/nb);
    if ~isfinite(se) || se <= 0
        p = NaN; return;
    end
    t = (ma - mb) / se;
    df_num = (va/na + vb/nb)^2;
    df_den = ((va/na)^2)/(na-1) + ((vb/nb)^2)/(nb-1);
    if df_den <= 0
        p = NaN; return;
    end
    df = df_num / df_den;
    p = 2 * (1 - tcdf(abs(t), df));
end

function labels = local_default_display_labels(project, n)
    canonical10 = {'auditory_R','visual_R','hippocampus_R','barrel_R','motor_R','auditory_L','visual_L','hippocampus_L','barrel_L','motor_L'};
    labels = strings(0,1);
    try
        if ~isempty(project) && isfield(project,'profile') && isfield(project.profile,'channelLabels') && ~isempty(project.profile.channelLabels)
            profLabels = string(project.profile.channelLabels(:));
            if numel(profLabels) == n && ~local_labels_are_generic(profLabels)
                labels = profLabels;
            end
        end
    catch
    end
    if isempty(labels)
        if n == 10
            labels = string(canonical10(:));
        else
            labels = compose('Lead %d', 1:n)';
        end
    end
    for ii = 1:numel(labels)
        labels(ii) = meeg_pretty_region_label(labels(ii));
    end
end

function tf = local_labels_are_generic(labels)
    tf = false;
    try
        s = lower(strtrim(string(labels(:))));
        if isempty(s), tf = true; return; end
        genericSet = lower([compose('r%d', 1:numel(s))'; compose('lead %d', 1:numel(s))'; compose('ch%d', 1:numel(s))']);
        tf = all(ismember(s, genericSet));
    catch
    end
end
