function meeg_corr_plot_matrix(ax, M, modeName, leadLabels, climMax)
% Plot one correlation-style matrix on a supplied axes.
    if nargin < 5 || isempty(climMax), climMax = 0.5; end
    if nargin < 4 || isempty(leadLabels)
        leadLabels = compose('Ch%d', 1:size(M,1));
    end
    leadLabels = cellstr(string(leadLabels(:)'));

    cla(ax);
    n = size(M,1);
    mask = triu(true(n));
    D = M;
    D(mask) = NaN;

    set(ax, 'Color', [0.86 0.90 0.90]);
    hold(ax, 'on');

    switch lower(char(modeName))
        case {'group a','groupa','group b','groupb'}
            imagesc(ax, D, 'AlphaData', ~isnan(D));
            colormap(ax, parula(256));
            % Correlation can be positive or negative. Use the same
            % symmetric limits as Connectivity so the same matrix has the
            % same color meaning in both subtabs.
            caxis(ax, [-climMax climMax]);
        case {'difference','diff','b-a','bminus a'}
            imagesc(ax, D, 'AlphaData', ~isnan(D));
            colormap(ax, parula(256));
            caxis(ax, [-climMax climMax]);
        case {'p-value','pvalue','p'}
            imagesc(ax, D, 'AlphaData', ~isnan(D));
            cmap = [linspace(0.35,0.85,128)' linspace(0.25,0.85,128)' ones(128,1); ...
                    linspace(0.85,0.78,128)' linspace(0.85,0.78,128)' linspace(0.85,0.78,128)'];
            colormap(ax, cmap);
            caxis(ax, [0 0.8]);
        otherwise
            imagesc(ax, D, 'AlphaData', ~isnan(D));
            colormap(ax, parula(256));
            caxis(ax, [-climMax climMax]);
    end

    axis(ax, 'image');
    xlim(ax, [0.5 n+0.5]); ylim(ax, [0.5 n+0.5]);
    set(ax, 'YDir', 'normal', 'XTick', 1:n, 'YTick', 1:n, ...
        'XTickLabel', leadLabels, 'YTickLabel', leadLabels, 'Layer', 'top', 'Box', 'on');
    ax.XTickLabelRotation = 90;
    xlabel(ax, 'Electrode / region');
    ylabel(ax, 'Electrode / region');
    for k = 0.5:1:(n+0.5)
        plot(ax, [0.5 n+0.5], [k k], '-', 'Color', [0.25 0.25 0.25], 'LineWidth', 0.8, 'HandleVisibility','off');
        plot(ax, [k k], [0.5 n+0.5], '-', 'Color', [0.25 0.25 0.25], 'LineWidth', 0.8, 'HandleVisibility','off');
    end
    hold(ax, 'off');
    colorbar(ax);
end
