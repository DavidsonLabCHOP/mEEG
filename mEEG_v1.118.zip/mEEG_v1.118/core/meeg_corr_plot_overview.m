function fig = meeg_corr_plot_overview(Sin, leadLabels, viewMode, climMax)
% Create an amplitude or frequency overview figure.
% Sin can be a single stats struct (amplitude) or a 1x6 struct array (frequency).
    if nargin < 4 || isempty(climMax), climMax = 0.5; end
    if nargin < 3 || isempty(viewMode), viewMode = 'frequency overview'; end
    if nargin < 2 || isempty(leadLabels)
        if numel(Sin) >= 1
            leadLabels = compose('Ch%d', 1:size(Sin(1).meanA,1));
        else
            leadLabels = {};
        end
    end

    viewMode = lower(char(viewMode));
    if strcmp(viewMode, 'amplitude overview')
        S = Sin(1);
        fig = figure('Color', [0.86 0.86 0.86], 'Units','pixels', 'Position', [50 80 1600 500]);
        t = tiledlayout(fig, 1, 3, 'TileSpacing', 'compact', 'Padding', 'compact');
        mats = {S.meanA, S.meanB, S.diff};
        titles = {char(S.groupA), char(S.groupB), 'Difference'};
        modes = {'Group A','Group B','Difference'};
        for i = 1:3
            ax = nexttile(t);
            meeg_corr_plot_matrix(ax, mats{i}, modes{i}, leadLabels, climMax);
            title(ax, titles{i}, 'Interpreter','none', 'FontSize', 20, 'FontWeight','bold');
        end
        title(t, sprintf('Amplitude%s', local_cap_time(S.timePoint)), 'FontSize', 34, 'FontWeight', 'normal');
    else
        bands = {'Delta','Theta','Alpha','Beta','Gamma','Fast Gamma'};
        S = Sin;
        fig = figure('Color', [0.86 0.86 0.86], 'Units','pixels', 'Position', [40 40 2050 1100]);
        t = tiledlayout(fig, 3, 6, 'TileSpacing', 'compact', 'Padding', 'compact');
        rowNames = {char(S(1).groupA), char(S(1).groupB), 'Difference'};
        for i = 1:min(6, numel(S))
            mats = {S(i).meanA, S(i).meanB, S(i).diff};
            modes = {'Group A','Group B','Difference'};
            for r = 1:3
                ax = nexttile(t, (r-1)*6 + i);
                meeg_corr_plot_matrix(ax, mats{r}, modes{r}, leadLabels, climMax);
                if r == 1
                    title(ax, bands{i}, 'FontSize', 16, 'FontWeight', 'bold');
                end
                if i ~= 1
                    ax.YTickLabel = [];
                else
                    ylabel(ax, rowNames{r}, 'FontSize', 14, 'FontWeight', 'bold');
                end
                if r ~= 3
                    ax.XTickLabel = [];
                end
            end
        end
        title(t, sprintf('Frequency%s', local_cap_time(S(1).timePoint)), 'FontSize', 28, 'FontWeight', 'normal');
    end
end

function out = local_cap_time(tp)
    tp = char(tp);
    if isempty(tp)
        out = '';
    else
        out = [upper(tp(1)) tp(2:end)];
    end
end
