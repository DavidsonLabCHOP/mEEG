function M = meeg_corr_read_animal_avg(corrXlsx, bandName, dayStart, dayEnd, timePoint)
% Read one animal's correlation output (<prefix>_corr.xlsx) and return an averaged NxN matrix.

    if nargin < 5 || isempty(timePoint), timePoint = 'all'; end
    bandName = char(bandName);
    timePoint = lower(char(timePoint));

    A = readmatrix(corrXlsx, 'Sheet', bandName);
    if isempty(A) || size(A,1) < 2
        M = nan(0,0);
        return;
    end

    n = size(A,1) - 1;
    if n < 1 || size(A,2) < n
        M = nan(max(n,0), max(n,0));
        return;
    end

    header = A(1,:);
    values = A(2:end,:);

    nBlocks = floor(size(values,2) / n);
    if nBlocks < 1
        M = nan(n,n);
        return;
    end

    keep = false(1, nBlocks);
    for b = 1:nBlocks
        c0 = (b-1)*n + 1;
        hr = header(c0);
        if isnan(hr), continue; end
        isDay = isInDay(hr, dayStart, dayEnd);
        switch timePoint
            case 'day'
                keep(b) = isDay;
            case 'night'
                keep(b) = ~isDay;
            otherwise
                keep(b) = true;
        end
    end

    idx = find(keep);
    if isempty(idx)
        M = nan(n,n);
        return;
    end

    stack = nan(n,n,numel(idx));
    for k = 1:numel(idx)
        b = idx(k);
        cols = (b-1)*n + (1:n);
        stack(:,:,k) = values(:, cols);
    end

    M = mean(stack, 3, 'omitnan');

    function tf = isInDay(hr, d0, d1)
        if d0 == 0 && d1 == 0
            tf = true;
        elseif d0 < d1
            tf = (hr >= d0) & (hr < d1);
        else
            tf = (hr >= d0) | (hr < d1);
        end
    end
end
