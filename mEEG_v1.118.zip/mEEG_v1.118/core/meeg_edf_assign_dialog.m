function cfg = meeg_edf_assign_dialog(edfPath)
% Popup dialog to choose which EDF signals to use and how they should be labeled.
% Returns [] if the user cancels.

    cfg = [];
    try
        info = edfinfo(edfPath);
    catch ME
        errordlg(sprintf('Could not read EDF header:\n%s', ME.message), 'EDF error');
        return;
    end

    labels = local_signal_labels(info);
    if isempty(labels)
        errordlg('No signal labels were found in this EDF.', 'EDF error');
        return;
    end

    maxRows = min(numel(labels), 10);
    labels = labels(1:maxRows);
    opts = meeg_edf_region_options();

    likely = true(numel(labels),1);
    defaults = cell(numel(labels),1);
    for i = 1:numel(labels)
        defaults{i} = local_guess_region(labels{i}, opts);
        likely(i) = local_likely_use(labels{i});
    end

    state.confirmed = false;

    f = uifigure('Name', sprintf('Assign EDF channels — %s', local_short_name(edfPath)), ...
        'Position', [180 120 900 520], 'Color', [1 1 1], 'WindowStyle', 'modal');
    g = uigridlayout(f, [3 1]);
    g.RowHeight = {54, '1x', 48};
    g.Padding = [12 12 12 12];

    hdr = uilabel(g, 'Text', ['Select the EDF signals to use, then assign the region label for each one. ' ...
        'If multiple signals share the same chosen region and the box below is checked, they will be averaged together before qEEG.']);
    hdr.WordWrap = 'on';
    hdr.FontSize = 13;

    tbl = uigridlayout(g, [numel(labels)+1 3]);
    tbl.RowHeight = [{24}, repmat({28},1,numel(labels))];
    tbl.ColumnWidth = {80, '1x', 220};
    tbl.Padding = [4 4 4 4];
    uilabel(tbl, 'Text', 'Use', 'FontWeight', 'bold');
    uilabel(tbl, 'Text', 'EDF signal label', 'FontWeight', 'bold');
    uilabel(tbl, 'Text', 'Assign region label', 'FontWeight', 'bold');

    useBoxes = gobjects(numel(labels),1);
    dd = gobjects(numel(labels),1);
    for i = 1:numel(labels)
        useBoxes(i) = uicheckbox(tbl, 'Value', logical(likely(i)));
        uilabel(tbl, 'Text', labels{i}, 'Interpreter', 'none');
        dd(i) = uidropdown(tbl, 'Items', opts, 'Value', defaults{i});
    end

    foot = uigridlayout(g, [1 3]);
    foot.ColumnWidth = {'1x', 120, 120};
    foot.Padding = [0 0 0 0];
    cbAvg = uicheckbox(foot, 'Text', 'Average channels with the same assigned region during qEEG', 'Value', true);
    uibutton(foot, 'Text', 'Cancel', 'ButtonPushedFcn', @(~,~) close(f));
    uibutton(foot, 'Text', 'Assign to animal', 'ButtonPushedFcn', @onAssign);

    uiwait(f);
    if ~ishandle(f)
        return;
    end
    if state.confirmed
        cfg = state.cfg;
    end
    delete(f);

    function onAssign(~,~)
        keep = arrayfun(@(h) logical(h.Value), useBoxes);
        if ~any(keep)
            uialert(f, 'Select at least one EDF signal to use.', 'No signals selected');
            return;
        end
        reg = strings(sum(keep),1);
        sig = strings(sum(keep),1);
        idx = find(keep);
        for k = 1:numel(idx)
            reg(k) = string(dd(idx(k)).Value);
            sig(k) = string(labels{idx(k)});
        end
        state.cfg = struct();
        state.cfg.edfPath = char(edfPath);
        state.cfg.sourceSignalLabels = cellstr(sig);
        state.cfg.assignedRegionLabels = cellstr(reg);
        state.cfg.averageSameRegion = logical(cbAvg.Value);
        state.confirmed = true;
        uiresume(f);
    end
end

function labels = local_signal_labels(info)
    labels = {};
    try
        labels = cellstr(string(info.SignalLabels));
    catch
    end
    if isempty(labels)
        try
            labels = cellstr(string(info.SignalLabel));
        catch
        end
    end
    labels = labels(:)';
end

function tf = local_likely_use(label)
    s = lower(char(string(label)));
    badTokens = {'ecg','ekg','pulse','resp','respiration','airflow','snore','event','marker','status','annotation','trigger'};
    tf = true;
    for i = 1:numel(badTokens)
        if contains(s, badTokens{i})
            tf = false;
            return;
        end
    end
end

function region = local_guess_region(label, opts)
    s = lower(char(string(label)));
    region = opts{1};
    if contains(s,'hip'), region = 'Hippocampus'; return; end
    if contains(s,'bar'), region = 'Barrel'; return; end
    if contains(s,'mot'), region = 'Motor'; return; end
    if contains(s,'aud'), region = 'Auditory'; return; end
    if contains(s,'vis'), region = 'Visual'; return; end
    if contains(s,'mPFC') || contains(s,'mpfc') || contains(s,'prefrontal'), region = 'Medial prefrontal'; return; end
    if contains(s,'retro'), region = 'Retrosplenial'; return; end
    if contains(s,'par'), region = 'Parietal'; return; end
    if contains(s,'cing'), region = 'Cingulate'; return; end
    if contains(s,'thal'), region = 'Thalamus'; return; end
    if contains(s,'striat'), region = 'Striatum'; return; end
end

function s = local_short_name(p)
    [~,n,e] = fileparts(p);
    s = [n e];
end
