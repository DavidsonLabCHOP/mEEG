function dt = meeg_edf_get_start_datetime(edfPath)
% Try to read recording start datetime from an EDF header.

    dt = [];
    if nargin < 1 || isempty(edfPath), return; end

    try
        info = edfinfo(edfPath);
    catch
        return;
    end

    fns = string(fieldnames(info));
    cand = ["StartDateTime","RecordingStartDateTime","EEGStartDateTime","StartTime"];
    for k = 1:numel(cand)
        fn = cand(k);
        if any(fns == fn)
            try
                v = info.(fn);
                dt = local_parse_datetime(v);
                if ~isempty(dt) && ~isnat(dt), return; end
            catch
            end
        end
    end

    % Try combining separate date/time fields if present.
    dateNames = ["StartDate","RecordingDate","Date"];
    timeNames = ["StartTime","RecordingStartTime","Time"];
    for i = 1:numel(dateNames)
        dfn = dateNames(i);
        if ~any(fns == dfn), continue; end
        for j = 1:numel(timeNames)
            tfn = timeNames(j);
            if ~any(fns == tfn), continue; end
            try
                d = local_parse_date(info.(dfn));
                t = local_parse_time(info.(tfn));
                if ~isempty(d) && ~isempty(t)
                    dt = d + timeofday(t);
                    return;
                end
            catch
            end
        end
    end
end

function dt = local_parse_datetime(v)
    dt = [];
    if isempty(v), return; end
    if isdatetime(v)
        dt = v(1);
        return;
    end
    if iscell(v) && ~isempty(v)
        dt = local_parse_datetime(v{1});
        return;
    end
    s = strtrim(char(string(v)));
    if isempty(s), return; end
    fmts = {'yyyy-MM-dd HH:mm:ss','yyyy-MM-dd HH:mm:ss.SSS','dd-MMM-yyyy HH:mm:ss', ...
            'dd.MM.yy HH:mm:ss','dd.MM.yyyy HH:mm:ss','MM/dd/yyyy HH:mm:ss', ...
            'dd.MM.yy','dd.MM.yyyy','MM/dd/yyyy','yyyy-MM-dd'};
    for i = 1:numel(fmts)
        try
            tmp = datetime(s, 'InputFormat', fmts{i});
            if ~isnat(tmp)
                dt = tmp;
                return;
            end
        catch
        end
    end
    try
        tmp = datetime(s);
        if ~isnat(tmp), dt = tmp; end
    catch
    end
end

function d = local_parse_date(v)
    d = [];
    dt = local_parse_datetime(v);
    if ~isempty(dt) && ~isnat(dt)
        d = dateshift(dt, 'start', 'day');
    end
end

function t = local_parse_time(v)
    t = [];
    if isempty(v), return; end
    if isdatetime(v)
        t = v(1);
        return;
    end
    if isduration(v)
        t = datetime('today') + v(1);
        return;
    end
    if iscell(v) && ~isempty(v)
        t = local_parse_time(v{1});
        return;
    end
    s = strtrim(char(string(v)));
    if isempty(s), return; end
    fmts = {'HH:mm:ss','HH:mm','hh:mm:ss a','hh:mm a'};
    for i = 1:numel(fmts)
        try
            tmp = datetime(s, 'InputFormat', fmts{i});
            if ~isnat(tmp)
                t = tmp;
                return;
            end
        catch
        end
    end
end
