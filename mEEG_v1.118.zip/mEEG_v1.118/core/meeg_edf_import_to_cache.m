function imported = meeg_edf_import_to_cache(project, row, assignCfg)
% Read selected EDF signals, optionally average matching assigned regions,
% then cache them as per-channel int16 .dat files so the existing pipeline
% can run unchanged downstream.

    imported = struct();
    imported.files = {};
    imported.fileOrder = {};
    imported.sourceFile = char(assignCfg.edfPath);
    imported.sourceSignalLabels = assignCfg.sourceSignalLabels(:);
    imported.assignedRegionLabels = assignCfg.assignedRegionLabels(:);
    imported.averageSameRegion = logical(assignCfg.averageSameRegion);

    prefix = sprintf('%s_%s', row.TreatmentGroup, row.MouseID);
    prefix = regexprep(prefix, '\s+', '_');
    outDir = fullfile(project.outdir, 'raw_import_cache', prefix);
    if ~isfolder(outDir), mkdir(outDir); end

    info = edfinfo(assignCfg.edfPath);
    T = edfread(assignCfg.edfPath, 'SelectedSignals', assignCfg.sourceSignalLabels);
    varNames = T.Properties.VariableNames;

    sigData = cell(numel(varNames),1);
    fsEach = nan(numel(varNames),1);
    unitsEach = strings(numel(varNames),1);
    for i = 1:numel(varNames)
        sigData{i} = local_flatten_signal(T.(varNames{i}));
        fsEach(i) = local_fs_for_signal(info, assignCfg.sourceSignalLabels{i}, numel(sigData{i}));
        unitsEach(i) = string(local_unit_for_signal(info, assignCfg.sourceSignalLabels{i}));
        sigData{i} = local_to_uV(sigData{i}, unitsEach(i));
    end

    fsMode = mode(round(fsEach(~isnan(fsEach))));
    if isempty(fsMode) || ~isfinite(fsMode)
        error('Could not determine EDF sampling rate for the selected signals.');
    end
    imported.fs = fsMode;

    if any(abs(fsEach - fsMode) > 1e-6 & ~isnan(fsEach))
        error('Selected EDF signals do not all share the same sampling rate. Please choose channels recorded at the same rate.');
    end

    if imported.averageSameRegion
        [uniqRegs,~,grp] = unique(string(assignCfg.assignedRegionLabels), 'stable');
        finalLabels = cell(numel(uniqRegs),1);
        finalData = cell(numel(uniqRegs),1);
        for g = 1:numel(uniqRegs)
            idx = find(grp == g);
            X = cellfun(@(x) x(:), sigData(idx), 'UniformOutput', false);
            L = min(cellfun(@numel, X));
            M = nan(L, numel(idx));
            for j = 1:numel(idx)
                M(:,j) = X{j}(1:L);
            end
            finalData{g} = mean(M, 2, 'omitnan');
            finalLabels{g} = meeg_edf_sanitize_label(uniqRegs(g));
        end
    else
        finalLabels = cell(numel(sigData),1);
        finalData = sigData;
        counts = containers.Map('KeyType','char','ValueType','double');
        for i = 1:numel(sigData)
            base = meeg_edf_sanitize_label(assignCfg.assignedRegionLabels{i});
            if isKey(counts, base)
                counts(base) = counts(base) + 1;
            else
                counts(base) = 1;
            end
            n = counts(base);
            if n > 1
                finalLabels{i} = sprintf('%s_%d', base, n);
            else
                finalLabels{i} = base;
            end
        end
    end

    imported.assignedLabels = finalLabels(:);
    imported.fileOrder = finalLabels(:);

    for i = 1:numel(finalData)
        x_uV = double(finalData{i}(:));
        counts = round(x_uV ./ project.profile.scale_uV);
        counts = max(min(counts, 32767), -32768);
        datPath = fullfile(outDir, sprintf('%02d_%s.dat', i, finalLabels{i}));
        fid = fopen(datPath, 'w');
        if fid == -1
            error('Could not create cache file: %s', datPath);
        end
        fwrite(fid, int16(counts), 'int16');
        fclose(fid);
        imported.files{i,1} = datPath;
    end
end

function x = local_flatten_signal(v)
    if isnumeric(v)
        x = double(v(:));
    elseif iscell(v)
        tmp = cell(size(v));
        for k = 1:numel(v)
            tmp{k} = double(v{k}(:));
        end
        x = vertcat(tmp{:});
    else
        error('Unsupported EDF signal container type: %s', class(v));
    end
end

function fs = local_fs_for_signal(info, sigLabel, nSamples)
    fs = NaN;
    try
        labels = cellstr(string(info.SignalLabels));
    catch
        labels = {};
    end
    idx = find(strcmp(string(labels), string(sigLabel)), 1, 'first');
    try
        dur = seconds(info.DataRecordDuration);
    catch
        try
            dur = seconds(info.DataRecordDuration(1));
        catch
            dur = NaN;
        end
    end
    if ~isempty(idx)
        try
            ns = double(info.NumSamples(idx));
            if isfinite(dur) && dur > 0
                fs = ns ./ dur;
                return;
            end
        catch
        end
    end
    try
        totalDur = seconds(info.NumDataRecords * info.DataRecordDuration);
        if totalDur > 0
            fs = nSamples / totalDur;
        end
    catch
    end
end

function u = local_unit_for_signal(info, sigLabel)
    u = 'uV';
    try
        labels = cellstr(string(info.SignalLabels));
        idx = find(strcmp(string(labels), string(sigLabel)), 1, 'first');
        if ~isempty(idx)
            dims = cellstr(string(info.PhysicalDimensions));
            if numel(dims) >= idx && ~isempty(dims{idx})
                u = dims{idx};
            end
        end
    catch
    end
end

function x = local_to_uV(x, unitLabel)
    u = lower(strtrim(char(string(unitLabel))));
    if any(strcmp(u, {'uv','µv','μv'}))
        return;
    elseif strcmp(u, 'mv')
        x = x * 1e3;
    elseif strcmp(u, 'v')
        x = x * 1e6;
    end
end
