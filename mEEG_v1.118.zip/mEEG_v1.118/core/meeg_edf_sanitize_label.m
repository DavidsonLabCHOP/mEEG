function out = meeg_edf_sanitize_label(in)
% Convert a region label into a safe compact channel label for files/sheets.
    out = char(meeg_sanitize_lead_label(in));
end
