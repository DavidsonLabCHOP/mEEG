function [ok, actualWorkers] = meeg_ensure_process_pool(logfn, requestedWorkers, forceExact)
%MEEG_ENSURE_PROCESS_POOL Ensure the current parallel pool is process-based.
%   [ok, actualWorkers] = meeg_ensure_process_pool(logfn)
%   [ok, actualWorkers] = meeg_ensure_process_pool(logfn, N)
%   [ok, actualWorkers] = meeg_ensure_process_pool(logfn, N, true)
%
%   N requests a process pool with up to N workers. When forceExact is true,
%   an existing process pool is resized to N. This is used by the adaptive
%   SWD fallback so worker memory is genuinely released between tiers.
%
%   Existing callers that provide only logfn retain the prior behavior.

    if nargin < 1 || isempty(logfn), logfn = @(msg) disp(msg); end
    if nargin < 2 || isempty(requestedWorkers) || ~isfinite(requestedWorkers)
        requestedWorkers = [];
    else
        requestedWorkers = max(1, floor(double(requestedWorkers)));
    end
    if nargin < 3 || isempty(forceExact), forceExact = false; end
    forceExact = logical(forceExact);

    ok = false;
    actualWorkers = 0;
    try
        if ~license('test','Distrib_Computing_Toolbox')
            logfn('Parallel Computing Toolbox is not available; using serial processing.');
            return;
        end
    catch
        return;
    end

    try
        p = gcp('nocreate');
        mustReplace = false;
        if ~isempty(p)
            mustReplace = local_is_thread_pool(p);
            if forceExact && ~isempty(requestedWorkers)
                try
                    mustReplace = mustReplace || double(p.NumWorkers) ~= requestedWorkers;
                catch
                    mustReplace = true;
                end
            end
        end

        if ~isempty(p) && mustReplace
            if local_is_thread_pool(p)
                logfn('Existing thread-based parallel pool detected; switching to process-based workers for this analysis.');
            elseif ~isempty(requestedWorkers)
                logfn(sprintf('Resizing process pool to %d worker(s) for adaptive resource fallback.', requestedWorkers));
            end
            delete(p);
            p = [];
        end

        if isempty(p)
            p = local_start_process_pool(requestedWorkers, forceExact);
        end

        ok = ~isempty(p) && ~local_is_thread_pool(p);
        if ok
            try, actualWorkers = double(p.NumWorkers); catch, actualWorkers = 0; end
            if forceExact && ~isempty(requestedWorkers) && actualWorkers ~= requestedWorkers
                logfn(sprintf('Requested %d process workers but MATLAB started %d.', requestedWorkers, actualWorkers));
                ok = false;
            end
        else
            logfn('Parallel pool is still thread-based; using serial processing for compatibility.');
            try
                if ~isempty(p), delete(p); end
            catch
            end
        end
    catch ME
        ok = false;
        actualWorkers = 0;
        try
            logfn(['Could not start a process-based parallel pool; using a lower tier or serial processing. ' ME.message]);
        catch
        end
    end
end

function p = local_start_process_pool(requestedWorkers, forceExact)
    p = [];
    errs = strings(0,1);

    if isempty(requestedWorkers)
        try
            p = parpool('Processes');
            return;
        catch ME
            errs(end+1) = string(ME.message); %#ok<AGROW>
        end
        try
            p = parpool;
            return;
        catch ME
            errs(end+1) = string(ME.message); %#ok<AGROW>
        end
    else
        try
            p = parpool('Processes', requestedWorkers);
            return;
        catch ME
            errs(end+1) = string(ME.message); %#ok<AGROW>
        end
        try
            c = parcluster('Processes');
            p = parpool(c, requestedWorkers);
            return;
        catch ME
            errs(end+1) = string(ME.message); %#ok<AGROW>
        end
        try
            c = parcluster;
            p = parpool(c, requestedWorkers);
            return;
        catch ME
            errs(end+1) = string(ME.message); %#ok<AGROW>
        end
        if ~forceExact
            try
                p = parpool;
                return;
            catch ME
                errs(end+1) = string(ME.message); %#ok<AGROW>
            end
        end
    end

    if isempty(errs)
        error('mEEG:ParallelPoolStart', 'Unable to start a process-based parallel pool.');
    else
        error('mEEG:ParallelPoolStart', '%s', char(strjoin(errs, ' | ')));
    end
end

function tf = local_is_thread_pool(p)
    tf = false;
    try
        tf = contains(string(class(p)), 'ThreadPool', 'IgnoreCase', true);
    catch
    end
    try
        if isprop(p,'Cluster') && ~isempty(p.Cluster)
            tf = tf || contains(string(class(p.Cluster)), 'ThreadPool', 'IgnoreCase', true) || ...
                contains(string(p.Cluster.Type), 'threads', 'IgnoreCase', true);
        end
    catch
    end
end
