function y = meeg_eventdetect_apply_filter(x, fs, F)
% Apply a reusable Event Detector filter with a backward-compatible fallback.

    y = double(x(:));
    if nargin < 3 || isempty(F)
        F = meeg_eventdetect_make_filter(fs);
    end

    try
        modeName = string(F.mode);
    catch
        modeName = "none";
    end

    try
        if modeName == "sos"
            y = filtfilt(F.sos, F.g, y);
            return;
        elseif modeName == "digitalFilter"
            y = filtfilt(F.d, y);
            return;
        end
    catch
        % Continue to the legacy-compatible fallback below.
    end

    try
        y = bandpass(y, [0.5 min(80, fs/2-1)], fs);
    catch
        % Preserve the unfiltered signal if no supported filter is available.
    end
end
