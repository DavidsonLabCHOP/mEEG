function T = meeg_eventdetect_collect_per_animal(project, timePoint, metricName, yScaleHours, eventType, thresh)
    if nargin < 2 || isempty(timePoint), timePoint = "all"; end
    if nargin < 3 || isempty(metricName), metricName = "count"; end
    if nargin < 4 || isempty(yScaleHours), yScaleHours = 0.5; end
    if nargin < 5 || isempty(eventType), eventType = "all"; end
    if nargin < 6 || isempty(thresh), thresh = local_default_thresholds(); end

    [prefixes, idxs] = meeg_manifest_get_animal_prefixes(project.manifest);
    inc = logical(project.manifest.Include(idxs));
    prefixes = prefixes(inc); idxs = idxs(inc);
    rows = {};
    outDir = meeg_outdir(project,'qeeg','Event Detection (beta)');
    for ii = 1:numel(prefixes)
        prefix = string(prefixes(ii));
        safePrefix = regexprep(char(prefix), '[^a-zA-Z0-9_\-]', '_');
        f = fullfile(outDir, sprintf('%s_event_detection_events.xlsx', safePrefix));
        if ~isfile(f), continue; end
        Te = readtable(f, 'TextType','string');
        if isempty(Te) || height(Te)==0, continue; end
        if ~ismember('UserIncluded', Te.Properties.VariableNames), Te.UserIncluded = true(height(Te),1); end
        Te = Te(logical(Te.UserIncluded),:);
        if isempty(Te), continue; end
        if ismember('StartHour', Te.Properties.VariableNames)
            hrs = double(Te.StartHour);
            d0 = 6.5; d1 = 18.5;
            try, d0 = project.profile.dayStart; d1 = project.profile.dayEnd; catch, end %#ok<TRYNC>
            keep = localSelectHours(hrs, string(timePoint), d0, d1);
            Te = Te(keep,:);
        end
        if string(eventType) ~= "all" && ismember('Reason', Te.Properties.VariableNames)
            if string(eventType) == "mixed abnormality"
                Te = Te(local_mixed_mask(Te, thresh),:);
            else
                Te = Te(string(Te.Reason)==string(eventType),:);
            end
        end
        if isempty(Te), continue; end
        try, labels = unique(string(Te.LeadLabel), 'stable'); catch, labels = unique(string(Te.LeadLabel)); end
        totalHours = NaN;
        sf = fullfile(outDir, sprintf('%s_event_detection_summary.xlsx', safePrefix));
        if isfile(sf)
            try
                Ts = readtable(sf, 'TextType','string');
                if ismember('TotalHours', Ts.Properties.VariableNames), totalHours = double(Ts.TotalHours(1)); end
            catch
            end
        end
        if ~isfinite(totalHours) || totalHours <= 0, totalHours = 24; end
        for li = 1:numel(labels)
            lbl = labels(li);
            sub = Te(string(Te.LeadLabel)==lbl,:);
            switch char(metricName)
                case 'count'
                    val = height(sub) / totalHours * yScaleHours;
                case 'duration'
                    val = sum(sub.DurationSec, 'omitnan') / totalHours * yScaleHours;
                otherwise
                    val = mean(sub.DurationSec, 'omitnan');
            end
            rows{end+1,1} = struct('Prefix', prefix, 'TreatmentGroup', string(project.manifest.TreatmentGroup(idxs(ii))), ...
                'MouseID', string(project.manifest.MouseID(idxs(ii))), 'LeadLabel', lbl, 'Value', val, ...
                'Sex', localOptManifest(project.manifest, idxs(ii), 'Sex'), 'LitterID', localOptManifest(project.manifest, idxs(ii), 'LitterID'), ...
                'RecordingDate', localOptManifest(project.manifest, idxs(ii), 'RecordingDate'), 'Genotype', localOptManifest(project.manifest, idxs(ii), 'Genotype'));
        end
    end
    if isempty(rows)
        T = table();
    else
        T = struct2table([rows{:}]);
    end
end

function thresh = local_default_thresholds()
    thresh = struct('rmsZ',3.5,'lineZ',3.0,'spikeRateZ',3.0,'rhythmZ',2.5);
end

function tf = local_mixed_mask(T, thresh)
    tf = false(height(T),1);
    if height(T)==0, return; end
    try
        if ismember('Reason', T.Properties.VariableNames)
            tf = tf | string(T.Reason)=="mixed abnormality" | string(T.Reason)=="mixed anomaly";
        end
        need = {'RMS_Z','Line_Z','SpikeRate_Z','Rhythm_Z'};
        if all(ismember(need, T.Properties.VariableNames))
            M = [double(T.RMS_Z) >= thresh.rmsZ, double(T.Line_Z) >= thresh.lineZ, double(T.SpikeRate_Z) >= thresh.spikeRateZ, double(T.Rhythm_Z) >= thresh.rhythmZ];
            M(~isfinite(M)) = false;
            tf = tf | sum(M,2) >= 2;
        end
    catch
        tf = false(height(T),1);
    end
end

function out = localOptManifest(M, idx, vn)
    out = "";
    if ismember(vn, M.Properties.VariableNames)
        try, out = string(M.(vn)(idx)); catch, end
    end
end
function keep = localSelectHours(hours, timePoint, dayStart, dayEnd)
    keep = true(size(hours));
    tp = string(timePoint);
    if tp == "all", return; end
    if dayStart < dayEnd
        isDay = hours >= dayStart & hours < dayEnd;
    else
        isDay = hours >= dayStart | hours < dayEnd;
    end
    if tp == "day", keep = isDay; else, keep = ~isDay; end
end
