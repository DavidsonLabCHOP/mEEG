function T = meeg_eventdetect_detect_signal(x, fs, opts, leadLabel, prefix, startOffsetSec, hourStart, eventFilter, retainStartSec, retainEndSec, retainEndInclusive)
% Detect locally abnormal EEG events in one signal block.
%
% v1.113 speed path:
%   - RMS, line length, peak-to-peak, and window SD are vectorized.
%   - Rhythmicity is calculated for all windows with one block spectrogram.
%   - The existing per-window findpeaks definition is retained.
%   - Rolling local-baseline Z scores and detection thresholds are unchanged.
%
% retainStartSec/retainEndSec define the central portion of an overlapping
% processing block. Events are retained by midpoint so boundary events are
% emitted once while still benefiting from the surrounding baseline context.

    if nargin < 4 || isempty(leadLabel), leadLabel = "Lead"; end
    if nargin < 5 || isempty(prefix), prefix = ""; end
    if nargin < 6 || isempty(startOffsetSec), startOffsetSec = 0; end
    if nargin < 7 || isempty(hourStart), hourStart = 0; end
    if nargin < 8, eventFilter = []; end
    if nargin < 9 || isempty(retainStartSec), retainStartSec = -Inf; end
    if nargin < 10 || isempty(retainEndSec), retainEndSec = Inf; end
    if nargin < 11 || isempty(retainEndInclusive), retainEndInclusive = true; end

    T = meeg_eventdetect_empty_table();
    x = double(x(:));
    if numel(x) < max(100, round(opts.candidateWinSec*fs))
        return;
    end

    if isfield(opts,'detrend') && opts.detrend
        x = detrend(x);
    else
        x = x - median(x, 'omitnan');
    end
    x = meeg_eventdetect_apply_filter(x, fs, eventFilter);

    winN = max(16, round(opts.candidateWinSec * fs));
    stepN = max(1, round(winN * max(0.02, 1 - opts.overlapFrac)));
    startIdx = (1:stepN:(numel(x)-winN+1))';
    nWin = numel(startIdx);
    if nWin < 3, return; end
    endIdx = startIdx + winN - 1;

    t0 = startOffsetSec + (startIdx-1)/fs;
    t1 = startOffsetSec + (endIdx-1)/fs;

    % Exact window sums/counts without materializing a winN-by-nWin matrix.
    [sumV, sumSqV, countV] = local_window_sum_stats(x, startIdx, endIdx);
    rmsV = sqrt(sumSqV ./ max(countV, 1));
    rmsV(countV < 1) = NaN;

    % Sample standard deviation, matching std(seg,0,'omitnan').
    varV = (sumSqV - (sumV.^2 ./ max(countV,1))) ./ max(countV-1,1);
    varV = max(varV, 0);
    sigStdV = sqrt(varV);
    sigStdV(countV <= 1) = NaN;

    % Exact mean absolute first difference per candidate window.
    lineV = local_window_line_length(x, startIdx, endIdx);

    % Exact sliding max-min, sampled at each candidate-window endpoint.
    p2pV = local_window_peak_to_peak(x, endIdx, winN);

    % Keep the current spike-rate definition exactly: findpeaks is still run
    % inside each candidate window with its own SD-scaled prominence.
    spikeV = nan(nWin,1);
    minPeakDistance = max(1, round(0.02*fs));
    for k = 1:nWin
        seg = x(startIdx(k):endIdx(k));
        sigStd = sigStdV(k);
        if ~isfinite(sigStd) || sigStd <= 0, sigStd = 1; end
        try
            [pks,~] = findpeaks(abs(seg), ...
                'MinPeakProminence', opts.peakPromZ * sigStd, ...
                'MinPeakDistance', minPeakDistance);
            spikeV(k) = numel(pks) / max(eps, opts.candidateWinSec);
        catch
            spikeV(k) = sum(abs(seg) > opts.peakPromZ * sigStd) / max(eps, opts.candidateWinSec);
        end
    end

    % One block-level short-time spectrum replaces one periodogram call per
    % candidate window. The queried frequencies are the same DFT bins that
    % the previous periodogram path used in the 3-30 Hz range.
    rhythmV = zeros(nWin,1);
    try
        nfft = max(256, 2^nextpow2(winN));
        allF = (0:floor(nfft/2))' .* (fs/nfft);
        maxRhythmHz = min(30, fs/2-1);
        fQuery = allF(allF >= 3 & allF <= maxRhythmHz);
        if ~isempty(fQuery)
            noverlap = max(0, winN-stepN);
            [S,~] = spectrogram(x, ones(winN,1), noverlap, fQuery, fs);
            P = abs(S).^2;
            if size(P,2) ~= nWin
                error('EventDetector:SpectrogramWindowMismatch', ...
                    'Expected %d spectral windows but received %d.', nWin, size(P,2));
            end
            if nWin > 0
                mx = max(P, [], 1);
                den = sum(P, 1);
                rhythmV = (mx ./ max(eps,den))';
            end
        end
    catch
        % Conservative compatibility fallback. It is slower but preserves
        % operation on MATLAB installations where the block call is unavailable.
        for k = 1:nWin
            seg = x(startIdx(k):endIdx(k));
            try
                [pxx,f] = periodogram(seg, [], [], fs);
                sel = f >= 3 & f <= min(30, fs/2-1);
                if any(sel)
                    p = pxx(sel);
                    rhythmV(k) = max(p) / max(eps, sum(p));
                end
            catch
                rhythmV(k) = 0;
            end
        end
    end

    % Preserve the existing two-sided rolling local-baseline interpretation.
    baseN = max(3, round(opts.baselineWinSec / max(eps, stepN/fs)));
    zR = local_rolling_z(rmsV, baseN);
    zL = local_rolling_z(lineV, baseN);
    zS = local_rolling_z(spikeV, baseN);
    zY = local_rolling_z(rhythmV, baseN);

    artifact = p2pV > opts.maxPhysP2P_uV;
    abnormal = ~artifact & (zR >= opts.rmsZ | zL >= opts.lineZ | ...
        zS >= opts.spikeRateZ | zY >= opts.rhythmZ);

    if ~any(abnormal), return; end

    gapN = max(1, round(opts.mergeGapSec / max(eps, stepN/fs)));
    starts = find(diff([false; abnormal]) == 1);
    ends   = find(diff([abnormal; false]) == -1);
    if isempty(starts), return; end

    % Merge nearby flagged runs exactly as in the previous detector.
    mergedS = starts(1); mergedE = ends(1); out = zeros(0,2);
    for k = 2:numel(starts)
        if starts(k) - mergedE <= gapN
            mergedE = ends(k);
        else
            out(end+1,:) = [mergedS mergedE]; %#ok<AGROW>
            mergedS = starts(k); mergedE = ends(k);
        end
    end
    out(end+1,:) = [mergedS mergedE];

    rows = cell(size(out,1),1);
    for k = 1:size(out,1)
        a = out(k,1); b = out(k,2);
        sSec = t0(a); eSec = t1(b);
        dur = eSec - sSec;
        if dur < opts.minDurSec, continue; end

        % Keep each overlap-region event in exactly one central block.
        midSec = (sSec + eSec) / 2;
        if midSec < retainStartSec, continue; end
        if retainEndInclusive
            if midSec > retainEndSec, continue; end
        else
            if midSec >= retainEndSec, continue; end
        end

        rz = max(zR(a:b), [], 'omitnan');
        lz = max(zL(a:b), [], 'omitnan');
        sz = max(zS(a:b), [], 'omitnan');
        yz = max(zY(a:b), [], 'omitnan');
        [~,ix] = max([rz lz sz yz]);
        reasons = ["amplitude burst", "line-length burst", "spike-rate burst", "rhythmic burst"];
        primaryReason = reasons(ix);
        activeReasons = [rz >= opts.rmsZ, lz >= opts.lineZ, ...
            sz >= opts.spikeRateZ, yz >= opts.rhythmZ];
        if sum(activeReasons) >= 2
            reason = "mixed abnormality";
        else
            reason = primaryReason;
        end
        rows{k} = struct( ...
            'Prefix', string(prefix), ...
            'LeadLabel', string(leadLabel), ...
            'StartSec', sSec, ...
            'EndSec', eSec, ...
            'DurationSec', dur, ...
            'StartHour', mod(hourStart + sSec/3600, 24), ...
            'RMS_Z', rz, ...
            'Line_Z', lz, ...
            'SpikeRate_Z', sz, ...
            'Rhythm_Z', yz, ...
            'PeakToPeak_uV', max(p2pV(a:b), [], 'omitnan'), ...
            'UserIncluded', true, ...
            'UserDecision', "included", ...
            'Reason', reason, ...
            'PrimaryReason', primaryReason, ...
            'FeatureCount', sum(activeReasons), ...
            'ReviewTimestamp', "");
    end
    rows = rows(~cellfun('isempty', rows));
    if isempty(rows), return; end
    T = struct2table([rows{:}]);
end

function [sumV, sumSqV, countV] = local_window_sum_stats(x, startIdx, endIdx)
    good = isfinite(x);
    x0 = x;
    x0(~good) = 0;
    cs = [0; cumsum(x0)];
    cs2 = [0; cumsum(x0.^2)];
    cc = [0; cumsum(double(good))];
    sumV = cs(endIdx+1) - cs(startIdx);
    sumSqV = cs2(endIdx+1) - cs2(startIdx);
    countV = cc(endIdx+1) - cc(startIdx);
end

function lineV = local_window_line_length(x, startIdx, endIdx)
    d = abs(diff(x));
    good = isfinite(d);
    d0 = d;
    d0(~good) = 0;
    cs = [0; cumsum(d0)];
    cc = [0; cumsum(double(good))];
    sumD = cs(endIdx) - cs(startIdx);
    countD = cc(endIdx) - cc(startIdx);
    lineV = sumD ./ max(countD,1);
    lineV(countD < 1) = NaN;
end

function p2pV = local_window_peak_to_peak(x, endIdx, winN)
    try
        mx = movmax(x, [winN-1 0], 'omitnan');
        maxV = mx(endIdx);
        clear mx
        mn = movmin(x, [winN-1 0], 'omitnan');
        minV = mn(endIdx);
        p2pV = maxV - minV;
    catch
        % Compatibility fallback for older MATLAB releases.
        p2pV = nan(numel(endIdx),1);
        startIdx = endIdx-winN+1;
        for k = 1:numel(endIdx)
            seg = x(startIdx(k):endIdx(k));
            p2pV(k) = max(seg,[],'omitnan') - min(seg,[],'omitnan');
        end
    end
end

function z = local_rolling_z(v, n)
    medv = movmedian(v, [n n], 'omitnan');
    try
        madv = movmad(v, [n n], 1, 'omitnan');
    catch
        madv = movmedian(abs(v - medv), [n n], 'omitnan');
    end
    s = 1.4826 * madv + eps;
    z = (v - medv) ./ s;
end
