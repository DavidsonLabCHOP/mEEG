function F = meeg_eventdetect_make_filter(fs)
% Design the reusable Event Detector 0.5-80 Hz bandpass once per animal.
%
% The preferred path asks MATLAB bandpass for its minimum-order IIR
% digitalFilter using the same default 60 dB attenuation and 0.85 transition
% steepness. The returned filter is then reused with zero-phase filtfilt.

    F = struct('mode', "none", 'sos', [], 'g', [], 'd', [], ...
        'lowHz', 0.5, 'highHz', NaN, 'fs', double(fs));

    fs = double(fs);
    if ~isfinite(fs) || fs <= 2
        return;
    end

    lowHz = 0.5;
    highHz = min(80, fs/2 - 1);
    F.highHz = highHz;
    if ~isfinite(highHz) || highHz <= lowHz
        return;
    end

    % Use a modest probe only to obtain the reusable filter object. The
    % probe is not EEG data and is discarded immediately after design.
    try
        probeN = max(4096, round(30 * fs));
        probe = zeros(probeN,1);
        [~,d] = bandpass(probe, [lowHz highHz], fs, ...
            'ImpulseResponse','iir', ...
            'Steepness',[0.85 0.85], ...
            'StopbandAttenuation',60);
        F.mode = "digitalFilter";
        F.d = d;
        return;
    catch
    end

    % Numerical-stability fallback when digitalFilter design is unavailable.
    try
        [z,p,k] = butter(4, [lowHz highHz] ./ (fs/2), 'bandpass');
        [sos,g] = zp2sos(z,p,k);
        F.mode = "sos";
        F.sos = sos;
        F.g = g;
    catch
        F.mode = "none";
    end
end
