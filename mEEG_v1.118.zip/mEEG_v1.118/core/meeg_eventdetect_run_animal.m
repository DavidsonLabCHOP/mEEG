function [T, S] = meeg_eventdetect_run_animal(project, prefix, rowIdx, evtOpts, logfn)
% Run Event Detection for one animal using memory-bounded 30-minute blocks.
%
% v1.113 reads one lead at a time. Each 30-minute central block includes
% surrounding local-baseline context, then only midpoint-owned events are kept.

    if nargin < 5 || isempty(logfn), logfn = @(msg) disp(msg); end
    [a,~] = meeg_project_get_animal(project, prefix);
    if isempty(a) && nargin >= 3 && isfinite(double(rowIdx)) && ...
            rowIdx >= 1 && rowIdx <= numel(project.animals)
        % Manifest and project.animals are maintained in the same row order.
        % This fallback protects legacy projects whose stored prefix differs
        % only by punctuation from the manifest-generated prefix.
        a = project.animals(rowIdx);
    end
    if isempty(a), error('Animal %s was not found in project.animals.', char(prefix)); end
    try
        if isfield(a,'prefix') && string(a.prefix) ~= string(prefix)
            logfn(sprintf('  - Resolved manifest animal %s to stored project prefix %s.', ...
                char(prefix), char(string(a.prefix))));
        end
    catch
    end
    files = a.files;
    if isempty(files), error('No channel files found for %s.', char(prefix)); end
    files = cellstr(string(files(:)));

    if isfield(a,'fs') && ~isempty(a.fs) && isfinite(double(a.fs))
        fs = double(a.fs);
    else
        fs = double(evtOpts.fs);
    end
    if ~isfinite(fs) || fs <= 0, fs = 2500; end

    if isfield(a,'fileOrder') && ~isempty(a.fileOrder)
        labels = cellstr(string(a.fileOrder(:)));
    elseif isfield(a,'assignedLabels') && ~isempty(a.assignedLabels)
        labels = cellstr(string(a.assignedLabels(:)));
    elseif isfield(project,'profile') && isfield(project.profile,'channelLabels')
        labels = cellstr(string(project.profile.channelLabels(:)));
    else
        labels = {};
    end
    if numel(labels) < numel(files)
        for kk = numel(labels)+1:numel(files)
            labels{kk,1} = sprintf('Ch%d', kk); %#ok<AGROW>
        end
    elseif numel(labels) > numel(files)
        labels = labels(1:numel(files));
    end

    hourStart = 0;
    try
        hs = meeg_manifest_get_start_hour(project, prefix, rowIdx);
        if isfinite(hs), hourStart = hs; end
    catch
    end
    logfn(sprintf('  - Recording start clock hour for day/night: %.3f', hourStart));

    bytesPerSample = 2;
    nSamplesEach = zeros(1, numel(files));
    for ch = 1:numel(files)
        d = dir(files{ch});
        if isempty(d), error('Missing file: %s', files{ch}); end
        nSamplesEach(ch) = floor(double(d.bytes) / bytesPerSample);
    end
    totalSamples = min(nSamplesEach);
    totalHours = totalSamples / fs / 3600;

    blockSec = max(60, double(conditionalField(evtOpts, 'chunkSec', 1800)));
    blockN = max(round(blockSec * fs), round(5 * fs));
    baselineSec = max(0, double(conditionalField(evtOpts, 'baselineWinSec', 60)));
    requestedContextSec = max(0, double(conditionalField(evtOpts, 'chunkOverlapSec', baselineSec)));
    % A complete candidate and merge interval are added so windows at the
    % central boundary still have their full rolling-baseline neighborhood.
    contextSec = max(requestedContextSec, baselineSec + ...
        double(evtOpts.candidateWinSec) + double(evtOpts.mergeGapSec));
    contextN = max(0, round(contextSec * fs));

    winN = max(16, round(evtOpts.candidateWinSec * fs));
    stepN = max(1, round(winN * max(0.02, 1 - evtOpts.overlapFrac)));
    nBlocks = max(1, ceil(totalSamples / blockN));
    scale_uV = conditionalField(project.profile, 'scale_uV', 0.195);

    eventFilter = meeg_eventdetect_make_filter(fs);
    filterMode = "legacy bandpass fallback";
    try
        if string(eventFilter.mode) == "sos"
            filterMode = "reusable SOS Butterworth";
        elseif string(eventFilter.mode) == "digitalFilter"
            filterMode = "reusable bandpass-compatible IIR";
        end
    catch
    end

    logfn(sprintf('  - Event speed mode: %.1f-min central blocks, %.1f-s baseline context, %d lead(s).', ...
        blockSec/60, contextSec, numel(files)));
    logfn(sprintf('  - Reusable bandpass: %s [%.1f..%.1f Hz] at fs=%.1f Hz.', ...
        char(filterMode), eventFilter.lowHz, eventFilter.highHz, fs));

    rows = cell(numel(files),1);
    for ch = 1:numel(files)
        file = files{ch};
        blockTables = cell(nBlocks,1);
        fid = fopen(file, 'r');
        if fid == -1, error('Could not open %s', file); end
        cleaner = onCleanup(@() local_close_file(fid)); %#ok<NASGU>

        for bb = 1:nBlocks
            central0 = (bb-1) * blockN; % zero-based, inclusive
            central1 = min(totalSamples, central0 + blockN); % zero-based, exclusive

            read0 = max(0, central0 - contextN);
            % Keep every block on the same global candidate-window grid.
            read0 = floor(read0 / stepN) * stepN;
            read1 = min(totalSamples, central1 + contextN);
            ns = read1 - read0;
            if ns < winN, continue; end

            status = fseek(fid, int64(read0) * int64(bytesPerSample), 'bof');
            if status ~= 0
                error('Could not seek to sample %d in %s.', read0, file);
            end
            raw = fread(fid, ns, 'int16=>double');
            if numel(raw) < winN, continue; end
            x = raw(:) * scale_uV;

            retainStartSec = central0 / fs;
            retainEndSec = central1 / fs;
            retainEndInclusive = (bb == nBlocks);
            blockTables{bb} = meeg_eventdetect_detect_signal(x, fs, evtOpts, ...
                labels{ch}, prefix, read0/fs, hourStart, eventFilter, ...
                retainStartSec, retainEndSec, retainEndInclusive);

            if bb == 1 || bb == nBlocks || mod(bb, max(1,ceil(nBlocks/4))) == 0
                logfn(sprintf('    %s: block %d/%d complete.', labels{ch}, bb, nBlocks));
            end
        end

        clear cleaner
        keep = ~cellfun(@(q) isempty(q) || height(q)==0, blockTables);
        if any(keep)
            leadRows = vertcat(blockTables{keep});
            leadRows = local_merge_boundary_events(leadRows, evtOpts, hourStart);
        else
            leadRows = meeg_eventdetect_empty_table();
        end
        rows{ch} = leadRows;
        logfn(sprintf('  - %s: %d candidate event(s)', labels{ch}, height(leadRows)));
    end

    keepRows = ~cellfun(@(q) isempty(q) || height(q)==0, rows);
    if ~any(keepRows)
        T = meeg_eventdetect_empty_table();
    else
        T = vertcat(rows{keepRows});
        T = sortrows(T, {'StartSec','LeadLabel'});
    end

    S = struct();
    S.Prefix = string(prefix);
    S.TreatmentGroup = string(project.manifest.TreatmentGroup(rowIdx));
    S.TotalEvents = height(T);
    S.TotalIncluded = sum(logical(T.UserIncluded));
    S.TotalDurationSec = sum(T.DurationSec(logical(T.UserIncluded)), 'omitnan');
    S.MeanDurationSec = mean(T.DurationSec(logical(T.UserIncluded)), 'omitnan');
    if isnan(S.MeanDurationSec), S.MeanDurationSec = 0; end
    S.TotalHours = totalHours;
end

function T = local_merge_boundary_events(T, opts, hourStart)
% Consolidate the rare event duplicated/split at a central-block boundary.
    if isempty(T) || height(T) < 2
        return;
    end
    T = sortrows(T, {'StartSec','EndSec'});
    out = cell(height(T),1);
    nOut = 0;
    cur = T(1,:);
    for ii = 2:height(T)
        nxt = T(ii,:);
        if nxt.StartSec <= cur.EndSec + opts.mergeGapSec
            cur.EndSec = max(cur.EndSec, nxt.EndSec);
            cur.DurationSec = cur.EndSec - cur.StartSec;
            cur.StartHour = mod(hourStart + cur.StartSec/3600, 24);
            cur.RMS_Z = max([cur.RMS_Z nxt.RMS_Z], [], 'omitnan');
            cur.Line_Z = max([cur.Line_Z nxt.Line_Z], [], 'omitnan');
            cur.SpikeRate_Z = max([cur.SpikeRate_Z nxt.SpikeRate_Z], [], 'omitnan');
            cur.Rhythm_Z = max([cur.Rhythm_Z nxt.Rhythm_Z], [], 'omitnan');
            cur.PeakToPeak_uV = max([cur.PeakToPeak_uV nxt.PeakToPeak_uV], [], 'omitnan');
            cur = local_refresh_reason(cur, opts);
        else
            nOut = nOut + 1;
            out{nOut} = cur;
            cur = nxt;
        end
    end
    nOut = nOut + 1;
    out{nOut} = cur;
    T = vertcat(out{1:nOut});
end

function row = local_refresh_reason(row, opts)
    vals = [row.RMS_Z row.Line_Z row.SpikeRate_Z row.Rhythm_Z];
    [~,ix] = max(vals);
    reasons = ["amplitude burst", "line-length burst", "spike-rate burst", "rhythmic burst"];
    row.PrimaryReason = reasons(ix);
    active = [row.RMS_Z >= opts.rmsZ, row.Line_Z >= opts.lineZ, ...
        row.SpikeRate_Z >= opts.spikeRateZ, row.Rhythm_Z >= opts.rhythmZ];
    row.FeatureCount = sum(active);
    if row.FeatureCount >= 2
        row.Reason = "mixed abnormality";
    else
        row.Reason = row.PrimaryReason;
    end
end

function local_close_file(fid)
    try
        if fid > 0, fclose(fid); end
    catch
    end
end

function v = conditionalField(S, f, defaultVal)
    v = defaultVal;
    try
        if isstruct(S) && isfield(S, f) && ~isempty(S.(f))
            v = S.(f);
        end
    catch
    end
end
