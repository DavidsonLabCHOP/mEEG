function meeg_eventdetect_runall(project, evtOpts, logfn)
% Run beta event detection for all included animals.
% v1.113: 30-minute block-wise feature extraction with animal-level parallel execution.

    if nargin < 3 || isempty(logfn), logfn = @(msg) disp(msg); end
    if ~isfield(evtOpts,'fs'), evtOpts.fs = 2500; end
    if ~isfield(evtOpts,'baselineWinSec'), evtOpts.baselineWinSec = 60; end
    if ~isfield(evtOpts,'candidateWinSec'), evtOpts.candidateWinSec = 1; end
    if ~isfield(evtOpts,'overlapFrac'), evtOpts.overlapFrac = 0.5; end
    if ~isfield(evtOpts,'detrend'), evtOpts.detrend = true; end
    if ~isfield(evtOpts,'rmsZ'), evtOpts.rmsZ = 3.5; end
    if ~isfield(evtOpts,'lineZ'), evtOpts.lineZ = 3.0; end
    if ~isfield(evtOpts,'spikeRateZ'), evtOpts.spikeRateZ = 3.0; end
    if ~isfield(evtOpts,'rhythmZ'), evtOpts.rhythmZ = 2.5; end
    if ~isfield(evtOpts,'peakPromZ'), evtOpts.peakPromZ = 1.5; end
    if ~isfield(evtOpts,'maxPhysP2P_uV'), evtOpts.maxPhysP2P_uV = 3000; end
    if ~isfield(evtOpts,'mergeGapSec'), evtOpts.mergeGapSec = 0.5; end
    if ~isfield(evtOpts,'minDurSec'), evtOpts.minDurSec = 0.5; end
    if ~isfield(evtOpts,'chunkSec'), evtOpts.chunkSec = 30 * 60; end
    if ~isfield(evtOpts,'chunkOverlapSec'), evtOpts.chunkOverlapSec = evtOpts.baselineWinSec; end
    if ~isfield(evtOpts,'useParallel'), evtOpts.useParallel = false; end

    if isempty(project.manifest) || height(project.manifest)==0
        logfn('No manifest loaded.'); return;
    end
    [prefixes, idxs] = meeg_manifest_get_animal_prefixes(project.manifest);
    inc = logical(project.manifest.Include(idxs));
    prefixes = prefixes(inc); idxs = idxs(inc);
    if isempty(prefixes), logfn('No animals selected.'); return; end

    outDir = meeg_outdir(project,'qeeg','Event Detection (beta)');
    if ~isfolder(outDir), mkdir(outDir); end

    usePar = false;
    try
        usePar = logical(evtOpts.useParallel) && numel(prefixes) > 1 && license('test','Distrib_Computing_Toolbox');
    catch
        usePar = false;
    end

    logfn(sprintf('Events speed mode: %.1f-min blocks with %.1f-s local-baseline context; vectorized RMS/line length/peak-to-peak and block spectrogram.', ...
        double(evtOpts.chunkSec)/60, double(evtOpts.chunkOverlapSec)));

    summaryRows = cell(numel(prefixes),1);
    logCells = cell(numel(prefixes),1);

    if usePar
        logfn(sprintf('Events: running in parallel across %d animals...', numel(prefixes)));
        try
            usePar = meeg_ensure_process_pool(logfn);
        catch
            usePar = false;
            logfn('Events: could not start a process-based parallel pool; falling back to serial.');
        end
    end

    if usePar
        parfor ii = 1:numel(prefixes)
            [summaryRows{ii}, logCells{ii}] = local_run_one_event(project, prefixes(ii), idxs(ii), ii, numel(prefixes), evtOpts, outDir);
        end
        for ii = 1:numel(prefixes)
            local_emit_logs(logfn, logCells{ii});
        end
    else
        for ii = 1:numel(prefixes)
            [summaryRows{ii}, logCells{ii}] = local_run_one_event(project, prefixes(ii), idxs(ii), ii, numel(prefixes), evtOpts, outDir);
            local_emit_logs(logfn, logCells{ii});
        end
    end

    summaryRows = summaryRows(~cellfun('isempty', summaryRows));
    if ~isempty(summaryRows)
        Sall = struct2table([summaryRows{:}]);
        writetable(Sall, fullfile(outDir, 'EventDetection_summary_all_animals.xlsx'));
        save(fullfile(outDir, 'EventDetection_summary_all_animals.mat'), 'Sall', 'evtOpts');
    end
end

function [Sout, logLines] = local_run_one_event(project, prefix, rowIdx, ii, nAnimals, evtOpts, outDir)
    logLines = strings(0,1);
    Sout = [];

    function lmsg(msg)
        logLines(end+1,1) = string(msg); %#ok<AGROW>
    end

    prefix = string(prefix);
    lmsg(sprintf('Events: %s (%d/%d)', char(prefix), ii, nAnimals));
    try
        [T, S] = meeg_eventdetect_run_animal(project, prefix, rowIdx, evtOpts, @lmsg);
        safePrefix = regexprep(char(prefix), '[^a-zA-Z0-9_\-]', '_');
        writetable(T, fullfile(outDir, sprintf('%s_event_detection_events.xlsx', safePrefix)));
        writetable(struct2table(S), fullfile(outDir, sprintf('%s_event_detection_summary.xlsx', safePrefix)));
        save(fullfile(outDir, sprintf('%s_event_detection.mat', safePrefix)), 'T', 'S', 'evtOpts', '-v7.3');
        Sout = S;
    catch ME
        lmsg(sprintf('  - ERROR: %s', ME.message));
    end
end

function local_emit_logs(logfn, lines)
    try
        for ii = 1:numel(lines)
            logfn(lines(ii));
        end
    catch
    end
end
