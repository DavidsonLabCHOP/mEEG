function C = meeg_get_group_colors(groups)
%MEEG_GET_GROUP_COLORS Return deterministic, non-repeating group colors.
%   The same treatment-group label always receives the same color within a
%   plot, repeated labels share a color, and distinct labels are prevented
%   from collapsing onto the same black/red pair. Familiar defaults are
%   retained where possible (WT=black; a single KO/disease group=red-orange;
%   vehicle=red; ASO-1=purple; ASO-2=green).

    labels = string(groups(:));
    labels(ismissing(labels) | strlength(strtrim(labels))==0) = "(unlabeled)";
    labels = strtrim(labels);

    if isempty(labels)
        C = zeros(0,3);
        return;
    end

    [uniqueLabels, ~, map] = unique(labels, 'stable');
    nUnique = numel(uniqueLabels);
    uniqueColors = nan(nUnique,3);

    % Fixed palette chosen to remain distinct on white backgrounds and in
    % exported figures. Preferred treatment colors are assigned first, then
    % unused palette colors fill all remaining groups.
    palette = [ ...
        0.000 0.447 0.741;  % blue
        0.850 0.325 0.098;  % orange
        0.494 0.184 0.556;  % purple
        0.466 0.674 0.188;  % green
        0.301 0.745 0.933;  % cyan
        0.929 0.694 0.125;  % gold
        0.635 0.078 0.184;  % burgundy
        0.850 0.475 0.700;  % pink
        0.300 0.650 0.550;  % teal
        0.550 0.420 0.300;  % brown
        0.500 0.500 0.500;  % gray
        0.740 0.740 0.130;  % olive
        0.200 0.200 0.700;  % deep blue
        0.700 0.300 0.700;  % magenta
        0.100 0.600 0.600;  % dark cyan
        0.900 0.550 0.100]; % amber

    used = zeros(0,3);

    % Assign non-conflicting familiar colors before generic palette colors.
    for i = 1:nUnique
        pref = local_preferred_color(uniqueLabels(i));
        if ~isempty(pref) && ~local_color_used(pref, used)
            uniqueColors(i,:) = pref;
            used(end+1,:) = pref; %#ok<AGROW>
        end
    end

    % Fill remaining labels from the fixed palette, skipping colors already
    % used by a preferred group. This guarantees no exact repeats.
    for i = 1:nUnique
        if all(isfinite(uniqueColors(i,:))), continue; end
        assigned = false;
        for p = 1:size(palette,1)
            candidate = palette(p,:);
            if ~local_color_used(candidate, used)
                uniqueColors(i,:) = candidate;
                used(end+1,:) = candidate; %#ok<AGROW>
                assigned = true;
                break;
            end
        end
        if ~assigned
            % More groups than the fixed palette: generate additional hues
            % and choose the first one not already used.
            extra = hsv(max(24, 2*nUnique));
            for p = 1:size(extra,1)
                candidate = 0.88*extra(p,:) + 0.04;
                if ~local_color_used(candidate, used)
                    uniqueColors(i,:) = candidate;
                    used(end+1,:) = candidate; %#ok<AGROW>
                    assigned = true;
                    break;
                end
            end
        end
        if ~assigned
            uniqueColors(i,:) = mod([0.37 0.61 0.83] * i, 1);
        end
    end

    C = uniqueColors(map,:);
end

function c = local_preferred_color(label)
    g = lower(strtrim(string(label)));
    c = [];

    if contains(g, "wildtype") || local_has_token(g, "wt")
        c = [0.000 0.000 0.000];       % black
    elseif contains(g, "vehicle")
        c = [0.900 0.100 0.100];       % red
    elseif contains(g, "aso-1") || contains(g, "aso1") || contains(g, "aso_1")
        c = [0.494 0.184 0.556];       % purple
    elseif contains(g, "aso-2") || contains(g, "aso2") || contains(g, "aso_2")
        c = [0.466 0.674 0.188];       % green
    elseif contains(g, "disease") || contains(g, "knockout") || local_has_token(g, "ko")
        c = [0.850 0.200 0.100];       % red-orange
    end
end

function tf = local_has_token(label, token)
    % Treat underscore, dash, spaces, and punctuation as token separators so
    % labels such as WT_1 and KO-treatment match without matching arbitrary
    % words that merely contain those letters.
    parts = split(regexprep(lower(string(label)), '[^a-z0-9]+', ' '));
    parts = parts(strlength(parts)>0);
    tf = any(parts == lower(string(token)));
end

function tf = local_color_used(candidate, used)
    if isempty(used)
        tf = false;
        return;
    end
    tf = any(max(abs(used - candidate), [], 2) < 1e-9);
end
