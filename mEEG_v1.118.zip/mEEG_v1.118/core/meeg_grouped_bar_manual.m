function [bh, xPos] = meeg_grouped_bar_manual(ax, Y, C, barWidth)
%MEEG_GROUPED_BAR_MANUAL Draw robust grouped bars for any number of categories/groups.
%   [BH, XPOS] = meeg_grouped_bar_manual(AX, Y, C) draws Y as
%   categories x groups. Unlike MATLAB bar(...,'grouped'), this preserves
%   one Bar object per group even when there is only one category/region.
%
%   XPOS is categories x groups and gives each bar center for error bars/dots.

    if nargin < 1 || isempty(ax), ax = gca; end
    if nargin < 2 || isempty(Y)
        bh = gobjects(0,1);
        xPos = [];
        return;
    end
    if nargin < 3 || isempty(C)
        C = lines(size(Y,2));
    end
    if nargin < 4 || isempty(barWidth)
        barWidth = 0.78;
    end

    Y = double(Y);
    [nCat, nGrp] = size(Y);
    bh = gobjects(nGrp,1);
    xPos = nan(nCat, nGrp);
    if nCat < 1 || nGrp < 1
        return;
    end

    centers = (1:nCat).';
    groupWidth = min(barWidth, nGrp/(nGrp + 1.5));
    singleWidth = groupWidth / max(nGrp,1);

    holdState = ishold(ax);
    hold(ax,'on');
    for gi = 1:nGrp
        offset = ((gi - 0.5) / nGrp - 0.5) * groupWidth;
        x = centers + offset;
        xPos(:,gi) = x;
        bh(gi) = bar(ax, x, Y(:,gi), singleWidth, 'FaceColor','flat', 'EdgeColor','k', 'LineWidth',0.75);
        try
            if size(C,1) >= gi
                bh(gi).CData = repmat(C(gi,:), nCat, 1);
            end
        catch
            try, bh(gi).FaceColor = C(gi,:); catch, end
        end
    end
    if ~holdState, hold(ax,'off'); end
end
