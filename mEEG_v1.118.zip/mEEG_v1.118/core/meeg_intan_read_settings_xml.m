function info = meeg_intan_read_settings_xml(xmlPath, fullpaths)
% Parse an Intan settings XML and map selected .dat files to canonical channel labels.
% The cage prefix (A/B/C/D) is used only to choose the correct SignalGroup.
% Backend labels are cage-independent, so A-004Hippo and C-004Hippo both map to Rhip.

    if nargin < 2 || isempty(fullpaths)
        error('Selected .dat file paths are required.');
    end
    if ~isfile(xmlPath)
        error('Settings XML not found: %s', xmlPath);
    end

    groupPrefix = local_group_from_files(fullpaths);
    if strlength(groupPrefix) == 0
        error('Could not infer Intan group prefix (A-D) from selected files.');
    end

    try
        dom = xmlread(xmlPath);
    catch ME
        error('Could not parse settings XML: %s', ME.message);
    end

    sgNodes = dom.getElementsByTagName('SignalGroup');
    entries = struct('NativeChannelName', {}, 'CustomChannelName', {}, 'Enabled', {}, 'UserOrder', {});
    for i = 0:sgNodes.getLength-1
        sg = sgNodes.item(i);
        pref = "";
        try
            pref = string(char(sg.getAttribute('Prefix')));
        catch
        end
        if ~strcmpi(pref, groupPrefix)
            continue;
        end
        chNodes = sg.getElementsByTagName('Channel');
        for j = 0:chNodes.getLength-1
            ch = chNodes.item(j);
            e = struct();
            e.NativeChannelName = string(char(ch.getAttribute('NativeChannelName')));
            e.CustomChannelName = string(char(ch.getAttribute('CustomChannelName')));
            e.Enabled = strcmpi(string(char(ch.getAttribute('Enabled'))), "True");
            uo = str2double(string(char(ch.getAttribute('UserOrder'))));
            if isnan(uo), uo = inf; end
            e.UserOrder = uo;
            entries(end+1) = e; %#ok<AGROW>
        end
        break;
    end

    if isempty(entries)
        error('No SignalGroup with Prefix="%s" was found in %s.', groupPrefix, xmlPath);
    end

    nativeNames = strings(numel(fullpaths),1);
    sourceNames = strings(numel(fullpaths),1);
    labels = strings(numel(fullpaths),1);

    for k = 1:numel(fullpaths)
        [nativeKey, orderNum] = local_native_from_filename(fullpaths{k});
        hit = [];
        if strlength(nativeKey) > 0
            for e = 1:numel(entries)
                if strcmpi(entries(e).NativeChannelName, nativeKey)
                    hit = e;
                    break;
                end
            end
        end
        if isempty(hit) && isfinite(orderNum)
            for e = 1:numel(entries)
                if entries(e).UserOrder == orderNum
                    hit = e;
                    break;
                end
            end
        end
        if isempty(hit)
            nativeNames(k) = "";
            sourceNames(k) = "";
            labels(k) = "Ch" + string(k);
            continue;
        end
        nativeNames(k) = entries(hit).NativeChannelName;
        sourceNames(k) = entries(hit).CustomChannelName;
        labels(k) = local_canonical_label(entries(hit).NativeChannelName, entries(hit).CustomChannelName);
    end

    info = struct();
    info.groupPrefix = char(groupPrefix);
    info.fileOrder = cellstr(labels(:))';
    info.sourceSignalLabels = cellstr(sourceNames(:))';
    info.nativeChannelNames = cellstr(nativeNames(:))';
    info.settingsXmlPath = char(xmlPath);
end

function grp = local_group_from_files(fullpaths)
    grp = "";
    for k = 1:numel(fullpaths)
        [~, name, ~] = fileparts(fullpaths{k});
        tok = regexp(name, '([A-D])-\d{3}', 'tokens', 'once');
        if ~isempty(tok)
            grp = string(tok{1});
            return;
        end
        tok = regexp(name, 'low-([A-D])', 'tokens', 'once');
        if ~isempty(tok)
            grp = string(tok{1});
            return;
        end
    end
end

function [nativeKey, orderNum] = local_native_from_filename(fp)
    [~, name, ~] = fileparts(fp);
    tok = regexp(name, '([A-D]-\d{3})', 'tokens', 'once');
    if isempty(tok)
        nativeKey = "";
    else
        nativeKey = string(tok{1});
    end
    numTok = regexp(name, '(\d{3})', 'tokens', 'once');
    if isempty(numTok)
        orderNum = NaN;
    else
        orderNum = str2double(numTok{1});
    end
end

function lbl = local_canonical_label(nativeName, customName)
    lbl = local_canonical_from_id(nativeName);
    if strlength(lbl) > 0
        return;
    end

    s = lower(regexprep(string(customName), '[^a-z0-9]', ''));
    if contains(s, 'hip')
        lbl = "Hippocampus";
    elseif contains(s, 'bar')
        lbl = "Barrel";
    elseif contains(s, 'mot')
        lbl = "Motor";
    elseif contains(s, 'vis')
        lbl = "Visual";
    elseif contains(s, 'aud')
        lbl = "Auditory";
    else
        lbl = string(customName);
    end
end

function lbl = local_canonical_from_id(nativeName)
    lbl = "";
    s = string(nativeName);
    tok = regexp(char(s), '(\d{3})', 'tokens', 'once');
    if isempty(tok)
        return;
    end
    leadId = tok{1};
    switch char(leadId)
        case '004'
            lbl = "hippocampus_R";
        case '011'
            lbl = "hippocampus_L";
        case '006'
            lbl = "barrel_R";
        case '009'
            lbl = "barrel_L";
        case '007'
            lbl = "motor_R";
        case '008'
            lbl = "motor_L";
        case '021'
            lbl = "visual_R";
        case '026'
            lbl = "visual_L";
        case '022'
            lbl = "auditory_R";
        case '025'
            lbl = "auditory_L";
        otherwise
            lbl = "";
    end
end
