function project = meeg_manifest_add(project, row, fullpaths, animalInfo)
% Add an animal to the project manifest and store its file list.

    % Append to manifest table
    T = project.manifest;
    newRow = {logical(row.Include), string(row.MouseID), string(row.TreatmentGroup), string(row.Genotype), string(row.Sex), ...
              string(row.DOB), string(row.RecordingDate), string(row.StartTime), string(row.LitterID), string(row.Notes)};
    T = [T; cell2table(newRow, 'VariableNames', T.Properties.VariableNames)];
    project.manifest = T;

    % Build output prefix (TreatmentGroup_MouseID)
    prefix = char(matlab.lang.makeValidName(string(row.TreatmentGroup) + "_" + string(row.MouseID)));

    % Store animal file info
    a = struct();
    a.files = fullpaths(:);
    if nargin >= 4 && isstruct(animalInfo) && isfield(animalInfo,'fileOrder') && ~isempty(animalInfo.fileOrder)
        a.fileOrder = animalInfo.fileOrder(:);
    else
        a.fileOrder = project.profile.channelLabels(:);
    end
    a.prefix = prefix;
    a.meta = row;
    a.sourceFile = '';
    a.sourceSignalLabels = {};
    a.assignedLabels = a.fileOrder;
    a.assignedRegionLabels = a.fileOrder;
    a.averageSameRegion = false;
    if nargin >= 4 && isstruct(animalInfo)
        fns = fieldnames(animalInfo);
        for ii = 1:numel(fns)
            try
                a.(fns{ii}) = animalInfo.(fns{ii});
            catch
            end
        end
    end


    % Normalize lead/region labels so older dot/dash labels never become
    % invalid MATLAB struct fields downstream (for example auditory.R).
    labelFields = {'fileOrder','assignedLabels','assignedRegionLabels'};
    for lf = 1:numel(labelFields)
        fn = labelFields{lf};
        if isfield(a, fn) && ~isempty(a.(fn))
            a.(fn) = cellstr(string(meeg_sanitize_lead_label(a.(fn)(:))));
        end
    end
    if isfield(a, 'assignCfg') && isstruct(a.assignCfg) && isfield(a.assignCfg, 'assignedRegionLabels') && ~isempty(a.assignCfg.assignedRegionLabels)
        a.assignCfg.assignedRegionLabels = cellstr(string(meeg_sanitize_lead_label(a.assignCfg.assignedRegionLabels(:))));
    end

    project.animals = local_append_struct(project.animals, a);
end

function S = local_append_struct(S, a)
% Append struct a to struct array S, padding fields as needed.

    if isempty(S)
        S = a;
        return;
    end

    sFields = fieldnames(S);
    aFields = fieldnames(a);
    allFields = [sFields; setdiff(aFields, sFields, 'stable')];

    for i = 1:numel(allFields)
        fn = allFields{i};
        if ~isfield(S, fn)
            [S.(fn)] = deal([]);
        end
        if ~isfield(a, fn)
            a.(fn) = [];
        end
    end

    S(end+1) = orderfields(a, S);
end
