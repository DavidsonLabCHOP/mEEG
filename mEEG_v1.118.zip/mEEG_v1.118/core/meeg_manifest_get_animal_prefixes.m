function [prefixes, rowIdx] = meeg_manifest_get_animal_prefixes(M)
% Robustly extract animal identifiers (prefixes) from a manifest table M.
% If AnimalPrefix exists, uses it. Otherwise tries common ID columns and
% optionally combines TreatmentGroup + ID into a unique prefix.

    prefixes = strings(0,1);
    rowIdx = [];

    if isempty(M) || ~istable(M) || height(M)==0
        return;
    end

    vars = string(M.Properties.VariableNames);

    % Preferred
    if any(vars=="AnimalPrefix")
        prefixes = string(M.AnimalPrefix);
        rowIdx = (1:height(M))';
        return;
    end

    % Candidate ID columns
    idCols = ["MouseID","AnimalID","Animal","Mouse","ID","Subject","SubjectID","Name"];
    idCol = "";
    for c = idCols
        if any(vars==c)
            idCol = c; break;
        end
    end

    if idCol == ""
        % fallback: first text-like column
        for k = 1:numel(vars)
            v = vars(k);
            if iscellstr(M.(v)) || isstring(M.(v)) || ischar(M.(v))
                idCol = v; break;
            end
        end
    end

    if idCol == ""
        % last resort: just numeric row numbers
        prefixes = "Animal" + string((1:height(M))');
        rowIdx = (1:height(M))';
        return;
    end

    ids = string(M.(idCol));

    % Optional combine with TreatmentGroup
    tgCols = ["TreatmentGroup","Group","GROUP_ID","Condition","Treatment"];
    tgCol = "";
    for c = tgCols
        if any(vars==c)
            tgCol = c; break;
        end
    end

    if tgCol ~= ""
        tg = string(M.(tgCol));
        prefixes = matlab.lang.makeValidName(tg + "_" + ids);
    else
        prefixes = matlab.lang.makeValidName(ids);
    end

    prefixes = string(prefixes);
    rowIdx = (1:height(M))';
end
