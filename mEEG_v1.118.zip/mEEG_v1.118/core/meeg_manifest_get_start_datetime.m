function dt = meeg_manifest_get_start_datetime(project, animalPrefix)
    dt = [];
    if isempty(project) || isempty(project.manifest) || height(project.manifest)==0, return; end
    M = project.manifest;
    prefix = string(animalPrefix);
    [prefixes, ~] = meeg_manifest_get_animal_prefixes(M);
    row = find(prefixes==prefix, 1);
    if isempty(row), return; end

    cand = ["RecordingStartDateTime","StartDateTime","EEGStartDateTime"];
    for c = cand
        if ismember(c, M.Properties.VariableNames)
            try
                v = M.(c)(row);
                if isdatetime(v), dt = v; return; end
                if isstring(v) || ischar(v)
                    tmp = datetime(string(v), 'InputFormat','yyyy-MM-dd HH:mm:ss');
                    if ~isnat(tmp), dt = tmp; return; end
                end
            catch
            end
        end
    end

    dateCols = ["RecordingDate","EEGDate","DateOfEEGRecording","Recording_Date"];
    timeCols = ["RecordingStartTime","StartTime","EEGStartTime","Recording_Time"];

    for dcol = dateCols
        if ~ismember(dcol, M.Properties.VariableNames), continue; end
        for tcol = timeCols
            if ~ismember(tcol, M.Properties.VariableNames), continue; end
            try
                d = parseDate(M.(dcol)(row));
                t = parseTime(M.(tcol)(row));
                if ~isempty(d) && ~isempty(t)
                    dt = d + timeofday(t);
                    return;
                end
            catch
            end
        end
    end
end

function d = parseDate(v)
    d = [];
    if isdatetime(v), d = dateshift(v,'start','day'); return; end
    if isnumeric(v) && isfinite(v)
        try, d = dateshift(datetime(v,'ConvertFrom','excel'),'start','day'); return; catch, end
    end
    s = string(v);
    if strlength(s)==0, return; end
    fmts = ["yyyy-MM-dd","MM/dd/yyyy","dd-MMM-yyyy","yyyyMMdd"];
    for f = fmts
        try
            tmp = datetime(s,'InputFormat',char(f));
            if ~isnat(tmp), d = dateshift(tmp,'start','day'); return; end
        catch
        end
    end
end

function t = parseTime(v)
    t = [];
    if iscell(v) && ~isempty(v), v = v{1}; end
    if isdatetime(v), t = v; return; end
    if isduration(v), t = datetime('today') + v; return; end
    if isnumeric(v) && isfinite(v)
        x = double(v(1));
        try
            if x >= 0 && x < 1
                t = datetime('today') + days(x); return;      % Excel fraction of day
            elseif x >= 0 && x < 24
                t = datetime('today') + hours(x); return;     % numeric clock hour, e.g. 11 = 11:00
            else
                frac = mod(x, 1);
                if frac > 0
                    t = datetime('today') + days(frac); return; % Excel datetime serial time part
                end
            end
        catch
        end
    end
    s = strtrim(string(v));
    if strlength(s)==0, return; end
    x = str2double(s);
    if isfinite(x)
        t = parseTime(x); return;
    end
    fmts = ["HH:mm:ss","HH:mm","H:mm:ss","H:mm","hh:mm:ss a","hh:mm a","h:mm:ss a","h:mm a","h a","ha"];
    for f = fmts
        try
            tmp = datetime(s,'InputFormat',char(f));
            if ~isnat(tmp), t = tmp; return; end
        catch
        end
    end
end
