function h = meeg_manifest_get_start_hour(project, animalPrefixOrRow, rowIdx)
%MEEG_MANIFEST_GET_START_HOUR Return recording start clock hour from manifest.
%   h is a scalar hour in [0,24), or NaN if unavailable.
%   This helper treats numeric StartTime values like 11 as 11:00 AM, not as
%   an Excel day/date serial. Numeric fractions such as 0.5 are treated as
%   fraction-of-day times, and Excel datetime serials use their fractional
%   time component.

    h = NaN;
    if nargin < 1 || isempty(project) || ~isfield(project,'manifest') || isempty(project.manifest) || height(project.manifest)==0
        return;
    end
    M = project.manifest;

    row = [];
    if nargin >= 3 && ~isempty(rowIdx) && isnumeric(rowIdx) && isfinite(rowIdx) && rowIdx >= 1 && rowIdx <= height(M)
        row = round(rowIdx);
    elseif nargin >= 2 && isnumeric(animalPrefixOrRow) && isfinite(animalPrefixOrRow) && animalPrefixOrRow >= 1 && animalPrefixOrRow <= height(M)
        row = round(animalPrefixOrRow);
    elseif nargin >= 2 && ~isempty(animalPrefixOrRow)
        prefix = string(animalPrefixOrRow);
        try
            [prefixes, ~] = meeg_manifest_get_animal_prefixes(M);
            row = find(string(prefixes(:)) == prefix, 1, 'first');
        catch
        end
        if isempty(row)
            try
                row = find(string(M.MouseID) == prefix, 1, 'first');
            catch
            end
        end
        if isempty(row)
            try
                row = find(string(M.AnimalID) == prefix, 1, 'first');
            catch
            end
        end
    end
    if isempty(row), return; end

    % Highest priority: explicit date-time columns.
    dtCols = ["RecordingStartDateTime","StartDateTime","EEGStartDateTime"];
    for c = dtCols
        if ismember(c, string(M.Properties.VariableNames))
            hh = local_parse_datetime_hour(local_cell_scalar(M.(c)(row)));
            if isfinite(hh), h = hh; return; end
        end
    end

    % Next priority: explicit numeric start-hour column.
    if ismember('RecordingStartHour', M.Properties.VariableNames)
        hh = local_parse_hour(local_cell_scalar(M.RecordingStartHour(row)));
        if isfinite(hh), h = hh; return; end
    end

    % Common manifest time columns. Numeric 11 means 11:00, not day 11.
    timeCols = ["RecordingStartTime","StartTime","EEGStartTime","Recording_Time"];
    for c = timeCols
        if ismember(c, string(M.Properties.VariableNames))
            hh = local_parse_hour(local_cell_scalar(M.(c)(row)));
            if isfinite(hh), h = hh; return; end
        end
    end

    % Fallback: if meeg_manifest_get_start_datetime can parse it, use that.
    try
        dt = meeg_manifest_get_start_datetime(project, animalPrefixOrRow);
        if ~isempty(dt) && ~isnat(dt)
            h = mod(hour(dt) + minute(dt)/60 + second(dt)/3600, 24);
        end
    catch
    end
end

function v = local_cell_scalar(v)
    try
        if iscell(v)
            if isempty(v), v = []; else, v = v{1}; end
        elseif isstring(v) && numel(v) > 1
            v = v(1);
        elseif isnumeric(v) && numel(v) > 1
            v = v(1);
        elseif isdatetime(v) && numel(v) > 1
            v = v(1);
        elseif isduration(v) && numel(v) > 1
            v = v(1);
        end
    catch
    end
end

function h = local_parse_datetime_hour(v)
    h = NaN;
    v = local_cell_scalar(v);
    if isempty(v), return; end
    if isdatetime(v)
        if ~isnat(v)
            h = mod(hour(v) + minute(v)/60 + second(v)/3600, 24);
        end
        return;
    end
    s = strtrim(char(string(v)));
    if isempty(s) || strcmpi(s,'missing') || strcmpi(s,'NaT'), return; end
    fmts = {'yyyy-MM-dd HH:mm:ss','yyyy-MM-dd HH:mm:ss.SSS','dd-MMM-yyyy HH:mm:ss', ...
            'dd.MM.yy HH:mm:ss','dd.MM.yyyy HH:mm:ss','MM/dd/yyyy HH:mm:ss', ...
            'MM/dd/yy HH:mm:ss','yyyy/MM/dd HH:mm:ss','yyyyMMdd HH:mm:ss'};
    for i = 1:numel(fmts)
        try
            dt = datetime(s, 'InputFormat', fmts{i});
            if ~isnat(dt)
                h = mod(hour(dt) + minute(dt)/60 + second(dt)/3600, 24);
                return;
            end
        catch
        end
    end
    try
        dt = datetime(s);
        if ~isnat(dt)
            h = mod(hour(dt) + minute(dt)/60 + second(dt)/3600, 24);
        end
    catch
    end
end

function h = local_parse_hour(v)
    h = NaN;
    v = local_cell_scalar(v);
    if isempty(v), return; end

    if isdatetime(v)
        if ~isnat(v)
            h = mod(hour(v) + minute(v)/60 + second(v)/3600, 24);
        end
        return;
    end
    if isduration(v)
        try
            h = mod(hours(v), 24);
        catch
            try, h = mod(double(v)*24, 24); catch, end
        end
        return;
    end
    if isnumeric(v)
        x = double(v(1));
        if ~isfinite(x), return; end
        if x >= 0 && x < 1
            h = mod(x * 24, 24);          % Excel fraction of day
        elseif x >= 0 && x < 24
            h = mod(x, 24);               % user-entered clock hour, e.g. 11
        else
            frac = mod(x, 1);             % Excel datetime serial with time fraction
            if frac > 0
                h = mod(frac * 24, 24);
            end
        end
        return;
    end

    s = strtrim(char(string(v)));
    if isempty(s) || strcmpi(s,'missing') || strcmpi(s,'NaT'), return; end

    x = str2double(s);
    if isfinite(x)
        h = local_parse_hour(x);
        return;
    end

    fmts = {'HH:mm:ss','HH:mm','H:mm:ss','H:mm','hh:mm:ss a','hh:mm a','h:mm:ss a','h:mm a','h a','ha'};
    for i = 1:numel(fmts)
        try
            dt = datetime(s, 'InputFormat', fmts{i});
            if ~isnat(dt)
                h = mod(hour(dt) + minute(dt)/60 + second(dt)/3600, 24);
                return;
            end
        catch
        end
    end

    % Last resort: strip common AM/PM spacing variants manually.
    try
        sl = lower(regexprep(s, '\s+', ''));
        tok = regexp(sl, '^(\d+(?:\.\d+)?)(am|pm)$', 'tokens', 'once');
        if ~isempty(tok)
            x = str2double(tok{1});
            if isfinite(x) && x >= 0 && x <= 12
                if strcmp(tok{2}, 'pm') && x < 12, x = x + 12; end
                if strcmp(tok{2}, 'am') && x == 12, x = 0; end
                h = mod(x, 24);
            end
        end
    catch
    end
end
