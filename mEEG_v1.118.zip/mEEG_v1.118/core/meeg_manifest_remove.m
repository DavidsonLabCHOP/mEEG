function project = meeg_manifest_remove(project, rowIdx)
% Remove one or more rows from manifest and animals list.
    rowIdx = unique(rowIdx(:));
    rowIdx = rowIdx(rowIdx >= 1 & rowIdx <= height(project.manifest));
    project.manifest(rowIdx,:) = [];
    project.animals(rowIdx) = [];
end
