function meeg_manifest_save(project)
% Save project.mat (full struct) + manifest.csv (human readable)

    outdir = project.outdir;
    if ~isfolder(outdir), mkdir(outdir); end

    save(fullfile(outdir, 'project.mat'), 'project');

    manifest = project.manifest;
    writetable(manifest, fullfile(outdir, 'manifest.csv'));
end
