function p = meeg_outdir(project, which, varargin)
%MEEG_OUTDIR Return standardized output subfolders.
%   p = meeg_outdir(project,'preprocessing',prefix)
%   p = meeg_outdir(project,'qeeg',prefix)
%
% Backward compatible: if project.outNames missing, defaults are used.

if nargin < 2 || isempty(which)
    error('meeg_outdir:MissingWhich','which is required');
end

which = lower(string(which));

preName = 'preprocessing';
qeegName = 'Results qEEG';

if isstruct(project) && isfield(project,'outNames')
    if isfield(project.outNames,'preproc') && ~isempty(project.outNames.preproc)
        preName = string(project.outNames.preproc);
    end
    if isfield(project.outNames,'qeeg') && ~isempty(project.outNames.qeeg)
        qeegName = string(project.outNames.qeeg);
    end
end

switch which
    case {"preproc","preprocessing"}
        base = char(preName);
    case {"qeeg","q_eeg"}
        base = char(qeegName);
    otherwise
        error('meeg_outdir:UnknownWhich','Unknown which: %s', which);
end

args = varargin;
if which == "qeeg" && ~isempty(args)
    firstArg = string(args{1});
    topLevelQEEG = ["BandAnalysis","Power Spectral Analysis","PS Analysis","Spike Analysis","SWD Analysis", ...
        "Event Detection (beta)","Raw Data Viewer","_group_summary","mEEG files (do not remove)"];
    isTopLevel = any(strcmpi(firstArg, topLevelQEEG));
    isAnimalPrefix = false;
    try
        if isfield(project,'animals') && ~isempty(project.animals)
            pfx = string({project.animals.prefix});
            isAnimalPrefix = any(pfx == firstArg);
        end
    catch
    end
    if isAnimalPrefix && ~isTopLevel
        args = [{char('mEEG files (do not remove)')}, args];
    end
end
p = fullfile(project.outdir, base, args{:});
end
