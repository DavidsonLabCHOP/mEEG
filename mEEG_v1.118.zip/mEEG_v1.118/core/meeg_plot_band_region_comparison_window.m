function hFig = meeg_plot_band_region_comparison_window(perAnimal, summary, bandName, whichTime, colorBy, outFolder)
% Create a region comparison figure for ONE band and Day/Night.
% - Bars show treatment-group means (with SE)
% - Dots show individual animals, colored by selected metadata when available.

    arguments
        perAnimal table
        summary table
        bandName {mustBeTextScalar}
        whichTime {mustBeTextScalar}
        colorBy {mustBeTextScalar}
        outFolder {mustBeTextScalar}
    end

    bandName  = lower(string(bandName));
    whichTime = lower(string(whichTime));
    colorBy   = string(colorBy);

    if ~(whichTime=="day" || whichTime=="night")
        error('whichTime must be ''day'' or ''night''.');
    end
    if ~isfolder(outFolder), mkdir(outFolder); end

    pa = perAnimal(lower(string(perAnimal.Band)) == bandName, :);
    sm = summary(lower(string(summary.Band)) == bandName, :);
    if isempty(pa) || isempty(sm)
        error('No data found for band %s.', bandName);
    end

    regions = unique(string(sm.Region), 'stable');
    groups  = unique(string(sm.TreatmentGroup), 'stable');
    regions(regions=="") = [];
    groups(groups=="") = [];
    if isempty(regions) || isempty(groups)
        error('No non-empty regions/groups found for band %s.', bandName);
    end
    Cg = meeg_get_group_colors(groups);

    if whichTime=="day"
        muCol = 'DayMean'; seCol = 'DaySE'; valCol = 'DayAvg';
        titleTime = 'day';
    else
        muCol = 'NightMean'; seCol = 'NightSE'; valCol = 'NightAvg';
        titleTime = 'night';
    end

    mu = nan(numel(groups), numel(regions));
    se = nan(numel(groups), numel(regions));
    for gi = 1:numel(groups)
        for ri = 1:numel(regions)
            idx = string(sm.TreatmentGroup)==groups(gi) & string(sm.Region)==regions(ri);
            if any(idx)
                k = find(idx, 1, 'first');
                mu(gi,ri) = sm{k, muCol};
                se(gi,ri) = sm{k, seCol};
            end
        end
    end

    hFig = figure('Color','w','Name',sprintf('Region Comparison (%s): %s', titleTime, bandName));
    ax = axes(hFig); hold(ax,'on');

    [bh, xPos] = meeg_grouped_bar_manual(ax, mu', Cg);

    for gi = 1:numel(groups)
        if gi > size(xPos,2), continue; end
        errorbar(ax, xPos(:,gi), mu(gi,:).', se(gi,:).', 'k', 'LineStyle','none', 'LineWidth', 1);
    end

    dotUsesSelectedMetadata = ismember(char(colorBy), pa.Properties.VariableNames);
    if dotUsesSelectedMetadata
        dotGroups = string(pa.(colorBy));
        dotCats = unique(dotGroups, 'stable');
    else
        dotGroups = string(pa.TreatmentGroup);
        dotCats = groups;
    end
    Cd = meeg_get_metadata_colors(max(1,numel(dotCats)));

    rng(0);
    for ri = 1:numel(regions)
        for gi = 1:numel(groups)
            idx = string(pa.Region)==regions(ri) & string(pa.TreatmentGroup)==groups(gi);
            if ~any(idx), continue; end
            y = pa{idx, valCol};
            if gi > size(xPos,2) || ri > size(xPos,1), continue; end
            x0 = xPos(ri,gi);
            x = x0 + (rand(size(y))-0.5)*0.12;

            cats = dotGroups(idx);
            for ci = 1:numel(dotCats)
                idc = cats==dotCats(ci);
                if ~any(idc), continue; end
                scatter(ax, x(idc), y(idc), 32, 'MarkerFaceColor', Cd(ci,:), 'MarkerEdgeColor','k', 'LineWidth', 0.5);
            end
        end
    end

    ax.XTick = 1:numel(regions);
    ax.XTickLabel = regions;
    ax.XTickLabelRotation = 30;
    ylabel(ax,'Power');
    title(ax, sprintf('Region Comparison (%s): %s', titleTime, bandName), 'Interpreter','none');

    dummyBar = gobjects(numel(groups),1);
    for gi = 1:numel(groups)
        dummyBar(gi) = scatter(ax, nan, nan, 40, 's', 'MarkerFaceColor', Cg(gi,:), 'MarkerEdgeColor','k');
    end
    dummy = gobjects(numel(dotCats),1);
    for ci = 1:numel(dotCats)
        dummy(ci) = scatter(ax, nan, nan, 32, 'MarkerFaceColor', Cd(ci,:), 'MarkerEdgeColor','k');
    end
    legend(ax, [dummyBar(:); dummy(:)], [strcat('Bar: ', cellstr(groups)); strcat('Dot: ', cellstr(dotCats))], 'Location','northeast', 'Interpreter','none');

    fname = sprintf('RegionComparison_%s_%s.png', char(titleTime), char(bandName));
    outPng = fullfile(outFolder, fname);
    meeg_save_png_svg(hFig, outPng, 'Resolution', 150);
end
