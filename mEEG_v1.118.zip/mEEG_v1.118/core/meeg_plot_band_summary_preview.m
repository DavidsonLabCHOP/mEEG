function meeg_plot_band_summary_preview(ax, summary, bandName, whichTime, perAnimal, colorBy)
% Preview grouped band plot for one band with optional individual points.
% whichTime: ''day'', ''night'', or ''combined''

    if nargin < 5, perAnimal = table(); end
    if nargin < 6 || isempty(colorBy), colorBy = "TreatmentGroup"; end

    if isempty(summary) || height(summary)==0
        cla(ax); text(ax, 0.1, 0.5, 'No data', 'FontSize', 12); return;
    end

    bandName = lower(string(bandName));
    whichTime = lower(string(whichTime));
    colorBy = string(colorBy);
    S = summary(lower(string(summary.Band)) == bandName, :);

    groups = string(unique(S.TreatmentGroup, 'stable'));
    groups(groups=="") = [];
    regions = string(unique(S.Region, 'stable'));
    regions(regions=="") = [];
    Cg = meeg_get_group_colors(groups);
    if isempty(groups) || isempty(regions)
        cla(ax); text(ax, 0.1, 0.5, 'No data', 'FontSize', 12); return;
    end

    M = nan(numel(regions), numel(groups));
    E = nan(numel(regions), numel(groups));
    for gi = 1:numel(groups)
        for ri = 1:numel(regions)
            sub = S(S.TreatmentGroup==groups(gi) & S.Region==regions(ri),:);
            if isempty(sub), continue; end
            if whichTime=="day"
                M(ri,gi) = sub.DayMean(1);
                E(ri,gi) = sub.DaySE(1);
                valCol = 'DayAvg';
            elseif whichTime=="night"
                M(ri,gi) = sub.NightMean(1);
                E(ri,gi) = sub.NightSE(1);
                valCol = 'NightAvg';
            else
                M(ri,gi) = mean([sub.DayMean(1), sub.NightMean(1)], 'omitnan');
                E(ri,gi) = mean([sub.DaySE(1), sub.NightSE(1)], 'omitnan');
                valCol = '';
            end
        end
    end

    cla(ax);
    hold(ax,'on');
    [b, xPos] = meeg_grouped_bar_manual(ax, M, Cg);
    for gi = 1:numel(groups)
        if gi > size(xPos,2), continue; end
        errorbar(ax, xPos(:,gi), M(:,gi), E(:,gi), 'k.', 'LineWidth', 1);
    end

    if ~isempty(perAnimal) && height(perAnimal)>0 && ismember('Band', perAnimal.Properties.VariableNames)
        PA = perAnimal(lower(string(perAnimal.Band)) == bandName, :);
        if ~isempty(PA)
            dotUsesSelectedMetadata = ismember(char(colorBy), PA.Properties.VariableNames);
            if dotUsesSelectedMetadata
                dotValsAll = string(PA.(colorBy));
                dotCats = unique(dotValsAll, 'stable');
            else
                dotCats = groups;
            end
            Cd = meeg_get_metadata_colors(max(1,numel(dotCats)));
            rng(0);
            for ri = 1:numel(regions)
                for gi = 1:numel(groups)
                    idx = string(PA.Region)==regions(ri) & string(PA.TreatmentGroup)==groups(gi);
                    if ~any(idx), continue; end
                    if whichTime=="combined"
                        y = mean([PA{idx, 'DayAvg'}, PA{idx, 'NightAvg'}], 2, 'omitnan');
                    else
                        y = PA{idx, valCol};
                    end
                    if gi > size(xPos,2) || ri > size(xPos,1), continue; end
                    x0 = xPos(ri,gi);
                    x = x0 + (rand(size(y))-0.5)*0.14;
                    if dotUsesSelectedMetadata
                        cats = string(PA.(colorBy));
                        cats = cats(idx);
                    else
                        cats = string(PA.TreatmentGroup(idx));
                    end
                    for ci = 1:numel(dotCats)
                        idc = cats==dotCats(ci);
                        if any(idc)
                            scatter(ax, x(idc), y(idc), 30, 'MarkerFaceColor', Cd(ci,:), 'MarkerEdgeColor','k', 'LineWidth',0.5);
                        end
                    end
                end
            end
        end
    end
    hold(ax,'off');

    ax.XTick = 1:numel(regions);
    ax.XTickLabel = regions;
    ax.XTickLabelRotation = 20;
    ylabel(ax, 'Band power (normalized area)');
    title(ax, sprintf('%s (%s): region means by treatment', bandName, whichTime), 'Interpreter','none');
    if ~isempty(perAnimal) && height(perAnimal)>0 && exist('dotCats','var') && ~isempty(dotCats)
        hold(ax,'on');
        dummyBar = gobjects(0,1);
        labelsBar = {};
        for gi = 1:numel(groups)
            h = plot(ax, nan, nan, 's', 'MarkerSize',10, ...
                'MarkerFaceColor', Cg(gi,:), 'MarkerEdgeColor','k', 'LineStyle','none', ...
                'HandleVisibility','on', 'Visible','off');
            if isgraphics(h)
                dummyBar(end+1,1) = h; %#ok<AGROW>
                labelsBar{end+1,1} = char("Bar: " + groups(gi)); %#ok<AGROW>
            end
        end
        dummyDot = gobjects(0,1);
        labelsDot = {};
        for ci = 1:numel(dotCats)
            h = plot(ax, nan, nan, 'o', 'MarkerSize',7, ...
                'MarkerFaceColor', Cd(ci,:), 'MarkerEdgeColor','k', 'LineStyle','none', ...
                'HandleVisibility','on', 'Visible','off');
            if isgraphics(h)
                dummyDot(end+1,1) = h; %#ok<AGROW>
                labelsDot{end+1,1} = char("Dot: " + dotCats(ci)); %#ok<AGROW>
            end
        end
        hold(ax,'off');

        legHandles = [dummyBar(:); dummyDot(:)];
        keep = arrayfun(@(h) isgraphics(h), legHandles);
        legHandles = legHandles(keep);
        allLabels = [labelsBar(:); labelsDot(:)];
        allLabels = allLabels(keep);
        if ~isempty(legHandles)
            lgd = legend(ax, legHandles, allLabels, 'Location','bestoutside', 'Interpreter','none');
            try, lgd.AutoUpdate = 'off'; catch, end
        else
            lgd = legend(ax, b, cellstr(groups), 'Location','bestoutside', 'Interpreter','none');
            try, lgd.AutoUpdate = 'off'; catch, end
        end
    else
        lgd = legend(ax, b, cellstr(groups), 'Location','bestoutside', 'Interpreter','none');
        try, lgd.AutoUpdate = 'off'; catch, end
    end
end
