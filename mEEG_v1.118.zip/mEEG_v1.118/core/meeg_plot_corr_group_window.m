function meeg_plot_corr_group_window(MA, MB, groupA, groupB, bandName, timePoint, climMax, outPng, leadLabels)
    if nargin < 7 || isempty(climMax), climMax = 1; end
    if nargin < 8, outPng = ''; end
    n = size(MA,1);
    if nargin < 9 || isempty(leadLabels)
        leadLabels = arrayfun(@(k) sprintf('Ch%d',k), 1:n, 'UniformOutput', false);
    end

    fig = figure('WindowState','maximized');
    t = tiledlayout(1,3,'TileSpacing','compact','Padding','compact');

    nexttile; imagesc(MA); axis image; title(sprintf('%s mean', groupA), 'Interpreter','none');
    set(gca,'XTick',1:n,'XTickLabel',leadLabels,'YTick',1:n,'YTickLabel',leadLabels); xtickangle(45);
    caxis([-climMax climMax]); colorbar;

    nexttile; imagesc(MB); axis image; title(sprintf('%s mean', groupB), 'Interpreter','none');
    set(gca,'XTick',1:n,'XTickLabel',leadLabels,'YTick',1:n,'YTickLabel',leadLabels); xtickangle(45);
    caxis([-climMax climMax]); colorbar;

    nexttile; imagesc(MA-MB); axis image; title('Difference (A - B)');
    set(gca,'XTick',1:n,'XTickLabel',leadLabels,'YTick',1:n,'YTickLabel',leadLabels); xtickangle(45);
    caxis([-climMax climMax]); colorbar;

    title(t, sprintf('Correlation — %s (%s)', bandName, timePoint), 'FontSize', 16);

    if ~isempty(outPng)
        meeg_save_png_svg(fig, outPng, 'Resolution', 300)
    end
end
