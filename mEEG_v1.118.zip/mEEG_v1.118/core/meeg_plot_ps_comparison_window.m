function meeg_plot_ps_comparison_window(spec, f, meta, whichTime, opts)
% Plot PS comparisons across treatment groups (optionally individual animal lines).
%
% spec: freq x region(5) x time(2) x animal
% meta: struct with TreatmentGroup, Sex, etc.
% whichTime: 'day', 'night', or 'combined'
% opts:
%   .fmin (default 0.4)
%   .fmax (default 12)
%   .showIndividuals (default false)
%   .colorIndividualsBy (default 'TreatmentGroup')
%   .shadeBands (default true)
%   .outFolder (optional) save PNG

    if nargin < 5, opts = struct(); end
    if ~isfield(opts,'fmin'), opts.fmin = 0.4; end
    if ~isfield(opts,'fmax'), opts.fmax = 12; end
    if ~isfield(opts,'showIndividuals'), opts.showIndividuals = false; end
    if ~isfield(opts,'colorIndividualsBy'), opts.colorIndividualsBy = "TreatmentGroup"; end
    if ~isfield(opts,'shadeBands'), opts.shadeBands = true; end
    if ~isfield(opts,'outFolder'), opts.outFolder = ""; end

    f = double(f(:));
    if size(spec,1) ~= numel(f)
        error('meeg_plot_ps_comparison_window:SizeMismatch', ...
            'PSD data must have one row per frequency value.');
    end
    keepFreq = isfinite(f) & f >= 0.4;
    if ~any(keepFreq)
        error('No PSD frequencies at or above 0.4 Hz were found.');
    end
    f = f(keepFreq);
    spec = spec(keepFreq,:,:,:);
    opts.fmin = max(0.4, double(opts.fmin));
    if opts.fmax <= opts.fmin
        error('Maximum PSD frequency must be greater than 0.4 Hz and the selected minimum.');
    end
    visibleFreq = f >= opts.fmin & f <= opts.fmax;
    if ~any(visibleFreq)
        error('No PSD frequencies fall within the selected plotting range.');
    end

    whichTime = lower(string(whichTime));
    useCombined = false;
    if whichTime=="day"
        t = 1;
    elseif whichTime=="night"
        t = 2;
    else
        useCombined = true;
        t = [];
    end

    if isfield(meta,'RegionNames') && ~isempty(meta.RegionNames)
        regions = string(meta.RegionNames(:))';
    else
        regions = ["Hippocampus","Barrel","Motor","Visual","Auditory"];
    end
    regions(regions=="") = [];

    groups = string(meta.TreatmentGroup);
    uniqG = unique(groups, 'stable');
    groupColors = meeg_get_group_colors(uniqG);


    fig = figure('WindowState','maximized');
    nR = max(1,numel(regions));
    nCols = min(3, nR);
    nRows = ceil(nR/nCols);
    tlo = tiledlayout(nRows,nCols,'TileSpacing','compact','Padding','compact');

    legendHandles = gobjects(numel(uniqG),1);
    for r = 1:numel(regions)
        ax = nexttile;
        hold(ax, 'on');

        if useCombined
            Yall = squeeze(mean(spec(:,r,1:2,:), 3, 'omitnan'));
        else
            Yall = squeeze(spec(:,r,t,:));
        end
        if isvector(Yall), Yall = Yall(:); end
        ymax = max(1, nanmax(Yall(visibleFreq,:), [], 'all') * 1.05);
        if opts.shadeBands
            patch(ax, [0.4 4 4 0.4], [0 0 ymax ymax], [0.80 0.80 0.80], 'EdgeColor','none', 'FaceAlpha',0.28, 'HandleVisibility','off');
            patch(ax, [4 8 8 4], [0 0 ymax ymax], [0.88 0.88 0.88], 'EdgeColor','none', 'FaceAlpha',0.28, 'HandleVisibility','off');
            patch(ax, [8 13 13 8], [0 0 ymax ymax], [0.94 0.94 0.94], 'EdgeColor','none', 'FaceAlpha',0.28, 'HandleVisibility','off');
            patch(ax, [13 30 30 13], [0 0 ymax ymax], [0.97 0.97 0.97], 'EdgeColor','none', 'FaceAlpha',0.28, 'HandleVisibility','off');
        end

        if isfield(meta,'MouseID')
            animalIDs = string(meta.MouseID);
        else
            animalIDs = strings(0,1);
        end
        hGroup = meeg_ps_plot_group_curves(ax, f, Yall, groups, groupColors, ...
            logical(opts.showIndividuals), animalIDs, opts.fmin, opts.fmax);
        if r == 1
            legendHandles = hGroup;
        end

        title(ax, char(regions(r)));
        xlabel(ax, 'Frequency (Hz)');
        ylabel(ax, 'Amplitude (\muV^2/Hz)');
        meeg_ps_apply_band_ticks(ax, opts.fmin, opts.fmax);
        ylim(ax, [0 ymax]);
        grid(ax, 'on');
        hold(ax, 'off');
    end

    title(tlo, sprintf('Power spectral density (%s)', whichTime), 'FontSize', 16);
    valid = isgraphics(legendHandles);
    if any(valid)
        legend(legendHandles(valid), cellstr(uniqG(valid)), 'Location','best');
    end

    if strlength(opts.outFolder) > 0
        if ~isfolder(opts.outFolder), mkdir(opts.outFolder); end
        fname = sprintf('PSD_%s_fmin-%g_fmax-%g.png', whichTime, opts.fmin, opts.fmax);
        meeg_save_png_svg(fig, fullfile(opts.outFolder, fname),'Resolution',600);
    end
end
