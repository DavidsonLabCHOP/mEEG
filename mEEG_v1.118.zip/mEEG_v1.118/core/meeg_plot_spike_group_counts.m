function [hFig, Texport] = meeg_plot_spike_group_counts(project, timePoint, dayStart, dayEnd, countType, yScaleHours, colorBy, outPng, selectedGroups)
% Plot lead-level spike counts in the same general style as normalized band power.
% countType: 'single' or 'multilead'
% yScaleHours controls conversion from average per 30-min block to a larger window.

    if nargin < 5 || isempty(countType), countType = 'single'; end
    if nargin < 6 || isempty(yScaleHours), yScaleHours = 0.5; end
    if nargin < 7 || isempty(colorBy), colorBy = "TreatmentGroup"; end
    if nargin < 8, outPng = ''; end
    if nargin < 9, selectedGroups = strings(0,1); end

    Tall = meeg_spike_collect_per_animal(project, timePoint, dayStart, dayEnd, countType);
    if isempty(Tall) || height(Tall)==0
        error('No spike tables found.');
    end

    allGroups = unique(string(Tall.TreatmentGroup), 'stable');
    allGroups(allGroups=="") = [];
    selectedGroups = string(selectedGroups(:));
    selectedGroups = selectedGroups(selectedGroups~="" & selectedGroups~="(none)");
    if isempty(selectedGroups)
        groups = allGroups;
    else
        groups = selectedGroups;
    end

    T = Tall(ismember(string(Tall.TreatmentGroup), groups), :);
    if isempty(T) || height(T)==0
        error('No spike data found for the selected group(s).');
    end

    leadLabels = unique(string(T.Lead), 'stable');
    leadLabels(leadLabels=="") = [];
    groups = unique(string(T.TreatmentGroup), 'stable');
    groups(groups=="") = [];
    Cg = meeg_get_group_colors(groups);

    scaleFactor = yScaleHours / 0.5;
    T.DisplaySpikeCount = T.SpikeCount * scaleFactor;
    T.DisplayWindowHours = repmat(yScaleHours, height(T), 1);

    colorVar = string(colorBy);
    dotUsesSelectedMetadata = ismember(char(colorVar), T.Properties.VariableNames);
    if dotUsesSelectedMetadata
        dotGroups = string(T.(char(colorVar)));
        dotCats = unique(dotGroups, 'stable');
        dotCats(dotCats=="") = [];
    else
        dotGroups = string(T.TreatmentGroup);
        dotCats = groups;
    end
    if isempty(dotCats)
        dotCats = groups;
        dotGroups = string(T.TreatmentGroup);
    end
    Cd = meeg_get_metadata_colors(max(1, numel(dotCats)));

    mu = nan(numel(groups), numel(leadLabels));
    se = nan(numel(groups), numel(leadLabels));
    for gi = 1:numel(groups)
        for ri = 1:numel(leadLabels)
            idx = string(T.TreatmentGroup)==groups(gi) & string(T.Lead)==leadLabels(ri);
            y = T.DisplaySpikeCount(idx);
            mu(gi,ri) = mean(y, 'omitnan');
            se(gi,ri) = std(y, 0, 'omitnan') ./ max(1, sqrt(sum(~isnan(y))));
        end
    end

    timeLabel = string(timePoint);
    if timeLabel == "all"
        timeLabel = "combined (day and night)";
    end
    countLabel = 'Single-lead spikes';
    if string(countType) == "multilead", countLabel = 'Multi-lead spikes'; end

    hFig = figure('Color','w','Name',sprintf('Spike Analysis (%s)', timeLabel));
    ax = axes(hFig); hold(ax,'on');

    [~, xPos] = meeg_grouped_bar_manual(ax, mu', Cg, 0.78);
    for gi = 1:numel(groups)
        errorbar(ax, xPos(:,gi)', mu(gi,:), se(gi,:), 'k', 'LineStyle','none', 'LineWidth', 1);
    end

    rng(0);
    for ri = 1:numel(leadLabels)
        for gi = 1:numel(groups)
            idx = string(T.Lead)==leadLabels(ri) & string(T.TreatmentGroup)==groups(gi);
            if ~any(idx), continue; end
            y = T.DisplaySpikeCount(idx);
            x0 = xPos(ri,gi);
            x = x0 + (rand(size(y))-0.5)*0.12;
            cats = dotGroups(idx);
            for ci = 1:numel(dotCats)
                idc = cats==dotCats(ci);
                if ~any(idc), continue; end
                scatter(ax, x(idc), y(idc), 32, 'MarkerFaceColor', Cd(ci,:), 'MarkerEdgeColor', 'k', 'LineWidth', 0.5);
            end
        end
    end

    set(ax, 'XLim', [0.5 numel(leadLabels)+0.5], 'XTick', 1:numel(leadLabels), 'XTickLabel', cellstr(leadLabels));
    xtickangle(ax, 35);
    ylabel(ax, sprintf('Avg spikes per %.1f hr', yScaleHours));
    title(ax, sprintf('Spike Analysis — %s (%s)', countLabel, timeLabel), 'Interpreter', 'none');
    grid(ax, 'on');

    dummyBar = gobjects(numel(groups),1);
    for gi = 1:numel(groups)
        dummyBar(gi) = scatter(ax, nan, nan, 40, 's', 'MarkerFaceColor', Cg(gi,:), 'MarkerEdgeColor','k');
    end
    dummyDot = gobjects(numel(dotCats),1);
    for ci = 1:numel(dotCats)
        dummyDot(ci) = scatter(ax, nan, nan, 32, 'MarkerFaceColor', Cd(ci,:), 'MarkerEdgeColor','k');
    end
    legHandles = dummyBar(:);
    legLabels = strcat('Bar: ', cellstr(groups));
    if ~isequal(cellstr(groups), cellstr(dotCats)) || colorVar ~= "TreatmentGroup"
        legHandles = [legHandles; dummyDot(:)]; %#ok<AGROW>
        legLabels = [legLabels; strcat('Dot: ', cellstr(dotCats))]; %#ok<AGROW>
    end
    legend(ax, legHandles, legLabels, 'Location','northeast', 'Interpreter','none');

    keepVars = intersect(["Prefix","Lead","Region","SpikeCount","DisplaySpikeCount","DisplayWindowHours","CountType","TreatmentGroup","Sex","LitterID","RecordingDate","Genotype","MouseID"], string(T.Properties.VariableNames), 'stable');
    Texport = T(:, cellstr(keepVars));
    if ~isempty(outPng)
        meeg_save_png_svg(hFig, outPng, 'Resolution', 300);
    end
end
