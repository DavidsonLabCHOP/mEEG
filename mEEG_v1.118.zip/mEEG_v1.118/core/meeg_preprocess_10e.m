function [qcSummary, qcHeat] = meeg_preprocess_10e(project, animalIdx, params, progressFcn)
% Preprocess one animal (10-electrode system).
%
% Outputs saved to:
%   <outdir>/preprocessing/<prefix>/
%     qc_summary.csv
%     lowQEpochMask.mat      (logical: nCh x nEpochsTotal)
%     goodQChannelMask.mat        (logical: nCh x nPeriods)
%     parameters_used.mat
%     qc_lowQEpochPercent_<ANIMAL_ID>.png
%     qc_badEpochHeatmap_<ANIMAL_ID>.png
%
% Notes:
% - To keep disk usage manageable, by default we store QC metrics + masks
%   (bad epochs, good/bad channels) rather than writing fully "cleaned" data.
% - Later analysis stages can re-read raw files and apply the saved masks.

    arguments
        project (1,1) struct
        animalIdx (1,1) double {mustBePositive}
        params (1,1) struct
        progressFcn = []
    end

    prof = project.profile;
    a = project.animals(animalIdx);
    files = a.files;

    nCh = prof.nChannels;
    if numel(files) ~= nCh
        error('Animal %d has %d files, expected %d.', animalIdx, numel(files), nCh);
    end

    fs = params.fs;
    windowSec = prof.preproc.windowSec;
    sampsPerWindow = round(fs * windowSec);
    bytesPerSample = prof.bytesPerSample;
    scale_uV = prof.scale_uV;

    % derive binning
    rmsBinSec = params.rmsBinSec;
    if abs((windowSec/rmsBinSec) - round(windowSec/rmsBinSec)) > 1e-6
        error('windowSec (%g) must be divisible by rmsBinSec (%g).', windowSec, rmsBinSec);
    end
    binsPerWindow = round(windowSec / rmsBinSec);
    sampsPerBin = round(fs * rmsBinSec);

    epochSec = params.epochSec;
    binsPerEpoch = max(1, ceil(epochSec / rmsBinSec));
    nEpochs = floor(binsPerWindow / binsPerEpoch);
    sampsPerEpoch = sampsPerBin * binsPerEpoch;

    % compute recording periods robustly across channels (min length)
    samplesPerFile = zeros(1,nCh);
    for k = 1:nCh
        info = dir(files{k});
        samplesPerFile(k) = floor(double(info.bytes) / bytesPerSample);
    end
    samplesPerFileMin = min(samplesPerFile);
    recPeriods = floor(samplesPerFileMin / sampsPerWindow);
    if recPeriods < 1
        error('Computed recPeriods < 1 for animal %d. Check fs/file sizes.', animalIdx);
    end

    fileHours = (samplesPerFileMin / fs) / 3600;
    procHours = (recPeriods * windowSec) / 3600;

    % ---------- per-animal log file (useful for crash recovery) ----------
    outBase = meeg_outdir(project,'preprocessing', a.prefix);
    if ~isfolder(outBase), mkdir(outBase); end
    logFile = fullfile(outBase, 'preproc_log.txt');
    lf = fopen(logFile, 'a');
    if lf ~= -1
        fprintf(lf, '[%s] Preproc start | file length ~%.2f h, processing %.2f h (%d periods)\n', datestr(now,'yyyy-mm-dd HH:MM:SS'), fileHours, procHours, recPeriods);
        fclose(lf);
    end

    if ~isempty(progressFcn)
        try
            progressFcn(struct('type','coverage','animalIdx',animalIdx,'prefix',a.prefix, ...
                'fileHours',fileHours,'procHours',procHours,'recPeriods',recPeriods));
        catch
        end
    end

    % notch
    if params.notch.enabled
        applyNotch = meeg_buildNotch(fs, params.notch.f1, params.notch.f2);
    else
        applyNotch = @(x) x;
    end

    % outputs to accumulate
    goodChByPeriod = false(nCh, recPeriods);
    badEpochAll = false(nCh, recPeriods*nEpochs);
    badEpochPctByPeriod = zeros(recPeriods,1);

    % buffer
    v = zeros(nCh, sampsPerWindow);

    stopFile = '';
    try
        if isfield(params, 'stopFile') && ~isempty(params.stopFile)
            stopFile = char(params.stopFile);
        end
    catch
        stopFile = '';
    end

    % ---------- open all channel files once (major speed win) ----------
    fid = zeros(1,nCh);
    for ch = 1:nCh
        fid(ch) = fopen(files{ch}, 'r');
        if fid(ch) == -1
            error('Could not open %s', files{ch});
        end
    end
    c = onCleanup(@() closeAll(fid));

    for t = 1:recPeriods
        if ~isempty(stopFile) && isfile(stopFile)
            try, clear c; catch, end
            try
                if isfolder(outBase), rmdir(outBase, 's'); end
            catch
            end
            qcSummary = struct('canceled', true, 'prefix', a.prefix);
            qcHeat = [];
            return;
        end
        if ~isempty(progressFcn)
            try
                progressFcn(struct('type','period','animalIdx',animalIdx,'prefix',a.prefix,'period',t,'nPeriods',recPeriods));
            catch
            end
        end

        % ----- read 30-min block per channel (byte seek) -----
        for ch = 1:nCh
            offsetBytes = int64(t-1) * int64(sampsPerWindow) * int64(bytesPerSample);
            if fseek(fid(ch), offsetBytes, 'bof') ~= 0
                error('fseek failed: %s @ byte %s', files{ch}, string(offsetBytes));
            end

            raw = fread(fid(ch), sampsPerWindow, 'int16=>double');

            if numel(raw) < sampsPerWindow
                error('Short read: %s expected %d samples, got %d', files{ch}, sampsPerWindow, numel(raw));
            end

            v(ch,:) = applyNotch(raw(:)' * scale_uV);
        end

        % ----- RMS + skewness per bin (default 1 s) -----
        skwAvg = zeros(nCh,1); rmsAvg = zeros(nCh,1);
        zscore_rms = zeros(nCh, binsPerWindow);
        for ch = 1:nCh
            X = reshape(v(ch,1:(sampsPerBin*binsPerWindow)), sampsPerBin, binsPerWindow); % sampsPerBin x bins
            r = sqrt(mean(X.^2, 1));

            mu = mean(X,1); sd = std(X,0,1);
            s = mean(((X - mu)./max(sd, eps)).^3, 1);

            skwAvg(ch) = mean(s);
            rmsAvg(ch) = mean(r);

            zscore_rms(ch,:) = (r - mean(r)) / max(std(r), eps);
        end

        % channel quality (legacy thresholds)
        goodCh = ~( (rmsAvg > params.rmsHigh) | (rmsAvg < params.rmsLow) | (skwAvg > params.skwHigh) );
        goodChByPeriod(:,t) = goodCh;

        % ----- bad epochs by max |z| within each epoch -----
        maxZ = zeros(nCh, nEpochs);
        for ch = 1:nCh
            for e = 1:nEpochs
                idxB = (e-1)*binsPerEpoch + (1:binsPerEpoch);
                maxZ(ch,e) = max(abs(zscore_rms(ch, idxB)));
            end
        end
        badEpoch = maxZ >= params.zThresh; % nCh x nEpochs

        % ----- apply mask (zero epochs, per channel) -----
        for ch = 1:nCh
            for e = 1:nEpochs
                if badEpoch(ch,e)
                    idx = (e-1)*sampsPerEpoch + (1:sampsPerEpoch);
                    v(ch, idx) = 0;
                end
            end
        end

        % store period-wise
        col0 = (t-1)*nEpochs + 1;
        badEpochAll(:, col0:col0+nEpochs-1) = badEpoch;
        badEpochPctByPeriod(t) = mean(badEpoch(:)) * 100;
    end

    if ~isempty(stopFile) && isfile(stopFile)
        try, clear c; catch, end
        try
            if isfolder(outBase), rmdir(outBase, 's'); end
        catch
        end
        qcSummary = struct('canceled', true, 'prefix', a.prefix);
        qcHeat = [];
        return;
    end

    % ---------- QC summary ----------
    badEpochPctByCh = mean(badEpochAll, 2) * 100;
    goodChPctByCh = mean(goodChByPeriod, 2) * 100;

    qcSummary = struct();
    qcSummary.badEpochPctByCh = badEpochPctByCh;
    qcSummary.goodChPctByCh = goodChPctByCh;
    qcSummary.badEpochPctByPeriod = badEpochPctByPeriod;
    qcSummary.recPeriods = recPeriods;
    qcSummary.nEpochsPerPeriod = nEpochs;
    qcSummary.fileHours = fileHours;
    qcSummary.procHours = procHours;

    qcHeat = badEpochAll; % for UI preview (channels x epochIndex)

    % ---------- save outputs ----------

    % csv summary
    T = table((1:nCh)', string(prof.channelLabels(:)), badEpochPctByCh, goodChPctByCh, ...
        'VariableNames', {'ChannelIndex','ChannelLabel','BadEpochPct','GoodChannelPct'});
    writetable(T, fullfile(outBase, 'qc_summary.csv'));

    save(fullfile(outBase, 'lowQEpochMask.mat'), 'badEpochAll');
    save(fullfile(outBase, 'goodQChannelMask.mat'), 'goodChByPeriod');
    save(fullfile(outBase, 'parameters_used.mat'), 'params');

    % QC figures
    f1 = figure('Visible','off'); bar(badEpochPctByCh); xticks(1:nCh); xticklabels(prof.channelLabels); xtickangle(45);
    ylabel('% of EEG that is poor quality');
    title({'Percentage of artifact epochs that do not pass quality control', '(% of the high-quality channels that did not meet quality control standards)'});
    meeg_save_png_svg(f1, fullfile(outBase, ['qc_lowQEpochPercent_' char(a.prefix) '.png']),'Resolution',150); close(f1);

    f2 = figure('Visible','off'); imagesc(double(badEpochAll)); colorbar; ylabel('Channel'); xlabel('5 second epochs');
    yticks(1:nCh); yticklabels(prof.channelLabels); title({'Low quality artifact epochs', '(visualization of low-quality epochs for the entire EEG recording)'});
    meeg_save_png_svg(f2, fullfile(outBase, ['qc_badEpochHeatmap_' char(a.prefix) '.png']),'Resolution',150); close(f2);

    % Good channel percent by channel
    f3 = figure('Visible','off'); bar(goodChPctByCh); xticks(1:nCh); xticklabels(prof.channelLabels); xtickangle(45);
    ylim([0 100]);
    ylabel('% of EEG recording that is high quality');
    title({'Percentage of EEG recording that passed quality control', '(% of 30 minute epochs that meet quality standards)'});
    meeg_save_png_svg(f3, fullfile(outBase, ['qc_goodQChannelPct_' char(a.prefix) '.png']),'Resolution',150); close(f3);

    % finish log
    lf = fopen(logFile, 'a');
    if lf ~= -1
        fprintf(lf, '[%s] Preproc done\n', datestr(now,'yyyy-mm-dd HH:MM:SS'));
        fclose(lf);
    end

    if ~isempty(progressFcn)
        try
            progressFcn(struct('type','done','animalIdx',animalIdx,'prefix',a.prefix));
        catch
        end
    end
end

function closeAll(fid)
    for k = 1:numel(fid)
        try
            if fid(k) > 0
                fclose(fid(k));
            end
        catch
        end
    end
end
