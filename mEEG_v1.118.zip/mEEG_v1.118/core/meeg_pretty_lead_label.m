function out = meeg_pretty_lead_label(lbl)
% Convert compact lead labels like Rhip or Lmot into human-readable dot style.
    s = string(lbl);
    mapIn = ["Rhip","Lhip","Rbar","Lbar","Rmot","Lmot","Raud","Laud","Rvis","Lvis"];
    mapOut = ["hippocampus_R","hippocampus_L","barrel_R","barrel_L","motor_R","motor_L","auditory_R","auditory_L","visual_R","visual_L"];
    out = s;
    for k = 1:numel(mapIn)
        out(s==mapIn(k)) = mapOut(k);
    end
end
