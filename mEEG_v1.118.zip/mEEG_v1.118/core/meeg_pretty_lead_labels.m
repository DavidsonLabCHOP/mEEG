function out = meeg_pretty_lead_labels(lbls)
    s = string(lbls);
    out = s;
    for i = 1:numel(s)
        out(i) = meeg_pretty_lead_label(s(i));
    end
    if iscell(lbls)
        out = cellstr(out);
    end
end
