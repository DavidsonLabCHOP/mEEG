function r = meeg_pretty_region_label(lbl)
%MEEG_PRETTY_REGION_LABEL Convert sanitized or display lead labels to display regions.
%   Preserves user-assigned laterality for labels such as Motor_L,
%   Motor (L), motor-R, auditory.R, etc. Area A-E labels are preserved.

    raw = string(lbl);
    s = lower(strtrim(raw));
    compact = lower(regexprep(s, '[^a-z0-9]', ''));

    hemi = "";
    if ~isempty(regexp(char(s), '(\(|_|-|\.|\s)(l|left)\)?\s*$', 'once')) || endsWith(compact, "left")
        hemi = "L";
    elseif ~isempty(regexp(char(s), '(\(|_|-|\.|\s)(r|right)\)?\s*$', 'once')) || endsWith(compact, "right")
        hemi = "R";
    end

    base = raw;
    if contains(compact,'hip')
        base = "Hippocampus";
    elseif contains(compact,'bar')
        base = "Barrel";
    elseif contains(compact,'mot')
        base = "Motor";
    elseif contains(compact,'vis')
        base = "Visual";
    elseif contains(compact,'aud')
        base = "Auditory";
    elseif contains(compact,'medialprefrontal') || contains(compact,'prefrontal') || contains(compact,'mpfc')
        base = "Medial prefrontal";
    elseif contains(compact,'retrosplenial') || contains(compact,'rsp')
        base = "Retrosplenial";
    elseif contains(compact,'pariet')
        base = "Parietal";
    elseif contains(compact,'cing')
        base = "Cingulate";
    elseif contains(compact,'thal')
        base = "Thalamus";
    elseif contains(compact,'stri')
        base = "Striatum";
    elseif contains(compact,'areaa')
        base = "Area A"; hemi = "";
    elseif contains(compact,'areab')
        base = "Area B"; hemi = "";
    elseif contains(compact,'areac')
        base = "Area C"; hemi = "";
    elseif contains(compact,'aread')
        base = "Area D"; hemi = "";
    elseif contains(compact,'areae')
        base = "Area E"; hemi = "";
    else
        base = strrep(raw, '_', ' ');
        base = strrep(base, '-', ' ');
        base = strtrim(base);
    end

    lateralBases = ["Motor","Barrel","Visual","Auditory","Hippocampus","Medial prefrontal", ...
        "Retrosplenial","Parietal","Cingulate","Thalamus","Striatum"];
    if strlength(hemi) > 0 && any(string(base) == lateralBases)
        r = string(base) + " (" + hemi + ")";
    else
        r = string(base);
    end
end
