function n = meeg_profile_nch(profile)
% Return number of channels from a profile struct (backward compatible).
    n = [];
    if isstruct(profile)
        if isfield(profile,'nChannels'), n = profile.nChannels; return; end
        if isfield(profile,'numCh'), n = meeg_profile_nch(profile); return; end
        if isfield(profile,'nCh'), n = profile.nCh; return; end
    end
    n = 0;
end
