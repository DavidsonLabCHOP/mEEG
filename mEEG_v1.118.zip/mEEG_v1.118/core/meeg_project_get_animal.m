function [a, idx] = meeg_project_get_animal(project, animalPrefix)
% Return animal struct from project.animals by prefix.
% Exact matching is preferred. A unique punctuation-insensitive fallback
% handles legacy projects where the manifest used makeValidName (for example
% WT_2_3) while project.animals retained punctuation (for example WT_2-3).

    a = [];
    idx = [];
    if ~isfield(project,'animals') || isempty(project.animals), return; end

    pref = string(animalPrefix);
    allp = string({project.animals.prefix});

    idx = find(allp == pref, 1);
    if isempty(idx)
        targetKey = local_prefix_key(pref);
        allKeys = strings(size(allp));
        for kk = 1:numel(allp)
            allKeys(kk) = local_prefix_key(allp(kk));
        end
        matches = find(allKeys == targetKey);
        if numel(matches) == 1
            idx = matches;
        end
    end

    if isempty(idx), return; end
    a = project.animals(idx);
end

function k = local_prefix_key(s)
    k = lower(regexprep(strtrim(string(s)), '[^a-zA-Z0-9]+', ''));
end
