function project = meeg_project_new(profile)
% Initialize a new project struct.

    project.profile = profile;
    project.outdir = pwd;

    % Output folder names (customizable)
    project.outNames.preproc = 'preprocessing';
    project.outNames.qeeg   = 'Results qEEG';

    % Manifest table (displayed/editable in GUI)
    project.manifest = table( ...
        false(0,1), strings(0,1), strings(0,1), strings(0,1), strings(0,1), strings(0,1), strings(0,1), strings(0,1), strings(0,1), strings(0,1), ...
        'VariableNames', {'Include','MouseID','TreatmentGroup','Genotype','Sex','DOB','RecordingDate','StartTime','LitterID','Notes'});

    % Animals array holds per-animal file paths etc.
    project.animals = struct('files', {}, 'fileOrder', {}, 'prefix', {}, 'meta', {}, 'sourceFile', {}, 'sourceSignalLabels', {}, 'assignedLabels', {}, 'assignedRegionLabels', {}, 'averageSameRegion', {}, 'fs', {}, 'assignCfg', {});
end
