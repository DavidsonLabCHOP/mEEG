function h = meeg_ps_add_sem_ribbon(ax, f, mu, sem, lineColor, faceAlpha)
% Add a semi-transparent mean +/- SEM ribbon behind a PSD group mean.
%
% The ribbon color is intentionally lighter than the matching group line:
%   - black lines use light gray
%   - red/red-orange lines use light pink
%   - other colors are blended toward white
%
% NaN gaps are rendered as separate ribbon segments so the patch never
% bridges missing PSD data. Negative lower bounds are clipped at zero.

    if nargin < 6 || isempty(faceAlpha), faceAlpha = 0.32; end
    h = gobjects(0,1);

    if isempty(ax) || ~isgraphics(ax) || isempty(f) || isempty(mu) || isempty(sem)
        return;
    end

    f = double(f(:));
    mu = double(mu(:));
    sem = double(sem(:));
    if numel(f) ~= numel(mu) || numel(f) ~= numel(sem)
        error('meeg_ps_add_sem_ribbon:SizeMismatch', ...
            'Frequency, mean, and SEM vectors must have the same length.');
    end

    valid = isfinite(f) & isfinite(mu) & isfinite(sem) & sem >= 0;
    if nnz(valid) < 2 || ~any(sem(valid) > 0)
        return;
    end

    ribbonColor = local_ribbon_color(lineColor);
    transitions = diff([false; valid; false]);
    starts = find(transitions == 1);
    stops = find(transitions == -1) - 1;

    for k = 1:numel(starts)
        ii = starts(k):stops(k);
        if numel(ii) < 2 || ~any(sem(ii) > 0), continue; end

        x = f(ii);
        upper = mu(ii) + sem(ii);
        lower = max(0, mu(ii) - sem(ii));
        hk = patch(ax, [x; flipud(x)], [upper; flipud(lower)], ribbonColor, ...
            'EdgeColor', 'none', ...
            'FaceAlpha', faceAlpha, ...
            'Tag', 'mEEG_PSD_SEM_Ribbon', ...
            'HandleVisibility', 'off', ...
            'HitTest', 'off');
        h(end+1,1) = hk; %#ok<AGROW>
    end
end

function c = local_ribbon_color(lineColor)
    c0 = double(lineColor(:).');
    if numel(c0) ~= 3 || any(~isfinite(c0))
        c0 = [0 0 0];
    end
    c0 = min(max(c0, 0), 1);

    if max(c0) <= 0.15
        c = [0.72 0.72 0.72];                 % light gray for black
    elseif c0(1) >= 0.65 && c0(1) >= c0(2) + 0.25 && c0(1) >= c0(3) + 0.25
        c = [1.00 0.62 0.70];                 % light pink for red/red-orange
    else
        c = 0.42*c0 + 0.58*[1 1 1];           % lighter matching shade
    end
    c = min(max(c, 0), 1);
end
