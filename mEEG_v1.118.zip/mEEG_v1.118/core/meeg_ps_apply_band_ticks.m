function displayXLim = meeg_ps_apply_band_ticks(ax, fmin, fmax)
% Apply mEEG EEG-band boundary ticks to a PSD axis.
%
% PSD samples below 0.4 Hz remain excluded from plotting and autoscaling.
% When the selected minimum is the mEEG lower PSD boundary (0.4 Hz), the
% visual axis begins at 0 Hz only so that 0 can be shown as a clean boundary
% tick. No data are drawn in the 0-0.4 Hz interval.
%
% Only band-definition ticks that fall inside the displayed range are shown:
%   0, 4, 8, 13, 30, and 50 Hz.

    if nargin < 1 || isempty(ax) || ~isgraphics(ax)
        displayXLim = [NaN NaN];
        return;
    end

    fmin = double(fmin);
    fmax = double(fmax);
    if ~isscalar(fmin) || ~isfinite(fmin), fmin = 0.4; end
    if ~isscalar(fmax) || ~isfinite(fmax), fmax = 50; end

    fmin = max(0.4, fmin);
    if fmax <= fmin
        fmax = fmin + eps(max(1, abs(fmin)));
    end

    % Show the zero boundary tick for the standard 0.4-Hz minimum without
    % reintroducing any excluded sub-0.4-Hz PSD values.
    tol = max(1e-10, 10*eps(max(1, abs(fmin))));
    if fmin <= 0.4 + tol
        displayMin = 0;
    else
        displayMin = fmin;
    end

    displayXLim = [displayMin, fmax];
    xlim(ax, displayXLim);

    bandTicks = [0 4 8 13 30 50];
    showTicks = bandTicks >= displayMin - tol & bandTicks <= fmax + tol;
    ticks = bandTicks(showTicks);
    set(ax, 'XTickMode', 'manual', 'XTick', ticks, ...
        'XTickLabelMode', 'manual', 'XTickLabel', compose('%g', ticks));
end
