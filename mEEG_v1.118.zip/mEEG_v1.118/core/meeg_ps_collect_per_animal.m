function [spec, f, meta] = meeg_ps_collect_per_animal(project, includedIdxs, dayStart, dayEnd, fs, which, opts)
% Collect per-animal power spectra into:
%   spec = frequency x region x time(day/night) x animal
%
% v1.108 macOS performance changes:
%   1) Prefer the compact *_ps_avg_cache.mat written during qEEG.
%   2) For legacy outputs, enumerate workbook sheets once and perform only
%      one readmatrix call per actual sheet instead of repeated failed XLSX reads.
%   3) Report progress through opts.logFcn when supplied.

    if nargin < 6 || isempty(which), which = 'avg'; end
    if nargin < 7 || isempty(opts), opts = struct(); end
    if ~isfield(opts,'logFcn'), opts.logFcn = []; end

    which = lower(string(which));
    if ~(which=="avg" || which=="std")
        error('which must be ''avg'' or ''std''.');
    end
    if nargin < 3 || isempty(dayStart), dayStart = 6.5; end
    if nargin < 4 || isempty(dayEnd), dayEnd = 18.5; end
    if nargin < 5 || isempty(fs), fs = project.profile.defaultFs; end

    N = fs * 5;
    f = linspace(0, fs/2, floor(N/2)+1).';
    nF = numel(f);
    nA = numel(includedIdxs);

    regionNames = strings(0,1);
    for ai = 1:nA
        a = project.animals(includedIdxs(ai));
        regs = local_channel_regions(a);
        regs = unique(regs(regs~=""), 'stable');
        regionNames = [regionNames; regs(:)]; %#ok<AGROW>
    end
    if isempty(regionNames)
        regionNames = ["Hippocampus";"Barrel";"Motor";"Visual";"Auditory"];
    else
        regionNames = unique(regionNames, 'stable');
    end
    nR = numel(regionNames);

    spec = nan(nF, nR, 2, nA);
    meta = struct();
    meta.Animal = strings(nA,1);
    meta.MouseID = strings(nA,1);
    meta.TreatmentGroup = strings(nA,1);
    meta.Sex = strings(nA,1);
    meta.Genotype = strings(nA,1);
    meta.LitterID = strings(nA,1);
    meta.RecordingDate = strings(nA,1);
    meta.RegionNames = regionNames;

    for ai = 1:nA
        i = includedIdxs(ai);
        a = project.animals(i);
        prefix = string(a.prefix);
        local_log(opts, sprintf('PSD post-processing: loading %s (%d/%d)...', char(prefix), ai, nA));

        meta.Animal(ai) = prefix;
        meta.MouseID(ai) = local_manifest_string(project.manifest,'MouseID',i);
        meta.TreatmentGroup(ai) = local_manifest_string(project.manifest,'TreatmentGroup',i);
        meta.Sex(ai) = local_manifest_string(project.manifest,'Sex',i);
        meta.Genotype(ai) = local_manifest_string(project.manifest,'Genotype',i);
        meta.LitterID(ai) = local_manifest_string(project.manifest,'LitterID',i);
        meta.RecordingDate(ai) = local_manifest_string(project.manifest,'RecordingDate',i);

        if which=="avg"
            psFile = meeg_outdir(project,'qeeg', a.prefix, sprintf('%s_ps_avg.xlsx', a.prefix));
            cacheFile = meeg_outdir(project,'qeeg', a.prefix, sprintf('%s_ps_avg_cache.mat', a.prefix));
        else
            psFile = meeg_outdir(project,'qeeg', a.prefix, sprintf('%s_ps_std.xlsx', a.prefix));
            cacheFile = '';
        end

        sheetLabels = local_sheet_labels(a);
        regionPerSheet = local_channel_regions(a);
        if isempty(sheetLabels)
            sheetLabels = local_default_sheet_labels(numel(regionPerSheet));
        end
        if isempty(regionPerSheet)
            regionPerSheet = local_default_region_labels(numel(sheetLabels));
        end

        dayAcc = containers.Map('KeyType','char','ValueType','any');
        ngtAcc = containers.Map('KeyType','char','ValueType','any');
        loadedFromCache = false;

        % ---------- fast MAT-cache path ----------
        if which=="avg" && ~isempty(cacheFile) && isfile(cacheFile)
            try
                S = load(cacheFile, 'psValues', 'psFreq', 'psTimeHours', 'psLabels');
                if isfield(S,'psValues') && isfield(S,'psFreq') && ...
                        isfield(S,'psTimeHours') && isfield(S,'psLabels')
                    cacheLabels = string(S.psLabels(:));
                    nCacheCh = size(S.psValues,3);
                    nCh = min([nCacheCh, numel(cacheLabels), numel(regionPerSheet)]);
                    sourceF = double(S.psFreq(:));
                    timestamps = double(S.psTimeHours(:).');
                    if nCh > 0 && numel(timestamps) == size(S.psValues,2)
                        local_log(opts, sprintf('PSD post-processing: using fast MAT cache for %s.', char(prefix)));
                        for ch = 1:nCh
                            values = double(S.psValues(:,:,ch));
                            values = local_match_frequency_grid(values, sourceF, f);
                            [dayCols, nightCols] = local_day_night_cols(timestamps, dayStart, dayEnd);
                            reg = char(regionPerSheet(ch));
                            if any(dayCols)
                                local_push(dayAcc, reg, mean(values(:,dayCols),2,'omitnan'));
                            end
                            if any(nightCols)
                                local_push(ngtAcc, reg, mean(values(:,nightCols),2,'omitnan'));
                            end
                        end
                        loadedFromCache = true;
                    end
                end
            catch MEcache
                local_log(opts, sprintf('PSD cache read failed for %s; using XLSX fallback: %s', char(prefix), MEcache.message));
            end
        end

        % ---------- legacy XLSX fallback ----------
        if ~loadedFromCache
            if ~isfile(psFile)
                warning('Missing PS file for %s: %s', prefix, psFile);
                continue;
            end
            local_log(opts, sprintf('PSD post-processing: reading workbook for %s (legacy path)...', char(prefix)));
            workbookSheets = local_sheetnames(psFile);
            nCh = min(numel(sheetLabels), numel(regionPerSheet));
            if nCh == 0, continue; end
            sheetLabels = sheetLabels(1:nCh);
            regionPerSheet = regionPerSheet(1:nCh);

            for ch = 1:nCh
                A = local_try_read(psFile, sheetLabels(ch), workbookSheets);
                if isempty(A) || size(A,1) < 2, continue; end
                timestamps = double(A(1,:));
                values = double(A(2:end,:));
                if size(values,1) > nF
                    values = values(1:nF,:);
                elseif size(values,1) < nF
                    values = [values; nan(nF-size(values,1), size(values,2))];
                end
                [dayCols, nightCols] = local_day_night_cols(timestamps, dayStart, dayEnd);
                reg = char(regionPerSheet(ch));
                if any(dayCols)
                    local_push(dayAcc, reg, mean(values(:,dayCols),2,'omitnan'));
                end
                if any(nightCols)
                    local_push(ngtAcc, reg, mean(values(:,nightCols),2,'omitnan'));
                end
                drawnow limitrate nocallbacks;
            end
        end

        for r = 1:nR
            reg = char(regionNames(r));
            if isKey(dayAcc, reg)
                spec(:,r,1,ai) = mean(dayAcc(reg),2,'omitnan');
            end
            if isKey(ngtAcc, reg)
                spec(:,r,2,ai) = mean(ngtAcc(reg),2,'omitnan');
            end
        end
        drawnow limitrate nocallbacks;
    end
end

function values = local_match_frequency_grid(values, sourceF, targetF)
    if size(values,1) == numel(targetF) && numel(sourceF) == numel(targetF) && ...
            all(abs(sourceF(:)-targetF(:)) < max(1e-8, eps(max(targetF))))
        return;
    end
    goodF = isfinite(sourceF);
    sourceF = sourceF(goodF);
    values = values(goodF,:);
    if numel(sourceF) < 2
        values = nan(numel(targetF), size(values,2));
        return;
    end
    values = interp1(sourceF, values, targetF, 'linear', NaN);
end

function [dayCols, nightCols] = local_day_night_cols(timestamps, dayStart, dayEnd)
    timestamps = mod(double(timestamps),24);
    if dayStart == 0 && dayEnd == 0
        dayCols = true(size(timestamps));
        nightCols = true(size(timestamps));
    elseif dayStart <= dayEnd
        dayCols = timestamps >= dayStart & timestamps < dayEnd;
        nightCols = ~dayCols;
    else
        dayCols = timestamps >= dayStart | timestamps < dayEnd;
        nightCols = ~dayCols;
    end
end

function local_push(mapObj, key, vec)
    if isKey(mapObj,key)
        mapObj(key) = [mapObj(key), vec];
    else
        mapObj(key) = vec;
    end
end

function sheets = local_sheetnames(psFile)
    sheets = strings(0,1);
    try
        sheets = string(sheetnames(psFile));
    catch
        try
            [~,s] = xlsfinfo(psFile); %#ok<XLSFI>
            sheets = string(s(:));
        catch
        end
    end
end

function A = local_try_read(psFile, baseName, workbookSheets)
    A = [];
    s = string(baseName);
    safe = string(meeg_sanitize_lead_label(s));
    pretty = string(meeg_pretty_region_label(s));
    cands = unique([s; safe; pretty; lower(s); lower(safe); upper(safe)], 'stable');

    actualSheet = "";
    if nargin >= 3 && ~isempty(workbookSheets)
        workbookSheets = string(workbookSheets(:));
        for k = 1:numel(cands)
            hit = find(strcmpi(workbookSheets, cands(k)),1,'first');
            if ~isempty(hit)
                actualSheet = workbookSheets(hit);
                break;
            end
        end
    end

    if actualSheet ~= ""
        try
            A = readmatrix(psFile,'Sheet',char(actualSheet));
        catch
            A = [];
        end
        return;
    end

    % Last-resort compatibility fallback when sheet enumeration is unavailable.
    for k = 1:numel(cands)
        try
            A = readmatrix(psFile,'Sheet',char(cands(k)));
            if ~isempty(A), return; end
        catch
        end
    end
end

function labs = local_sheet_labels(a)
    labs = strings(0,1);
    try
        if isfield(a,'fileOrder') && ~isempty(a.fileOrder)
            labs = string(a.fileOrder(:));
        elseif isfield(a,'assignedLabels') && ~isempty(a.assignedLabels)
            labs = string(a.assignedLabels(:));
        end
    catch
    end
end

function regs = local_channel_regions(a)
    regs = strings(0,1);
    try
        if isfield(a,'assignedRegionLabels') && ~isempty(a.assignedRegionLabels)
            regs = string(a.assignedRegionLabels(:));
        elseif isfield(a,'fileOrder') && ~isempty(a.fileOrder)
            regs = string(a.fileOrder(:));
        end
    catch
    end
    for k = 1:numel(regs)
        regs(k) = local_pretty_region(regs(k));
    end
    regs = local_collapse_template_lr_regions(regs);
end

function regs = local_collapse_template_lr_regions(regs)
    regs = string(regs(:));
    if numel(regs) ~= 10, return; end
    [bases,sides,ok] = local_parse_template_bases(regs);
    if ~ok, return; end
    wanted = ["Auditory";"Visual";"Hippocampus";"Barrel";"Motor"];
    hasPairs = true;
    for w = wanted(:)'
        idx = bases == w;
        hasPairs = hasPairs && sum(idx)==2 && any(sides(idx)=="L") && any(sides(idx)=="R");
    end
    if hasPairs, regs = bases; end
end

function [bases,sides,ok] = local_parse_template_bases(regs)
    bases = strings(size(regs));
    sides = strings(size(regs));
    ok = true;
    for ii = 1:numel(regs)
        tok = regexp(char(string(regs(ii))), ...
            '^(Auditory|Visual|Hippocampus|Barrel|Motor)\s*\(([LR])\)$', ...
            'tokens','once');
        if isempty(tok), ok = false; return; end
        bases(ii) = string(tok{1});
        sides(ii) = string(tok{2});
    end
end

function s = local_manifest_string(M, field, idx)
    s = "";
    try
        if ismember(field,M.Properties.VariableNames)
            s = string(M.(field)(idx));
        end
    catch
    end
end

function labs = local_default_sheet_labels(n)
    labs = arrayfun(@(k) string(sprintf('Lead%d',k)),(1:n).','UniformOutput',true);
end

function regs = local_default_region_labels(n)
    regs = arrayfun(@(k) string(sprintf('Lead %d',k)),(1:n).','UniformOutput',true);
end

function r = local_pretty_region(lbl)
    r = meeg_pretty_region_label(lbl);
end

function local_log(opts,msg)
    didLog = false;
    try
        if isfield(opts,'logFcn') && isa(opts.logFcn,'function_handle')
            opts.logFcn(msg);
            didLog = true;
        end
    catch
    end
    if ~didLog
        fprintf('%s\n',msg);
    end
end
