function [summary, perAnimal] = meeg_ps_fractional_band_tables(project, includedIdxs, dayStart, dayEnd, fs)
% Build BandAnalysis-like per-animal and summary tables from fractional PS band power.
% Uses the same fractional normalization as *_band_power_frac outputs from PS Analysis.

    if nargin < 3 || isempty(dayStart), dayStart = 6.5; end
    if nargin < 4 || isempty(dayEnd), dayEnd = 18.5; end
    if nargin < 5 || isempty(fs)
        if isfield(project,'profile') && isfield(project.profile,'defaultFs')
            fs = project.profile.defaultFs;
        else
            fs = 2500;
        end
    end

    [spec, f, meta] = meeg_ps_collect_per_animal(project, includedIdxs, dayStart, dayEnd, fs, 'avg');
    if isempty(spec)
        summary = table();
        perAnimal = table();
        return;
    end

    if isfield(meta,'RegionNames') && ~isempty(meta.RegionNames)
        regionNames = string(meta.RegionNames(:));
    else
        regionNames = string(compose('Region %d', 1:size(spec,2)))';
    end

    bands = struct(...
        'delta',     [0.4, 4], ...
        'theta',     [4, 8], ...
        'alpha',     [8, 13], ...
        'beta',      [13, 30], ...
        'gamma',     [30, 50], ...
        'fastGamma', [50, 100]);
    bandNames = string(fieldnames(bands));

    rows = cell(0,13);
    nAnimals = size(spec,4);
    nRegions = size(spec,2);

    for a = 1:nAnimals
        tg = local_meta_string(meta,'TreatmentGroup',a);
        mid = local_meta_string(meta,'MouseID',a);
        animalID = local_meta_string(meta,'Animal',a);
        geno = local_meta_string(meta,'Genotype',a);
        sex = local_meta_string(meta,'Sex',a);
        dob = local_meta_string(meta,'DOB',a);
        rdate = local_meta_string(meta,'RecordingDate',a);
        stime = local_meta_string(meta,'StartTime',a);
        litter = local_meta_string(meta,'LitterID',a);

        for r = 1:nRegions
            dayVals = local_band_auc_vector(spec(:,r,1,a), f, bands, bandNames);
            nightVals = local_band_auc_vector(spec(:,r,2,a), f, bands, bandNames);

            dayFrac = local_fractionalize(dayVals);
            nightFrac = local_fractionalize(nightVals);

            for b = 1:numel(bandNames)
                rows(end+1,:) = {tg, mid, animalID, geno, sex, dob, rdate, stime, litter, char(bandNames(b)), char(regionNames(r)), dayFrac(b), nightFrac(b)}; %#ok<AGROW>
            end
        end
    end

    if isempty(rows)
        perAnimal = table();
        summary = table();
        return;
    end

    perAnimal = cell2table(rows, 'VariableNames', {'TreatmentGroup','MouseID','Animal','Genotype','Sex','DOB','RecordingDate','StartTime','LitterID','Band','Region','DayAvg','NightAvg'});

    [GID, TG, BAND, REGION] = findgroups(perAnimal.TreatmentGroup, perAnimal.Band, perAnimal.Region);
    dayMean   = splitapply(@(x) mean(x,'omitnan'), perAnimal.DayAvg, GID);
    dayStd    = splitapply(@(x) std(x,'omitnan'),  perAnimal.DayAvg, GID);
    dayN      = splitapply(@(x) sum(~isnan(x)),    perAnimal.DayAvg, GID);
    daySE     = dayStd ./ sqrt(max(dayN,1));

    nightMean = splitapply(@(x) mean(x,'omitnan'), perAnimal.NightAvg, GID);
    nightStd  = splitapply(@(x) std(x,'omitnan'),  perAnimal.NightAvg, GID);
    nightN    = splitapply(@(x) sum(~isnan(x)),    perAnimal.NightAvg, GID);
    nightSE   = nightStd ./ sqrt(max(nightN,1));
    nAnimalsByGroup = splitapply(@numel, perAnimal.Animal, GID);

    summary = table(TG, BAND, REGION, dayMean, daySE, nightMean, nightSE, nAnimalsByGroup, dayN, nightN, ...
        'VariableNames', {'TreatmentGroup','Band','Region','DayMean','DaySE','NightMean','NightSE','N','DayN','NightN'});
end

function vals = local_band_auc_vector(y, f, bands, bandNames)
    vals = nan(numel(bandNames),1);
    if isempty(y) || all(~isfinite(y))
        return;
    end
    try
        fitObj = fit(f(:), y(:), 'smoothingspline');
    catch
        fitObj = [];
    end
    for b = 1:numel(bandNames)
        hz = bands.(char(bandNames(b)));
        denseF = linspace(hz(1), hz(2), 600);
        if isempty(fitObj)
            yy = interp1(f(:), y(:), denseF, 'linear', 'extrap');
        else
            yy = feval(fitObj, denseF);
        end
        yy(yy < 0) = 0;
        vals(b) = trapz(denseF, yy);
    end
end

function frac = local_fractionalize(vals)
    frac = nan(size(vals));
    total = sum(vals, 'omitnan');
    ok = isfinite(vals) & isfinite(total) & total > 0;
    frac(ok) = vals(ok) ./ total;
end

function s = local_meta_string(meta, field, idx)
    s = "";
    try
        if isfield(meta, field)
            v = meta.(field);
            if numel(v) >= idx
                s = string(v(idx));
            end
        end
    catch
    end
    s = char(s);
end
