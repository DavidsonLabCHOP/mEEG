function h = meeg_ps_plot_group_curves(ax, f, Yfull, groups, groupColors, showIndividuals, animalIDs, fmin, fmax)
% Plot individual PSDs (optional), group mean curves, and conditional SEM ribbons.
%
% The mean +/- SEM ribbon is drawn only when showIndividuals is false.
% SEM is calculated independently at every frequency using the number of
% finite animals at that frequency. At least two valid animals are required.

    if nargin < 6 || isempty(showIndividuals), showIndividuals = false; end
    if nargin < 7, animalIDs = strings(0,1); end
    if nargin < 8 || isempty(fmin), fmin = min(f, [], 'omitnan'); end
    if nargin < 9 || isempty(fmax), fmax = max(f, [], 'omitnan'); end

    % Remove ribbons from any previous render. HandleVisibility='off' objects
    % can survive a normal CLA call in MATLAB UI axes.
    try
        delete(findall(ax, 'Tag', 'mEEG_PSD_SEM_Ribbon'));
    catch
    end

    f = double(f(:));
    groups = string(groups(:));
    animalIDs = string(animalIDs(:));
    Yfull = double(Yfull);

    if isempty(Yfull)
        h = gobjects(numel(unique(groups, 'stable')),1);
        return;
    end
    if isvector(Yfull), Yfull = Yfull(:); end
    if size(Yfull,1) ~= numel(f) && size(Yfull,2) == numel(f)
        Yfull = Yfull.';
    end
    if size(Yfull,1) ~= numel(f)
        error('meeg_ps_plot_group_curves:SizeMismatch', ...
            'PSD data must have one row per frequency value.');
    end

    % Frequencies below 0.4 Hz are intentionally excluded from every PSD
    % rendering because these bins are not considered reliable in mEEG.
    keepFreq = isfinite(f) & f >= 0.4;
    f = f(keepFreq);
    Yfull = Yfull(keepFreq,:);
    fmin = max(0.4, double(fmin));

    nAnimals = size(Yfull,2);
    if numel(groups) < nAnimals
        groups(end+1:nAnimals,1) = "Unassigned";
    elseif numel(groups) > nAnimals
        groups = groups(1:nAnimals);
    end

    uniqG = unique(groups, 'stable');
    if isempty(groupColors) || size(groupColors,1) < numel(uniqG)
        groupColors = meeg_get_group_colors(uniqG);
    end
    h = gobjects(numel(uniqG),1);

    if showIndividuals
        for a = 1:nAnimals
            y = Yfull(:,a);
            if all(~isfinite(y)), continue; end
            gi = find(uniqG == groups(a), 1);
            if isempty(gi), gi = 1; end
            c = 0.65*groupColors(gi,:) + 0.35*[1 1 1];
            if numel(animalIDs) >= a && strlength(animalIDs(a)) > 0
                animalID = animalIDs(a);
            else
                animalID = "Animal " + string(a);
            end
            meeg_ps_plot_individual_labeled(ax, f, y, c, animalID, fmin, fmax);
        end
    end

    meanByGroup = cell(numel(uniqG),1);
    semByGroup = cell(numel(uniqG),1);
    for g = 1:numel(uniqG)
        idx = groups == uniqG(g);
        Y = Yfull(:,idx);
        if isempty(Y), continue; end

        mu = mean(Y, 2, 'omitnan');
        if all(~isfinite(mu)), continue; end
        meanByGroup{g} = mu;

        if ~showIndividuals
            nValid = sum(isfinite(Y), 2);
            sd = std(Y, 0, 2, 'omitnan');
            sem = sd ./ sqrt(max(nValid, 1));
            sem(nValid < 2) = NaN;
            semByGroup{g} = sem;
        end
    end

    % Draw every ribbon first so no ribbon can cover another group's line.
    if ~showIndividuals
        for g = 1:numel(uniqG)
            if isempty(meanByGroup{g}) || isempty(semByGroup{g}), continue; end
            meeg_ps_add_sem_ribbon(ax, f, meanByGroup{g}, semByGroup{g}, groupColors(g,:));
        end
    end

    % Draw all group mean curves last so they remain crisp above the ribbons.
    for g = 1:numel(uniqG)
        if isempty(meanByGroup{g}), continue; end
        h(g) = plot(ax, f, meanByGroup{g}, ...
            'LineWidth', 1.8, ...
            'Color', groupColors(g,:), ...
            'DisplayName', char(uniqG(g)));
    end
end
