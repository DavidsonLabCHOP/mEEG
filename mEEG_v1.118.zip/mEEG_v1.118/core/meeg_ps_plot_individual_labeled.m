function hLine = meeg_ps_plot_individual_labeled(ax, f, y, lineColor, animalID, fmin, fmax)
% Plot one individual-animal PSD curve and place a small Animal ID near
% the beginning of the visible curve.
%
% The label is intentionally small and excluded from legends. It is placed
% at the first finite point inside the selected frequency range, with a
% slight rightward offset so it does not sit directly on the y-axis.

    f = double(f(:));
    y = double(y(:));
    animalID = string(animalID);

    hLine = plot(ax, f, y, ...
        'LineWidth', 0.8, ...
        'Color', lineColor, ...
        'HandleVisibility', 'off');

    if strlength(animalID) == 0 || isempty(f) || isempty(y)
        return;
    end

    if nargin < 6 || isempty(fmin) || ~isfinite(fmin)
        fmin = min(f, [], 'omitnan');
    end
    if nargin < 7 || isempty(fmax) || ~isfinite(fmax)
        fmax = max(f, [], 'omitnan');
    end
    if ~isfinite(fmin) || ~isfinite(fmax) || fmax <= fmin
        return;
    end

    visible = isfinite(f) & isfinite(y) & f >= fmin & f <= fmax;
    idx = find(visible, 1, 'first');
    if isempty(idx)
        return;
    end

    % Move the label slightly to the right of the first visible data point.
    dx = 0.008 * (fmax - fmin);
    xLabel = min(fmax, max(fmin, f(idx) + dx));
    yLabel = y(idx);

    % When possible, interpolate the y-position at the shifted x-value so
    % the text remains anchored to the plotted curve.
    finiteXY = isfinite(f) & isfinite(y);
    if nnz(finiteXY) >= 2
        try
            yInterp = interp1(f(finiteXY), y(finiteXY), xLabel, 'linear', NaN);
            if isfinite(yInterp)
                yLabel = yInterp;
            end
        catch
        end
    end

    try
        hText = text(ax, xLabel, yLabel, char(animalID), ...
            'FontSize', 6, ...
            'FontWeight', 'normal', ...
            'Color', lineColor, ...
            'Interpreter', 'none', ...
            'HorizontalAlignment', 'left', ...
            'VerticalAlignment', 'middle', ...
            'Clipping', 'on', ...
            'HandleVisibility', 'off');
        try, hText.HitTest = 'off'; catch, end
        try, hText.PickableParts = 'none'; catch, end
    catch
        % Labels are a display aid only; never interrupt PSD plotting if a
        % graphics backend does not support one of the text properties.
    end
end
