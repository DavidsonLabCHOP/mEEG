function paths = meeg_ps_postprocess_autosave(project, includedIdxs, dayStart, dayEnd, fs, opts)
% Auto-save PS Analysis outputs after qEEG PSD has finished.
%
% Outputs in <project>/qEEG/PS Analysis:
%   <Group>_day_PowerSpecDens_bandAUC.xlsx
%   <Group>_night_PowerSpecDens_bandAUC.xlsx
%   <Group>_day_band_power_frac.xlsx
%   <Group>_night_band_power_frac.xlsx
%   PAPlot_FullRange_Bilateral3_day/night.(png,fig)
%   PAPlotUP_Bilateral3_day/night.(png,fig)
%
% Notes:
%   - Uses day/night boundaries supplied from the qEEG Settings tab.
%   - Uses smoothing-spline integration like compute_band_power_day_night.
%   - Uses current mEEG region pairings (already handled by meeg_ps_collect_per_animal).
%   - Fractional normalization includes FastGamma in the total.

    if nargin < 3 || isempty(dayStart), dayStart = 6.5; end
    if nargin < 4 || isempty(dayEnd),   dayEnd   = 18.5; end
    if nargin < 5 || isempty(fs)
        if isfield(project,'profile') && isfield(project.profile,'defaultFs')
            fs = project.profile.defaultFs;
        else
            fs = 2500;
        end
    end
    if nargin < 6, opts = struct(); end
    if ~isfield(opts,'saveFig'), opts.saveFig = true; end
    if ~isfield(opts,'savePng'), opts.savePng = true; end
    if ~isfield(opts,'plotTitleSuffix'), opts.plotTitleSuffix = ''; end
    if ~isfield(opts,'logFcn'), opts.logFcn = []; end

    outDir = meeg_outdir(project,'qeeg','Power Spectral Analysis');
    if ~isfolder(outDir), mkdir(outDir); end

    local_log(opts, 'PSD post-processing: collecting per-animal spectra...');
    [spec, f, meta] = meeg_ps_collect_per_animal(project, includedIdxs, dayStart, dayEnd, fs, 'avg', opts);
    local_log(opts, 'PSD post-processing: spectra loaded; building AUC tables...');
    groups = string(meta.TreatmentGroup);
    uniqG = unique(groups, 'stable');

    paths = struct();
    paths.outDir = outDir;
    paths.groupTables = strings(0,1);
    paths.groupFracTables = strings(0,1);
    paths.plotFiles = strings(0,1);

    % -------- per-group AUC tables + fractional tables --------
    for g = 1:numel(uniqG)
        grp = uniqG(g);
        idx = find(groups == grp);
        if isempty(idx), continue; end

        local_log(opts, sprintf('PSD post-processing: calculating AUC tables for group %s (%d/%d)...', char(grp), g, numel(uniqG)));
        Tday   = local_auc_table(local_select_spec_time(spec, 1, idx), f, meta, idx);
        Tnight = local_auc_table(local_select_spec_time(spec, 2, idx), f, meta, idx);

        grpSafe = regexprep(char(grp), '[^A-Za-z0-9_\-]+', '_');

        fDay = fullfile(outDir,   sprintf('%s_day_PowerSpecDens_bandAUC.xlsx', grpSafe));
        fNgt = fullfile(outDir, sprintf('%s_night_PowerSpecDens_bandAUC.xlsx', grpSafe));
        writetable(Tday, fDay);
        writetable(Tnight, fNgt);
        local_log(opts, sprintf('PSD post-processing: wrote AUC tables for group %s.', char(grp)));
        paths.groupTables(end+1,1) = string(fDay); %#ok<AGROW>
        paths.groupTables(end+1,1) = string(fNgt); %#ok<AGROW>

        TdayFrac   = local_fractionalize_auc(Tday);
        TnightFrac = local_fractionalize_auc(Tnight);

        fDayF = fullfile(outDir,   sprintf('%s_day_PowerSpecDens_fractionAUC.xlsx', grpSafe));
        fNgtF = fullfile(outDir, sprintf('%s_night_PowerSpecDens_fractionAUC.xlsx', grpSafe));
        writetable(TdayFrac, fDayF);
        writetable(TnightFrac, fNgtF);
        local_log(opts, sprintf('PSD post-processing: wrote fractional AUC tables for group %s.', char(grp)));
        paths.groupFracTables(end+1,1) = string(fDayF); %#ok<AGROW>
        paths.groupFracTables(end+1,1) = string(fNgtF); %#ok<AGROW>
    end

    % -------- overview PSD figure autosaves (all groups present) --------
    if numel(uniqG) >= 1
        local_log(opts, 'PSD post-processing: creating overview figures...');
        colors = meeg_get_group_colors(uniqG);
        dataDayByGroup = cell(1, numel(uniqG));
        dataNightByGroup = cell(1, numel(uniqG));
        for g = 1:numel(uniqG)
            idxg = find(groups == uniqG(g));
            dataDayByGroup{g} = local_select_spec_time(spec, 1, idxg);
            dataNightByGroup{g} = local_select_spec_time(spec, 2, idxg);
        end

        regionNamesForPlot = string(meta.RegionNames(:));
        hFull = meeg_PAPlot_FullRange_Bilateral3_autosave(f, dataDayByGroup, dataNightByGroup, ...
            uniqG, colors, 'day', 'night', opts.plotTitleSuffix, regionNamesForPlot);

        hHi = meeg_PAPlotUP_Bilateral3_autosave(f, dataDayByGroup, dataNightByGroup, ...
            uniqG, colors, 'day', 'night', opts.plotTitleSuffix, regionNamesForPlot);

        stamp = datestr(now, 'yyyymmdd_HHMMSS');
        if opts.savePng
            p = fullfile(outDir,['PowerSpecDens_0to30Hz_day_' stamp '.png']);
            meeg_save_png_svg(hFull(1), p, 'Resolution', 300); paths.plotFiles(end+1,1) = string(p); %#ok<AGROW>
            p = fullfile(outDir,['PowerSpecDens_0to30Hz_night_' stamp '.png']);
            meeg_save_png_svg(hFull(2), p, 'Resolution', 300); paths.plotFiles(end+1,1) = string(p); %#ok<AGROW>
            p = fullfile(outDir,['PowerSpecDens_13to50Hz_day_' stamp '.png']);
            meeg_save_png_svg(hHi(1), p, 'Resolution', 300); paths.plotFiles(end+1,1) = string(p); %#ok<AGROW>
            p = fullfile(outDir,['PowerSpecDens_13to50Hz_night_' stamp '.png']);
            meeg_save_png_svg(hHi(2), p, 'Resolution', 300); paths.plotFiles(end+1,1) = string(p); %#ok<AGROW>
        end
        if opts.saveFig
            p = fullfile(outDir,['PowerSpecDens_0to30Hz_day_' stamp '.fig']); savefig(hFull(1), p); paths.plotFiles(end+1,1) = string(p); %#ok<AGROW>
            p = fullfile(outDir,['PowerSpecDens_0to30Hz_night_' stamp '.fig']); savefig(hFull(2), p); paths.plotFiles(end+1,1) = string(p); %#ok<AGROW>
            p = fullfile(outDir,['PowerSpecDens_13to50Hz_day_' stamp '.fig']); savefig(hHi(1), p); paths.plotFiles(end+1,1) = string(p); %#ok<AGROW>
            p = fullfile(outDir,['PowerSpecDens_13to50Hz_night_' stamp '.fig']); savefig(hHi(2), p); paths.plotFiles(end+1,1) = string(p); %#ok<AGROW>
        end

        try, close(hFull(1)); catch, end
        try, close(hFull(2)); catch, end
        try, close(hHi(1)); catch, end
        try, close(hHi(2)); catch, end
        local_log(opts, 'PSD post-processing: overview figures saved.');
    end
    local_log(opts, 'PSD post-processing complete.');
end

function out = local_select_spec_time(spec, timeIdx, idxAnimals)
    % Return freq x region x animal, preserving singleton region/animal dimensions.
    if isempty(idxAnimals)
        out = nan(size(spec,1), size(spec,2), 0);
        return;
    end
    tmp = spec(:,:,timeIdx,idxAnimals);
    out = reshape(tmp, size(spec,1), size(spec,2), numel(idxAnimals));
end

function T = local_auc_table(specTime, f, meta, idxAnimals)
    % specTime: freq x region x animalSubset
    if isfield(meta,'RegionNames') && ~isempty(meta.RegionNames)
        regionNames = string(meta.RegionNames(:));
    else
        regionNames = ["Hippocampus","Barrel","Motor","Visual","Auditory"];
    end

    bands = struct(...
        'Delta',     [0.4, 4], ...
        'Theta',     [4, 8], ...
        'Alpha',     [8, 13], ...
        'Beta',      [13, 30], ...
        'Gamma',     [30, 50], ...
        'FastGamma', [50, 100]);
    bandNames = fieldnames(bands);

    rows = cell(0, 8 + numel(bandNames));
    nA = size(specTime, 3);
    for a = 1:nA
        srcIdx = idxAnimals(a);
        animalID = local_meta_string(meta,'Animal',srcIdx);
        mouseID  = local_meta_string(meta,'MouseID',srcIdx);
        grp      = local_meta_string(meta,'TreatmentGroup',srcIdx);
        sex      = local_meta_string(meta,'Sex',srcIdx);
        geno     = local_meta_string(meta,'Genotype',srcIdx);
        litter   = local_meta_string(meta,'LitterID',srcIdx);
        recDate  = local_meta_string(meta,'RecordingDate',srcIdx);

        for r = 1:numel(regionNames)
            y = specTime(:, r, a);
            if all(isnan(y)), continue; end

            % Only frequencies used by the defined bands (0.4-100 Hz)
            % are needed for AUC.  Fitting the full PSD up to Nyquist can be
            % very slow on macOS at high sampling rates and does not affect
            % any of these band integrals.
            use = isfinite(f) & isfinite(y) & f >= 0.4 & f <= 100;
            xFit = double(f(use));
            yFit = double(y(use));
            if numel(xFit) < 4
                warning('Insufficient PSD data for AUC: %s, region %s', animalID, regionNames(r));
                continue;
            end

            fitObj = [];
            try
                fitObj = fit(xFit(:), yFit(:), 'smoothingspline');
            catch MEfit
                warning('AUC smoothing-spline fit failed for %s, region %s (%s). Using pchip fallback.', ...
                    animalID, regionNames(r), MEfit.message);
            end

            row = {animalID, mouseID, grp, sex, geno, litter, recDate, char(regionNames(r))};
            for b = 1:numel(bandNames)
                hz = bands.(bandNames{b});
                denseF = linspace(hz(1), hz(2), 1000);
                if ~isempty(fitObj)
                    splineY = feval(fitObj, denseF);
                else
                    splineY = interp1(xFit, yFit, denseF, 'pchip', NaN);
                end
                splineY(splineY < 0) = 0;
                row{end+1} = trapz(denseF, splineY); %#ok<AGROW>
            end
            rows(end+1,:) = row; %#ok<AGROW>
        end
    end

    T = cell2table(rows, 'VariableNames', {'Animal','MouseID','TreatmentGroup','Sex','Genotype','LitterID','RecordingDate','Region', bandNames{:}});
end

function s = local_meta_string(meta, field, idx)
    s = "";
    try
        if isfield(meta, field)
            v = meta.(field);
            if numel(v) >= idx
                s = string(v(idx));
            end
        end
    catch
    end
    s = char(s);
end

function T = local_fractionalize_auc(T)
    bandCols = {'Delta','Theta','Alpha','Beta','Gamma','FastGamma'};
    bandCols = bandCols(ismember(bandCols, T.Properties.VariableNames));
    if isempty(bandCols), return; end

    M = T{:, bandCols};
    total = sum(M, 2, 'omitnan');

    for b = 1:numel(bandCols)
        bn = bandCols{b};
        x = T.(bn);
        y = nan(size(x));
        ok = ~isnan(x) & ~isnan(total) & total > 0;
        y(ok) = x(ok) ./ total(ok);
        T.(bn) = y;
    end
    T.TotalAUC = total;
end


function local_log(opts, msg)
    didLog = false;
    try
        if isfield(opts,'logFcn') && isa(opts.logFcn,'function_handle')
            opts.logFcn(msg);
            didLog = true;
        end
    catch
    end
    if ~didLog
        fprintf('%s\n', msg);
    end
    drawnow limitrate nocallbacks;
end
