function meeg_qeeg_runall_10e(project, animalIdx, q)
% Run per-animal qEEG analyses using the EEG_RunAll logic adapted to explicit file paths.

    a = project.animals(animalIdx);
    prefix = a.prefix;
    outBase = meeg_outdir(project,'qeeg', prefix);
    if ~isfolder(outBase), mkdir(outBase); end
    outputPrefix = fullfile(outBase, prefix);

    hourStart = NaN;
    try
        hourStart = meeg_manifest_get_start_hour(project, animalIdx, animalIdx);
    catch
    end
    if isnan(hourStart)
        try
            hourStart = str2double(project.manifest.StartTime(animalIdx));
        catch
        end
    end
    if isnan(hourStart), hourStart = 0; end

    preprocDir = meeg_outdir(project,'preprocessing', prefix);
    useMasks = true;
    if isfield(q, 'usePreprocMasks')
        useMasks = logical(q.usePreprocMasks);
    end

    % Use the exact notch band selected during preprocessing. qEEG reads
    % raw DAT files again, so without this propagation the spectra would
    % otherwise fall back to a hard-coded 59-61 Hz band.
    notchEnabled = logical(conditionalField(q, 'notchEnabled', true));
    notchF1 = double(conditionalField(q, 'notchF1', 59));
    notchF2 = double(conditionalField(q, 'notchF2', 61));
    paramsPath = fullfile(preprocDir, 'parameters_used.mat');
    if isfile(paramsPath)
        try
            P = load(paramsPath, 'params');
            if isfield(P, 'params') && isstruct(P.params) && ...
                    isfield(P.params, 'notch') && isstruct(P.params.notch)
                notchEnabled = logical(conditionalField(P.params.notch, 'enabled', notchEnabled));
                notchF1 = double(conditionalField(P.params.notch, 'f1', notchF1));
                notchF2 = double(conditionalField(P.params.notch, 'f2', notchF2));
            end
        catch
            % Keep the GUI fallback values if an older/malformed parameter
            % file cannot be read.
        end
    end

    qLabels = conditionalField(project.profile, 'channelLabels', {});
    if isempty(qLabels) && isfield(a, 'fileOrder')
        qLabels = a.fileOrder;
    end
    qLabels = cellstr(string(meeg_sanitize_lead_label(qLabels(:)))');

    meeg_EEG_RunAll_fromFiles(q.fs, hourStart, outputPrefix, q.corr_window_sec, a.files, ...
        'runBand', q.runBand, 'runPSD', q.runPSD, 'runCorr', q.runCorr, 'runCoh', q.runCoh, ...
        'saveCohSpec', isfield(q,'saveCohSpec') && q.saveCohSpec, ...
        'dayStart', conditionalField(q, 'dayStart', 6.5), 'dayEnd', conditionalField(q, 'dayEnd', 18.5), ...
        'coh_window_sec', q.coh_window_sec, 'coh_overlap', q.coh_overlap, 'coh_fmax', q.coh_fmax, ...
        'coh_resample_500', conditionalField(q, 'coh_resample_500', false), ...
        'coh_resample_target_hz', conditionalField(q, 'coh_resample_target_hz', 500), ...
        'usePreprocMasks', useMasks, 'preprocMaskDir', preprocDir, ...
        'notchEnabled', notchEnabled, 'notchF1', notchF1, 'notchF2', notchF2, ...
        'channelLabels', qLabels, ...
        'stopFile', conditionalField(q, 'stopFile', ''));
end

function v = conditionalField(S, f, defaultVal)
    v = defaultVal;
    try
        if isstruct(S) && isfield(S, f)
            v = S.(f);
        end
    catch
    end
end
