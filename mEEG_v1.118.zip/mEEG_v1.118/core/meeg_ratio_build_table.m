function T = meeg_ratio_build_table(project, sourceKind, numBand, denBand, timeMode, regionMode, includedIdxs, dayStart, dayEnd)
% Build per-animal ratio table for either normalized band-power ratios or PSD/AUC ratios.
% This version uses the active project outputs/metadata directly so EDF projects with
% dynamic lead/region labels are handled the same way as Intan projects.

    if nargin < 7 || isempty(includedIdxs)
        includedIdxs = find(project.manifest.Include);
    end
    if nargin < 8 || isempty(dayStart), dayStart = 6.5; end
    if nargin < 9 || isempty(dayEnd),   dayEnd   = 18.5; end

    sourceKind = lower(string(sourceKind));
    numBand    = string(numBand);
    denBand    = string(denBand);
    timeMode   = lower(string(timeMode));
    regionMode = string(regionMode);

    switch sourceKind
        case "band"
            T = local_build_band_ratio_table(project, numBand, denBand, timeMode, regionMode, includedIdxs, dayStart, dayEnd);
        case "power"
            T = local_build_power_ratio_table(project, numBand, denBand, timeMode, regionMode, includedIdxs, dayStart, dayEnd);
        otherwise
            error('Unsupported sourceKind: %s', char(sourceKind));
    end

    if isempty(T) || height(T)==0
        T = local_empty_ratio_table();
        return;
    end

    T.SourceType      = repmat(sourceKind, height(T), 1);
    T.TimeMode        = repmat(timeMode, height(T), 1);
    T.RegionMode      = repmat(regionMode, height(T), 1);
    T.NumeratorBand   = repmat(numBand, height(T), 1);
    T.DenominatorBand = repmat(denBand, height(T), 1);

    T.Ratio = T.NumeratorValue ./ T.DenominatorValue;
    bad = isnan(T.Ratio) | ~isfinite(T.Ratio) | isnan(T.NumeratorValue) | isnan(T.DenominatorValue) | T.DenominatorValue == 0;
    T = T(~bad, :);

    if isempty(T) || height(T)==0
        T = local_empty_ratio_table();
        return;
    end

    preferred = {'Animal','MouseID','TreatmentGroup','Sex','Genotype','LitterID','RecordingDate','Region', ...
        'SourceType','TimeMode','RegionMode','NumeratorBand','DenominatorBand','NumeratorValue','DenominatorValue','Ratio'};
    existing = preferred(ismember(preferred, T.Properties.VariableNames));
    rest = setdiff(T.Properties.VariableNames, existing, 'stable');
    T = T(:, [existing rest]);
end

function Tout = local_build_band_ratio_table(project, numBand, denBand, timeMode, regionMode, includedIdxs, dayStart, dayEnd)
    % Regenerate the active BandAnalysis tables from the current project/output files.
    [~, perAnimal] = meeg_band_group_summary(project, includedIdxs, dayStart, dayEnd, struct('writeCsv', false));
    if isempty(perAnimal) || height(perAnimal)==0
        Tout = table();
        return;
    end

    perAnimal = local_normalize_basic_columns(perAnimal);
    numT = perAnimal(strcmpi(string(perAnimal.Band), numBand), :);
    denT = perAnimal(strcmpi(string(perAnimal.Band), denBand), :);
    if isempty(numT) || isempty(denT)
        Tout = table();
        return;
    end

    numT.SelectedValue = local_time_value(numT, timeMode);
    denT.SelectedValue = local_time_value(denT, timeMode);

    if regionMode ~= "Average across all regions"
        numT = numT(local_region_match(numT.Region, regionMode), :);
        denT = denT(local_region_match(denT.Region, regionMode), :);
    end

    keepVars = local_keep_vars(numT, {'Animal','MouseID','TreatmentGroup','Sex','Genotype','LitterID','RecordingDate','Region'});
    numT = numT(:, [keepVars {'SelectedValue'}]);
    denT = denT(:, [keepVars {'SelectedValue'}]);
    numT.Properties.VariableNames{'SelectedValue'} = 'NumeratorValue';
    denT.Properties.VariableNames{'SelectedValue'} = 'DenominatorValue';

    keyVars = intersect(setdiff(numT.Properties.VariableNames, {'NumeratorValue'}), setdiff(denT.Properties.VariableNames, {'DenominatorValue'}), 'stable');
    T = innerjoin(numT, denT, 'Keys', keyVars);
    if isempty(T)
        Tout = table();
        return;
    end

    if regionMode == "Average across all regions"
        T = local_aggregate_ratio_rows(T, false, true);
        T.Region = repmat("Average across all regions", height(T), 1);
    else
        % Collapse any matched bilateral Intan rows to one per-animal value.
        % For EDF side-specific selections, exact matching yields one row and
        % this aggregation leaves that value unchanged.
        T = local_aggregate_ratio_rows(T, false, true);
        T.Region = repmat(regionMode, height(T), 1);
    end
    Tout = T;
end

function Tout = local_build_power_ratio_table(project, numBand, denBand, timeMode, regionMode, includedIdxs, dayStart, dayEnd)
    fs = 2500;
    try
        if isfield(project,'profile') && isfield(project.profile,'defaultFs') && ~isempty(project.profile.defaultFs)
            fs = project.profile.defaultFs;
        end
    catch
    end

    [spec, f, meta] = meeg_ps_collect_per_animal(project, includedIdxs, dayStart, dayEnd, fs, 'avg');
    if isempty(spec) || isempty(f)
        Tout = table();
        return;
    end

    regionNames = string(meta.RegionNames(:));
    nA = numel(includedIdxs);
    rows = {};
    for ai = 1:nA
        animal = local_meta(meta, 'Animal', ai);
        mouse  = local_meta(meta, 'MouseID', ai);
        grp    = local_meta(meta, 'TreatmentGroup', ai);
        sex    = local_meta(meta, 'Sex', ai);
        geno   = local_meta(meta, 'Genotype', ai);
        lit    = local_meta(meta, 'LitterID', ai);
        rdate  = local_meta(meta, 'RecordingDate', ai);

        for ri = 1:numel(regionNames)
            reg = regionNames(ri);
            if regionMode ~= "Average across all regions" && ~local_region_match(reg, regionMode)
                continue;
            end
            yDay = spec(:,ri,1,ai);
            yNgt = spec(:,ri,2,ai);
            if all(isnan(yDay)) && all(isnan(yNgt))
                continue;
            end
            numVal = local_auc_for_time(f, yDay, yNgt, numBand, timeMode);
            denVal = local_auc_for_time(f, yDay, yNgt, denBand, timeMode);
            rows(end+1,:) = {animal, mouse, grp, sex, geno, lit, rdate, char(reg), numVal, denVal}; %#ok<AGROW>
        end
    end

    if isempty(rows)
        Tout = table();
        return;
    end

    T = cell2table(rows, 'VariableNames', {'Animal','MouseID','TreatmentGroup','Sex','Genotype','LitterID','RecordingDate','Region','NumeratorValue','DenominatorValue'});
    T = local_normalize_basic_columns(T);

    if regionMode == "Average across all regions"
        T = local_aggregate_ratio_rows(T, false, true);
        T.Region = repmat("Average across all regions", height(T), 1);
    else
        % Collapse any matched bilateral Intan rows to one per-animal value.
        % For EDF side-specific selections, exact matching yields one row and
        % this aggregation leaves that value unchanged.
        T = local_aggregate_ratio_rows(T, false, true);
        T.Region = repmat(regionMode, height(T), 1);
    end
    Tout = T;
end

function val = local_auc_for_time(f, yDay, yNgt, bandName, timeMode)
    switch lower(char(timeMode))
        case 'day'
            val = local_auc(f, yDay, bandName);
        case 'night'
            val = local_auc(f, yNgt, bandName);
        case 'average'
            val = mean([local_auc(f, yDay, bandName), local_auc(f, yNgt, bandName)], 'omitnan');
        otherwise
            error('Unsupported timeMode: %s', char(timeMode));
    end
end

function val = local_auc(f, y, bandName)
    br = local_band_range(bandName);
    f = f(:);
    y = y(:);
    ok = f >= br(1) & f < br(2) & isfinite(f) & isfinite(y);
    if sum(ok) < 2
        val = NaN;
    else
        val = trapz(f(ok), y(ok));
    end
end

function br = local_band_range(bandName)
    b = lower(string(bandName));
    switch b
        case 'delta'
            br = [0.4 4];
        case 'theta'
            br = [4 8];
        case 'alpha'
            br = [8 13];
        case 'beta'
            br = [13 30];
        case 'gamma'
            br = [30 50];
        case {'fastgamma','fast_gamma','fast gamma'}
            br = [50 100];
        otherwise
            error('Unknown band: %s', char(bandName));
    end
end

function vals = local_time_value(T, timeMode)
    switch lower(char(timeMode))
        case 'day'
            vals = T.DayAvg;
        case 'night'
            vals = T.NightAvg;
        case 'average'
            vals = mean([T.DayAvg, T.NightAvg], 2, 'omitnan');
        otherwise
            error('Unsupported timeMode: %s', char(timeMode));
    end
end

function T = local_aggregate_ratio_rows(T, collapseTime, collapseRegion)
    if isempty(T), return; end
    if nargin < 2, collapseTime = false; end
    if nargin < 3, collapseRegion = false; end

    vars = T.Properties.VariableNames;
    metaCandidates = {'Animal','MouseID','TreatmentGroup','Sex','Genotype','LitterID','RecordingDate'};
    keys = metaCandidates(ismember(metaCandidates, vars));
    if ~collapseRegion && ismember('Region', vars)
        keys = [keys {'Region'}];
    end
    if ~collapseTime && ismember('Time', vars)
        keys = [keys {'Time'}];
    end

    if isempty(keys)
        return;
    end

    [G, keyRows] = findgroups(T(:, keys));
    Tmeta = keyRows;
    Tmeta.NumeratorValue = splitapply(@(x) mean(x, 'omitnan'), T.NumeratorValue, G);
    Tmeta.DenominatorValue = splitapply(@(x) mean(x, 'omitnan'), T.DenominatorValue, G);
    T = Tmeta;
end

function T = local_normalize_basic_columns(T)
    vars = string(T.Properties.VariableNames);
    if ~ismember('Animal', vars) && ismember('Prefix', vars)
        T.Animal = string(T.Prefix);
    end
    if ~ismember('MouseID', vars) && ismember('AnimalID', vars)
        T.MouseID = string(T.AnimalID);
    end
    if ~ismember('TreatmentGroup', vars) && ismember('StudyGroup', vars)
        T.TreatmentGroup = string(T.StudyGroup);
    end
    must = {'Animal','MouseID','TreatmentGroup','Sex','Genotype','LitterID','RecordingDate','Region'};
    for k = 1:numel(must)
        v = must{k};
        if ~ismember(v, T.Properties.VariableNames)
            T.(v) = repmat("", height(T), 1);
        else
            T.(v) = string(T.(v));
        end
    end
end

function keep = local_keep_vars(T, preferred)
    keep = preferred(ismember(preferred, T.Properties.VariableNames));
end

function s = local_meta(meta, field, idx)
    s = "";
    try
        if isfield(meta, field)
            v = meta.(field);
            if numel(v) >= idx
                s = string(v(idx));
            end
        end
    catch
    end
    s = char(s);
end

function tf = local_region_match(regionVals, regionMode)
    rawR = string(regionVals);
    rawQ = string(regionMode);
    r = lower(regexprep(rawR, '[^a-z0-9]', ''));
    q = lower(regexprep(rawQ, '[^a-z0-9]', ''));
    if q == "averageacrossallregions"
        tf = true(size(r));
        return;
    end

    % Always prefer an exact normalized label match. This is essential for
    % EDF projects where Hippocampus (L) and Hippocampus (R), Motor (L/R),
    % Area A, etc. are independent user-assigned electrodes/regions.
    exact = (r == q);
    if any(exact(:))
        tf = exact;
        return;
    end

    % Fallback aliases support the five bilateral Intan regional averages
    % and legacy abbreviated labels when no exact label exists.
    if contains(q, "hip")
        tf = contains(r, "hip");
    elseif contains(q, "bar")
        tf = contains(r, "bar");
    elseif contains(q, "mot")
        tf = contains(r, "mot");
    elseif contains(q, "vis")
        tf = contains(r, "vis");
    elseif contains(q, "aud")
        tf = contains(r, "aud");
    elseif contains(q, "medial") || contains(q, "mpfc")
        tf = contains(r, "medial") | contains(r, "mpfc");
    elseif contains(q, "retro") || contains(q, "rsp")
        tf = contains(r, "retro") | contains(r, "rsp");
    elseif contains(q, "pariet")
        tf = contains(r, "pariet");
    elseif contains(q, "cing")
        tf = contains(r, "cing");
    elseif contains(q, "thal")
        tf = contains(r, "thal");
    elseif contains(q, "stri")
        tf = contains(r, "stri");
    elseif contains(q, "areaa")
        tf = contains(r, "areaa");
    elseif contains(q, "areab")
        tf = contains(r, "areab");
    elseif contains(q, "areac")
        tf = contains(r, "areac");
    elseif contains(q, "aread")
        tf = contains(r, "aread");
    elseif contains(q, "areae")
        tf = contains(r, "areae");
    else
        tf = false(size(r));
    end
end

function T = local_empty_ratio_table()
    T = table('Size',[0 16], ...
        'VariableTypes', {'string','string','string','string','string','string','string','string','string','string','string','string','string','double','double','double'}, ...
        'VariableNames', {'Animal','MouseID','TreatmentGroup','Sex','Genotype','LitterID','RecordingDate','Region','SourceType','TimeMode','RegionMode','NumeratorBand','DenominatorBand','NumeratorValue','DenominatorValue','Ratio'});
end
