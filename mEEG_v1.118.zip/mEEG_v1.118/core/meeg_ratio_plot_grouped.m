function h = meeg_ratio_plot_grouped(T, colorBy, ax, titleStr)
% Plot ratio bars by TreatmentGroup with per-animal dots.
% If ax is empty, a new figure is created and returned in h.Figure.

    if nargin < 2 || isempty(colorBy), colorBy = 'TreatmentGroup'; end
    if nargin < 3, ax = []; end
    if nargin < 4 || isempty(titleStr), titleStr = 'Band/Power Ratio'; end

    colorBy = string(colorBy);
    if isempty(T) || height(T)==0
        error('No ratio data to plot.');
    end

    groups = unique(string(T.TreatmentGroup), 'stable');
    Cg = meeg_get_group_colors(groups);
    mu = nan(numel(groups),1);
    se = nan(numel(groups),1);
    n  = zeros(numel(groups),1);
    for gi = 1:numel(groups)
        idx = string(T.TreatmentGroup) == groups(gi);
        y = T.Ratio(idx);
        y = y(~isnan(y) & isfinite(y));
        n(gi) = numel(y);
        if ~isempty(y)
            mu(gi) = mean(y, 'omitnan');
            se(gi) = std(y, 0, 'omitnan') / sqrt(max(1, numel(y)));
        end
    end

    if isempty(ax) || ~isvalid(ax)
        h.Figure = figure('Color','w','Name', char(titleStr));
        ax = axes(h.Figure);
    else
        cla(ax, 'reset');
        h.Figure = ancestor(ax, 'figure');
    end
    hold(ax, 'on');

    bh = bar(ax, 1:numel(groups), mu, 0.72, 'FaceColor','flat', 'EdgeColor','k', 'LineWidth',0.75);
    bh.CData = Cg;
    errorbar(ax, 1:numel(groups), mu, se, 'k', 'LineStyle','none', 'LineWidth', 1.2, 'CapSize', 8);

    dotUsesSelectedMetadata = ismember(char(colorBy), T.Properties.VariableNames);
    if dotUsesSelectedMetadata
        dotVals = string(T.(char(colorBy)));
        dotCats = unique(dotVals, 'stable');
        Cd = meeg_get_metadata_colors(max(1,numel(dotCats)));
    else
        dotCats = groups;
        Cd = meeg_get_metadata_colors(max(1,numel(dotCats)));
    end

    rng(0);
    for gi = 1:numel(groups)
        idx = string(T.TreatmentGroup) == groups(gi);
        y = T.Ratio(idx);
        x = gi + (rand(sum(idx),1)-0.5)*0.22;
        if dotUsesSelectedMetadata
            vals = string(T.(char(colorBy))(idx));
        else
            vals = string(T.TreatmentGroup(idx));
        end
        for ci = 1:numel(dotCats)
            idc = vals == dotCats(ci);
            if any(idc)
                scatter(ax, x(idc), y(idc), 28, 'MarkerFaceColor', Cd(ci,:), 'MarkerEdgeColor','k', 'LineWidth',0.5);
            end
        end
    end

    ax.XTick = 1:numel(groups);
    ax.XTickLabel = cellstr(groups);
    ax.XTickLabelRotation = 25;
    ylabel(ax, 'Ratio');
    xlabel(ax, 'Treatment group');
    title(ax, titleStr, 'Interpreter', 'none');
    grid(ax, 'on');
    box(ax, 'off');

    barDummy = gobjects(numel(groups),1);
    for gi = 1:numel(groups)
        barDummy(gi) = scatter(ax, nan, nan, 46, 's', 'MarkerFaceColor', Cg(gi,:), 'MarkerEdgeColor','k', 'LineWidth',0.75);
    end

    dotDummy = gobjects(numel(dotCats),1);
    for ci = 1:numel(dotCats)
        dotDummy(ci) = scatter(ax, nan, nan, 28, 'o', 'MarkerFaceColor', Cd(ci,:), 'MarkerEdgeColor','k');
    end
    labelsBar = cellfun(@(s) ['Bar: ' s], cellstr(groups), 'UniformOutput', false);
    labelsDot = cellfun(@(s) ['Dot: ' s], cellstr(dotCats), 'UniformOutput', false);
    legend(ax, [barDummy(:); dotDummy(:)], [labelsBar(:); labelsDot(:)], 'Location','best', 'Interpreter','none');

    h.Axes = ax;
    h.Bar = bh;
    h.Groups = groups;
    h.N = n;
end
