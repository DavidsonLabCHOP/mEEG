function out = meeg_sanitize_lead_label(in)
%MEEG_SANITIZE_LEAD_LABEL Convert EEG lead/region labels to MATLAB-safe labels.
%   Examples:
%       auditory.R    -> auditory_R
%       motor-L       -> motor_L
%       Motor (L)     -> motor_L
%       Rhip          -> hippocampus_R
%
%   The returned labels are safe for struct fields, table variables, Excel
%   sheets, filenames, and downstream mEEG outputs. Vector/cell inputs are
%   made unique after sanitization to avoid duplicate field/sheet names.

    wasCell = iscell(in);
    wasString = isstring(in);
    wasChar = ischar(in);

    s = string(in);
    outS = strings(size(s));

    legacyIn  = ["rhip","lhip","rbar","lbar","rmot","lmot","raud","laud","rvis","lvis"];
    legacyOut = ["hippocampus_R","hippocampus_L","barrel_R","barrel_L","motor_R","motor_L","auditory_R","auditory_L","visual_R","visual_L"];

    for k = 1:numel(s)
        t0 = strtrim(char(s(k)));
        if isempty(t0) || strcmpi(t0, '<missing>')
            t0 = sprintf('Channel_%d', k);
        end

        compact = lower(regexprep(t0, '[^A-Za-z0-9]', ''));
        hit = find(legacyIn == string(compact), 1, 'first');
        if ~isempty(hit)
            t = char(legacyOut(hit));
        else
            t = t0;

            % Convert common side encodings to an underscore suffix first.
            % Examples: auditory.R, auditory-R, auditory (R), auditory R.
            t = regexprep(t, '\s*\(\s*([LRlr])\s*\)\s*$', '_$1');
            t = regexprep(t, '\s*[\.\-]\s*([LRlr])\s*$', '_$1');
            t = regexprep(t, '\s+([LRlr])\s*$', '_$1');

            % Remove all remaining non-code-friendly characters.
            t = regexprep(t, '\s+', '_');
            t = regexprep(t, '[^A-Za-z0-9_]', '_');
            t = regexprep(t, '_+', '_');
            t = regexprep(t, '^_+|_+$', '');
            if isempty(t)
                t = sprintf('Channel_%d', k);
            end

            % Canonicalize the common 10-lead region names while preserving
            % support for custom labels such as mPFC_R or Ch1.
            tok = regexp(t, '^(hippocampus|hip|barrel|bar|motor|mot|visual|vis|auditory|aud)_([LRlr])$', 'tokens', 'once', 'ignorecase');
            if ~isempty(tok)
                base = lower(tok{1});
                side = upper(tok{2});
                switch base
                    case {'hippocampus','hip'}
                        base = 'hippocampus';
                    case {'barrel','bar'}
                        base = 'barrel';
                    case {'motor','mot'}
                        base = 'motor';
                    case {'visual','vis'}
                        base = 'visual';
                    case {'auditory','aud'}
                        base = 'auditory';
                end
                t = [base '_' side];
            else
                % Make any remaining edge case a legal MATLAB identifier.
                t = matlab.lang.makeValidName(t);
            end
        end

        outS(k) = string(t);
    end

    if numel(outS) > 1
        flat = cellstr(outS(:));
        flat = matlab.lang.makeUniqueStrings(flat);
        outS = reshape(string(flat), size(outS));
    end

    if wasCell
        tmp = cellstr(outS(:));
        out = reshape(tmp, size(outS));
    elseif wasString
        out = outS;
    elseif wasChar
        out = char(outS);
    else
        out = outS;
    end
end
