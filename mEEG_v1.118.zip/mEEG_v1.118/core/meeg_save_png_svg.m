function meeg_save_png_svg(figOrAx, outPng, varargin)
%MEEG_SAVE_PNG_SVG Save PNG + SVG with same basename.
% outPng should end with .png
% Usage: meeg_save_png_svg(gcf, fullfile(outDir,'plot.png'),'Resolution',150)

p = inputParser;
addParameter(p,'Resolution',150,@(x) isnumeric(x) && isscalar(x) && x>0);
parse(p,varargin{:});
res = p.Results.Resolution;

outPng = char(outPng);
[outDir, base, ext] = fileparts(outPng);
if isempty(ext)
    ext = '.png';
    outPng = fullfile(outDir,[base ext]);
end
if ~strcmpi(ext,'.png')
    error('meeg_save_png_svg:Ext','outPng must end with .png');
end
if ~isempty(outDir) && ~isfolder(outDir)
    mkdir(outDir);
end

% PNG
try
    exportgraphics(figOrAx, outPng, 'Resolution', res);
catch
    % fallback
    saveas(ancestor(figOrAx,'figure'), outPng);
end

% SVG (vector)
outSvg = fullfile(outDir, [base '.svg']);
try
    exportgraphics(figOrAx, outSvg, 'ContentType','vector');
catch
    % fallback
    try
        print(ancestor(figOrAx,'figure'), outSvg, '-dsvg');
    catch
        saveas(ancestor(figOrAx,'figure'), outSvg);
    end
end
end
