function counts = meeg_spike_apply_review_to_counts(project, prefix, counts, fs, countType)
% Subtract user-rejected spike events from count matrices used by plots.
% This never deletes the original spike detection output; it only adjusts plotted summaries.
    if nargin < 5 || isempty(countType), countType = 'single'; end
    countType = lower(string(countType));
    R = meeg_spike_load_review(project, prefix);
    if isempty(R) || height(R)==0 || isempty(counts), return; end
    if ~ismember('UserIncluded', R.Properties.VariableNames), return; end
    try
        R = R(~logical(R.UserIncluded), :);
    catch
        return;
    end
    if isempty(R), return; end
    sampsPerWindow = fs * 60 * 30;
    for i = 1:height(R)
        try
            if countType == "single" && lower(string(R.EventType(i))) ~= "single", continue; end
            if countType == "multilead" && lower(string(R.EventType(i))) ~= "multilead", continue; end
            period = floor((double(R.Idx(i))-1) / sampsPerWindow) + 1;
            if period < 1 || period > size(counts,2), continue; end
            if countType == "single"
                ch = double(R.LeadIndex(i));
                if ch >= 1 && ch <= size(counts,1) && isfinite(counts(ch,period))
                    counts(ch,period) = max(0, counts(ch,period) - 1);
                end
            else
                % Multilead counts are saved per lead. If LeadIndices exists, subtract from each involved lead.
                leads = [];
                if ismember('LeadIndices', R.Properties.VariableNames)
                    leads = str2num(char(R.LeadIndices(i))); %#ok<ST2NM>
                end
                if isempty(leads)
                    leads = 1:size(counts,1);
                end
                leads = leads(leads>=1 & leads<=size(counts,1));
                for ch = leads(:)'
                    if isfinite(counts(ch,period))
                        counts(ch,period) = max(0, counts(ch,period) - 1);
                    end
                end
            end
        catch
        end
    end
end
