function T = meeg_spike_collect_per_animal(project, timePoint, dayStart, dayEnd, countType)
% Build per-animal lead-level average spike counts from saved spike outputs.
% countType: 'single' (spikesCount) or 'multilead' (multCount)

    if nargin < 2 || isempty(timePoint), timePoint = 'all'; end
    if nargin < 3 || isempty(dayStart), dayStart = 6.5; end
    if nargin < 4 || isempty(dayEnd), dayEnd = 18.5; end
    if nargin < 5 || isempty(countType), countType = 'single'; end
    countType = lower(string(countType));

    rows = {};
    if isempty(project) || ~isfield(project,'manifest') || isempty(project.manifest) || height(project.manifest)==0
        T = table(); return;
    end

    M = project.manifest;
    vars = M.Properties.VariableNames;
    idx = find(local_include_mask(M));
    for ii = 1:numel(idx)
        i = idx(ii);

        a = [];
        if isfield(project,'animals') && numel(project.animals) >= i
            a = project.animals(i);
        end

        prefix = "";
        if ~isempty(a) && isfield(a,'prefix') && strlength(string(a.prefix)) > 0
            prefix = string(a.prefix);
        else
            try
                [allPrefixes, ~] = meeg_manifest_get_animal_prefixes(M(i,:));
                prefix = string(allPrefixes(1));
            catch
                prefix = string(M.MouseID(i));
            end
        end

        prefixCandidates = local_prefix_candidates(project, i, prefix);
        [matf, xlsxf, resolvedPrefix] = findSpikeOutputs(project, prefixCandidates);
        if strlength(resolvedPrefix) > 0
            prefix = resolvedPrefix;
        end
        if strlength(matf) == 0 && strlength(xlsxf) == 0
            continue;
        end

        hours = [];
        counts = [];
        channelLabels = {};
        if strlength(matf) > 0
            S = load(char(matf));
            if isfield(S,'hours'), hours = S.hours; end
            if countType == "multilead"
                if isfield(S,'multCount'), counts = S.multCount; end
            else
                if isfield(S,'spikesCount'), counts = S.spikesCount; end
            end
            if isfield(S,'channelLabels') && ~isempty(S.channelLabels)
                channelLabels = cellstr(string(S.channelLabels(:))');
            elseif ~isempty(a) && isfield(a,'fileOrder') && ~isempty(a.fileOrder)
                channelLabels = cellstr(string(a.fileOrder(:))');
            end
        end

        if (isempty(hours) || isempty(counts)) && strlength(xlsxf) > 0
            sheetName = 'spikes';
            if countType == "multilead", sheetName = 'multileadspikes'; end
            A = readmatrix(char(xlsxf), 'Sheet', sheetName);
            if isempty(A) || size(A,1) < 2
                continue;
            end
            hours = A(1,:);
            counts = A(2:end,:);
            if ~isempty(a) && isfield(a,'fileOrder') && ~isempty(a.fileOrder)
                channelLabels = cellstr(string(a.fileOrder(:))');
            else
                channelLabels = arrayfun(@(k) sprintf('Ch%d', k), 1:size(counts,1), 'UniformOutput', false);
            end
        end

        if isempty(hours) || isempty(counts)
            continue;
        end
        try
            counts = meeg_spike_apply_review_to_counts(project, prefix, counts, conditionalFieldFromLoaded(matf, 'fs', 2500), countType);
        catch
        end
        if isempty(channelLabels)
            channelLabels = arrayfun(@(k) sprintf('Ch%d', k), 1:size(counts,1), 'UniformOutput', false);
        end

        keep = localSelectHours(hours, timePoint, dayStart, dayEnd);
        if ~any(keep), continue; end
        meanLead = mean(counts(:,keep), 2, 'omitnan');
        leadPretty = cellfun(@local_pretty_lead_label, channelLabels, 'UniformOutput', false);
        regionLabels = cellfun(@local_normalize_region_label, channelLabels, 'UniformOutput', false);

        for r = 1:numel(leadPretty)
            row = struct();
            row.Prefix = prefix;
            row.Lead = string(leadPretty{r});
            row.Region = string(regionLabels{r});
            row.SpikeCount = meanLead(r);
            row.CountType = countType;
            row.BaseWindowHours = 0.5;
            for v = 1:numel(vars)
                try
                    row.(vars{v}) = M{i, vars{v}};
                catch
                end
            end
            rows(end+1,1) = {row}; %#ok<AGROW>
        end
    end

    if isempty(rows)
        T = table(); return;
    end
    T = struct2table([rows{:}]);
end

function [matf, xlsxf, resolvedPrefix] = findSpikeOutputs(project, prefixCandidates)
    matf = ""; xlsxf = ""; resolvedPrefix = "";
    for ii = 1:numel(prefixCandidates)
        p = string(prefixCandidates(ii));
        b = meeg_outdir(project,'qeeg', char(p));
        if ~isfolder(b), continue; end
        d = dir(fullfile(b, '*_spikes.mat'));
        if ~isempty(d)
            matf = string(fullfile(d(1).folder, d(1).name));
        end
        d = dir(fullfile(b, '*_spikes.xlsx'));
        if ~isempty(d)
            xlsxf = string(fullfile(d(1).folder, d(1).name));
        end
        if strlength(matf) > 0 || strlength(xlsxf) > 0
            resolvedPrefix = p; return;
        end
    end
end

function candidates = local_prefix_candidates(project, rowIdx, defaultPrefix)
    candidates = strings(0,1);
    if nargin >= 3 && strlength(string(defaultPrefix)) > 0
        candidates(end+1,1) = string(defaultPrefix);
    end
    try
        if isfield(project,'animals') && numel(project.animals) >= rowIdx && isfield(project.animals,'prefix')
            p = string(project.animals(rowIdx).prefix);
            if strlength(p) > 0, candidates(end+1,1) = p; end
        end
    catch
    end
    try
        raw = string(project.manifest.TreatmentGroup(rowIdx)) + "_" + string(project.manifest.MouseID(rowIdx));
        if strlength(raw) > 1, candidates(end+1,1) = raw; end
    catch
    end
    try
        [allPrefixes, ~] = meeg_manifest_get_animal_prefixes(project.manifest(rowIdx,:));
        if ~isempty(allPrefixes), candidates(end+1,1) = string(allPrefixes(1)); end
    catch
    end
    base = candidates;
    for ii = 1:numel(base)
        p = string(base(ii));
        variants = [p; string(matlab.lang.makeValidName(char(p))); replace(p,"-","_"); replace(p," ","_"); replace(replace(p,"-","_")," ","_")];
        candidates = [candidates; variants]; %#ok<AGROW>
    end
    candidates = candidates(strlength(candidates) > 0);
    [~, ia] = unique(cellstr(candidates), 'stable');
    candidates = candidates(sort(ia));
end

function keep = localSelectHours(hours, timePoint, d0, d1)
    hours = hours(:)';
    switch lower(char(string(timePoint)))
        case 'day'
            keep = localIsInDay(hours, d0, d1);
        case 'night'
            keep = ~localIsInDay(hours, d0, d1);
        otherwise
            keep = true(size(hours));
    end
end

function tf = localIsInDay(hr, d0, d1)
    if d0 == 0 && d1 == 0
        tf = true(size(hr));
    elseif d0 < d1
        tf = (hr >= d0) & (hr < d1);
    else
        tf = (hr >= d0) | (hr < d1);
    end
end

function mask = local_include_mask(M)
    mask = true(height(M),1);
    try
        inc = M.Include;
        if islogical(inc)
            mask = inc;
        elseif isnumeric(inc)
            mask = inc ~= 0;
        else
            incs = lower(strtrim(string(inc)));
            mask = ismember(incs, ["true","1","yes","y"]);
        end
    catch
    end
end

function r = local_normalize_region_label(lbl)
    s = lower(regexprep(string(lbl), '[^a-z0-9]', ''));
    if contains(s,'hip')
        r = 'Hippocampus';
    elseif contains(s,'bar')
        r = 'Barrel';
    elseif contains(s,'mot')
        r = 'Motor';
    elseif contains(s,'vis')
        r = 'Visual';
    elseif contains(s,'aud')
        r = 'Auditory';
    elseif contains(s,'medialprefrontal') || contains(s,'mpfc')
        r = 'Medial prefrontal';
    elseif contains(s,'retrosplenial') || contains(s,'rsp')
        r = 'Retrosplenial';
    elseif contains(s,'pariet')
        r = 'Parietal';
    elseif contains(s,'cing')
        r = 'Cingulate';
    elseif contains(s,'thal')
        r = 'Thalamus';
    elseif contains(s,'stri')
        r = 'Striatum';
    elseif contains(s,'areaa')
        r = 'Area A';
    elseif contains(s,'areab')
        r = 'Area B';
    elseif contains(s,'areac')
        r = 'Area C';
    elseif contains(s,'aread')
        r = 'Area D';
    elseif contains(s,'areae')
        r = 'Area E';
    else
        r = char(string(lbl));
    end
end

function lbl = local_pretty_lead_label(raw)
    s = string(raw);
    region = string(local_normalize_region_label(s));
    hemi = "";
    sl = lower(regexprep(s, '[^a-z0-9]', ''));
    if startsWith(sl, 'l') || contains(sl, 'left')
        hemi = 'L';
    elseif startsWith(sl, 'r') || contains(sl, 'right')
        hemi = 'R';
    elseif contains(sl, '026') || contains(sl, '025') || contains(sl, '011') || contains(sl, '009') || contains(sl, '008')
        hemi = 'L';
    elseif contains(sl, '022') || contains(sl, '021') || contains(sl, '004') || contains(sl, '006') || contains(sl, '007')
        hemi = 'R';
    end
    if strlength(hemi) > 0 && any(region == ["Motor","Barrel","Visual","Auditory","Hippocampus","Medial prefrontal","Retrosplenial","Parietal","Cingulate","Thalamus","Striatum"])
        lbl = sprintf('%s (%s)', char(region), char(hemi));
    else
        lbl = char(region);
    end
end


function val = conditionalFieldFromLoaded(matf, fieldName, defaultVal)
    val = defaultVal;
    try
        if strlength(string(matf)) > 0 && isfile(matf)
            S = load(char(matf), fieldName);
            if isfield(S, fieldName), val = S.(fieldName); end
        end
    catch
    end
end
