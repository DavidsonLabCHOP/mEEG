function [nspikes, spikeFlags, peakIdx, zPeaks] = meeg_spike_detect(data, Zspike, fs, minDist_sec, wmin_sec, wmax_sec, cleanupWindow_sec, lowpass_hz)
% data: column vector uV
% Returns:
%   nspikes: number of true spikes
%   spikeFlags: 1xN int8 flags (1 true, -1 false, -2 removed-by-cleanup, 0 none)
%   peakIdx: indices of true spikes
%   zPeaks: z-score at peaks

    if nargin < 4 || isempty(minDist_sec), minDist_sec = 0.2; end
    if nargin < 5 || isempty(wmin_sec), wmin_sec = 0.05; end
    if nargin < 6 || isempty(wmax_sec), wmax_sec = 0.2; end
    if nargin < 7 || isempty(cleanupWindow_sec), cleanupWindow_sec = 5.0; end
    if nargin < 8 || isempty(lowpass_hz), lowpass_hz = 70; end

    data = double(data(:));
    cutoffNorm = max(0.001, min(0.999, (lowpass_hz/fs)*2));
    [b,a] = butter(6, cutoffNorm);         % lowpass filter, legacy-compatible default 70 Hz
    dataF = filter(b,a, data);
    zData = zscore(dataF);

    spikeFlags = zeros(1,length(zData), 'int8');
    peakIdx = [];
    zPeaks = [];

    if isempty(zData) || all(isnan(zData)) || all(zData==0)
        nspikes = 0;
        return;
    end

    minDist = max(1, round(minDist_sec*fs));

    if ~any(isfinite(zData)) || max(zData, [], 'omitnan') < Zspike
        nspikes = 0;
        return;
    end

    [pks, locs, w] = findpeaks(zData, 'MinPeakHeight', Zspike, 'MinPeakDistance', minDist);

    if isempty(locs)
        nspikes = 0;
        return;
    end

    w = w(:)'; locs = locs(:)'; pks = pks(:)';
    ok = (w <= wmax_sec*fs) & (w >= wmin_sec*fs);
    bad = ~ok;

    for i = 1:numel(locs)
        if bad(i)
            spikeFlags(locs(i)) = -1;
        else
            spikeFlags(locs(i)) = 1;
        end
    end

    % Legacy-compatible cleanup: if a false spike is present and there are no true spikes
    % within +/- cleanupWindow_sec, remove that false-spike-associated count.
    if cleanupWindow_sec > 0
        win = max(1, round(cleanupWindow_sec*fs));
        goodLocs = locs(ok);
        falseLocs = locs(bad);
        removeMask = false(size(goodLocs));
        for i = 1:numel(falseLocs)
            lo = falseLocs(i) - win;
            hi = falseLocs(i) + win;
            near = goodLocs >= lo & goodLocs <= hi;
            if ~any(near)
                % remove nearest good spike if one exists in the whole trace
                [~,j] = min(abs(goodLocs - falseLocs(i)));
                if ~isempty(j) && isfinite(j) && j>=1 && j<=numel(goodLocs)
                    removeMask(j) = true;
                end
                spikeFlags(falseLocs(i)) = -2;
            end
        end
        goodLocs(removeMask) = [];
        zGood = pks(ok);
        zGood(removeMask) = [];
        peakIdx = goodLocs;
        zPeaks = zGood;
    else
        peakIdx = locs(ok);
        zPeaks = pks(ok);
    end

    % ensure final flags mark only retained true spikes as 1
    spikeFlags(spikeFlags==1) = 0;
    spikeFlags(peakIdx) = 1;
    nspikes = numel(peakIdx);
end
