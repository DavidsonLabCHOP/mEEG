function [matf, xlsxf, resolvedPrefix] = meeg_spike_find_outputs(project, prefixOrRow)
% Robustly find saved per-animal spike outputs, even if manifest prefixes were
% sanitized differently from project.animals prefixes.

    matf = ""; xlsxf = ""; resolvedPrefix = "";
    candidates = strings(0,1);

    if isnumeric(prefixOrRow) || islogical(prefixOrRow)
        rowIdx = double(prefixOrRow);
        try
            if isfield(project,'animals') && numel(project.animals) >= rowIdx && isfield(project.animals,'prefix')
                p = string(project.animals(rowIdx).prefix);
                if strlength(p) > 0, candidates(end+1,1) = p; end
            end
        catch
        end
        try
            [allPrefixes, ~] = meeg_manifest_get_animal_prefixes(project.manifest);
            if numel(allPrefixes) >= rowIdx
                p = string(allPrefixes(rowIdx));
                if strlength(p) > 0, candidates(end+1,1) = p; end
            end
        catch
        end
        try
            raw = string(project.manifest.TreatmentGroup(rowIdx)) + "_" + string(project.manifest.MouseID(rowIdx));
            if strlength(raw) > 1, candidates(end+1,1) = raw; end
        catch
        end
    else
        p = string(prefixOrRow);
        if strlength(p) > 0, candidates(end+1,1) = p; end
    end

    base = candidates;
    for ii = 1:numel(base)
        p = string(base(ii));
        variants = [p; string(matlab.lang.makeValidName(char(p))); replace(p,'-','_'); replace(p,'_','-'); replace(p,' ','_'); replace(replace(p,'-','_'),' ','_')];
        candidates = [candidates; variants]; %#ok<AGROW>
    end
    candidates = candidates(strlength(candidates) > 0);
    [~, ia] = unique(cellstr(candidates), 'stable');
    candidates = candidates(sort(ia));

    for ii = 1:numel(candidates)
        prefix = char(candidates(ii));
        baseDir = meeg_outdir(project,'qeeg', prefix);
        if ~isfolder(baseDir), continue; end
        d = dir(fullfile(baseDir, '*_spikes.mat'));
        if ~isempty(d), matf = string(fullfile(d(1).folder, d(1).name)); end
        d = dir(fullfile(baseDir, '*_spikes.xlsx'));
        if ~isempty(d), xlsxf = string(fullfile(d(1).folder, d(1).name)); end
        if strlength(matf) > 0 || strlength(xlsxf) > 0
            resolvedPrefix = string(prefix);
            return;
        end
        d = dir(fullfile(baseDir, 'Spikes', '*_spikes.mat'));
        if ~isempty(d), matf = string(fullfile(d(1).folder, d(1).name)); end
        d = dir(fullfile(baseDir, 'Spikes', '*_spikes.xlsx'));
        if ~isempty(d), xlsxf = string(fullfile(d(1).folder, d(1).name)); end
        if strlength(matf) > 0 || strlength(xlsxf) > 0
            resolvedPrefix = string(prefix);
            return;
        end
    end
end
