function [events, meta] = meeg_spike_list_events(project, animalPrefix, leadIdx, timePoint, dayStart, dayEnd)
% Build a table of spike events for a given animal + lead from <prefix>_spikes.mat
% events columns:
%   idx        - global sample index (int64)
%   sec        - seconds from recording start
%   hour       - hour-of-day estimate (if available)
%   period     - 30-min block index
%   leadIdx    - lead index (1..10)
%   z          - z-score at peak
%
% meta:
%   fs, hourStart (if available), leadLabel

    if nargin < 4 || isempty(timePoint), timePoint = 'all'; end
    if nargin < 5 || isempty(dayStart), dayStart = 6.5; end
    if nargin < 6 || isempty(dayEnd), dayEnd = 18.5; end

    prefix = char(animalPrefix);
    [matFile, ~, resolvedPrefix] = meeg_spike_find_outputs(project, prefix);
    if strlength(string(resolvedPrefix)) > 0
        prefix = char(resolvedPrefix);
    end
    if isempty(matFile) || ~isfile(matFile)
        events = table(); meta = struct(); return;
    end

    S = load(matFile);
    fs = S.fs;
    hours = S.hours;
    try
        h0 = meeg_manifest_get_start_hour(project, prefix);
        if isfinite(h0) && ~isempty(hours)
            hours = mod(h0 + (0:numel(hours)-1)*0.5, 24);
        end
    catch
    end
    spikePeaks = S.spikePeaks;
    spikeZ = S.spikeZ;

    sampsPerWindow = fs*60*30;

    idxAll = [];
    zAll = [];
    periodAll = [];
    hourAll = [];
    leadAll = [];

    leadVec = leadIdx(:)';

    for t = 1:numel(hours)
        for li = 1:numel(leadVec)
            ldx = leadVec(li);
            peaks = spikePeaks{ldx,t};
            if isempty(peaks), continue; end
            zpk = spikeZ{ldx,t};
            if isempty(zpk), zpk = nan(size(peaks)); end

            idxAll = [idxAll; peaks(:)]; %#ok<AGROW>
            zAll = [zAll; zpk(:)]; %#ok<AGROW>
            periodAll = [periodAll; repmat(t, numel(peaks), 1)]; %#ok<AGROW>
            hourAll = [hourAll; repmat(hours(t), numel(peaks), 1)]; %#ok<AGROW>
            leadAll = [leadAll; repmat(ldx, numel(peaks), 1)]; %#ok<AGROW>
        end
    end

    if isempty(idxAll)
        events = table();
    else
        secAll = double(idxAll - 1) / fs;

        keep = true(size(hourAll));
        tp = lower(string(timePoint));
        if tp ~= "all"
            if dayStart == 0 && dayEnd == 0
                isDay = true(size(hourAll));
            else
                isDay = false(size(hourAll));
                for k = 1:numel(hourAll)
                    hr = hourAll(k);
                    if dayStart < dayEnd
                        isDay(k) = (hr >= dayStart) && (hr < dayEnd);
                    else
                        isDay(k) = (hr >= dayStart) || (hr < dayEnd);
                    end
                end
            end
            if tp=="day"
                keep = isDay;
            else
                keep = ~isDay;
            end
        end

        idxAll = idxAll(keep);
        zAll = zAll(keep);
        secAll = secAll(keep);
        periodAll = periodAll(keep);
        hourAll = hourAll(keep);
        leadAll = leadAll(keep);

        events = table(int64(idxAll), secAll, hourAll, periodAll, leadAll, zAll, ...
            'VariableNames', {'idx','sec','hour','period','leadIdx','z'});
        R = meeg_spike_load_review(project, prefix);
        inc = true(height(events),1);
        dec = repmat("auto-kept", height(events), 1);
        for rr = 1:height(events)
            [inc(rr), dec(rr)] = meeg_spike_review_lookup(R, 'single', events.leadIdx(rr), events.idx(rr));
        end
        events.UserIncluded = inc;
        events.UserDecision = dec;
        events = sortrows(events, 'idx', 'ascend');
    end

    meta = struct();
    meta.fs = fs;
    meta.sampsPerWindow = sampsPerWindow;
    meta.hours = hours;
    meta.leadIdx = leadIdx;
    if numel(leadIdx)==1
        meta.leadLabel = leadLabel(project, leadIdx);
    else
        meta.leadLabel = 'Multiple';
    end
end

function lbl = leadLabel(project, leadIdx)
    if isfield(project,'profile')
        profile = project.profile;
    else
        profile = meeg_getSystemProfile(project.systemId);
    end
    if isfield(profile,'channelLabels') && numel(profile.channelLabels) >= leadIdx
        lbl = profile.channelLabels{leadIdx};
    else
        lbl = sprintf('Lead %d', leadIdx);
    end
end
