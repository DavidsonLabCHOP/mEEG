function [events, meta] = meeg_spike_list_multilead_events(project, animalPrefix, timePoint, dayStart, dayEnd, winSec, minLeads)
    if nargin < 3 || isempty(timePoint), timePoint='all'; end
    if nargin < 4 || isempty(dayStart), dayStart=6.5; end
    if nargin < 5 || isempty(dayEnd), dayEnd=18.5; end
    if nargin < 6 || isempty(winSec), winSec=0.1; end
    if nargin < 7 || isempty(minLeads), minLeads=2; end

    prefix = char(animalPrefix);
    [matFile, ~, resolvedPrefix] = meeg_spike_find_outputs(project, prefix);
    if strlength(string(resolvedPrefix)) > 0
        prefix = char(resolvedPrefix);
    end
    if isempty(matFile) || ~isfile(matFile)
        events = table(); meta = struct(); return;
    end

    S = load(matFile);
    fs = S.fs;
    hours = S.hours;
    try
        h0 = meeg_manifest_get_start_hour(project, prefix);
        if isfinite(h0) && ~isempty(hours)
            hours = mod(h0 + (0:numel(hours)-1)*0.5, 24);
        end
    catch
    end
    spikePeaks = S.spikePeaks;
    spikeZ = S.spikeZ;

    numCh = size(spikePeaks,1);
    winSamp = max(1, round(winSec*fs));

    allIdx=[]; allZ=[]; allLead=[]; allPeriod=[]; allHour=[];
    for t = 1:numel(hours)
        for ch = 1:numCh
            p = spikePeaks{ch,t};
            if isempty(p), continue; end
            zpk = spikeZ{ch,t};
            if isempty(zpk), zpk = nan(size(p)); end
            allIdx = [allIdx; int64(p(:))];
            allZ = [allZ; zpk(:)];
            allLead = [allLead; repmat(ch, numel(p), 1)];
            allPeriod = [allPeriod; repmat(t, numel(p), 1)];
            allHour = [allHour; repmat(hours(t), numel(p), 1)];
        end
    end
    if isempty(allIdx)
        events = table(); meta = struct('fs',fs); return;
    end

    [allIdx, ord] = sort(allIdx);
    allZ = allZ(ord); allLead = allLead(ord); allPeriod = allPeriod(ord); allHour = allHour(ord);

    tp = lower(string(timePoint));
    keep = true(size(allHour));
    if tp ~= "all"
        if dayStart == 0 && dayEnd == 0
            isDay = true(size(allHour));
        else
            isDay = false(size(allHour));
            for k = 1:numel(allHour)
                hr = allHour(k);
                if dayStart < dayEnd
                    isDay(k) = (hr >= dayStart) && (hr < dayEnd);
                else
                    isDay(k) = (hr >= dayStart) || (hr < dayEnd);
                end
            end
        end
        if tp=="day", keep=isDay; else, keep=~isDay; end
    end
    allIdx=allIdx(keep); allZ=allZ(keep); allLead=allLead(keep); allPeriod=allPeriod(keep); allHour=allHour(keep);
    if isempty(allIdx)
        events=table(); meta=struct('fs',fs); return;
    end

    clusters = {};
    cl.idx = allIdx(1); cl.leads = allLead(1); cl.z = allZ(1); cl.period = allPeriod(1); cl.hour = allHour(1);
    curEnd = allIdx(1);
    for i = 2:numel(allIdx)
        idxi = allIdx(i);
        if idxi <= curEnd + winSamp
            cl.idx(end+1,1)=idxi;
            cl.leads(end+1,1)=allLead(i);
            cl.z(end+1,1)=allZ(i);
            cl.period(end+1,1)=allPeriod(i);
            cl.hour(end+1,1)=allHour(i);
            curEnd = idxi;
        else
            clusters{end+1}=cl; %#ok<AGROW>
            cl.idx = idxi; cl.leads = allLead(i); cl.z = allZ(i); cl.period = allPeriod(i); cl.hour = allHour(i);
            curEnd = idxi;
        end
    end
    clusters{end+1}=cl;

    if isfield(project,'profile')
        profile = project.profile;
    else
        profile = meeg_getSystemProfile(project.systemId);
    end
    leadLabels = profile.channelLabels;

    evIdx=[]; evSec=[]; evHour=[]; evPeriod=[]; evN=[]; evLeads=strings(0,1); evZmax=[];
    for c = 1:numel(clusters)
        cl = clusters{c};
        u = unique(cl.leads);
        if numel(u) < minLeads, continue; end
        rep = int64(round(median(double(cl.idx))));
        evIdx(end+1,1)=rep; %#ok<AGROW>
        evSec(end+1,1)=double(rep-1)/fs;
        evHour(end+1,1)=median(cl.hour);
        evPeriod(end+1,1)=mode(cl.period);
        evN(end+1,1)=numel(u);
        evLeads(end+1,1)=strjoin(string(leadLabels(u)), ",");
        evZmax(end+1,1)=max(cl.z, [], 'omitnan');
    end

    if isempty(evIdx)
        events = table();
    else
        events = table(int64(evIdx), evSec, evHour, evPeriod, evN, evLeads, evZmax, ...
            'VariableNames', {'idx','sec','hour','period','nLeads','leads','zMax'});
        R = meeg_spike_load_review(project, prefix);
        inc = true(height(events),1);
        dec = repmat("auto-kept", height(events), 1);
        for rr = 1:height(events)
            [inc(rr), dec(rr)] = meeg_spike_review_lookup(R, 'multilead', NaN, events.idx(rr));
        end
        events.UserIncluded = inc;
        events.UserDecision = dec;
        events = sortrows(events,'idx','ascend');
    end
    meta = struct('fs',fs,'leadLabels',{leadLabels});
end

