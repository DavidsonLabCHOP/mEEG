function R = meeg_spike_load_review(project, prefix)
% Load per-spike user review decisions. Missing table means all events included.
    f = meeg_spike_review_file(project, prefix);
    if strlength(f)==0 || ~isfile(f)
        R = table();
        return;
    end
    try
        R = readtable(f, 'FileType', 'spreadsheet');
    catch
        try
            R = readtable(f);
        catch
            R = table();
        end
    end
    if isempty(R), return; end
    if ~ismember('EventType', R.Properties.VariableNames), R.EventType = strings(height(R),1); end
    if ~ismember('LeadIndex', R.Properties.VariableNames), R.LeadIndex = nan(height(R),1); end
    if ~ismember('Idx', R.Properties.VariableNames), R.Idx = nan(height(R),1); end
    if ~ismember('UserIncluded', R.Properties.VariableNames), R.UserIncluded = true(height(R),1); end
    if ~ismember('UserDecision', R.Properties.VariableNames), R.UserDecision = repmat("auto-kept", height(R), 1); end
    if ~ismember('ReviewTimestamp', R.Properties.VariableNames), R.ReviewTimestamp = repmat("", height(R), 1); end
end
