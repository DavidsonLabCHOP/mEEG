function [tsec, Y] = meeg_spike_read_snippet(files, chIdx, startSample, nSamples, fs, scale_uV, applyNotch)
% Read a snippet from raw .dat files for selected channels.
% files: cellstr length numCh (each is a channel file)
% chIdx: vector of channel indices to read (1-based)
% startSample: 1-based sample index in the recording
% nSamples: number of samples to read
% Returns:
%   tsec: 1 x nSamples time vector (sec, relative to snippet start)
%   Y: numel(chIdx) x nSamples (uV)

    if nargin < 7, applyNotch = true; end
    bytesPerSample = 2;

    Y = nan(numel(chIdx), nSamples);
    for k = 1:numel(chIdx)
        ch = chIdx(k);
        fid = fopen(files{ch}, 'r');
        if fid == -1, error('Could not open %s', files{ch}); end
        offsetBytes = int64(startSample-1) * int64(bytesPerSample);
        fseek(fid, offsetBytes, 'bof');
        raw = fread(fid, nSamples, 'int16=>double');
        fclose(fid);
        x = raw(:)' * scale_uV;

        if applyNotch
            filt = designfilt('bandstopiir','FilterOrder',2, ...
                'HalfPowerFrequency1',59,'HalfPowerFrequency2',61, ...
                'DesignMethod','butter','SampleRate',fs);
            x = filtfilt(filt, x);
        end

        Y(k,:) = x;
    end

    tsec = (0:(nSamples-1)) / fs;
end
