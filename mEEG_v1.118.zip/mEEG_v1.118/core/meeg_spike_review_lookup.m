function [included, decision] = meeg_spike_review_lookup(R, eventType, leadIdx, idx)
% Return inclusion status for a spike event key.
    included = true;
    decision = "auto-kept";
    if isempty(R) || height(R)==0, return; end
    try
        et = lower(string(R.EventType));
        ids = double(R.Idx);
        if strcmpi(char(eventType), 'single')
            mask = et == "single" & double(R.LeadIndex) == double(leadIdx) & ids == double(idx);
        else
            mask = et == "multilead" & ids == double(idx);
        end
        k = find(mask, 1, 'last');
        if ~isempty(k)
            included = logical(R.UserIncluded(k));
            decision = string(R.UserDecision(k));
        end
    catch
    end
end
