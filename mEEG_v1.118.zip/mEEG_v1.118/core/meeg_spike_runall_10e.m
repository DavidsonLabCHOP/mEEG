function meeg_spike_runall_10e(project, spikeOpts, logfn)
% Run spike analysis for all included animals in manifest.
% Supports Intan and EDF-backed cached channel files.
%
% spikeOpts fields (defaults applied if missing):
%   fs, hourStart
%   artifactMode: 'use_preprocessing_masks' | 'bad_channel_selection_only' | 'none'
%   legacyNotchFilter: true/false
%   Zspike, minDist_sec, width_min_sec, width_max_sec
%   cleanupWindow_sec, multilead_win_sec, lowpass_hz

    if nargin < 3 || isempty(logfn)
        logfn = @(msg) disp(msg);
    end

    M = project.manifest;
    if isempty(M) || height(M)==0
        logfn("No manifest loaded.");
        return;
    end

    includeMask = local_include_mask(M);
    idxAll = find(includeMask);
    if isempty(idxAll)
        logfn("No animals selected (Include == true).");
        return;
    end

    if ~isfield(spikeOpts,'Zspike'), spikeOpts.Zspike = 5; end
    if ~isfield(spikeOpts,'minDist_sec'), spikeOpts.minDist_sec = 0.2; end
    if ~isfield(spikeOpts,'width_min_sec'), spikeOpts.width_min_sec = 0.05; end
    if ~isfield(spikeOpts,'width_max_sec'), spikeOpts.width_max_sec = 0.2; end
    if ~isfield(spikeOpts,'multilead_win_sec'), spikeOpts.multilead_win_sec = 0.1; end
    if ~isfield(spikeOpts,'cleanupWindow_sec'), spikeOpts.cleanupWindow_sec = 5; end
    if ~isfield(spikeOpts,'lowpass_hz'), spikeOpts.lowpass_hz = 70; end
    if ~isfield(spikeOpts,'legacyNotchFilter'), spikeOpts.legacyNotchFilter = true; end
    if ~isfield(spikeOpts,'artifactMode') || strlength(string(spikeOpts.artifactMode))==0
        if isfield(spikeOpts,'useMasks') && spikeOpts.useMasks
            spikeOpts.artifactMode = 'use_preprocessing_masks';
        elseif isfield(spikeOpts,'useMasks')
            spikeOpts.artifactMode = 'bad_channel_selection_only';
        else
            spikeOpts.artifactMode = 'use_preprocessing_masks';
        end
    end

    if isfield(project,'profile')
        profile = project.profile;
    else
        profile = meeg_getSystemProfile(project.systemId);
    end

    useParallelAnimals = false;
    try
        useParallelAnimals = isfield(spikeOpts,'useParallel') && logical(spikeOpts.useParallel) && numel(idxAll) > 1 && license('test','Distrib_Computing_Toolbox');
    catch
        useParallelAnimals = false;
    end
    if useParallelAnimals
        logfn(sprintf('Spikes: running in parallel across %d animals...', numel(idxAll)));
        try
            useParallelAnimals = meeg_ensure_process_pool(logfn);
        catch
            useParallelAnimals = false;
            logfn('Spikes: could not start a process-based parallel pool; falling back to serial.');
        end
    end
    if useParallelAnimals
        parfor kk = 1:numel(idxAll)
            pOne = project;
            Mone = pOne.manifest;
            incOne = false(height(Mone),1);
            incOne(idxAll(kk)) = true;
            Mone.Include = incOne;
            pOne.manifest = Mone;
            optOne = spikeOpts;
            optOne.useParallel = false;
            meeg_spike_runall_10e(pOne, optOne, @(m) fprintf('%s\n', char(string(m))));
        end
        logfn('Spikes: parallel run complete.');
        return;
    end

    [allPrefixes, ~] = meeg_manifest_get_animal_prefixes(M);
    for k = 1:numel(idxAll)
        i = idxAll(k);
        prefix = local_text_scalar(allPrefixes(i));
        logfn("Spikes: " + prefix + sprintf(" (%d/%d)", k, numel(idxAll)));

        [a,~] = meeg_project_get_animal(project, prefix);
        if isempty(a)
            try
                allp = string({project.animals.prefix});
                prefA = matlab.lang.makeValidName(char(prefix));
                prefB = replace(string(prefix), "_", "-");
                prefC = replace(string(prefix), "-", "_");
                hit = find(allp==prefix | string(matlab.lang.makeValidName(cellstr(allp)))==prefA | allp==prefB | allp==prefC, 1);
                if ~isempty(hit)
                    a = project.animals(hit);
                    prefix = local_text_scalar(a.prefix);
                end
            catch
            end
        end
        if isempty(a)
            logfn("WARNING: No files found for " + string(prefix) + "; skipping.");
            continue;
        end
        files = a.files;
        numCh = numel(files);
        if numCh < 1
            logfn("WARNING: No channel files for " + string(prefix) + "; skipping.");
            continue;
        end
        fs = spikeOpts.fs;

        if isfield(a,'fileOrder') && ~isempty(a.fileOrder)
            channelLabels = cellstr(string(a.fileOrder(:))');
        elseif isfield(profile,'channelLabels') && numel(profile.channelLabels) >= numCh
            channelLabels = cellstr(string(profile.channelLabels(1:numCh))');
        else
            channelLabels = arrayfun(@(kk) sprintf('Ch%d', kk), 1:numCh, 'UniformOutput', false);
        end

        hourStart = spikeOpts.hourStart;
        try
            hs = meeg_manifest_get_start_hour(project, prefix, i);
            if isfinite(hs)
                hourStart = hs;
            end
        catch
        end
        logfn(sprintf('  - Recording start clock hour for day/night: %.3f', hourStart));

        prefix = local_text_scalar(prefix);
        outDir = char(meeg_outdir(project,'qeeg', char(prefix)));
        if ~isfolder(outDir), mkdir(outDir); end
        outputPrefix = char(fullfile(outDir, char(prefix)));

        haveMasks = false;
        artifactMode = lower(string(spikeOpts.artifactMode));
        if artifactMode == "use_preprocessing_masks"
            maskDir = meeg_outdir(project,'preprocessing', prefix);
            if isfolder(maskDir)
                badFile = fullfile(maskDir, 'lowQEpochMask.mat');
                goodFile = fullfile(maskDir, 'goodQChannelMask.mat');
                if isfile(badFile) && isfile(goodFile)
                    Sbad = load(badFile); Sgood = load(goodFile);
                    if isfield(Sbad,'badEpochAll') && isfield(Sgood,'goodChByPeriod')
                        haveMasks = true;
                        badEpochAll = logical(Sbad.badEpochAll);
                        goodChByPeriod = logical(Sgood.goodChByPeriod);
                    end
                end
            end
            if ~haveMasks
                logfn("  - Preprocessing masks not found; falling back to bad channel selection only.");
                artifactMode = "bad_channel_selection_only";
            end
        end

        bytesPerSample = 2;
        scale_uV = conditionalField(profile, 'scale_uV', 0.195);
        sampsPer5s = fs*5;
        sampsPerWindow = fs*60*30;
        nEpochs5s = sampsPerWindow / sampsPer5s;

        samplesPerFile = zeros(1,numCh);
        for ch = 1:numCh
            d = dir(files{ch});
            if isempty(d), error('Missing file: %s', files{ch}); end
            samplesPerFile(ch) = floor(double(d.bytes)/bytesPerSample);
        end
        recPeriods = floor(min(samplesPerFile) / sampsPerWindow);
        if recPeriods < 1
            logfn("  - Skipping, file too short.");
            continue;
        end
        if haveMasks
            maskPeriods = min(size(goodChByPeriod,2), floor(size(badEpochAll,2)/nEpochs5s));
            recPeriods = min(recPeriods, maskPeriods);
        end

        filt = designfilt('bandstopiir','FilterOrder',2, ...
                       'HalfPowerFrequency1',59,'HalfPowerFrequency2',61, ...
                       'DesignMethod','butter','SampleRate',fs);
        if spikeOpts.legacyNotchFilter
            applyNotch = @(x) filter(filt, x);
        else
            applyNotch = @(x) filtfilt(filt, x);
        end

        spikesCount = nan(numCh, recPeriods);
        multCount   = nan(numCh, recPeriods);
        hours = nan(1, recPeriods);
        spikePeaks = cell(numCh, recPeriods);
        spikeZ     = cell(numCh, recPeriods);
        v = zeros(numCh, sampsPerWindow);

        for t = 1:recPeriods
            hours(t) = mod(hourStart + (t-1)*0.5, 24);
            for ch = 1:numCh
                fid = fopen(files{ch}, 'r');
                if fid == -1, error('Could not open %s', files{ch}); end
                offsetBytes = int64(t-1) * int64(sampsPerWindow) * int64(bytesPerSample);
                fseek(fid, offsetBytes, 'bof');
                raw = fread(fid, sampsPerWindow, 'int16=>double'); fclose(fid);
                v(ch,:) = applyNotch(raw(:)' * scale_uV);
            end

            switch char(artifactMode)
                case 'use_preprocessing_masks'
                    goodCh = goodChByPeriod(:, t);
                    badEpoch = badEpochAll(:, (t-1)*nEpochs5s + 1 : t*nEpochs5s);
                case 'bad_channel_selection_only'
                    goodCh = local_compute_good_channels(v, fs);
                    badEpoch = false(numCh, nEpochs5s);
                otherwise
                    goodCh = true(numCh,1);
                    badEpoch = false(numCh, nEpochs5s);
            end
            goodCh = logical(goodCh(:));
            if numel(goodCh) < numCh
                goodCh(end+1:numCh,1) = true;
            end

            for ch = 1:numCh
                if ~goodCh(ch)
                    v(ch,:) = 0;
                elseif any(badEpoch(ch,:))
                    for e = 1:nEpochs5s
                        if badEpoch(ch,e)
                            sIdx = (e-1)*sampsPer5s + (1:sampsPer5s);
                            v(ch,sIdx) = 0;
                        end
                    end
                end
            end

            tempFlags = zeros(numCh, sampsPerWindow, 'int8');
            for ch = 1:numCh
                if ~goodCh(ch)
                    spikesCount(ch,t) = NaN;
                    multCount(ch,t) = NaN;
                    continue;
                end
                x = v(ch,:)';
                [nsp, flags, peaks, zpk] = meeg_spike_detect(x, spikeOpts.Zspike, fs, spikeOpts.minDist_sec, spikeOpts.width_min_sec, spikeOpts.width_max_sec, spikeOpts.cleanupWindow_sec, spikeOpts.lowpass_hz);
                tempFlags(ch,:) = int8(flags);
                spikesCount(ch,t) = nsp;
                spikePeaks{ch,t} = int64(peaks) + int64((t-1)*sampsPerWindow);
                spikeZ{ch,t} = zpk;
            end

            win = round(spikeOpts.multilead_win_sec * fs);
            for ch = 1:numCh
                if ~goodCh(ch), continue; end
                cnt = 0;
                flags = tempFlags(ch,:);
                for j = (1+win):(sampsPerWindow-win)
                    if flags(j) == 1
                        if sum(sum(tempFlags(:, (j-win):(j+win))==1)) >= 2
                            cnt = cnt + 1;
                        end
                    end
                end
                multCount(ch,t) = cnt;
            end
        end

        xlsxFile = [outputPrefix '_spikes.xlsx'];
        try
            writematrix([hours; spikesCount], xlsxFile, 'Sheet', 'spikes');
            writematrix([hours; multCount],   xlsxFile, 'Sheet', 'multileadspikes');
            logfn("  - Saved spike table: " + string(xlsxFile));
        catch ME
            logfn("  - WARNING: Could not save spike table for " + string(prefix) + ": " + string(ME.message));
        end

        regionLabels = local_region_labels_from_channels(channelLabels);
        matFile = [outputPrefix '_spikes.mat'];
        try
            save(matFile, 'fs','hours','spikesCount','multCount','spikePeaks','spikeZ','profile','spikeOpts','channelLabels','regionLabels');
            logfn("  - Saved spike MAT: " + string(matFile));
        catch ME
            logfn("  - WARNING: Could not save spike MAT for " + string(prefix) + ": " + string(ME.message));
        end
    end
end

function s = local_text_scalar(x)
    if isstring(x)
        x = x(:);
        x = x(~ismissing(x));
        if isempty(x)
            s = "";
        else
            s = string(x(1));
        end
    elseif iscell(x)
        if isempty(x)
            s = "";
        else
            s = local_text_scalar(x{1});
        end
    elseif ischar(x)
        s = string(x);
    else
        try
            s = string(x);
            s = s(1);
        catch
            s = "";
        end
    end
end

function goodCh = local_compute_good_channels(v, fs)
    numCh = size(v,1);
    nSec = floor(size(v,2)/fs);
    goodCh = true(numCh,1);
    for i = 1:numCh
        skw = nan(1,nSec);
        rtms = nan(1,nSec);
        for n = 1:nSec
            idx = (fs*(n-1)+1):(fs*n);
            seg = v(i,idx);
            skw(n) = skewness(seg);
            rtms(n) = rms(seg);
        end
        meanSkw = mean(skw,'omitnan');
        meanRtms = mean(rtms,'omitnan');
        if meanRtms > 200 || meanRtms < 30 || meanSkw > 0.4
            goodCh(i) = false;
        end
    end
end

function labels = local_region_labels_from_channels(channelLabels)
    labels = cell(size(channelLabels));
    for i = 1:numel(channelLabels)
        labels{i} = local_normalize_region_label(channelLabels{i});
    end
end

function out = local_normalize_region_label(lbl)
    s = lower(regexprep(string(lbl), '[^a-z0-9]', ''));
    if contains(s,'hip'), out = 'Hippocampus';
    elseif contains(s,'bar'), out = 'Barrel';
    elseif contains(s,'mot'), out = 'Motor';
    elseif contains(s,'vis'), out = 'Visual';
    elseif contains(s,'aud'), out = 'Auditory';
    elseif contains(s,'medialprefrontal') || contains(s,'mpfc'), out = 'Medial prefrontal';
    elseif contains(s,'retrosplenial') || contains(s,'rsp'), out = 'Retrosplenial';
    elseif contains(s,'pariet'), out = 'Parietal';
    elseif contains(s,'cing'), out = 'Cingulate';
    elseif contains(s,'thal'), out = 'Thalamus';
    elseif contains(s,'stri'), out = 'Striatum';
    elseif contains(s,'areaa'), out = 'Area A';
    elseif contains(s,'areab'), out = 'Area B';
    elseif contains(s,'areac'), out = 'Area C';
    elseif contains(s,'aread'), out = 'Area D';
    elseif contains(s,'areae'), out = 'Area E';
    else, out = char(string(lbl));
    end
end

function v = conditionalField(S, f, default)
    if isstruct(S) && isfield(S,f) && ~isempty(S.(f)), v = S.(f); else, v = default; end
end

function mask = local_include_mask(M)
    mask = true(height(M),1);
    if ismember('Include', M.Properties.VariableNames)
        try
            inc = M.Include;
            if islogical(inc), mask = inc;
            elseif isnumeric(inc), mask = inc ~= 0;
            else
                incs = lower(strtrim(string(inc)));
                mask = ismember(incs, ["true","1","yes","y"]);
            end
        catch
        end
    end
end
