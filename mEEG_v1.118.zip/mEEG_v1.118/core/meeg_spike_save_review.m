function meeg_spike_save_review(project, prefix, R)
% Save per-spike user review decisions.
    f = meeg_spike_review_file(project, prefix);
    outDir = fileparts(char(f));
    if ~isfolder(outDir), mkdir(outDir); end
    writetable(R, f, 'FileType', 'spreadsheet');
end
