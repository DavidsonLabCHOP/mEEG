function [T, settingsTbl, summaryTbl, readmeTbl] = meeg_swd_collect_feature_list(project)
%MEEG_SWD_COLLECT_FEATURE_LIST Collect reviewed SWD candidates across a project.
%   One output row is produced per saved SWD candidate. The table preserves
%   automatic detector decisions, current user Keep/Exclude decisions,
%   animal/group metadata, timing, and all available SWD features.

    rows = cell(0,1);
    settingRows = cell(0,1);

    nAnimals = 0;
    try, nAnimals = numel(project.animals); catch, end
    for ai = 1:nAnimals
        prefix = string(project.animals(ai).prefix);
        eventFile = local_event_file(project, prefix);
        if strlength(eventFile)==0 || ~isfile(eventFile), continue; end

        try
            E = readtable(eventFile, 'TextType','string');
        catch
            E = readtable(eventFile);
        end
        if isempty(E), continue; end

        E = local_standardize_event_columns(E, prefix);
        meta = local_manifest_metadata(project, ai, prefix);
        E = local_add_metadata(E, meta);

        n = height(E);
        E.EventID = local_event_ids(E, prefix);
        if ismember('PeakCount', E.Properties.VariableNames)
            E.NumberOfCycles = double(E.PeakCount);
        elseif ~ismember('NumberOfCycles', E.Properties.VariableNames)
            E.NumberOfCycles = nan(n,1);
        end
        if ismember('PeakToPeak', E.Properties.VariableNames)
            E.Amplitude_uV = double(E.PeakToPeak);
        elseif ~ismember('Amplitude_uV', E.Properties.VariableNames)
            E.Amplitude_uV = nan(n,1);
        end

        if ismember('IsDay', E.Properties.VariableNames)
            E.TimePeriod = repmat("Night", n, 1);
            E.TimePeriod(logical(E.IsDay)) = "Day";
        else
            E.TimePeriod = repmat("Available recording", n, 1);
        end
        E.ManualClass = repmat("Exclude", n, 1);
        E.ManualClass(logical(E.UserIncluded)) = "Keep";
        decisions = lower(string(E.UserDecision));
        manualMask = startsWith(decisions, "user-") | startsWith(decisions, "manual-");
        E.ReviewSource = repmat("Automatic / not explicitly reviewed", n, 1);
        E.ReviewSource(manualMask) = "Manual review";

        rows{end+1,1} = E; %#ok<AGROW>
        settingRows{end+1,1} = local_settings_row(project, prefix, eventFile, meta); %#ok<AGROW>
    end

    if isempty(rows)
        T = table();
    else
        T = local_vertcat_tables(rows);
        T = local_reorder_features(T);
    end
    if isempty(settingRows)
        settingsTbl = table();
    else
        settingsTbl = vertcat(settingRows{:});
    end

    summaryTbl = local_review_summary(T);
    readmeTbl = table( ...
        ["Purpose";"ManualClass";"ReviewSource";"AutoIncluded";"CalibrationMode"; ...
         "Threshold assistant";"Treatment groups";"Small pilot studies";"Day/night recordings"], ...
        ["One row per saved SWD candidate, including automatic and manual decisions plus measured features."; ...
         "Current Keep/Exclude state used by SWD Analysis."; ...
         "Shows whether the event was explicitly marked by a user or still reflects the automatic detector decision."; ...
         "Whether the original detector accepted the event using the settings from that run."; ...
         "True when the run retained a broader candidate pool for threshold calibration."; ...
         "Recommendations compare manually reviewed Keep versus Exclude events one feature at a time; they are descriptive starting points and the combined detector must be rerun and validated."; ...
         "TreatmentGroup remains visible for stratified summaries, but thresholds are optimized for real-SWD versus non-SWD classification rather than maximizing treatment-group separation."; ...
         "No minimum group size is required. Recommendations are flagged exploratory when event or animal counts are small."; ...
         "The export and assistant use whichever time periods are present; both day and night are not required."], ...
        'VariableNames', {'Item','Description'});
end

function f = local_event_file(project, prefix)
    f = "";
    candidates = [ ...
        string(fullfile(meeg_outdir(project,'qeeg',char(prefix)), char(prefix) + "_swd_events.xlsx")); ...
        string(fullfile(meeg_outdir(project,'qeeg','SWD Analysis'), char(prefix) + "_swd_events.xlsx"))];
    for k = 1:numel(candidates)
        if isfile(candidates(k)), f = candidates(k); return; end
    end
end

function E = local_standardize_event_columns(E, prefix)
    n = height(E);
    E = meeg_swd_normalize_review_columns(E);
    if ~ismember('Prefix', E.Properties.VariableNames), E.Prefix = repmat(prefix,n,1); end
end

function ids = local_event_ids(E, prefix)
    n = height(E); ids = strings(n,1);
    for r = 1:n
        lead = "Lead"; startKey = r;
        try, lead = string(E.LeadLabel(r)); catch, end
        try
            if ismember('StartSample',E.Properties.VariableNames), startKey = double(E.StartSample(r));
            elseif ismember('StartSec',E.Properties.VariableNames), startKey = round(1000*double(E.StartSec(r))); end
        catch
        end
        ids(r) = prefix + "_" + local_safe_token(lead) + "_" + string(round(startKey));
    end
end

function s = local_safe_token(s)
    s = regexprep(string(s),'[^A-Za-z0-9_-]+','_');
end

function meta = local_manifest_metadata(project, ai, prefix)
    meta = struct('Prefix',prefix,'AnimalID',prefix,'TreatmentGroup',"",'Genotype',"", ...
        'Sex',"",'LitterID',"",'RecordingDate',"");
    try
        M = project.manifest;
        if isempty(M), return; end
        ri = min(ai,height(M));
        % Prefer a row that explicitly contains the project prefix or animal ID.
        vars = M.Properties.VariableNames;
        match = false(height(M),1);
        for vn = ["Prefix","AnimalID","MouseID","ID"]
            if ismember(char(vn),vars)
                try, match = match | string(M.(char(vn)))==prefix; catch, end
            end
        end
        hit = find(match,1); if ~isempty(hit), ri=hit; end
        meta.AnimalID = local_first_meta(M,ri,["MouseID","AnimalID","ID","Prefix"],prefix);
        meta.TreatmentGroup = local_first_meta(M,ri,["TreatmentGroup","StudyGroup","Group"],"");
        meta.Genotype = local_first_meta(M,ri,["Genotype","GEN"],"");
        meta.Sex = local_first_meta(M,ri,["Sex"],"");
        meta.LitterID = local_first_meta(M,ri,["LitterID","Litter"],"");
        meta.RecordingDate = local_first_meta(M,ri,["RecordingDate","Date"],"");
    catch
    end
end

function v = local_first_meta(M,ri,names,defaultVal)
    v=string(defaultVal);
    for name=names
        if ismember(char(name),M.Properties.VariableNames)
            try
                q=string(M.(char(name))(ri));
                if strlength(q)>0 && q~="<missing>", v=q; return; end
            catch
            end
        end
    end
end

function E = local_add_metadata(E, meta)
    n=height(E);
    fields={'AnimalID','TreatmentGroup','Genotype','Sex','LitterID','RecordingDate'};
    for k=1:numel(fields)
        E.(fields{k})=repmat(string(meta.(fields{k})),n,1);
    end
end

function S = local_settings_row(project,prefix,eventFile,meta)
    opts=struct();
    matFile=fullfile(fileparts(eventFile),char(prefix + "_swd.mat"));
    try
        if isfile(matFile)
            q=load(matFile,'swdOpts'); if isfield(q,'swdOpts'), opts=q.swdOpts; end
        end
    catch
    end
    S=table(prefix,string(meta.AnimalID),string(meta.TreatmentGroup),string(matFile), ...
        'VariableNames',{'Prefix','AnimalID','TreatmentGroup','SettingsSource'});
    names={'fs','bandSWD','bandBroad','minDurSec','minPeaks','envZ','minRhythmScore', ...
        'minHarmonicScore','maxArtifactScore','minFreqHz','maxFreqHz','maxIPIcv', ...
        'minLeads','artifactMode','dayStart','dayEnd','calibrationMode', ...
        'candidateEnvZ','candidateMinDurSec','candidateMinPeaks','candidateMinFreqHz','candidateMaxFreqHz'};
    for k=1:numel(names)
        name=names{k};
        if isfield(opts,name)
            val=opts.(name);
            if isnumeric(val) || islogical(val)
                S.(name)=string(mat2str(double(val)));
            else
                S.(name)=string(val);
            end
        else
            S.(name)="";
        end
    end
end


function T=local_vertcat_tables(rows)
    allNames={};
    for i=1:numel(rows)
        allNames=union(allNames,rows{i}.Properties.VariableNames,'stable');
    end
    for i=1:numel(rows)
        R=rows{i}; n=height(R);
        missingNames=setdiff(allNames,R.Properties.VariableNames,'stable');
        for j=1:numel(missingNames)
            name=missingNames{j}; proto=[];
            for q=1:numel(rows)
                if ismember(name,rows{q}.Properties.VariableNames)
                    proto=rows{q}.(name); break;
                end
            end
            if isstring(proto), R.(name)=strings(n,1);
            elseif islogical(proto), R.(name)=false(n,1);
            elseif isnumeric(proto), R.(name)=nan(n,1);
            elseif isdatetime(proto), R.(name)=NaT(n,1);
            elseif iscell(proto), R.(name)=cell(n,1);
            else, R.(name)=strings(n,1);
            end
        end
        rows{i}=R(:,allNames);
    end
    T=vertcat(rows{:});
end

function T = local_reorder_features(T)
    preferred={'EventID','Prefix','AnimalID','TreatmentGroup','Genotype','Sex','LitterID','RecordingDate', ...
        'LeadLabel','LeadIndex','StartSec','EndSec','DurationSec','HourOfDay','IsDay','TimePeriod', ...
        'ManualClass','UserIncluded','UserDecision','ReviewSource','ReviewTimestamp', ...
        'AutoIncluded','AutoDecision','Classification','ConfidenceScore','FailedCriteria','CalibrationMode', ...
        'PassDuration','PassFrequency','PassCycles','PassIPIRegularity','PassRhythmicity','PassHarmonic','PassArtifact','PassLeadCount', ...
        'Amplitude_uV','PeakToPeak','RMS','NumberOfCycles','PeakCount','MeanIPI','IPIcv', ...
        'DominantFreqHz','PeakSharpness','EnvelopeZ','RhythmicityScore','HarmonicScore','ArtifactScore', ...
        'NumLeadsInvolved','StartSample','EndSample'};
    have=preferred(ismember(preferred,T.Properties.VariableNames));
    rest=setdiff(T.Properties.VariableNames,have,'stable');
    T=T(:,[have rest]);
end

function S = local_review_summary(T)
    if isempty(T), S=table(); return; end
    groups=unique(string(T.TreatmentGroup),'stable'); if isempty(groups), groups=""; end
    periods=unique(string(T.TimePeriod),'stable');
    classes=["Keep";"Exclude"];
    rows=cell(0,1);
    for g=1:numel(groups)
        for p=1:numel(periods)
            for c=1:numel(classes)
                idx=string(T.TreatmentGroup)==groups(g) & string(T.TimePeriod)==periods(p) & string(T.ManualClass)==classes(c);
                if ~any(idx), continue; end
                R=table(groups(g),periods(p),classes(c),sum(idx),numel(unique(string(T.AnimalID(idx)))), ...
                    sum(string(T.ReviewSource(idx))=="Manual review"), ...
                    local_med(T,idx,'DurationSec'),local_med(T,idx,'EnvelopeZ'),local_med(T,idx,'RhythmicityScore'), ...
                    local_med(T,idx,'HarmonicScore'),local_med(T,idx,'ArtifactScore'), ...
                    'VariableNames',{'TreatmentGroup','TimePeriod','ManualClass','EventCount','AnimalCount','ManuallyReviewedCount', ...
                    'MedianDurationSec','MedianEnvelopeZ','MedianRhythmicity','MedianHarmonic','MedianArtifact'});
                rows{end+1,1}=R; %#ok<AGROW>
            end
        end
    end
    if isempty(rows), S=table(); else, S=vertcat(rows{:}); end
end

function v=local_med(T,idx,name)
    v=NaN;
    if ismember(name,T.Properties.VariableNames)
        try, v=median(double(T.(name)(idx)),'omitnan'); catch, end
    end
end
