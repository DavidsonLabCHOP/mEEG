function T = meeg_swd_collect_per_animal(project, timePoint, dayStart, dayEnd)
% Collect per-animal SWD metrics for GUI plotting, using only user-included
% possible SWDs. Count and duration are returned as raw totals together with
% the actual recording exposure for the selected day/night/all period.
%
% Day/night classification is rebuilt from each event's recording-relative
% StartSec plus the animal's manifest StartTime whenever possible. This keeps
% existing SWD event files valid when day/night settings change and does not
% require a RecordingDate to be present or parseable.

    if nargin < 2 || isempty(timePoint), timePoint = 'all'; end
    if nargin < 3 || isempty(dayStart) || nargin < 4 || isempty(dayEnd)
        [dayStart, dayEnd] = local_day_bounds(project);
    else
        dayStart = mod(double(dayStart), 24);
        dayEnd = mod(double(dayEnd), 24);
    end

    rows = {};
    M = project.manifest;
    if isempty(M) || height(M)==0
        T = table(); return;
    end

    for i = 1:height(M)
        try
            prefix = string(project.animals(i).prefix);
        catch
            continue;
        end

        % The SWD Viewer writes the per-animal workbook. Always read that
        % same canonical file first so manual Keep/Exclude changes are
        % reflected immediately. Older root-level copies are fallback only.
        f = fullfile(meeg_outdir(project,'qeeg', char(prefix)), char(prefix) + "_swd_events.xlsx");
        if ~isfile(f)
            f = fullfile(meeg_outdir(project,'qeeg','SWD Analysis'), char(prefix) + "_swd_events.xlsx");
        end
        if ~isfile(f), continue; end

        try
            E = readtable(f, 'TextType','string');
        catch
            E = readtable(f);
        end
        E = meeg_swd_normalize_review_columns(E);
        if ~isempty(E)
            E = E(logical(E.UserIncluded), :);
        end

        totalHours = local_total_hours(project, prefix);
        startHour = NaN;
        try
            startHour = meeg_manifest_get_start_hour(project, prefix, i);
        catch
        end

        dayHours = local_day_hours(startHour, totalHours, dayStart, dayEnd);
        if isfinite(dayHours)
            nightHours = max(totalHours - dayHours, 0);
        else
            nightHours = NaN;
        end

        nEvents = height(E);
        isDay = nan(nEvents,1);
        if nEvents > 0
            % Highest priority: rebuild clock time from StartSec + manifest
            % StartTime. This avoids stale IsDay values and works without a
            % full RecordingDate/StartDateTime.
            if isfinite(startHour) && ismember('StartSec', E.Properties.VariableNames)
                try
                    startSec = double(E.StartSec);
                    valid = isfinite(startSec);
                    eventHour = mod(startHour + startSec(valid)./3600, 24);
                    isDay(valid) = double(local_is_in_day(eventHour, dayStart, dayEnd));
                catch
                end
            end

            % Fall back to saved clock-hour values for any rows not rebuilt.
            missingClass = ~isfinite(isDay);
            if any(missingClass) && ismember('HourOfDay', E.Properties.VariableNames)
                try
                    eventHour = double(E.HourOfDay);
                    valid = missingClass & isfinite(eventHour);
                    isDay(valid) = double(local_is_in_day(eventHour(valid), dayStart, dayEnd));
                catch
                end
            end

            % Final legacy fallback for older event files that contain only
            % the detector-time IsDay column.
            missingClass = ~isfinite(isDay);
            if any(missingClass) && ismember('IsDay', E.Properties.VariableNames)
                try
                    oldIsDay = double(logical(E.IsDay));
                    isDay(missingClass) = oldIsDay(missingClass);
                catch
                end
            end
        end

        hasCompleteDayClassification = nEvents == 0 || all(isfinite(isDay));
        selectedPeriod = lower(string(timePoint));
        switch selectedPeriod
            case "day"
                selected = isDay == 1;
                exposureHours = dayHours;
            case "night"
                selected = isDay == 0;
                exposureHours = nightHours;
            otherwise
                selected = true(nEvents,1);
                exposureHours = totalHours;
                selectedPeriod = "all";
        end

        selectionKnown = selectedPeriod == "all" || hasCompleteDayClassification;
        if selectionKnown
            countSelected = sum(selected);
        else
            countSelected = NaN;
        end

        if ~selectionKnown
            durationSelectedSec = NaN;
            meanDurationSec = NaN;
        elseif nEvents == 0 || ~ismember('DurationSec', E.Properties.VariableNames)
            durationSelectedSec = 0;
            meanDurationSec = NaN;
        else
            durations = double(E.DurationSec);
            durationSelectedSec = sum(durations(selected), 'omitnan');
            meanDurationSec = mean(durations(selected), 'omitnan');
        end

        if ~selectionKnown || nEvents == 0 || ~ismember('DominantFreqHz', E.Properties.VariableNames)
            meanFreqHz = NaN;
        else
            freqs = double(E.DominantFreqHz);
            meanFreqHz = mean(freqs(selected), 'omitnan');
        end

        row = table();
        row.Prefix = string(prefix);
        vnames = M.Properties.VariableNames;
        for v = 1:numel(vnames)
            try, row.(vnames{v}) = M{i,vnames{v}}; catch, end
        end

        % Write analysis fields after manifest metadata so similarly named
        % manifest columns cannot overwrite the calculated values.
        row.Count = countSelected;
        row.DurationSec = durationSelectedSec;
        row.MeanDurationSec = meanDurationSec;
        row.MeanDominantFreqHz = meanFreqHz;
        row.BurdenPct = local_burden_pct(durationSelectedSec, exposureHours);
        row.ExposureHours = exposureHours;
        row.TotalHours = totalHours;
        row.DayExposureHours = dayHours;
        row.NightExposureHours = nightHours;
        row.RecordingStartHour = startHour;
        row.SelectedPeriod = selectedPeriod;

        rows{end+1,1} = row; %#ok<AGROW>
    end

    if isempty(rows), T = table(); else, T = vertcat(rows{:}); end
end

function [d0, d1] = local_day_bounds(project)
    d0 = 6.5;
    d1 = 18.5;
    try
        if isfield(project, 'profile')
            if isfield(project.profile, 'dayStart') && isfinite(double(project.profile.dayStart))
                d0 = mod(double(project.profile.dayStart), 24);
            end
            if isfield(project.profile, 'dayEnd') && isfinite(double(project.profile.dayEnd))
                d1 = mod(double(project.profile.dayEnd), 24);
            end
        end
    catch
        d0 = 6.5;
        d1 = 18.5;
    end
end

function tf = local_is_in_day(hr, d0, d1)
    if d0 < d1
        tf = hr >= d0 & hr < d1;
    else
        % Equal boundaries preserve mEEG's existing convention that the
        % selected window spans the full 24-hour cycle.
        tf = hr >= d0 | hr < d1;
    end
end

function pct = local_burden_pct(durationSec, exposureHours)
    if ~isfinite(exposureHours) || exposureHours <= 0
        pct = NaN;
    else
        pct = 100 * durationSec / (exposureHours * 3600);
    end
end

function h = local_total_hours(project, prefix)
    h = NaN;
    try
        sf = fullfile(meeg_outdir(project,'qeeg',char(prefix)), sprintf('%s_swd_summary.xlsx', char(prefix)));
        if ~isfile(sf)
            sf = fullfile(meeg_outdir(project,'qeeg','SWD Analysis'), sprintf('%s_swd_summary.xlsx', char(prefix)));
        end
        if isfile(sf)
            Ts = readtable(sf, 'TextType','string');
            if ismember('TotalHours', Ts.Properties.VariableNames)
                candidate = double(Ts.TotalHours(1));
                if isfinite(candidate) && candidate >= 0
                    h = candidate; return;
                end
            end
        end
    catch
    end
    try
        [a,~] = meeg_project_get_animal(project, prefix);
        if ~isempty(a) && isfield(a,'files') && ~isempty(a.files)
            fs = project.profile.defaultFs;
            if isfield(a,'fs') && ~isempty(a.fs), fs = double(a.fs); end
            n = inf;
            for k = 1:numel(a.files)
                d = dir(a.files{k});
                if isempty(d), continue; end
                n = min(n, floor(double(d.bytes)/2));
            end
            if isfinite(n), h = n / fs / 3600; return; end
        end
    catch
    end
    h = 0;
end

function dh = local_day_hours(startHour, totalHours, d0, d1)
% Exact overlap of a recording interval with the recurring day window.
% Only the manifest StartTime clock hour is required; RecordingDate is not.
    if ~isfinite(totalHours) || totalHours <= 0
        dh = 0; return;
    end

    if ~isfinite(startHour)
        % For an exact whole number of 24-hour cycles, start time does not
        % affect exposure. Otherwise a reliable day/night denominator cannot
        % be calculated without StartTime.
        if abs(totalHours/24 - round(totalHours/24)) < 1e-9
            dayWindowHours = local_day_window_hours(d0, d1);
            dh = totalHours * dayWindowHours / 24;
        else
            dh = NaN;
        end
        return;
    end

    recordStart = mod(double(startHour), 24);
    recordEnd = recordStart + double(totalHours);
    dh = 0;

    firstCycle = floor(recordStart/24) - 1;
    lastCycle = ceil(recordEnd/24) + 1;
    for k = firstCycle:lastCycle
        base = 24 * k;
        if d0 < d1
            dh = dh + local_overlap_hours(recordStart, recordEnd, base + d0, base + d1);
        else
            dh = dh + local_overlap_hours(recordStart, recordEnd, base + d0, base + 24);
            dh = dh + local_overlap_hours(recordStart, recordEnd, base, base + d1);
        end
    end

    dh = min(max(dh, 0), totalHours);
end

function h = local_day_window_hours(d0, d1)
    if d0 < d1
        h = d1 - d0;
    else
        h = 24 - d0 + d1;
    end
end

function h = local_overlap_hours(recordStart, recordEnd, windowStart, windowEnd)
    left = max(recordStart, windowStart);
    right = min(recordEnd, windowEnd);
    if right > left
        h = right - left;
    else
        h = 0;
    end
end
