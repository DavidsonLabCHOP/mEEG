function outFile = meeg_swd_export_feature_list(project, outFile)
%MEEG_SWD_EXPORT_FEATURE_LIST Export full reviewed SWD candidate workbook.
    if nargin<2 || strlength(string(outFile))==0
        outDir=meeg_outdir(project,'qeeg','SWD Analysis');
        if ~isfolder(outDir), mkdir(outDir); end
        outFile=fullfile(outDir,"SWD_reviewed_feature_list_"+string(datestr(now,'yyyymmdd_HHMMSS'))+".xlsx");
    end
    outFile=string(outFile);
    [T,settingsTbl,summaryTbl,readmeTbl]=meeg_swd_collect_feature_list(project);
    if isempty(T), error('No saved SWD candidate event files were found.'); end
    if isfile(outFile), delete(outFile); end

    maxRows=900000;
    nParts=ceil(height(T)/maxRows);
    for k=1:nParts
        idx=(k-1)*maxRows+1:min(k*maxRows,height(T));
        sheet="SWD_Features"; if nParts>1, sheet="SWD_Features_"+string(k); end
        writetable(T(idx,:),outFile,'FileType','spreadsheet','Sheet',char(sheet));
    end
    writetable(settingsTbl,outFile,'FileType','spreadsheet','Sheet','Settings_Used');
    writetable(summaryTbl,outFile,'FileType','spreadsheet','Sheet','Review_Summary');
    writetable(readmeTbl,outFile,'FileType','spreadsheet','Sheet','README');
end
