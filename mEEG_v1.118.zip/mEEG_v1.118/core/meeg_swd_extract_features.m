function featTbl = meeg_swd_extract_features(x, fs, candTbl, swdOpts)
% Extract feature table for one lead from candidate events.

    if nargin < 4, swdOpts = struct(); end
    if isempty(candTbl) || height(candTbl)==0
        featTbl = table();
        return;
    end
    x = double(x(:));
    broadBand = local_get_opt(swdOpts, 'bandBroad', [3 12]);
    swdBand   = local_get_opt(swdOpts, 'bandSWD', [5 9]);
    maxFreqHz = local_get_opt(swdOpts, 'maxFreqHz', 9);
    minPromZ  = local_get_opt(swdOpts, 'minPromZ', 1.5);

    xfBroad = local_bandpass(x, fs, broadBand);
    xfSWD   = local_bandpass(x, fs, swdBand);
    rows = repmat(struct(), height(candTbl), 1);
    for ii = 1:height(candTbl)
        s1 = max(1, double(candTbl.StartSample(ii)));
        s2 = min(numel(x), double(candTbl.EndSample(ii)));
        xb = xfBroad(s1:s2);
        xs = xfSWD(s1:s2);
        xr = x(s1:s2);
        zloc = local_robust_z(xb);
        prom = max(0.5, minPromZ * 0.5 * std(zloc, 0, 'omitnan'));
        minPkDist = max(1, round(fs / maxFreqHz * 0.75));
        try
            [~, locs] = findpeaks(zloc, 'MinPeakProminence', prom, 'MinPeakDistance', minPkDist);
        catch
            locs = local_simple_peaks(zloc, prom, minPkDist);
        end
        ipi = diff(locs) ./ fs;
        meanIPI = mean(ipi, 'omitnan');
        ipiCv = std(ipi, 0, 'omitnan') / max(meanIPI, eps);
        [domFreq, peakSharp] = local_dominant_freq(xs, fs, swdBand);
        harmonicScore = local_harmonic_score(xs, fs, domFreq);
        rmsVal = rms(xs);
        ptpVal = max(xr) - min(xr);
        rhythmScore = 1 / (1 + 4 * max(0, ipiCv));
        bandPow = bandpower(xs, fs, swdBand);
        hf = local_bandpower_safe(xr, fs, [20 min(80, fs/2 - 1)]);
        artScore = hf / max(bandPow + hf, eps);
        rows(ii).StartSample = candTbl.StartSample(ii);
        rows(ii).EndSample = candTbl.EndSample(ii);
        rows(ii).StartSec = candTbl.StartSec(ii);
        rows(ii).EndSec = candTbl.EndSec(ii);
        rows(ii).DurationSec = candTbl.DurationSec(ii);
        rows(ii).PeakCount = numel(locs);
        rows(ii).MeanIPI = meanIPI;
        rows(ii).IPIcv = ipiCv;
        rows(ii).DominantFreqHz = domFreq;
        rows(ii).PeakSharpness = peakSharp;
        rows(ii).RMS = rmsVal;
        rows(ii).PeakToPeak = ptpVal;
        rows(ii).RhythmicityScore = rhythmScore;
        rows(ii).HarmonicScore = harmonicScore;
        rows(ii).ArtifactScore = artScore;
        rows(ii).EnvelopeZ = conditional_col(candTbl, 'EnvelopeZ', ii, NaN);
    end
    featTbl = struct2table(rows);
end

function y = local_bandpass(x, fs, band)
    d = designfilt('bandpassiir', 'FilterOrder', 4, ...
        'HalfPowerFrequency1', band(1), 'HalfPowerFrequency2', band(2), ...
        'DesignMethod', 'butter', 'SampleRate', fs);
    y = filtfilt(d, x);
end

function z = local_robust_z(x)
    mu = median(x, 'omitnan');
    sig = 1.4826 * mad(x, 1);
    if ~isfinite(sig) || sig <= eps, sig = std(x, 0, 'omitnan'); end
    if ~isfinite(sig) || sig <= eps, sig = 1; end
    z = (x - mu) ./ sig;
end

function locs = local_simple_peaks(x, prom, minDist)
    locs = [];
    for i = 2:numel(x)-1
        if x(i) > x(i-1) && x(i) >= x(i+1) && x(i) >= prom
            if isempty(locs) || (i - locs(end)) >= minDist
                locs(end+1,1) = i; %#ok<AGROW>
            elseif x(i) > x(locs(end))
                locs(end) = i;
            end
        end
    end
end

function [df, sharp] = local_dominant_freq(x, fs, band)
    df = NaN; sharp = NaN;
    if numel(x) < 8, return; end
    [pxx, f] = periodogram(x, [], max(256, 2^nextpow2(numel(x))), fs);
    mask = f >= band(1) & f <= band(2);
    if ~any(mask), return; end
    p = pxx(mask); ff = f(mask);
    [mx, idx] = max(p);
    df = ff(idx);
    sharp = mx / max(median(p), eps);
end

function hs = local_harmonic_score(x, fs, domFreq)
    hs = 0;
    if ~isfinite(domFreq) || domFreq <= 0, return; end
    [pxx, f] = periodogram(x, [], max(256, 2^nextpow2(numel(x))), fs);
    p1 = local_bandmean(pxx, f, domFreq * [0.9 1.1]);
    p2 = local_bandmean(pxx, f, (2*domFreq) * [0.9 1.1]);
    hs = p2 / max(p1 + p2, eps);
end

function p = local_bandmean(pxx, f, band)
    mask = f >= band(1) & f <= band(2);
    if ~any(mask), p = 0; else, p = mean(pxx(mask), 'omitnan'); end
end

function bp = local_bandpower_safe(x, fs, band)
    if band(2) <= band(1) || band(2) >= fs/2
        bp = 0;
        return;
    end
    try
        bp = bandpower(x, fs, band);
    catch
        [pxx, f] = periodogram(x, [], max(256, 2^nextpow2(numel(x))), fs);
        mask = f >= band(1) & f <= band(2);
        bp = trapz(f(mask), pxx(mask));
    end
end

function v = local_get_opt(S, f, defaultVal)
    v = defaultVal;
    try
        if isstruct(S) && isfield(S, f) && ~isempty(S.(f))
            v = S.(f);
        end
    catch
    end
end

function v = conditional_col(T, col, idx, defaultVal)
    v = defaultVal;
    try
        if ismember(col, T.Properties.VariableNames)
            v = T.(col)(idx);
        end
    catch
    end
end
