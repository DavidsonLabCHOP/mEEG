function [candTbl, debug] = meeg_swd_find_candidates(x, fs, swdOpts)
% Find putative SWD candidate segments in a single lead.

    if nargin < 3, swdOpts = struct(); end
    x = double(x(:));
    if isempty(x)
        candTbl = table();
        debug = struct();
        return;
    end

    broadBand = local_get_opt(swdOpts, 'bandBroad', [3 12]);
    envWinSec = local_get_opt(swdOpts, 'envWinSec', 0.20);
    % Candidate-generation limits can be relaxed independently from the
    % final scoring thresholds. This is used by Calibration / Discovery
    % mode so users can manually review near-miss events and learn suitable
    % thresholds without changing the detector's automatic decision rules.
    envZ      = local_get_opt(swdOpts, 'candidateEnvZ', local_get_opt(swdOpts, 'envZ', 2.0));
    minDurSec = local_get_opt(swdOpts, 'candidateMinDurSec', local_get_opt(swdOpts, 'minDurSec', 0.50));
    mergeGapSec = local_get_opt(swdOpts, 'mergeGapSec', 0.20);
    minPeaks  = local_get_opt(swdOpts, 'candidateMinPeaks', local_get_opt(swdOpts, 'minPeaks', 3));
    minFreqHz = local_get_opt(swdOpts, 'candidateMinFreqHz', local_get_opt(swdOpts, 'minFreqHz', 5));
    maxFreqHz = local_get_opt(swdOpts, 'candidateMaxFreqHz', local_get_opt(swdOpts, 'maxFreqHz', 9));
    minPromZ  = local_get_opt(swdOpts, 'minPromZ', 1.5);

    xf = local_bandpass(x, fs, broadBand);
    env = abs(hilbert(xf));
    envSm = movmean(env, max(3, round(envWinSec * fs)));
    envMu = median(envSm, 'omitnan');
    envSig = 1.4826 * mad(envSm, 1);
    if ~isfinite(envSig) || envSig <= eps
        envSig = std(envSm, 0, 'omitnan');
    end
    if ~isfinite(envSig) || envSig <= eps
        envSig = 1;
    end
    envZs = (envSm - envMu) ./ envSig;
    isHi = envZs >= envZ;

    minSamp = max(1, round(minDurSec * fs));
    mergeGap = max(0, round(mergeGapSec * fs));
    segs = local_binary_segments(isHi);
    segs = local_merge_segments(segs, mergeGap);
    if ~isempty(segs)
        dur = segs(:,2) - segs(:,1) + 1;
        segs = segs(dur >= minSamp, :);
    end

    rows = {};
    for ii = 1:size(segs,1)
        s1 = segs(ii,1); s2 = segs(ii,2);
        xs = xf(s1:s2);
        zloc = local_robust_z(xs);
        prom = max(0.5, minPromZ * 0.5 * std(zloc, 0, 'omitnan'));
        minPkDist = max(1, round(fs / maxFreqHz * 0.75));
        try
            [~, locs] = findpeaks(zloc, 'MinPeakProminence', prom, 'MinPeakDistance', minPkDist);
        catch
            locs = local_simple_peaks(zloc, prom, minPkDist);
        end
        if numel(locs) < minPeaks
            continue;
        end
        ipi = diff(locs) ./ fs;
        if isempty(ipi)
            continue;
        end
        domFreq = 1 / mean(ipi, 'omitnan');
        if ~(domFreq >= minFreqHz && domFreq <= maxFreqHz)
            continue;
        end
        row = struct();
        row.StartSample = int64(s1);
        row.EndSample = int64(s2);
        row.StartSec = (s1 - 1) / fs;
        row.EndSec = (s2 - 1) / fs;
        row.DurationSec = (s2 - s1 + 1) / fs;
        row.PeakCount = numel(locs);
        row.DominantFreqHz = domFreq;
        row.EnvelopeZ = max(envZs(s1:s2));
        rows{end+1,1} = row; %#ok<AGROW>
    end

    if isempty(rows)
        candTbl = table();
    else
        candTbl = struct2table([rows{:}]);
    end
    keepDebug = logical(local_get_opt(swdOpts, 'keepDebug', false));
    if keepDebug
        debug = struct('xf', xf, 'envelope', env, 'envelopeSmooth', envSm, 'envelopeZ', envZs, 'segments', segs, ...
            'envelopeMedian', envMu, 'envelopeSigma', envSig);
    else
        % Do not retain full-recording filtered/envelope vectors. They were
        % the largest part of the SWD auxiliary payload and are not needed
        % by the viewer or analysis tables.
        debug = struct('segments', segs, 'envelopeMedian', envMu, 'envelopeSigma', envSig);
    end
end

function y = local_bandpass(x, fs, band)
    d = designfilt('bandpassiir', 'FilterOrder', 4, ...
        'HalfPowerFrequency1', band(1), 'HalfPowerFrequency2', band(2), ...
        'DesignMethod', 'butter', 'SampleRate', fs);
    y = filtfilt(d, x);
end

function z = local_robust_z(x)
    mu = median(x, 'omitnan');
    sig = 1.4826 * mad(x, 1);
    if ~isfinite(sig) || sig <= eps
        sig = std(x, 0, 'omitnan');
    end
    if ~isfinite(sig) || sig <= eps
        sig = 1;
    end
    z = (x - mu) ./ sig;
end

function segs = local_binary_segments(mask)
    mask = logical(mask(:));
    d = diff([false; mask; false]);
    s = find(d == 1);
    e = find(d == -1) - 1;
    segs = [s e];
end

function segs = local_merge_segments(segs, gap)
    if isempty(segs), return; end
    out = segs(1,:);
    for i = 2:size(segs,1)
        if segs(i,1) - out(end,2) - 1 <= gap
            out(end,2) = segs(i,2);
        else
            out(end+1,:) = segs(i,:); %#ok<AGROW>
        end
    end
    segs = out;
end

function locs = local_simple_peaks(x, prom, minDist)
    locs = [];
    for i = 2:numel(x)-1
        if x(i) > x(i-1) && x(i) >= x(i+1) && x(i) >= prom
            if isempty(locs) || (i - locs(end)) >= minDist
                locs(end+1,1) = i; %#ok<AGROW>
            elseif x(i) > x(locs(end))
                locs(end) = i;
            end
        end
    end
end

function v = local_get_opt(S, f, defaultVal)
    v = defaultVal;
    try
        if isstruct(S) && isfield(S, f) && ~isempty(S.(f))
            v = S.(f);
        end
    catch
    end
end
