function T = meeg_swd_merge_events(T, mergeGapSec)
% Merge nearby events within the same lead.

    if nargin < 2 || isempty(mergeGapSec), mergeGapSec = 0.20; end
    if isempty(T) || height(T)==0, return; end
    vars = T.Properties.VariableNames;
    if ~ismember('LeadLabel', vars)
        T.LeadLabel = repmat("Lead1", height(T), 1);
    end
    T = sortrows(T, {'LeadLabel','StartSample'});
    rows = {};
    i = 1;
    while i <= height(T)
        cur = T(i,:);
        j = i + 1;
        while j <= height(T)
            sameLead = string(T.LeadLabel(j)) == string(cur.LeadLabel(1));
            gap = T.StartSec(j) - cur.EndSec(1);
            if sameLead && gap <= mergeGapSec
                cur.EndSample(1) = max(cur.EndSample(1), T.EndSample(j));
                cur.EndSec(1) = max(cur.EndSec(1), T.EndSec(j));
                cur.DurationSec(1) = cur.EndSec(1) - cur.StartSec(1);
                if ismember('PeakCount', vars), cur.PeakCount(1) = max(cur.PeakCount(1), T.PeakCount(j)); end
                if ismember('ConfidenceScore', vars), cur.ConfidenceScore(1) = max(cur.ConfidenceScore(1), T.ConfidenceScore(j)); end
                j = j + 1;
            else
                break;
            end
        end
        rows{end+1,1} = cur; %#ok<AGROW>
        i = j;
    end
    T = vertcat(rows{:});
end
