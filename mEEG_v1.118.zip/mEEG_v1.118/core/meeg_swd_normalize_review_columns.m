function T = meeg_swd_normalize_review_columns(T)
%MEEG_SWD_NORMALIZE_REVIEW_COLUMNS Standardize SWD review fields after import.
% Excel can return text columns as cell arrays, strings, categoricals, or
% datetimes depending on workbook contents and MATLAB release. This helper
% gives the SWD Viewer, SWD Analysis, feature export, and Threshold Assistant
% one consistent schema.

    if isempty(T)
        return;
    end
    n = height(T);

    hadUserIncluded = ismember('UserIncluded', T.Properties.VariableNames);
    hadUserDecision = ismember('UserDecision', T.Properties.VariableNames);

    if hadUserIncluded
        T.UserIncluded = local_to_logical(T.UserIncluded, true);
    elseif ismember('AutoIncluded', T.Properties.VariableNames)
        T.UserIncluded = local_to_logical(T.AutoIncluded, true);
    elseif ismember('Classification', T.Properties.VariableNames)
        cls = lower(strtrim(string(T.Classification)));
        T.UserIncluded = cls == "possible swd" | cls == "keep" | cls == "included";
    else
        T.UserIncluded = true(n,1);
    end

    if hadUserDecision
        T.UserDecision = local_to_string(T.UserDecision, "auto-kept");
    else
        T.UserDecision = repmat("auto-kept", n, 1);
        T.UserDecision(~logical(T.UserIncluded)) = "auto-rejected";
    end

    if ~ismember('ReviewTimestamp', T.Properties.VariableNames)
        T.ReviewTimestamp = repmat("", n, 1);
    else
        T.ReviewTimestamp = local_to_string(T.ReviewTimestamp, "");
    end

    if ~ismember('AutoIncluded', T.Properties.VariableNames)
        if ismember('Classification', T.Properties.VariableNames)
            T.AutoIncluded = string(T.Classification) == "Possible SWD";
        else
            T.AutoIncluded = T.UserIncluded;
        end
    else
        T.AutoIncluded = local_to_logical(T.AutoIncluded, true);
    end

    if ~ismember('AutoDecision', T.Properties.VariableNames)
        if ismember('Classification', T.Properties.VariableNames)
            T.AutoDecision = string(T.Classification);
        else
            T.AutoDecision = repmat("Unavailable", n, 1);
        end
    else
        T.AutoDecision = local_to_string(T.AutoDecision, "Unavailable");
    end

    if ~ismember('CalibrationMode', T.Properties.VariableNames)
        T.CalibrationMode = false(n,1);
    else
        T.CalibrationMode = local_to_logical(T.CalibrationMode, false);
    end

    % Explicit manual decisions are authoritative even for older workbooks
    % whose UserIncluded and UserDecision columns became inconsistent.
    decision = lower(strtrim(string(T.UserDecision)));
    manualExclude = startsWith(decision, "user-exclud") | ...
        startsWith(decision, "manual-exclud") | ...
        startsWith(decision, "user-reject") | ...
        startsWith(decision, "manual-reject");
    manualKeep = startsWith(decision, "user-keep") | ...
        startsWith(decision, "manual-keep") | ...
        startsWith(decision, "user-restor") | ...
        startsWith(decision, "manual-restor");
    T.UserIncluded(manualExclude) = false;
    T.UserIncluded(manualKeep) = true;
end

function tf = local_to_logical(v, defaultValue)
    n = numel(v);
    tf = repmat(logical(defaultValue), n, 1);
    if islogical(v)
        tf = v(:);
        return;
    end
    if isnumeric(v)
        q = double(v(:));
        valid = isfinite(q);
        tf(valid) = q(valid) ~= 0;
        return;
    end

    s = lower(strtrim(string(v(:))));
    trueValues = ["true","1","yes","y","keep","kept","included","include","pass","day"];
    falseValues = ["false","0","no","n","exclude","excluded","rejected","reject","night"];
    tf(ismember(s,trueValues)) = true;
    tf(ismember(s,falseValues)) = false;

    % Numeric text that was not covered above is also accepted.
    q = str2double(s);
    valid = isfinite(q);
    tf(valid) = q(valid) ~= 0;
end

function s = local_to_string(v, defaultValue)
    s = string(v(:));
    clean = lower(strtrim(s));
    bad = ismissing(s) | strlength(clean) == 0 | ismember(clean,["<missing>","nan","nat"]);
    s(bad) = string(defaultValue);
end
