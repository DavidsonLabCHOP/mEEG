function [eventsTbl, summaryTbl, aux] = meeg_swd_run_animal(project, animalIdx, swdOpts, logfn)
% Run SWD detection for one animal.
% v1.112 processes each channel in overlapping 30-minute chunks so long recordings
% are never loaded into memory as one channels-by-samples double matrix.

    if nargin < 4 || isempty(logfn), logfn = @(msg) disp(msg); end
    if nargin < 3, swdOpts = struct(); end

    a = project.animals(animalIdx);
    prefix = string(a.prefix);
    files = a.files;
    fs = double(swdOpts.fs);
    profile = project.profile;
    scale_uV = conditionalField(profile, 'scale_uV', 0.195);

    [nSamples, nCh] = local_recording_shape(files);
    chLabels = local_channel_labels(a, profile, nCh);
    if nSamples <= 0 || nCh <= 0
        eventsTbl = table();
        summaryTbl = local_empty_summary(prefix);
        aux = struct();
        return;
    end

    chunkSec = max(60, double(conditionalField(swdOpts, 'chunkSec', 1800)));
    overlapSec = max(2, double(conditionalField(swdOpts, 'chunkOverlapSec', 60)));
    chunkSamples = max(1, round(chunkSec * fs));
    overlapSamples = max(1, round(overlapSec * fs));
    nChunks = ceil(nSamples / chunkSamples);
    totalHours = nSamples / fs / 3600;

    logfn(sprintf('  - Memory-safe SWD processing: %d lead(s), %.2f recording hours, %d chunk(s) per lead.', ...
        nCh, totalHours, nChunks));

    useMasks = false;
    try
        useMasks = string(swdOpts.artifactMode) == "use_preprocessing_masks";
    catch
    end
    badEpochAll = [];
    if useMasks
        badEpochAll = local_load_preproc_masks(project, prefix, logfn);
    end

    notchFilter = [];
    if isfield(swdOpts,'useNotch') && swdOpts.useNotch
        notchFilter = local_prepare_notch_filter(fs, conditionalField(swdOpts, 'notchHz', 60));
    end

    keepDebug = logical(conditionalField(swdOpts, 'keepDebug', false));
    eventRows = cell(nCh,1);
    aux = struct();
    aux.channelLabels = chLabels;
    aux.processingMode = 'chunked-memory-safe';
    aux.chunkSec = chunkSec;
    aux.chunkOverlapSec = overlapSec;
    aux.recordingSamples = nSamples;
    aux.recordingHours = totalHours;
    aux.leadCandidateCounts = zeros(nCh,1);
    if keepDebug
        aux.leadFeatures = cell(nCh,1);
    end

    for ch = 1:nCh
        label = chLabels{min(ch, numel(chLabels))};
        logfn(sprintf('  - Lead %d/%d (%s): processing...', ch, nCh, label));

        fid = fopen(files{ch}, 'r');
        if fid == -1
            error('Could not open SWD input file: %s', files{ch});
        end
        fidCleanup = onCleanup(@() local_safe_fclose(fid)); %#ok<NASGU>

        leadParts = cell(nChunks,1);
        partCount = 0;
        progressStep = max(1, floor(nChunks/4));

        for ci = 1:nChunks
            coreStart = (ci-1) * chunkSamples + 1;
            coreEnd = min(nSamples, ci * chunkSamples);
            readStart = max(1, coreStart - overlapSamples);
            readEnd = min(nSamples, coreEnd + overlapSamples);
            readCount = readEnd - readStart + 1;

            status = fseek(fid, 2 * (readStart - 1), 'bof');
            if status ~= 0
                error('Could not seek in SWD input file %s at sample %d.', files{ch}, readStart);
            end
            raw = fread(fid, readCount, 'int16=>double');
            if isempty(raw)
                continue;
            end
            if numel(raw) < readCount
                readEnd = readStart + numel(raw) - 1;
            end
            x = raw(:) .* scale_uV;
            clear raw;

            if ~isempty(notchFilter)
                x = local_apply_notch_vector(x, notchFilter);
            end
            if ~isempty(badEpochAll) && ch <= size(badEpochAll,1)
                x = local_apply_mask_chunk(x, badEpochAll(ch,:), readStart, readEnd, fs);
            end

            [candTbl, ~] = meeg_swd_find_candidates(x, fs, swdOpts);
            if ~isempty(candTbl) && height(candTbl) > 0
                featTbl = meeg_swd_extract_features(x, fs, candTbl, swdOpts);
                if ~isempty(featTbl) && height(featTbl) > 0
                    sampleOffset = readStart - 1;
                    featTbl.StartSample = int64(double(featTbl.StartSample) + sampleOffset);
                    featTbl.EndSample = int64(double(featTbl.EndSample) + sampleOffset);
                    featTbl.StartSec = (double(featTbl.StartSample) - 1) ./ fs;
                    featTbl.EndSec = (double(featTbl.EndSample) - 1) ./ fs;

                    % Each event belongs to the non-overlap core containing
                    % its center. This removes duplicates while retaining
                    % overlap for filter/envelope edge stability.
                    centers = (double(featTbl.StartSample) + double(featTbl.EndSample)) ./ 2;
                    own = centers >= coreStart & centers <= coreEnd;
                    featTbl = featTbl(own,:);
                    if ~isempty(featTbl)
                        featTbl.Prefix = repmat(prefix, height(featTbl), 1);
                        featTbl.LeadIndex = repmat(ch, height(featTbl), 1);
                        featTbl.LeadLabel = repmat(string(label), height(featTbl), 1);
                        partCount = partCount + 1;
                        leadParts{partCount} = featTbl;
                    end
                end
            end

            clear x candTbl featTbl;
            if ci == nChunks || mod(ci, progressStep) == 0
                logfn(sprintf('    %s: chunk %d/%d complete.', label, ci, nChunks));
            end
        end

        clear fidCleanup; % closes the file now rather than at function exit

        if partCount > 0
            leadTbl = vertcat(leadParts{1:partCount});
            leadTbl = sortrows(leadTbl, {'StartSample','EndSample'});
            leadTbl = local_deduplicate_events(leadTbl);
            eventRows{ch} = leadTbl;
            aux.leadCandidateCounts(ch) = height(leadTbl);
            if keepDebug
                aux.leadFeatures{ch} = leadTbl;
            end
            logfn(sprintf('    %s: %d candidate event(s) retained across chunks.', label, height(leadTbl)));
        else
            eventRows{ch} = table();
            if keepDebug, aux.leadFeatures{ch} = table(); end
            logfn(sprintf('    %s: no candidate events retained.', label));
        end
        clear leadParts leadTbl;
    end

    nonEmpty = ~cellfun(@isempty, eventRows);
    if ~any(nonEmpty)
        eventsTbl = table();
        summaryTbl = local_empty_summary(prefix);
        return;
    end

    eventsTbl = vertcat(eventRows{nonEmpty});
    eventsTbl = local_add_multilead_counts(eventsTbl, swdOpts);
    eventsTbl = meeg_swd_score_candidates(eventsTbl, swdOpts);
    eventsTbl = meeg_swd_merge_events(eventsTbl, conditionalField(swdOpts, 'mergeGapSec', 0.20));
    eventsTbl = sortrows(eventsTbl, {'StartSample','LeadIndex'});

    % Recording-relative event seconds are converted to real clock hours by
    % adding the manifest StartTime-derived hour.
    hours = mod(conditionalField(swdOpts, 'hourStart', 0) + eventsTbl.StartSec / 3600, 24);
    eventsTbl.HourOfDay = hours;
    d0 = conditionalField(swdOpts, 'dayStart', 6.5);
    d1 = conditionalField(swdOpts, 'dayEnd', 18.5);
    eventsTbl.IsDay = local_is_in_day(hours, d0, d1);

    % Preserve the automatic detector decision separately from the user's
    % manual review decision. In normal mode, retain the historical behavior
    % of saving detector-passing events only. Calibration / Discovery mode
    % retains the broader candidate pool, including automatic near-misses.
    autoIncluded = eventsTbl.Classification == "Possible SWD";
    eventsTbl.AutoIncluded = logical(autoIncluded);
    eventsTbl.AutoDecision = string(eventsTbl.Classification);
    calibrationMode = logical(conditionalField(swdOpts, 'calibrationMode', false));
    if ~calibrationMode
        eventsTbl = eventsTbl(autoIncluded,:);
    end
    if ~isempty(eventsTbl)
        eventsTbl.UserIncluded = logical(eventsTbl.AutoIncluded);
        eventsTbl.UserDecision = repmat("auto-kept", height(eventsTbl), 1);
        eventsTbl.UserDecision(~eventsTbl.AutoIncluded) = "auto-rejected";
        eventsTbl.ReviewTimestamp = repmat(string(""), height(eventsTbl), 1);
        eventsTbl.CalibrationMode = repmat(calibrationMode, height(eventsTbl), 1);
    end
    summaryTbl = local_build_summary(prefix, eventsTbl, nSamples, fs);
end

function [nSamples, nCh] = local_recording_shape(files)
    nSamples = 0;
    nCh = numel(files);
    if nCh == 0, return; end
    nS = zeros(nCh,1);
    for i = 1:nCh
        d = dir(files{i});
        if isempty(d), nSamples = 0; return; end
        nS(i) = floor(double(d.bytes) / 2);
    end
    nSamples = min(nS);
end

function labels = local_channel_labels(a, profile, nCh)
    if isfield(a,'fileOrder') && ~isempty(a.fileOrder)
        labels = cellstr(string(a.fileOrder(:))');
    elseif isfield(a,'assignedRegionLabels') && ~isempty(a.assignedRegionLabels)
        labels = cellstr(string(a.assignedRegionLabels(:))');
    elseif isfield(profile,'channelLabels') && numel(profile.channelLabels) >= nCh
        labels = cellstr(string(profile.channelLabels(1:nCh))');
    else
        labels = arrayfun(@(k) sprintf('Ch%d', k), 1:nCh, 'UniformOutput', false);
    end
    if numel(labels) < nCh
        for k = numel(labels)+1:nCh
            labels{k} = sprintf('Ch%d', k); %#ok<AGROW>
        end
    end
end

function d = local_prepare_notch_filter(fs, notchHz)
    d = [];
    try
        if notchHz > 1 && notchHz + 1 < fs/2
            d = designfilt('bandstopiir','FilterOrder',2, ...
                'HalfPowerFrequency1', notchHz-1, 'HalfPowerFrequency2', notchHz+1, ...
                'DesignMethod','butter','SampleRate',fs);
        end
    catch
        d = [];
    end
end

function x = local_apply_notch_vector(x, d)
    try
        if numel(x) > 30
            x = filtfilt(d, x);
        end
    catch
        % Preserve the un-notched chunk rather than failing the full animal.
    end
end

function badEpochAll = local_load_preproc_masks(project, prefix, logfn)
    badEpochAll = [];
    badFile = fullfile(meeg_outdir(project,'preprocessing', char(prefix)), 'lowQEpochMask.mat');
    if ~isfile(badFile), return; end
    try
        S = load(badFile, 'badEpochAll');
        if isfield(S,'badEpochAll')
            badEpochAll = logical(S.badEpochAll);
        end
    catch ME
        logfn("SWD mask load warning: " + string(ME.message));
    end
end

function x = local_apply_mask_chunk(x, badEpochRow, readStart, readEnd, fs)
    sampsPer5s = max(1, round(fs * 5));
    eFirst = max(1, floor((readStart - 1) / sampsPer5s) + 1);
    eLast = min(numel(badEpochRow), floor((readEnd - 1) / sampsPer5s) + 1);
    for e = eFirst:eLast
        if ~badEpochRow(e), continue; end
        globalStart = (e-1) * sampsPer5s + 1;
        globalEnd = e * sampsPer5s;
        localStart = max(1, globalStart - readStart + 1);
        localEnd = min(numel(x), globalEnd - readStart + 1);
        if localEnd >= localStart
            x(localStart:localEnd) = 0;
        end
    end
end

function T = local_deduplicate_events(T)
    if isempty(T) || height(T) < 2, return; end
    key = [double(T.StartSample), double(T.EndSample)];
    [~, ia] = unique(key, 'rows', 'stable');
    T = T(sort(ia),:);
end

function T = local_add_multilead_counts(T, swdOpts)
    if isempty(T) || height(T)==0, return; end
    T = sortrows(T, {'StartSec','LeadIndex'});
    n = height(T);
    T.NumLeadsInvolved = ones(n,1);
    win = double(conditionalField(swdOpts, 'multileadWinSec', 0.10));
    times = double(T.StartSec);
    leads = double(T.LeadIndex);
    left = 1;
    right = 0;
    for i = 1:n
        while left <= n && times(left) < times(i) - win
            left = left + 1;
        end
        if right < i, right = i; end
        while right < n && times(right+1) <= times(i) + win
            right = right + 1;
        end
        T.NumLeadsInvolved(i) = numel(unique(leads(left:right)));
    end
end

function S = local_build_summary(prefix, T, nSamples, fs)
    totalDurHr = double(nSamples) / fs / 3600;
    if isempty(T) || height(T)==0
        S = table(string(prefix), 0, 0, 0, 0, 0, 0, 0, totalDurHr, ...
            'VariableNames', {'Prefix','CountAll','DurationAllSec','BurdenAllPct','CountDay','DurationDaySec','CountNight','DurationNightSec','TotalHours'});
        return;
    end
    dayMask = logical(T.IsDay);
    nightMask = ~dayMask;
    if ismember('UserIncluded', T.Properties.VariableNames)
        isPossible = logical(T.UserIncluded);
    else
        isPossible = T.Classification == "Possible SWD";
    end
    cAll = sum(isPossible);
    cDay = sum(isPossible & dayMask);
    cNight = sum(isPossible & nightMask);
    dAll = sum(T.DurationSec(isPossible), 'omitnan');
    dDay = sum(T.DurationSec(isPossible & dayMask), 'omitnan');
    dNight = sum(T.DurationSec(isPossible & nightMask), 'omitnan');
    S = table(string(prefix), cAll, dAll, 100*dAll/max(totalDurHr*3600,eps), cDay, dDay, cNight, dNight, totalDurHr, ...
        'VariableNames', {'Prefix','CountAll','DurationAllSec','BurdenAllPct','CountDay','DurationDaySec','CountNight','DurationNightSec','TotalHours'});
end

function tf = local_is_in_day(hr, d0, d1)
    if d0 == 0 && d1 == 0
        tf = true(size(hr));
    elseif d0 < d1
        tf = hr >= d0 & hr < d1;
    else
        tf = hr >= d0 | hr < d1;
    end
end

function T = local_empty_summary(prefix)
    T = table(string(prefix), 0, 0, 0, 0, 0, 0, 0, 0, 'VariableNames', ...
        {'Prefix','CountAll','DurationAllSec','BurdenAllPct','CountDay','DurationDaySec','CountNight','DurationNightSec','TotalHours'});
end

function local_safe_fclose(fid)
    try
        if fid > 0, fclose(fid); end
    catch
    end
end

function v = conditionalField(S, f, defaultVal)
    v = defaultVal;
    try
        if isstruct(S) && isfield(S, f) && ~isempty(S.(f))
            v = S.(f);
        end
    catch
    end
end
