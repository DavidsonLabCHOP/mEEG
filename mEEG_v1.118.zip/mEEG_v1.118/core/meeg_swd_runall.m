function meeg_swd_runall(project, swdOpts, logfn)
% Run hybrid-rule SWD detection for all included animals.
% v1.112: 30-minute memory-bounded chunks plus adaptive process-worker
% fallback: maximum available -> ~75% -> ~50% -> ~25% -> serial.

    if nargin < 3 || isempty(logfn), logfn = @(msg) disp(msg); end
    if nargin < 2, swdOpts = struct(); end
    M = project.manifest;
    if isempty(M) || height(M)==0
        logfn("No manifest loaded.");
        return;
    end

    includeMask = true(height(M),1);
    try
        inc = M.Include;
        if islogical(inc)
            includeMask = inc;
        elseif isnumeric(inc)
            includeMask = inc ~= 0;
        end
    catch
    end
    idxAll = find(includeMask);
    if isempty(idxAll)
        logfn("No animals selected (Include == true).");
        return;
    end

    defs = struct('fs', 2500, 'bandBroad', [3 12], 'bandSWD', [5 9], 'notchHz', 60, 'useNotch', true, ...
        'envWinSec', 0.20, 'envZ', 2.0, 'minDurSec', 0.50, 'mergeGapSec', 0.20, ...
        'minPeaks', 3, 'minFreqHz', 5, 'maxFreqHz', 9, 'maxIPIcv', 0.25, 'minPromZ', 1.5, ...
        'minRhythmScore', 0.55, 'minHarmonicScore', 0.20, 'maxArtifactScore', 0.60, ...
        'multileadWinSec', 0.10, 'minLeads', 1, 'artifactMode', 'use_preprocessing_masks', ...
        'dayStart', 6.5, 'dayEnd', 18.5, 'hourStart', 0, 'useParallel', false, ...
        'chunkSec', 1800, 'chunkOverlapSec', 60, 'keepDebug', false, ...
        'adaptiveParallel', true, 'parallelFractions', [1.00 0.75 0.50 0.25]);
    fns = fieldnames(defs);
    for i = 1:numel(fns)
        if ~isfield(swdOpts, fns{i}) || isempty(swdOpts.(fns{i}))
            swdOpts.(fns{i}) = defs.(fns{i});
        end
    end

    swdDir = meeg_outdir(project,'qeeg','SWD Analysis');
    if ~isfolder(swdDir), mkdir(swdDir); end

    nAnimals = numel(idxAll);
    summaryCells = cell(nAnimals,1);
    completed = false(nAnimals,1);
    finalErrors = strings(nAnimals,1);

    logfn(sprintf(['SWD chunked mode: %.1f-minute core windows with %.1f-second overlap; ' ...
        'one lead is held in memory per animal worker.'], ...
        double(swdOpts.chunkSec)/60, double(swdOpts.chunkOverlapSec)));

    usePar = false;
    try
        usePar = logical(swdOpts.useParallel) && nAnimals > 1 && ...
            license('test','Distrib_Computing_Toolbox');
    catch
        usePar = false;
    end

    if usePar
        maxWorkers = local_available_process_workers();
        maxWorkers = max(1, min([maxWorkers, nAnimals]));
        adaptiveEnabled = true;
        try, adaptiveEnabled = logical(swdOpts.adaptiveParallel); catch, end
        if adaptiveEnabled
            workerTiers = local_worker_tiers(maxWorkers, swdOpts.parallelFractions);
        else
            workerTiers = maxWorkers;
            workerTiers = workerTiers(workerTiers >= 2);
        end

        if isempty(workerTiers)
            usePar = false;
        else
            logfn(sprintf('SWD adaptive parallel plan: %s worker(s), then serial if needed.', ...
                char(strjoin(string(workerTiers), ' -> '))));
        end

        for tierIdx = 1:numel(workerTiers)
            pending = find(~completed);
            if isempty(pending), break; end

            requestedWorkers = min(workerTiers(tierIdx), numel(pending));
            if requestedWorkers < 2, break; end

            logfn(sprintf(['SWD parallel attempt %d/%d: %d pending animal(s), ' ...
                '%d process worker(s).'], tierIdx, numel(workerTiers), ...
                numel(pending), requestedWorkers));

            poolOK = false;
            actualWorkers = 0;
            try
                [poolOK, actualWorkers] = meeg_ensure_process_pool(logfn, requestedWorkers, true);
            catch MEpool
                logfn(sprintf('SWD: process pool preparation failed at %d workers: %s', ...
                    requestedWorkers, MEpool.message));
            end
            if ~poolOK || actualWorkers < 1
                logfn(sprintf('SWD: unable to use %d workers; trying the next lower resource level.', ...
                    requestedWorkers));
                local_close_parallel_pool(logfn);
                continue;
            end

            attemptSummary = cell(numel(pending),1);
            attemptLogs = cell(numel(pending),1);
            attemptErrors = strings(numel(pending),1);

            try
                parfor (jj = 1:numel(pending), actualWorkers)
                    k = pending(jj);
                    [attemptSummary{jj}, attemptLogs{jj}, attemptErrors(jj)] = ...
                        local_run_one_swd(project, idxAll(k), k, nAnimals, swdOpts);
                end

                for jj = 1:numel(pending)
                    k = pending(jj);
                    local_emit_logs(logfn, attemptLogs{jj});
                    if strlength(strtrim(attemptErrors(jj))) == 0
                        summaryCells{k} = attemptSummary{jj};
                        completed(k) = true;
                        finalErrors(k) = "";
                    else
                        finalErrors(k) = attemptErrors(jj);
                    end
                end

                stillPending = find(~completed);
                if isempty(stillPending)
                    logfn(sprintf('SWD: all animals completed with %d process worker(s).', actualWorkers));
                    break;
                end

                logfn(sprintf(['SWD: %d animal(s) did not complete at %d workers. ' ...
                    'Releasing the pool and reducing parallel resource use.'], ...
                    numel(stillPending), actualWorkers));
                local_close_parallel_pool(logfn);
            catch MEpar
                % A worker access violation or hard out-of-memory event can
                % abort the whole parfor before MATLAB returns partial data.
                % Keep all currently pending animals eligible for the next
                % lower worker tier; any already-written files are safely
                % overwritten if an animal is repeated.
                logfn(sprintf(['SWD parallel attempt failed at %d workers: %s. ' ...
                    'Releasing workers and retrying at the next lower level.'], ...
                    actualWorkers, MEpar.message));
                local_close_parallel_pool(logfn);
            end
        end
    end

    % Finish any unresolved animals serially. Closing the process pool first
    % returns worker RAM to the operating system before the serial attempt.
    pending = find(~completed);
    if ~isempty(pending)
        local_close_parallel_pool(logfn);
        if usePar
            logfn(sprintf('SWD serial fallback: processing %d remaining animal(s) one at a time.', ...
                numel(pending)));
        else
            logfn(sprintf('SWD: processing %d animal(s) serially.', numel(pending)));
        end

        serialOpts = swdOpts;
        serialOpts.useParallel = false;
        for jj = 1:numel(pending)
            k = pending(jj);
            [summaryCells{k}, serialLogs, finalErrors(k)] = ...
                local_run_one_swd(project, idxAll(k), k, nAnimals, serialOpts);
            local_emit_logs(logfn, serialLogs);
            if strlength(strtrim(finalErrors(k))) == 0
                completed(k) = true;
            end
        end
    end

    failed = find(~completed);
    if ~isempty(failed)
        logfn(sprintf('SWD finished with %d animal(s) still unsuccessful after serial fallback.', ...
            numel(failed)));
        for ii = 1:numel(failed)
            k = failed(ii);
            try
                prefix = string(project.animals(idxAll(k)).prefix);
            catch
                prefix = "animal_" + idxAll(k);
            end
            logfn(sprintf('  - %s: %s', char(prefix), char(finalErrors(k))));
        end
    end

    allSummary = table();
    for k = 1:numel(summaryCells)
        if completed(k) && ~isempty(summaryCells{k}) && istable(summaryCells{k})
            allSummary = [allSummary; summaryCells{k}]; %#ok<AGROW>
        end
    end
    if ~isempty(allSummary)
        try
            writetable(allSummary, fullfile(swdDir, 'SWD_summary_all_animals.xlsx'), ...
                'FileType', 'spreadsheet');
        catch MEwrite
            logfn(sprintf('SWD summary spreadsheet warning: %s', MEwrite.message));
        end
        save(fullfile(swdDir, 'SWD_summary_all_animals.mat'), ...
            'allSummary', 'swdOpts', 'completed', 'finalErrors');
    end
end

function [summaryTbl, logLines, errMsg] = local_run_one_swd(project, animalIdx, k, nAnimals, swdOptsIn)
    logLines = strings(0,1);
    summaryTbl = table();
    errMsg = "";
    swdOpts = swdOptsIn;

    function lmsg(msg)
        logLines(end+1,1) = string(msg); %#ok<AGROW>
    end

    try
        prefix = string(project.animals(animalIdx).prefix);
        try
            hs = meeg_manifest_get_start_hour(project, prefix, animalIdx);
            if isfinite(hs), swdOpts.hourStart = hs; end
        catch
        end
        lmsg("SWD: " + prefix + sprintf(" (%d/%d)", k, nAnimals));
        lmsg(sprintf('  - Recording start clock hour for day/night: %.3f', swdOpts.hourStart));
        [eventsTbl, summaryTbl, aux] = meeg_swd_run_animal(project, animalIdx, swdOpts, @lmsg);
        meeg_swd_save_outputs(project, char(prefix), eventsTbl, summaryTbl, swdOpts, aux);
        lmsg(sprintf('  - SWD events saved for %s (%d events)', char(prefix), height(eventsTbl)));
    catch ME
        try
            prefix = string(project.animals(animalIdx).prefix);
        catch
            prefix = "animal_" + animalIdx;
        end
        errMsg = string(ME.message);
        if strlength(errMsg) == 0, errMsg = string(ME.identifier); end
        lmsg(sprintf('  - ERROR for %s: %s', char(prefix), char(errMsg)));
    end
end

function tiers = local_worker_tiers(maxWorkers, fractions)
    maxWorkers = max(1, floor(double(maxWorkers)));
    try
        fractions = double(fractions(:)');
        fractions = fractions(isfinite(fractions) & fractions > 0 & fractions <= 1);
    catch
        fractions = [1.00 0.75 0.50 0.25];
    end
    if isempty(fractions), fractions = [1.00 0.75 0.50 0.25]; end
    raw = round(maxWorkers .* fractions);
    raw(1) = maxWorkers;
    raw = max(1, min(maxWorkers, raw));
    raw = unique(raw, 'stable');
    raw = raw(raw >= 2);
    tiers = raw;
end

function n = local_available_process_workers()
    n = 1;
    try
        p = gcp('nocreate');
        if ~isempty(p) && ~local_is_thread_pool(p)
            n = max(n, double(p.NumWorkers));
        end
    catch
    end
    try
        c = parcluster('Processes');
        n = max(n, double(c.NumWorkers));
    catch
        try
            c = parcluster;
            n = max(n, double(c.NumWorkers));
        catch
        end
    end
    n = max(1, floor(n));
end

function local_close_parallel_pool(logfn)
    try
        p = gcp('nocreate');
        if ~isempty(p)
            delete(p);
        end
    catch ME
        try, logfn(sprintf('SWD pool cleanup warning: %s', ME.message)); catch, end
    end
end

function tf = local_is_thread_pool(p)
    tf = false;
    try
        tf = contains(string(class(p)), 'ThreadPool', 'IgnoreCase', true);
    catch
    end
    try
        if isprop(p,'Cluster') && ~isempty(p.Cluster)
            tf = tf || contains(string(class(p.Cluster)), 'ThreadPool', 'IgnoreCase', true) || ...
                contains(string(p.Cluster.Type), 'threads', 'IgnoreCase', true);
        end
    catch
    end
end

function local_emit_logs(logfn, lines)
    try
        for ii = 1:numel(lines)
            logfn(lines(ii));
        end
    catch
    end
end
