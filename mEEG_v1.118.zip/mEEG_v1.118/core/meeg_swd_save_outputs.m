function meeg_swd_save_outputs(project, prefix, eventsTbl, summaryTbl, swdOpts, aux)
% Save per-animal SWD outputs.

    if nargin < 6, aux = struct(); end
    outDir = meeg_outdir(project, 'qeeg', prefix);
    if ~isfolder(outDir), mkdir(outDir); end
    base = fullfile(outDir, prefix + "_swd");

    try
        writetable(eventsTbl, base + "_events.xlsx", 'FileType', 'spreadsheet');
    catch
    end
    try
        writetable(summaryTbl, base + "_summary.xlsx", 'FileType', 'spreadsheet');
    catch
    end
    matFile = char(base + ".mat");
    try
        save(matFile, 'eventsTbl', 'summaryTbl', 'swdOpts', 'aux', '-v7.3');
    catch ME
        warning('mEEG:SWDSaveAux', 'Could not save full SWD aux debug payload for %s: %s. Saving core tables only.', prefix, ME.message);
        save(matFile, 'eventsTbl', 'summaryTbl', 'swdOpts', '-v7.3');
    end
end
