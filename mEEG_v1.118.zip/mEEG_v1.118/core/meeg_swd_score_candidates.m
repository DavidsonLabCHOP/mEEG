function scoredTbl = meeg_swd_score_candidates(featTbl, swdOpts)
% Score candidate SWD events using hybrid rule-based logic.
% v1.115 also preserves each individual criterion result and a readable
% failed-criteria list for feature export and threshold calibration.

    if nargin < 2, swdOpts = struct(); end
    if isempty(featTbl) || height(featTbl)==0
        scoredTbl = featTbl;
        return;
    end
    minDurSec = local_get_opt(swdOpts, 'minDurSec', 0.50);
    minFreqHz = local_get_opt(swdOpts, 'minFreqHz', 5);
    maxFreqHz = local_get_opt(swdOpts, 'maxFreqHz', 9);
    minPeaks = local_get_opt(swdOpts, 'minPeaks', 3);
    maxIPIcv = local_get_opt(swdOpts, 'maxIPIcv', 0.25);
    minRhythmScore = local_get_opt(swdOpts, 'minRhythmScore', 0.55);
    minHarmonicScore = local_get_opt(swdOpts, 'minHarmonicScore', 0.20);
    maxArtifactScore = local_get_opt(swdOpts, 'maxArtifactScore', 0.60);
    minLeads = local_get_opt(swdOpts, 'minLeads', 1);

    n = height(featTbl);
    passDuration = featTbl.DurationSec >= minDurSec;
    passFrequency = featTbl.DominantFreqHz >= minFreqHz & featTbl.DominantFreqHz <= maxFreqHz;
    passCycles = featTbl.PeakCount >= minPeaks;
    passIPIcv = featTbl.IPIcv <= maxIPIcv;
    passRhythmicity = featTbl.RhythmicityScore >= minRhythmScore;
    passHarmonic = featTbl.HarmonicScore >= minHarmonicScore;
    passArtifact = featTbl.ArtifactScore <= maxArtifactScore;
    if ismember('NumLeadsInvolved', featTbl.Properties.VariableNames)
        passLeadCount = featTbl.NumLeadsInvolved >= minLeads;
    else
        passLeadCount = true(n,1);
    end

    score = double(passDuration) + double(passFrequency) + double(passCycles) + ...
        double(passIPIcv) + double(passRhythmicity) + double(passHarmonic) + ...
        double(passArtifact) + double(passLeadCount);
    label = repmat("Reject", n, 1);
    label(score >= 4) = "Possible SWD";

    failed = strings(n,1);
    names = ["duration","frequency","cycles","IPI regularity","rhythmicity","harmonic score","artifact score","lead count"];
    P = [passDuration,passFrequency,passCycles,passIPIcv,passRhythmicity,passHarmonic,passArtifact,passLeadCount];
    for r = 1:n
        bad = names(~P(r,:));
        if isempty(bad), failed(r) = "none"; else, failed(r) = strjoin(bad, "; "); end
    end

    scoredTbl = featTbl;
    scoredTbl.PassDuration = logical(passDuration);
    scoredTbl.PassFrequency = logical(passFrequency);
    scoredTbl.PassCycles = logical(passCycles);
    scoredTbl.PassIPIRegularity = logical(passIPIcv);
    scoredTbl.PassRhythmicity = logical(passRhythmicity);
    scoredTbl.PassHarmonic = logical(passHarmonic);
    scoredTbl.PassArtifact = logical(passArtifact);
    scoredTbl.PassLeadCount = logical(passLeadCount);
    scoredTbl.FailedCriteria = failed;
    scoredTbl.ConfidenceScore = score;
    scoredTbl.Classification = label;
end

function v = local_get_opt(S, f, defaultVal)
    v = defaultVal;
    try
        if isstruct(S) && isfield(S, f) && ~isempty(S.(f))
            v = S.(f);
        end
    catch
    end
end
