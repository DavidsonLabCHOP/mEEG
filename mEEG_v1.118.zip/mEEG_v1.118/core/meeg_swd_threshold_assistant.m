function h = meeg_swd_threshold_assistant(project, currentSettings, applyFcn)
%MEEG_SWD_THRESHOLD_ASSISTANT Interactive descriptive SWD threshold guidance.
% Treatment groups remain visible as colors, but recommendations distinguish
% reviewed Keep versus Exclude candidates rather than maximizing group separation.

    if nargin<2, currentSettings=struct(); end
    if nargin<3, applyFcn=[]; end
    [T,~,~,~]=meeg_swd_collect_feature_list(project);
    if isempty(T), error('No saved SWD candidate feature tables were found.'); end

    decisions=lower(string(T.UserDecision));
    manualMask=startsWith(decisions,"user-") | startsWith(decisions,"manual-");
    manualHasBoth=any(manualMask & logical(T.UserIncluded)) && any(manualMask & ~logical(T.UserIncluded));

    h=uifigure('Name','SWD Threshold Assistant','Position',[70 60 1320 820]);
    root=uigridlayout(h,[4 2]);
    root.RowHeight={42,52,'1x',220}; root.ColumnWidth={'1x','1x'};
    root.Padding=[10 10 10 10]; root.RowSpacing=8; root.ColumnSpacing=10;

    controls=uigridlayout(root,[1 9]); controls.Layout.Row=1; controls.Layout.Column=[1 2];
    controls.ColumnWidth={65,175,55,135,205,170,105,125,'1x'}; controls.Padding=[0 0 0 0];
    uilabel(controls,'Text','Feature:');
    ddFeature=uidropdown(controls,'Items',{'Rhythmicity score'},'ValueChangedFcn',@(~,~)refreshPlots());
    uilabel(controls,'Text','Time:');
    [timeItems,timeData]=local_time_options(T);
    ddTime=uidropdown(controls,'Items',timeItems,'ItemsData',timeData,'Value','all','ValueChangedFcn',@(~,~)refreshAll());
    chkManual=uicheckbox(controls,'Text','Use only explicitly reviewed events','Value',manualHasBoth,'ValueChangedFcn',@(~,~)refreshAll());
    chkAnimalWeight=uicheckbox(controls,'Text','Weight animals equally','Value',true,'ValueChangedFcn',@(~,~)refreshAll());
    uibutton(controls,'Text','Apply selected','ButtonPushedFcn',@(~,~)applySelected());
    uibutton(controls,'Text','Apply all suggestions','ButtonPushedFcn',@(~,~)applyAll());
    uibutton(controls,'Text','Export assistant report','ButtonPushedFcn',@(~,~)exportReport());

    lblNote=uilabel(root,'Text','','WordWrap','on','FontAngle','italic');
    lblNote.Layout.Row=2; lblNote.Layout.Column=[1 2];
    axDist=uiaxes(root); axDist.Layout.Row=3; axDist.Layout.Column=1;
    axPerf=uiaxes(root); axPerf.Layout.Row=3; axPerf.Layout.Column=2;
    tbl=uitable(root); tbl.Layout.Row=4; tbl.Layout.Column=[1 2];

    R=table(); curves=table(); groupDiag=table(); filteredT=table();
    refreshAll();

    function refreshAll()
        opts=struct('manualOnly',logical(chkManual.Value),'animalWeighting',logical(chkAnimalWeight.Value),'timeFilter',string(ddTime.Value));
        [R,curves,groupDiag]=meeg_swd_threshold_recommendations(T,currentSettings,opts);
        filteredT=local_filter_table(T,opts);
        if isempty(R)
            ddFeature.Items={'No feature has both Keep and Exclude labels'};
            tbl.Data=table(); cla(axDist); cla(axPerf);
            text(axDist,.5,.5,'At least one Keep and one Exclude event are required.','Units','normalized','HorizontalAlignment','center');
            lblNote.Text=local_note(filteredT,opts,false);
            return;
        end
        old=string(ddFeature.Value);
        ddFeature.Items=cellstr(string(R.Feature));
        if any(string(R.Feature)==old), ddFeature.Value=char(old); else, ddFeature.Value=ddFeature.Items{1}; end
        tbl.Data=R(:,{'Feature','CurrentThreshold','SuggestedThreshold','SuggestedRangeLow','SuggestedRangeHigh', ...
            'KeepEvents','ExcludeEvents','Animals','SensitivityKeepRetained','SpecificityExcludeRejected','BalancedAccuracy','GuidanceStrength'});
        lblNote.Text=local_note(filteredT,opts,true);
        refreshPlots();
    end

    function refreshPlots()
        if isempty(R), return; end
        feature=string(ddFeature.Value);
        rr=R(string(R.Feature)==feature,:); if isempty(rr), return; end
        field=char(rr.Field(1));
        plotDistribution(filteredT,field,feature,double(rr.CurrentThreshold(1)),double(rr.SuggestedThreshold(1)),string(rr.Direction(1)));
        plotPerformance(feature,double(rr.CurrentThreshold(1)),double(rr.SuggestedThreshold(1)));
    end

    function plotDistribution(D,field,feature,currentTh,suggestedTh,direction)
        cla(axDist); hold(axDist,'on');
        if isempty(D) || ~ismember(field,D.Properties.VariableNames), hold(axDist,'off'); return; end
        x=double(D.(field)); keep=logical(D.UserIncluded); valid=isfinite(x); x=x(valid); keep=keep(valid); D=D(valid,:);
        groups=string(D.TreatmentGroup); groups(groups=="")="Unspecified";
        ug=unique(groups,'stable'); C=meeg_get_group_colors(ug);
        for gi=1:numel(ug)
            for cls=0:1
                id=find(groups==ug(gi) & keep==logical(cls));
                if isempty(id), continue; end
                if numel(id)>1200, id=id(round(linspace(1,numel(id),1200))); end
                base=1+cls; off=(gi-(numel(ug)+1)/2)*min(.055,.25/max(numel(ug),1));
                jitter=linspace(-.035,.035,numel(id))';
                scatter(axDist,base+off+jitter,x(id),16,C(gi,:),'filled','MarkerFaceAlpha',.45,'DisplayName',char(ug(gi)));
            end
        end
        yline(axDist,currentTh,'--','Current','LabelHorizontalAlignment','left');
        yline(axDist,suggestedTh,'-','Suggested','LineWidth',1.5,'LabelHorizontalAlignment','right');
        axDist.XTick=[1 2]; axDist.XTickLabel={'Exclude','Keep'}; xlim(axDist,[.6 2.4]);
        ylabel(axDist,char(feature)); grid(axDist,'on');
        title(axDist,sprintf('%s by reviewed class and TreatmentGroup',feature),'Interpreter','none');
        % One legend entry per group.
        kids=findobj(axDist,'Type','Scatter'); labels=string(get(kids,'DisplayName'));
        if ~isempty(kids)
            [~,ia]=unique(labels,'stable'); legend(axDist,kids(ia),cellstr(labels(ia)),'Location','best','Interpreter','none');
        end
        if direction=="maximum"
            subtitle(axDist,'Lower values pass this maximum threshold');
        else
            subtitle(axDist,'Higher values pass this minimum threshold');
        end
        hold(axDist,'off');
    end

    function plotPerformance(feature,currentTh,suggestedTh)
        cla(axPerf); hold(axPerf,'on');
        C=curves(string(curves.Feature)==feature,:);
        if isempty(C), hold(axPerf,'off'); return; end
        plot(axPerf,C.Threshold,C.Sensitivity,'LineWidth',1.4,'DisplayName','Keep retained (sensitivity)');
        plot(axPerf,C.Threshold,C.Specificity,'LineWidth',1.4,'DisplayName','Exclude rejected (specificity)');
        plot(axPerf,C.Threshold,C.BalancedAccuracy,'LineWidth',1.8,'DisplayName','Balanced accuracy');
        xline(axPerf,currentTh,'--','Current'); xline(axPerf,suggestedTh,'-','Suggested','LineWidth',1.5);
        ylim(axPerf,[0 1.03]); xlabel(axPerf,'Threshold'); ylabel(axPerf,'Fraction'); grid(axPerf,'on');
        title(axPerf,'Threshold trade-off from reviewed candidates'); legend(axPerf,'Location','best'); hold(axPerf,'off');
    end

    function applySelected()
        if isempty(R) || isempty(applyFcn), return; end
        q=R(string(R.Feature)==string(ddFeature.Value),:);
        try, applyFcn(q); catch ME, uialert(h,ME.message,'Could not apply threshold'); end
    end
    function applyAll()
        if isempty(R) || isempty(applyFcn), return; end
        choice=uiconfirm(h,'Apply all suggested thresholds to the SWD Settings controls? No analysis will run automatically.','Apply suggestions', ...
            'Options',{'Apply','Cancel'},'DefaultOption',2,'CancelOption',2);
        if strcmp(choice,'Apply')
            try, applyFcn(R); catch ME, uialert(h,ME.message,'Could not apply thresholds'); end
        end
    end
    function exportReport()
        if isempty(R), return; end
        outDir=meeg_outdir(project,'qeeg','SWD Analysis'); if ~isfolder(outDir), mkdir(outDir); end
        default=fullfile(outDir,"SWD_threshold_assistant_"+string(datestr(now,'yyyymmdd_HHMMSS'))+".xlsx");
        [file,path]=uiputfile('*.xlsx','Save SWD threshold assistant report',default);
        if isequal(file,0), return; end
        out=fullfile(path,file);
        try
            if isfile(out), delete(out); end
            writetable(R,out,'Sheet','Recommendations');
            writetable(groupDiag,out,'Sheet','Group_Diagnostics');
            writetable(curves,out,'Sheet','Threshold_Curves');
            note=table(string(lblNote.Text),'VariableNames',{'Notes'}); writetable(note,out,'Sheet','README');
            uialert(h,"Saved threshold assistant report:\n"+string(out),'Saved');
        catch ME
            uialert(h,ME.message,'Export error');
        end
    end
end

function D=local_filter_table(T,opts)
    idx=true(height(T),1);
    if opts.manualOnly && ismember('ReviewSource',T.Properties.VariableNames)
        idx=idx & string(T.ReviewSource)=="Manual review";
    end
    tf=lower(string(opts.timeFilter));
    if tf=="day", idx=idx & lower(string(T.TimePeriod))=="day";
    elseif tf=="night", idx=idx & lower(string(T.TimePeriod))=="night"; end
    D=T(idx,:);
end
function [items,data]=local_time_options(T)
    items={'All available recording times'}; data={'all'};
    if ismember('TimePeriod',T.Properties.VariableNames)
        p=lower(string(T.TimePeriod));
        if any(p=="day"), items{end+1}='Day only'; data{end+1}='day'; end
        if any(p=="night"), items{end+1}='Night only'; data{end+1}='night'; end
    end
end
function s=local_note(T,opts,hasResults)
    n=height(T); nAnimals=0; nGroups=0; manual=0;
    if n>0
        if ismember('AnimalID',T.Properties.VariableNames), nAnimals=numel(unique(string(T.AnimalID))); end
        if ismember('TreatmentGroup',T.Properties.VariableNames), nGroups=numel(unique(string(T.TreatmentGroup))); end
        if ismember('ReviewSource',T.Properties.VariableNames), manual=sum(string(T.ReviewSource)=="Manual review"); end
    end
    s=sprintf(['Pilot guidance: %d candidate events from %d animal(s) and %d treatment group(s); %d explicitly reviewed. ' ...
        'No minimum animal count and no day/night pair are required. Treatment groups remain visible, but suggested thresholds separate Keep versus Exclude events—not the treatment groups themselves.'], ...
        n,nAnimals,nGroups,manual);
    if opts.manualOnly, s=[s ' Only explicitly reviewed events are currently used.']; else, s=[s ' Current automatic/unreviewed decisions may also be included; explicit Keep/Exclude review is preferable.']; end
    if isfield(opts,'animalWeighting') && opts.animalWeighting, s=[s ' Each animal contributes equal weight to sensitivity and specificity so animals with many events do not dominate the recommendation.']; end
    s=[s ' Each feature is evaluated individually; because the SWD detector combines several criteria, rerun and validate the complete settings after applying suggestions.'];
    if ~hasResults, s=[s ' More reviewed Keep and Exclude examples are needed for recommendations.']; end
end
