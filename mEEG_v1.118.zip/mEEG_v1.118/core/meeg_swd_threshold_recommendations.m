function [R, curves, groupDiag] = meeg_swd_threshold_recommendations(T, current, opts)
%MEEG_SWD_THRESHOLD_RECOMMENDATIONS Descriptive thresholds from reviewed events.
% Recommendations distinguish manually classified Keep versus Exclude SWD
% candidates. They do not optimize treatment-group separation.
    if nargin<2, current=struct(); end
    if nargin<3, opts=struct(); end
    manualOnly=local_opt(opts,'manualOnly',false);
    animalWeighting=logical(local_opt(opts,'animalWeighting',true));
    timeFilter=lower(string(local_opt(opts,'timeFilter','all')));

    if isempty(T), R=table(); curves=table(); groupDiag=table(); return; end
    idx=true(height(T),1);
    if manualOnly && ismember('ReviewSource',T.Properties.VariableNames)
        idx=idx & string(T.ReviewSource)=="Manual review";
    end
    if timeFilter=="day" && ismember('TimePeriod',T.Properties.VariableNames)
        idx=idx & lower(string(T.TimePeriod))=="day";
    elseif timeFilter=="night" && ismember('TimePeriod',T.Properties.VariableNames)
        idx=idx & lower(string(T.TimePeriod))=="night";
    end
    T=T(idx,:);
    if isempty(T), R=table(); curves=table(); groupDiag=table(); return; end

    cfg=local_configs(current);
    rrows=cell(0,1); crows=cell(0,1); grows=cell(0,1);
    y=logical(T.UserIncluded);
    for fi=1:numel(cfg)
        f=cfg(fi);
        if ~ismember(f.Field,T.Properties.VariableNames), continue; end
        x=double(T.(f.Field)); valid=isfinite(x);
        xv=x(valid); yv=y(valid); Tv=T(valid,:);
        nKeep=sum(yv); nExclude=sum(~yv);
        if nKeep<1 || nExclude<1, continue; end
        th=local_thresholds(xv,f.Integer);
        sens=nan(numel(th),1); spec=sens; bal=sens; prec=sens; f1=sens;
        for j=1:numel(th)
            pass=local_pass(xv,th(j),f.Direction);
            tp=sum(pass & yv); fn=sum(~pass & yv); fp=sum(pass & ~yv);
            [sens(j),spec(j)]=local_sens_spec(pass,yv,Tv,animalWeighting);
            prec(j)=tp/max(tp+fp,1); f1(j)=2*prec(j)*sens(j)/max(prec(j)+sens(j),eps);
            bal(j)=mean([sens(j),spec(j)]);
        end
        mx=max(bal,[],'omitnan'); candidates=find(abs(bal-mx)<1e-12);
        [~,kk]=min(abs(th(candidates)-f.Current)); best=candidates(kk);
        near=bal>=mx-0.02;
        lo=min(th(near)); hi=max(th(near));
        nAnimals=local_unique_count(Tv,'AnimalID'); nGroups=local_unique_count(Tv,'TreatmentGroup');
        strength="exploratory";
        if nKeep>=20 && nExclude>=20 && nAnimals>=4
            if mx>=0.80, strength="promising"; elseif mx<0.65, strength="weak separation"; else, strength="moderate"; end
        end
        autoNote="";
        if ismember('ReviewSource',Tv.Properties.VariableNames)
            nManual=sum(string(Tv.ReviewSource)=="Manual review");
            if nManual<height(Tv), autoNote=string(height(Tv)-nManual)+" automatic/unreviewed event(s) included"; end
        end
        weighting="Pooled events"; if animalWeighting, weighting="Equal weight per animal"; end
        rr=table(string(f.Display),string(f.Field),string(f.Direction),f.Current,th(best),lo,hi, ...
            nKeep,nExclude,nAnimals,nGroups,sens(best),spec(best),prec(best),f1(best),bal(best),strength,weighting,autoNote, ...
            'VariableNames',{'Feature','Field','Direction','CurrentThreshold','SuggestedThreshold','SuggestedRangeLow','SuggestedRangeHigh', ...
            'KeepEvents','ExcludeEvents','Animals','TreatmentGroups','SensitivityKeepRetained','SpecificityExcludeRejected', ...
            'Precision','F1','BalancedAccuracy','GuidanceStrength','Weighting','ReviewNote'});
        rrows{end+1,1}=rr; %#ok<AGROW>
        cc=table(repmat(string(f.Display),numel(th),1),th,sens,spec,prec,f1,bal, ...
            'VariableNames',{'Feature','Threshold','Sensitivity','Specificity','Precision','F1','BalancedAccuracy'});
        crows{end+1,1}=cc; %#ok<AGROW>

        groups=unique(string(Tv.TreatmentGroup),'stable');
        if isempty(groups), groups=""; end
        bestPass=local_pass(xv,th(best),f.Direction);
        for gi=1:numel(groups)
            gm=string(Tv.TreatmentGroup)==groups(gi);
            gKeep=gm & yv; gExc=gm & ~yv;
            ret=sum(bestPass & gKeep)/max(sum(gKeep),1);
            falsePass=sum(bestPass & gExc)/max(sum(gExc),1);
            gg=table(string(f.Display),groups(gi),sum(gKeep),sum(gExc),ret,falsePass, ...
                'VariableNames',{'Feature','TreatmentGroup','KeepEvents','ExcludeEvents','KeepRetention','ExcludedPassRate'});
            grows{end+1,1}=gg; %#ok<AGROW>
        end
    end
    if isempty(rrows), R=table(); else, R=vertcat(rrows{:}); end
    if isempty(crows), curves=table(); else, curves=vertcat(crows{:}); end
    if isempty(grows), groupDiag=table(); else, groupDiag=vertcat(grows{:}); end
end

function cfg=local_configs(current)
    cfg=struct('Display',{},'Field',{},'Direction',{},'Current',{},'Integer',{});
    cfg(end+1)=local_cfg('Duration','DurationSec','minimum',local_opt(current,'minDurSec',1.0),false);
    cfg(end+1)=local_cfg('Number of cycles','PeakCount','minimum',local_opt(current,'minPeaks',3),true);
    cfg(end+1)=local_cfg('Envelope z-score','EnvelopeZ','minimum',local_opt(current,'envZ',3.0),false);
    cfg(end+1)=local_cfg('Rhythmicity score','RhythmicityScore','minimum',local_opt(current,'minRhythmScore',0.55),false);
    cfg(end+1)=local_cfg('Harmonic score','HarmonicScore','minimum',local_opt(current,'minHarmonicScore',0.20),false);
    cfg(end+1)=local_cfg('Artifact score','ArtifactScore','maximum',local_opt(current,'maxArtifactScore',0.60),false);
end
function s=local_cfg(a,b,c,d,e), s=struct('Display',a,'Field',b,'Direction',c,'Current',double(d),'Integer',logical(e)); end
function th=local_thresholds(x,isInteger)
    x=sort(unique(x(:))); if isempty(x), th=[]; return; end
    if isInteger
        th=x;
    elseif numel(x)>300
        th=linspace(min(x),max(x),300)';
    else
        th=x;
    end
    th=unique(th,'stable');
end
function pass=local_pass(x,t,direction)
    if string(direction)=="maximum", pass=x<=t; else, pass=x>=t; end
end

function [sens,spec]=local_sens_spec(pass,y,T,animalWeighting)
    if ~animalWeighting || ~ismember('AnimalID',T.Properties.VariableNames)
        sens=sum(pass & y)/max(sum(y),1);
        spec=sum(~pass & ~y)/max(sum(~y),1);
        return;
    end
    animals=string(T.AnimalID); ua=unique(animals,'stable');
    sv=[]; pv=[];
    for ai=1:numel(ua)
        m=animals==ua(ai);
        kp=m & y; ex=m & ~y;
        if any(kp), sv(end+1,1)=sum(pass & kp)/sum(kp); end %#ok<AGROW>
        if any(ex), pv(end+1,1)=sum(~pass & ex)/sum(ex); end %#ok<AGROW>
    end
    if isempty(sv), sens=NaN; else, sens=mean(sv,'omitnan'); end
    if isempty(pv), spec=NaN; else, spec=mean(pv,'omitnan'); end
end

function n=local_unique_count(T,name)
    n=0; if ismember(name,T.Properties.VariableNames), n=numel(unique(string(T.(name)))); end
end
function v=local_opt(S,name,defaultVal)
    v=defaultVal; try, if isstruct(S)&&isfield(S,name)&&~isempty(S.(name)), v=S.(name); end, catch, end
end
