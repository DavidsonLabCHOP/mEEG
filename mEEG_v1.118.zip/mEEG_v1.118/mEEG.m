function mEEG()
% mEEG launcher - system selection window.
% Usage:
%   >> mEEG

    here = fileparts(mfilename('fullpath'));
    logo = fullfile(here, 'assets', 'mEEG_logo.png');

    choices = { ...
        '10-electrode Intan RHX (.dat)', ...
        '1-10 electrode Standard (.edf)' ...
    };

    sel = struct('idx', 0);

    f = uifigure('Name', 'mEEG v1.118 — Select EEG system', 'Position', [300 250 720 340]);
    f.Color = [1 1 1];

    root = uigridlayout(f, [2 1]);
    root.RowHeight = {90, '1x'};
    root.ColumnWidth = {'1x'};
    root.Padding = [16 12 16 12];
    root.RowSpacing = 10;

    header = uigridlayout(root, [1 2]);
    header.Layout.Row = 1;
    header.ColumnWidth = {140, '1x'};
    header.RowHeight = {70};
    header.Padding = [0 0 0 0];
    header.ColumnSpacing = 12;

    if isfile(logo)
        uiimage(header, 'ImageSource', logo, 'ScaleMethod', 'fit');
    else
        uilabel(header, 'Text', 'mEEG', 'FontSize', 28, 'FontWeight', 'bold');
    end

    titleGrid = uigridlayout(header, [2 1]);
    titleGrid.RowHeight = {34, 34};
    titleGrid.Padding = [0 6 0 0];
    uilabel(titleGrid, 'Text', 'Mouse EEG Analysis Toolbox', 'FontSize', 20, 'FontWeight', 'bold');
    uilabel(titleGrid, 'Text', 'Select your acquisition system to load the correct pipeline.', 'FontSize', 13);

    body = uigridlayout(root, [2 2]);
    body.Layout.Row = 2;
    body.ColumnWidth = {'1x','1x'};
    body.RowHeight = {86,'1x'};
    body.RowSpacing = 10;
    body.ColumnSpacing = 12;
    body.Padding = [0 0 0 0];

    makeButton(body, choices{1}, 1, 1, 'Current fully implemented pipeline for 10-electrode Intan RHX .dat recordings.');
    makeButton(body, choices{2}, 1, 2, 'EDF upload pipeline with channel selection, relabeling, and optional within-region averaging.');
    foot = uigridlayout(body, [1 2]);
    foot.Layout.Row = 2; foot.Layout.Column = [1 2];
    foot.ColumnWidth = {'1x', 120};
    foot.Padding = [0 0 0 0];
    uilabel(foot, 'Text', 'Tip: Standard file formats work best!', 'FontSize', 12);
    uibutton(foot, 'Text','Cancel', 'ButtonPushedFcn', @(~,~) close(f));

    f.CloseRequestFcn = @onClose;
    uiwait(f);

    if sel.idx == 0
        return;
    end

    switch sel.idx
        case 1
            profile = meeg_getSystemProfile('10-electrode system');
            profile.name = '10-electrode Intan RHX (.dat)';
            mEEGApp(profile);
        case 2
            profile = meeg_getSystemProfile('standard-edf');
            mEEGApp(profile);
        otherwise
            return;
    end

    function onClose(~,~)
        try, uiresume(f); catch, end
        delete(f);
    end

    function makeButton(parent, label, r, c, subtitle)
        p = uipanel(parent, 'BackgroundColor', [1 1 1]);
        p.Layout.Row = r; p.Layout.Column = c;
        g = uigridlayout(p, [2 1]);
        g.RowHeight = {34,'1x'};
        g.Padding = [12 10 12 10];
        g.RowSpacing = 2;

        b = uibutton(g, 'Text', label);
        b.FontSize = 14; b.FontWeight = 'bold';
        b.HorizontalAlignment = 'left';
        b.ButtonPushedFcn = @(~,~) choose(label);

        uilabel(g, 'Text', subtitle, 'FontSize', 12, 'FontColor', [0.35 0.35 0.35]);

        p.ButtonDownFcn = @(~,~) choose(label);
    end

    function choose(label)
        sel.idx = find(strcmp(choices, label), 1);
        if isempty(sel.idx), sel.idx = 0; end
        uiresume(f);
        delete(f);
    end
end
