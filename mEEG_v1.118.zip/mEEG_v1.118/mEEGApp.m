function mEEGApp(profile)
% Programmatic (non-AppDesigner) GUI for mEEG v1.118
% Tabs: Manifest, Pre-processing, qEEG, Results
%
% New in v0.3:
% - qEEG analysis checkboxes are stacked vertically (readable)
% - Results tab: Band plots with option to color dots by manifest metadata

    if nargin < 1, profile = meeg_getSystemProfile('10-electrode system'); end
    if isfield(profile, 'channelLabels') && ~isempty(profile.channelLabels)
        profile.channelLabels = cellstr(string(meeg_sanitize_lead_label(profile.channelLabels(:)))');
        profile.nChannels = numel(profile.channelLabels);
    end

    % ---------------- Project state ----------------
    project = meeg_project_new(profile);
    project = localSanitizeProjectLabels(project);
    profile = project.profile;
    % Temporarily hide the optional Intan settings-XML import prompt.
    % Set this to true if the feature is revisited in a later release.
    enableIntanSettingsXmlImport = false;
    selectedManifestRows = [];
    initLabels = cellstr(string(profile.channelLabels(:))');
    if isempty(initLabels)
        initLabels = {'Ch1','Ch2'};
    end

    % ---------------- UI ----------------
    fig = uifigure('Name', sprintf('mEEG v1.118 (%s)', profile.name), 'Position', [100 60 1650 900], ...
        'Color', [0.95 0.97 0.99]);

    main = uigridlayout(fig, [2 2]);
    main.RowHeight = {108, '1x'};
    main.ColumnWidth = {175, '1x'};
    main.RowSpacing = 8;
    main.ColumnSpacing = 10;
    main.Padding = [10 10 10 10];

    % --- Header branding (left/right anchored logos) ---
    hdr = uipanel(main, 'BorderType','line', 'BackgroundColor',[0.95 0.97 0.99]);
    hdr.Layout.Row = 1; hdr.Layout.Column = [1 2];
    hdrGrid = uigridlayout(hdr, [1 3]);
    hdrGrid.RowHeight = {'1x'};
    hdrGrid.ColumnWidth = {340, '1x', 360};
    hdrGrid.ColumnSpacing = 10;
    hdrGrid.RowSpacing = 0;
    hdrGrid.Padding = [12 6 12 6];
    hdrGrid.BackgroundColor = [0.95 0.97 0.99];
    try
        here = fileparts(mfilename('fullpath'));
        leftLogo = fullfile(here, 'assets', 'mEEGLogo.png');
        if ~isfile(leftLogo)
            leftLogo = fullfile(here, 'assets', 'mEEG_logo.png');
        end
        rightLogo = fullfile(here, 'assets', 'DavidsonLabLogo.png');
        if ~isfile(rightLogo)
            rightLogo = fullfile(here, 'assets', 'mEEG_logo_top.png');
        end

        if isfile(leftLogo)
            imgLeft = uiimage(hdrGrid, 'ImageSource', leftLogo, 'ScaleMethod', 'fit');
            imgLeft.Layout.Row = 1; imgLeft.Layout.Column = 1;
            imgLeft.HorizontalAlignment = 'left';
        end
        spacer = uipanel(hdrGrid, 'BorderType', 'none', 'BackgroundColor', [0.95 0.97 0.99]);
        spacer.Layout.Row = 1; spacer.Layout.Column = 2;
        if isfile(rightLogo)
            imgRight = uiimage(hdrGrid, 'ImageSource', rightLogo, 'ScaleMethod', 'fit');
            imgRight.Layout.Row = 1; imgRight.Layout.Column = 3;
            imgRight.HorizontalAlignment = 'right';
        end
    catch
    end

    % Left-side main navigation
    nav = uipanel(main, 'Title', 'Workspace', 'FontWeight','bold', ...
        'BackgroundColor',[0.94 0.96 0.99]);
    nav.Layout.Row = 2; nav.Layout.Column = 1;
    navGrid = uigridlayout(nav, [8 1]);
    navGrid.RowHeight = {44,44,44,44,44,44,44,'1x'};
    navGrid.ColumnWidth = {'1x'};
    navGrid.RowSpacing = 8;
    navGrid.Padding = [10 10 10 10];

    btnNavProject = uibutton(navGrid, 'Text', 'Project', 'ButtonPushedFcn', @(~,~) showMainSection('project'));
    btnNavPreproc = uibutton(navGrid, 'Text', 'Preprocessing', 'ButtonPushedFcn', @(~,~) showMainSection('preproc'));
    btnNavQEEG    = uibutton(navGrid, 'Text', 'qEEG', 'ButtonPushedFcn', @(~,~) showMainSection('qeeg'));
    btnNavSpikes  = uibutton(navGrid, 'Text', 'Spike Analysis', 'ButtonPushedFcn', @(~,~) showMainSection('spikes'));
    btnNavSWD     = uibutton(navGrid, 'Text', 'Spike-Wave Discharge', 'ButtonPushedFcn', @(~,~) showMainSection('swd'));
    btnNavEvent   = uibutton(navGrid, 'Text', 'Event Detection (beta)', 'ButtonPushedFcn', @(~,~) showMainSection('events'));
    btnNavRaw     = uibutton(navGrid, 'Text', 'Raw Viewer', 'ButtonPushedFcn', @(~,~) showMainSection('rawviewer'));
    uilabel(navGrid, 'Text', '');

    % Right-side content stack
    contentHost = uipanel(main, 'BorderType','none', 'BackgroundColor',[0.95 0.97 0.99]);
    contentHost.Layout.Row = 2; contentHost.Layout.Column = 2;
    contentGrid = uigridlayout(contentHost, [1 1]);
    contentGrid.RowHeight = {'1x'};
    contentGrid.ColumnWidth = {'1x'};
    contentGrid.Padding = [0 0 0 0];

    panelManifest = uipanel(contentGrid, 'BorderType','none', 'BackgroundColor',[0.95 0.97 0.99]);
    panelManifest.Layout.Row = 1; panelManifest.Layout.Column = 1;
    panelPreproc = uipanel(contentGrid, 'BorderType','none', 'BackgroundColor',[0.95 0.97 0.99]);
    panelPreproc.Layout.Row = 1; panelPreproc.Layout.Column = 1;
    panelQEEG = uipanel(contentGrid, 'BorderType','none', 'BackgroundColor',[0.95 0.97 0.99]);
    panelQEEG.Layout.Row = 1; panelQEEG.Layout.Column = 1;
    panelSpikes = uipanel(contentGrid, 'BorderType','none', 'BackgroundColor',[0.95 0.97 0.99]);
    panelSpikes.Layout.Row = 1; panelSpikes.Layout.Column = 1;
    panelSWD = uipanel(contentGrid, 'BorderType','none', 'BackgroundColor',[0.95 0.97 0.99]);
    panelSWD.Layout.Row = 1; panelSWD.Layout.Column = 1;
    panelEvent = uipanel(contentGrid, 'BorderType','none', 'BackgroundColor',[0.95 0.97 0.99]);
    panelEvent.Layout.Row = 1; panelEvent.Layout.Column = 1;
    panelRaw = uipanel(contentGrid, 'BorderType','none', 'BackgroundColor',[0.95 0.97 0.99]);
    panelRaw.Layout.Row = 1; panelRaw.Layout.Column = 1;

    % Section containers used by the rest of the code
    tabManifest = panelManifest;
    tabPreproc  = panelPreproc;
    tabRaw      = panelRaw;

    tgQ = uitabgroup(panelQEEG, 'Position', [0 0 1465 748]);
    tabqEEG     = uitab(tgQ, 'Title', 'Settings');
    tabResultsPS = uitab(tgQ, 'Title', 'Power Spectral Density');
    tabResults  = uitab(tgQ, 'Title', 'Normalized Band Power');
    tabResultsRatio = uitab(tgQ, 'Title', 'Power Ratios');
    tabResultsCorr = uitab(tgQ, 'Title', 'Correlation');
    tabResultsCoh = uitab(tgQ, 'Title', 'Coherence');
    tabResultsConn = uitab(tgQ, 'Title', 'Connectivity Plots');

    tgS = uitabgroup(panelSpikes, 'Position', [0 0 1465 748]);
    tabSpikes   = uitab(tgS, 'Title', 'Settings');
    tabSpikeBrowser = uitab(tgS, 'Title', 'Spike Viewer');
    tabResultsSpikes = uitab(tgS, 'Title', 'Spike Analysis');

    tgSWD = uitabgroup(panelSWD, 'Position', [0 0 1465 748]);
    tabSWDSettings = uitab(tgSWD, 'Title', 'Settings');
    tabSWDViewer = uitab(tgSWD, 'Title', 'SWD Viewer');
    tabSWDAnalysis = uitab(tgSWD, 'Title', 'SWD Analysis');

    tgEV = uitabgroup(panelEvent, 'Position', [0 0 1465 748]);
    tabEventSettings = uitab(tgEV, 'Title', 'Settings');
    tabEventViewer = uitab(tgEV, 'Title', 'Event Viewer');
    tabEventAnalysis = uitab(tgEV, 'Title', 'Event Analysis');

    % Keep names used elsewhere
    tg = tgQ;

    % Show initial section
    showMainSection('project');

    % ===== Manifest tab =====
    gridM = uigridlayout(tabManifest, [3 1]);
    gridM.RowHeight = {40,'1x',60};
    gridM.ColumnWidth = {'1x'};

    topM = uigridlayout(gridM, [1 7]);
    topM.Layout.Row = 1;
    topM.ColumnWidth = {140,'1x',150,150,120,130,160};

    uilabel(topM, 'Text', 'Project Output folder:');
    edtOut = uieditfield(topM, 'text', 'Value', project.outdir);
    uibutton(topM, 'Text', 'Select output folder', 'ButtonPushedFcn', @onBrowseOut);
    uibutton(topM, 'Text', 'Load existing project', 'ButtonPushedFcn', @onLoadManifest);
    uibutton(topM, 'Text', 'Add animal', 'ButtonPushedFcn', @onAddAnimal);
    uibutton(topM, 'Text', 'Remove animal', 'ButtonPushedFcn', @onRemoveAnimal);
    uibutton(topM, 'Text', 'Save Project', 'ButtonPushedFcn', @onSaveManifest);

    tbl = uitable(gridM);
    tbl.Layout.Row = 2;
    tbl.ColumnEditable = true;
    tbl.Multiselect = 'on';
    tbl.CellSelectionCallback = @onManifestTableSelect;
    tbl.ColumnName = {'Include','AnimalID','StudyGroup','Genotype','Sex','DOB','RecordingDate','StartTime','LitterID','Notes'};
    tbl.Data = project.manifest(:, {'Include','MouseID','TreatmentGroup','Genotype','Sex','DOB','RecordingDate','StartTime','LitterID','Notes'});

    bottomM = uigridlayout(gridM, [1 3]);
    bottomM.Layout.Row = 3;
    bottomM.ColumnWidth = {'1x',170,150};
    txtStatus = uitextarea(bottomM, 'Editable', 'off', 'Value', {'Ready.'});
    uibutton(bottomM, 'Text', 'Go to Pre-processing →', 'ButtonPushedFcn', @(~,~) showMainSection('preproc'));
    uibutton(bottomM, 'Text', 'Go to qEEG →', 'ButtonPushedFcn', @(~,~) showMainSection('qeeg'));

    % ===== Pre-processing tab =====
    gridP = uigridlayout(tabPreproc, [2 2]);
    gridP.RowHeight = {'1x','1x'};
    gridP.ColumnWidth = {620,'1x'};

    pnlP = uipanel(gridP, 'Title', 'Preprocessing settings', 'BackgroundColor',[1 1 1]);
    pnlP.Layout.Row = [1 2];
    pnlP.Layout.Column = 1;

    formP = uigridlayout(pnlP, [16 2]);
    formP.RowHeight = repmat({34}, 1, 16);
    formP.RowHeight{10} = 54;
    formP.RowHeight{12} = 44;
    formP.ColumnWidth = {290,'1x'};

    lblRow = uigridlayout(formP, [1 2]); lblRow.ColumnWidth = {'1x', 28}; lblRow.Padding = [0 0 0 0]; lblRow.ColumnSpacing = 6;
    uilabel(lblRow, 'Text', 'Sampling rate (Hz):');
    uibutton(lblRow, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('sampling_rate', 'Sampling rate (Hz)'));
    edtFsP = uieditfield(formP, 'numeric', 'Value', profile.defaultFs, 'Limits', [1 inf]);

    lblRow = uigridlayout(formP, [1 2]); lblRow.ColumnWidth = {'1x', 28}; lblRow.Padding = [0 0 0 0]; lblRow.ColumnSpacing = 6;
    uilabel(lblRow, 'Text', 'RMS bin (sec):');
    uibutton(lblRow, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('rms_bin', 'RMS bin (sec)'));
    edtRmsBin = uieditfield(formP, 'numeric', 'Value', profile.preproc.rmsBinSec, 'Limits', [0.1 60]);

    lblRow = uigridlayout(formP, [1 2]); lblRow.ColumnWidth = {'1x', 28}; lblRow.Padding = [0 0 0 0]; lblRow.ColumnSpacing = 6;
    uilabel(lblRow, 'Text', 'Artifact epoch (sec):');
    uibutton(lblRow, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('artifact_epoch', 'Artifact epoch (sec)'));
    edtEpoch = uieditfield(formP, 'numeric', 'Value', profile.preproc.epochSec, 'Limits', [0.5 10]);

    lblRow = uigridlayout(formP, [1 2]); lblRow.ColumnWidth = {'1x', 28}; lblRow.Padding = [0 0 0 0]; lblRow.ColumnSpacing = 6;
    uilabel(lblRow, 'Text', 'Z-score threshold:');
    uibutton(lblRow, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('z_threshold', 'Z-score threshold'));
    edtZ = uieditfield(formP, 'numeric', 'Value', profile.preproc.zThresh, 'Limits', [0.5 20]);

    lblRow = uigridlayout(formP, [1 2]); lblRow.ColumnWidth = {'1x', 28}; lblRow.Padding = [0 0 0 0]; lblRow.ColumnSpacing = 6;
    uilabel(lblRow, 'Text', 'RMS low / high (uV):');
    uibutton(lblRow, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('rms_thresholds', 'RMS low / high (uV)'));
    rmsRow = uigridlayout(formP, [1 2]); rmsRow.ColumnWidth = {120,120}; rmsRow.Padding = [0 0 0 0]; rmsRow.ColumnSpacing = 10;
    edtRmsLow = uieditfield(rmsRow, 'numeric', 'Value', profile.preproc.rmsLow);
    edtRmsHigh = uieditfield(rmsRow, 'numeric', 'Value', profile.preproc.rmsHigh);

    lblRow = uigridlayout(formP, [1 2]); lblRow.ColumnWidth = {'1x', 28}; lblRow.Padding = [0 0 0 0]; lblRow.ColumnSpacing = 6;
    uilabel(lblRow, 'Text', 'Skewness (high):');
    uibutton(lblRow, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('skewness_high', 'Skewness high'));
    edtSkw = uieditfield(formP, 'numeric', 'Value', profile.preproc.skwHigh, 'Limits', [0 10]);

    lblRow = uigridlayout(formP, [1 2]); lblRow.ColumnWidth = {'1x', 28}; lblRow.Padding = [0 0 0 0]; lblRow.ColumnSpacing = 6;
    uilabel(lblRow, 'Text', 'Notch filter:');
    uibutton(lblRow, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showInfo('Notch filter', 'Enable a configurable band-stop filter. The exact lower and upper frequencies entered below are used, so the notch can target 59-61 Hz, 35-37 Hz, or another instrument-specific interference band.'));
    chkNotch = uicheckbox(formP, 'Value', profile.preproc.notch.enabled, 'Text', 'enabled');

    lblRow = uigridlayout(formP, [1 2]); lblRow.ColumnWidth = {'1x', 28}; lblRow.Padding = [0 0 0 0]; lblRow.ColumnSpacing = 6;
    uilabel(lblRow, 'Text', 'Notch band (Hz):');
    uibutton(lblRow, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showInfo('Notch band (Hz)', 'Frequency range for notch filter (e.g., 59–61). Wider bands remove more noise but may distort nearby signal.'));
    notchRow = uigridlayout(formP, [1 2]); notchRow.ColumnWidth = {120,120}; notchRow.Padding = [0 0 0 0]; notchRow.ColumnSpacing = 10;
    edtF1 = uieditfield(notchRow, 'numeric', 'Value', profile.preproc.notch.f1);
    edtF2 = uieditfield(notchRow, 'numeric', 'Value', profile.preproc.notch.f2);

    lblRow = uigridlayout(formP, [1 2]); lblRow.ColumnWidth = {'1x', 28}; lblRow.Padding = [0 0 0 0]; lblRow.ColumnSpacing = 6;
    uilabel(lblRow, 'Text', 'Output:');
    uibutton(lblRow, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showInfo('Output', 'Choose whether to save only QC + masks (recommended) or also save cleaned 30-min blocks (large).'));
    ddOut = uidropdown(formP, 'Items', {'Save QC + masks (recommended)','Also save cleaned 30-min blocks (large!)'}, 'Value', 'Save QC + masks (recommended)');

    % speed
    lblRow = uigridlayout(formP, [1 2]); lblRow.ColumnWidth = {'1x', 28}; lblRow.Padding = [0 0 0 0]; lblRow.ColumnSpacing = 6;
    uilabel(lblRow, 'Text', 'Parallel processing:');
    uibutton(lblRow, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showInfo('Parallel processing', ...
        'Speed of preprocessing can be increased via parallel processing, but this requires the Parallel Processing Toolbox, which can be downloaded directly from MathWorks (free with existing license). If you do not have this toolbox/package, uncheck the box.'));
    chkPreParallel = uicheckbox(formP, 'Text', 'Use parallel processing (process animals concurrently)', 'Value', true, 'WordWrap', 'on');

    btnRunPreproc = uibutton(formP, 'Text', 'Run pre-processing ▶', 'ButtonPushedFcn', @onRunPreproc, ...
        'BackgroundColor', [0.60 0.84 0.60], 'FontColor', [1 1 1], 'FontWeight', 'bold');
    btnRunPreproc.Layout.Row = 11;
    btnRunPreproc.Layout.Column = [1 2];

    % Per-animal QC preview controls
    pnlPreQC = uipanel(formP, 'Title', 'Per animal QC Preview', 'BackgroundColor', [1 1 1], 'ForegroundColor', [0 0 0]);
    pnlPreQC.Layout.Row = [12 16];
    pnlPreQC.Layout.Column = [1 2];
    glPreQC = uigridlayout(pnlPreQC, [3 2]);
    glPreQC.RowHeight = {34, 34, 40};
    glPreQC.ColumnWidth = {130, '1x'};
    glPreQC.RowSpacing = 8;
    glPreQC.ColumnSpacing = 10;
    glPreQC.Padding = [10 10 10 10];

    uilabel(glPreQC, 'Text', 'Preview animal:');
    rowPrev = uigridlayout(glPreQC,[1 2]);
    rowPrev.ColumnWidth = {'1x', 95};
    rowPrev.Padding = [0 0 0 0];
    rowPrev.ColumnSpacing = 8;
    ddPreprocPreview = uidropdown(rowPrev, 'Items', {'(last run)'}, 'Value','(last run)', 'ValueChangedFcn', @(~,~) onPreprocPreviewChanged());
    uibutton(rowPrev, 'Text', 'Refresh', 'Tooltip', 'Refresh preview list from preprocessing outputs', 'ButtonPushedFcn', @(~,~) onRefreshPreprocPreview());

    uilabel(glPreQC, 'Text', 'Lower plot:');
    % NOTE: uitogglebutton requires a ButtonGroup parent in uifigure-based apps.
    % Use state buttons instead and keep them mutually exclusive.
    glLower = uigridlayout(glPreQC,[1 2]);
    glLower.ColumnWidth = {'1x','1x'}; glLower.ColumnSpacing = 10;
    glLower.Padding = [0 0 0 0];
    tglGood = uibutton(glLower,'state','Text','% low quality epochs','Value',true,'ValueChangedFcn',@onPreprocLowerToggle);
    tglHeat = uibutton(glLower,'state','Text','low quality heatmap','Value',false,'ValueChangedFcn',@onPreprocLowerToggle);

    uilabel(glPreQC, 'Text', 'Quick action:');
    btnExcludePreprocAnimal = uibutton(glPreQC, 'Text', 'Remove current animal from analyses', 'ButtonPushedFcn', @(~,~) onExcludeCurrentPreprocAnimal(), ...
        'BackgroundColor', [1.0 0.90 0.93], 'FontColor', [0.45 0.05 0.12]);

    axP1 = uiaxes(gridP); axP1.Layout.Row = 1; axP1.Layout.Column = 2; title(axP1, 'Percentage of EEG recording that passed quality control');
    axP2 = uiaxes(gridP); axP2.Layout.Row = 2; axP2.Layout.Column = 2; title(axP2, 'Percentage of artifact epochs that do not pass quality control');

    % ===== qEEG tab =====
    gridQ = uigridlayout(tabqEEG, [1 2]);
    gridQ.RowHeight = {'1x'};
    gridQ.ColumnWidth = {588,'1x'};

    pnlQ = uipanel(gridQ, 'Title', 'qEEG settings', 'BackgroundColor',[1 1 1]);
    pnlQ.Layout.Row = 1;
    pnlQ.Layout.Column = 1;

    formQ = uigridlayout(pnlQ, [22 2]);
    formQ.RowHeight = repmat({34}, 1, 22);
    formQ.ColumnWidth = {252,'1x'};
    formQ.RowSpacing = 8;

    lblRowQ = uigridlayout(formQ, [1 2]); lblRowQ.ColumnWidth = {'1x', 28}; lblRowQ.Padding = [0 0 0 0]; lblRowQ.ColumnSpacing = 6;
    uilabel(lblRowQ, 'Text', 'Sampling rate (Hz):');
    uibutton(lblRowQ, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('sampling_rate', 'qEEG: Sampling rate (Hz)'));
    edtFsQ = uieditfield(formQ, 'numeric', 'Value', profile.defaultFs, 'Limits', [1 inf]);

    lblRowQ = uigridlayout(formQ, [1 2]); lblRowQ.ColumnWidth = {'1x', 28}; lblRowQ.Padding = [0 0 0 0]; lblRowQ.ColumnSpacing = 6;
    uilabel(lblRowQ, 'Text', 'Correlation window (sec):');
    uibutton(lblRowQ, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('corr_window', 'qEEG: Correlation window (sec)'));
    edtCorrWin = uieditfield(formQ, 'numeric', 'Value', 30, 'Limits', [1 600]);

    lblRowQ = uigridlayout(formQ, [1 2]); lblRowQ.ColumnWidth = {'1x', 28}; lblRowQ.Padding = [0 0 0 0]; lblRowQ.ColumnSpacing = 6;
    uilabel(lblRowQ, 'Text', 'Coherence window (sec):');
    uibutton(lblRowQ, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('coh_window', 'qEEG: Coherence window (sec)'));
    edtCohWin = uieditfield(formQ, 'numeric', 'Value', 2, 'Limits', [0.5 30]);

    lblRowQ = uigridlayout(formQ, [1 2]); lblRowQ.ColumnWidth = {'1x', 28}; lblRowQ.Padding = [0 0 0 0]; lblRowQ.ColumnSpacing = 6;
    uilabel(lblRowQ, 'Text', 'Coherence overlap (0-0.9):');
    uibutton(lblRowQ, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('coh_overlap', 'qEEG: Coherence overlap (0-0.9)'));
    edtCohOv = uieditfield(formQ, 'numeric', 'Value', 0.5, 'Limits', [0 0.9]);

    lblRowQ = uigridlayout(formQ, [1 2]); lblRowQ.ColumnWidth = {'1x', 28}; lblRowQ.Padding = [0 0 0 0]; lblRowQ.ColumnSpacing = 6;
    uilabel(lblRowQ, 'Text', 'Coherence fmax (Hz):');
    uibutton(lblRowQ, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('coh_fmax', 'qEEG: Coherence fmax (Hz)'));
    edtCohFmax = uieditfield(formQ, 'numeric', 'Value', 50, 'Limits', [50 200]);

    lblRowQ = uigridlayout(formQ, [1 2]); lblRowQ.ColumnWidth = {'1x', 28}; lblRowQ.Padding = [0 0 0 0]; lblRowQ.ColumnSpacing = 6;
    uilabel(lblRowQ, 'Text', 'Coherence processing rate:');
    uibutton(lblRowQ, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('coh_resample_500', 'qEEG: Optional coherence-only resampling'));
    chkCohResample500 = uicheckbox(formQ, ...
        'Text', 'Use 500 Hz when original sampling rate is higher', ...
        'Value', false, ...
        'Tooltip', 'Applies anti-alias resampling only to coherence. Lower-rate recordings are never upsampled.');

    lblRowQ = uigridlayout(formQ, [1 2]); lblRowQ.ColumnWidth = {'1x', 28}; lblRowQ.Padding = [0 0 0 0]; lblRowQ.ColumnSpacing = 6;
    uilabel(lblRowQ, 'Text', 'Daytime start (hour 0-24):', 'Tooltip', 'If both daytime start and daytime end are set to 0, all data is used for both day and night plots.');
    uibutton(lblRowQ, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('qeeg_daynight', 'qEEG: Day/night definition'));
    edtDayStart = uieditfield(formQ, 'numeric', 'Value', 6.5, 'Limits', [0 24]);

    lblRowQ = uigridlayout(formQ, [1 2]); lblRowQ.ColumnWidth = {'1x', 28}; lblRowQ.Padding = [0 0 0 0]; lblRowQ.ColumnSpacing = 6;
    uilabel(lblRowQ, 'Text', 'Daytime end (hour 0-24):', 'Tooltip', 'If both daytime start and daytime end are set to 0, all data is used for both day and night plots.');
    uibutton(lblRowQ, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('qeeg_daynight', 'qEEG: Day/night definition'));
    edtDayEnd = uieditfield(formQ, 'numeric', 'Value', 18.5, 'Limits', [0 24]);

    uilabel(formQ, 'Text', 'Analyses to run:');

    % Row 9 contains the full analysis checkbox block after the optional
    % coherence-only resampling row. Keep the following controls readable.
    formQ.RowHeight{9}  = 142;
    formQ.RowHeight{10} = 52;
    formQ.RowHeight{11} = 44;

    box = uigridlayout(formQ, [4 1]);
    box.RowHeight = {24,24,24,24};
    box.ColumnWidth = {'1x'};
    box.RowSpacing = 4;
    box.Padding = [0 2 0 0];
    box.ColumnSpacing = 0;

    chkCore = uicheckbox(box, 'Text', 'CORE modules (normalized band power + power spectrum; ratios use these outputs)', 'Value', true, 'Enable', 'on');
    chkCorr = uicheckbox(box, 'Text', 'Correlation analysis', 'Value', true);
    chkCoh  = uicheckbox(box, 'Text', 'Coherence analysis', 'Value', true);
    chkCohSpec = uicheckbox(box, 'Text', 'Save pair-spectrum coherence data (for Pair Explorer)', 'Value', false);
    chkBand = chkCore; chkPSD = chkCore;

    uilabel(formQ, 'Text', 'Artifact masks:');
    chkUseMasks = uicheckbox(formQ, 'Text', sprintf('Use quality control metrics from preprocessing\nto remove poor quality epochs (if available)'), 'Value', true);

    uilabel(formQ, 'Text', 'Parallel processing:');
    chkQParallel = uicheckbox(formQ, 'Text', 'Use parallel processing (process animals concurrently)', 'Value', true);

    btnRunQ = uibutton(formQ, 'Text', 'Run qEEG ▶', 'ButtonPushedFcn', @onRunqEEG, ...
        'BackgroundColor', [0.60 0.84 0.60], 'FontColor', [1 1 1], 'FontWeight', 'bold');
    btnRunQ.Layout.Row = 12;
    btnRunQ.Layout.Column = [1 2];

    pnlQLog = uipanel(gridQ, 'Title', 'qEEG run log', 'BackgroundColor',[1 1 1]);
    pnlQLog.Layout.Row = 1; pnlQLog.Layout.Column = 2;
    glQLog = uigridlayout(pnlQLog, [1 1]);
    glQLog.RowHeight = {'1x'}; glQLog.ColumnWidth = {'1x'};
    glQLog.Padding = [8 8 8 8];
    txtQLog = uitextarea(glQLog, 'Editable', 'off', 'Value', {'qEEG log will appear here during processing.'});

    % ===== Results tab =====
    gridR = uigridlayout(tabResults, [1 2]);
    gridR.ColumnWidth = {605,'1x'};
    gridR.RowHeight = {'1x'};

    pnlR = uipanel(gridR, 'Title', 'Normalized band power plots', 'BackgroundColor',[1 1 1]);
    pnlR.Layout.Row = 1; pnlR.Layout.Column = 1;
    formR = uigridlayout(pnlR, [11 2]);
    formR.RowHeight = {38,34,34,34,34,34,0,0,34,34,'1x'};
    formR.ColumnWidth = {244,'1x'};

    btnLoadBand = uibutton(formR, 'Text', 'Load project data', 'ButtonPushedFcn', @onRefreshBandTables, ...
        'BackgroundColor', [0.62 0.80 0.98], 'FontColor', [1 1 1], 'FontWeight', 'bold');
    btnLoadBand.Layout.Row = 1;
    btnLoadBand.Layout.Column = [1 2];

    uilabel(formR, 'Text', 'Source data for calculations:');
    srcRowBand = uigridlayout(formR, [1 2]);
    srcRowBand.ColumnWidth = {28,'1x'};
    srcRowBand.Padding = [0 0 0 0];
    srcRowBand.ColumnSpacing = 8;
    uibutton(srcRowBand, 'Text', char(9432), 'Tooltip', 'More info', ...
        'ButtonPushedFcn', @(~,~) showHelp('ratio_source', 'Band plot source data for calculations'));
    ddBandSource = uidropdown(srcRowBand, 'Items', {'Normalized Band Power','Power Spectra (fractional)'}, ...
        'ItemsData', {'band','power_frac'}, 'Value', 'band', 'ValueChangedFcn', @onBandPreviewOptionsChanged);

    uilabel(formR, 'Text', 'Frequency band:');
    ddBand = uidropdown(formR, 'Items', local_band_items(), 'ItemsData', local_band_values(), 'Value', 'delta', 'ValueChangedFcn', @onBandPreviewOptionsChanged);

    uilabel(formR, 'Text', 'Time:');
    ddTime = uidropdown(formR, 'Items', {'day','night','combined (day and night)'}, 'ItemsData', {'day','night','combined'}, 'Value', 'day', 'ValueChangedFcn', @onBandPreviewOptionsChanged);

    uilabel(formR, 'Text', 'Color data points by:');
    ddColorBy = uidropdown(formR, 'Items', {'StudyGroup','Sex','LitterID','RecordingDate','Genotype','AnimalID'}, ...
        'ItemsData', {'TreatmentGroup','Sex','LitterID','RecordingDate','Genotype','MouseID'}, ...
        'Value', 'TreatmentGroup', 'ValueChangedFcn', @onBandPreviewOptionsChanged);

    uilabel(formR, 'Text', 'Actions:');
    btnRow = uigridlayout(formR, [1 2]); btnRow.ColumnWidth = {153,153}; btnRow.Padding = [0 0 0 0]; btnRow.ColumnSpacing = 10;
    uibutton(btnRow, 'Text', 'Open plot window', 'ButtonPushedFcn', @onOpenBandPlot);
    uibutton(btnRow, 'Text', 'Save plot and data', 'ButtonPushedFcn', @onSaveBandPlotData);

    uilabel(formR, 'Text', '', 'Visible', 'off');
    dnRow = uigridlayout(formR, [1 2]); dnRow.ColumnWidth = {130,130}; dnRow.Padding = [0 0 0 0]; dnRow.ColumnSpacing = 10; dnRow.Visible = 'off';
    edtDayStartR = uieditfield(dnRow, 'numeric', 'Value', 6.5, 'Limits', [0 24], 'Visible', 'off');
    edtDayEndR   = uieditfield(dnRow, 'numeric', 'Value', 18.5, 'Limits', [0 24], 'Visible', 'off');

    lblOutR = uilabel(formR, 'Text', 'Output folder:', 'Visible', 'off'); %#ok<NASGU>
    edtOutR = uieditfield(formR, 'text', 'Editable', 'off', 'Value', project.outdir, 'Visible', 'off');

    lblInfoR = uilabel(formR, 'Text', 'What this does:', 'Visible', 'off'); %#ok<NASGU>
    txtInfoR = uitextarea(formR, 'Editable', 'off', ...
        'Value', {'Reads per-animal day/night band averages and plots region comparisons.', ...
                  'Dots can be colored by metadata (sex/litter/date/etc).', ...
                  'Figures auto-save into qEEG/_group_summary/.'}, 'Visible', 'off'); %#ok<NASGU>

    axR = uiaxes(gridR);
    axR.Layout.Row = 1; axR.Layout.Column = 2;
    title(axR, 'Preview (click Open plot window or Save plot and data)');

    
    
% ===== Spikes tab =====
    gridSpk = uigridlayout(tabSpikes, [1 2]);
    gridSpk.ColumnWidth = {660,'1x'};
    gridSpk.RowHeight = {'1x'};

    pnlSpk = uipanel(gridSpk, 'Title', 'Spike analysis settings', 'BackgroundColor',[1 1 1]);
    pnlSpk.Layout.Row = 1; pnlSpk.Layout.Column = 1;

    formSpk = uigridlayout(pnlSpk, [8 2]);
    formSpk.RowHeight = {34,34,34,34,34,34,180,38};
    formSpk.ColumnWidth = {300,'1x'};

    lblRowSpk = uigridlayout(formSpk, [1 2]); lblRowSpk.ColumnWidth = {'1x',28}; lblRowSpk.Padding = [0 0 0 0]; lblRowSpk.ColumnSpacing = 6;
    uilabel(lblRowSpk, 'Text', 'Sampling rate (Hz):');
    uibutton(lblRowSpk, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('sampling_rate', 'Spike analysis: Sampling rate (Hz)'));
    edtSpkFs = uieditfield(formSpk, 'numeric', 'Value', 2500, 'Limits', [1 100000]);

    lblRowSpk = uigridlayout(formSpk, [1 2]); lblRowSpk.ColumnWidth = {'1x',28}; lblRowSpk.Padding = [0 0 0 0]; lblRowSpk.ColumnSpacing = 6;
    uilabel(lblRowSpk, 'Text', 'Spike threshold (Z-score):');
    uibutton(lblRowSpk, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('spike_threshold', 'Spike analysis: Spike threshold (Z-score)'));
    edtSpkZ = uieditfield(formSpk, 'numeric', 'Value', 5, 'Limits', [1 20]);

    lblRowSpk = uigridlayout(formSpk, [1 2]); lblRowSpk.ColumnWidth = {'1x',28}; lblRowSpk.Padding = [0 0 0 0]; lblRowSpk.ColumnSpacing = 6;
    uilabel(lblRowSpk, 'Text', 'Minimum time between spikes (sec):');
    uibutton(lblRowSpk, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('spike_min_time_between', 'Spike analysis: Minimum time between spikes (sec)'));
    edtSpkMinDist = uieditfield(formSpk, 'numeric', 'Value', 0.2, 'Limits', [0.01 10]);

    lblRowSpk = uigridlayout(formSpk, [1 2]); lblRowSpk.ColumnWidth = {'1x',28}; lblRowSpk.Padding = [0 0 0 0]; lblRowSpk.ColumnSpacing = 6;
    uilabel(lblRowSpk, 'Text', 'Individual spike duration (sec):');
    uibutton(lblRowSpk, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('spike_duration', 'Spike analysis: Individual spike duration'));
    rowW = uigridlayout(formSpk, [1 2]); rowW.ColumnWidth = {130,130}; rowW.Padding = [0 0 0 0]; rowW.ColumnSpacing = 10;
    edtSpkWmin = uieditfield(rowW, 'numeric', 'Value', 0.05, 'Limits', [0.01 1]);
    edtSpkWmax = uieditfield(rowW, 'numeric', 'Value', 0.2, 'Limits', [0.02 2]);
    edtSpkWmin.Tooltip = 'Minimum individual spike duration in seconds';
    edtSpkWmax.Tooltip = 'Maximum individual spike duration in seconds';

    lblRowSpk = uigridlayout(formSpk, [1 2]); lblRowSpk.ColumnWidth = {'1x',28}; lblRowSpk.Padding = [0 0 0 0]; lblRowSpk.ColumnSpacing = 6;
    uilabel(lblRowSpk, 'Text', 'Multilead window (sec):');
    uibutton(lblRowSpk, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('spike_multilead_window', 'Spike analysis: Multilead window (sec)'));
    edtSpkML = uieditfield(formSpk, 'numeric', 'Value', 0.1, 'Limits', [0.01 1]);

    lblRowSpk = uigridlayout(formSpk, [1 2]); lblRowSpk.ColumnWidth = {'1x',28}; lblRowSpk.Padding = [0 0 0 0]; lblRowSpk.ColumnSpacing = 6;
    uilabel(lblRowSpk, 'Text', 'Artifact filtering:');
    uibutton(lblRowSpk, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('spike_artifact_masks', 'Spike analysis: Artifact handling'));
    ddSpkArtifact = uidropdown(formSpk, 'Items', {'Use low QC filter from preprocessing (most stringent)','Remove poor quality channels only','No artifact exclusion (least stringent)'}, 'ItemsData', {'use_preprocessing_masks','bad_channel_selection_only','none'}, 'Value', 'use_preprocessing_masks');

    pnlSpkFilt = uipanel(formSpk, 'Title', 'Advanced detection settings');
    pnlSpkFilt.Layout.Row = 7; pnlSpkFilt.Layout.Column = [1 2];
    gridSpkFilt = uigridlayout(pnlSpkFilt, [3 2]);
    gridSpkFilt.RowHeight = {34,34,34};
    gridSpkFilt.ColumnWidth = {300,'1x'};

    lblRowSpk = uigridlayout(gridSpkFilt, [1 2]); lblRowSpk.ColumnWidth = {'1x',28}; lblRowSpk.Padding = [0 0 0 0]; lblRowSpk.ColumnSpacing = 6;
    uilabel(lblRowSpk, 'Text', 'Spike cleanup window (sec):');
    uibutton(lblRowSpk, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('spike_cleanup_window', 'Spike analysis: Spike cleanup window'));
    edtSpkCleanup = uieditfield(gridSpkFilt, 'numeric', 'Value', 5, 'Limits', [0 10]);

    lblRowSpk = uigridlayout(gridSpkFilt, [1 2]); lblRowSpk.ColumnWidth = {'1x',28}; lblRowSpk.Padding = [0 0 0 0]; lblRowSpk.ColumnSpacing = 6;
    uilabel(lblRowSpk, 'Text', 'Minimum spike frequency detection (Hz):');
    uibutton(lblRowSpk, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('spike_lowpass_cutoff', 'Spike analysis: Minimum spike frequency detection'));
    edtSpkLowpass = uieditfield(gridSpkFilt, 'numeric', 'Value', 70, 'Limits', [1 500]);

    chkSpkLegacyFilter = uicheckbox(gridSpkFilt, 'Text', 'Use advanced detection settings', 'Value', true);
    chkSpkLegacyFilter.Layout.Column = [1 2];

    btnSpkRun = uibutton(formSpk, 'Text', '▶ Run Spike Analysis', 'ButtonPushedFcn', @(~,~) onRunSpikes(), ...
        'BackgroundColor', [0.55 0.82 0.55], 'FontColor', [1 1 1], 'FontWeight', 'bold');
    btnSpkRun.Layout.Row = 8; btnSpkRun.Layout.Column = [1 2];

    txtSpk = uitextarea(gridSpk, 'Editable', 'off');
    txtSpk.Layout.Row = 1; txtSpk.Layout.Column = 2;
    spikeResultsDir = meeg_outdir(project,'qeeg','Spike Analysis');
    spikeLogFile = fullfile(spikeResultsDir, 'SpikeAnalysis_log.txt');

% ===== Results: PS tab =====
    gridPS = uigridlayout(tabResultsPS, [1 2]);
    gridPS.ColumnWidth = {605,'1x'};
    gridPS.RowHeight = {'1x'};

    pnlPS = uipanel(gridPS, 'Title', 'Power spectral density plots');
    pnlPS.Layout.Row = 1; pnlPS.Layout.Column = 1;

    formPS = uigridlayout(pnlPS, [9 2]);
    formPS.RowHeight = {38,34,34,34,34,50,34,34,'1x'};
    formPS.ColumnWidth = {244,'1x'};

    btnLoadPS = uibutton(formPS, 'Text', 'Load project data', 'ButtonPushedFcn', @onPreviewPS, ...
        'BackgroundColor', [0.62 0.80 0.98], 'FontColor', [1 1 1], 'FontWeight', 'bold');
    btnLoadPS.Layout.Row = 1;
    btnLoadPS.Layout.Column = [1 2];

    uilabel(formPS, 'Text', 'Electrode/region to preview:');
    ddPSRegion = uidropdown(formPS, 'Items', {'Hippocampus','Barrel','Motor','Visual','Auditory'}, 'Value', 'Hippocampus');

    uilabel(formPS, 'Text', 'Time:');
    ddPSTime = uidropdown(formPS, 'Items', {'day','night','combined (day and night)'}, 'ItemsData', {'day','night','combined'}, 'Value', 'day');

    lblRowPS = uigridlayout(formPS, [1 2]); lblRowPS.ColumnWidth = {'1x', 28}; lblRowPS.Padding = [0 0 0 0]; lblRowPS.ColumnSpacing = 6;
    uilabel(lblRowPS, 'Text', 'Min frequency to plot (Hz):');
    uibutton(lblRowPS, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('ps_min_freq', 'Power spectral density: Min frequency to plot (Hz)'));
    edtPSFmin = uieditfield(formPS, 'numeric', 'Value', 0.4, 'Limits', [0 inf]);

    lblRowPS = uigridlayout(formPS, [1 2]); lblRowPS.ColumnWidth = {'1x', 28}; lblRowPS.Padding = [0 0 0 0]; lblRowPS.ColumnSpacing = 6;
    uilabel(lblRowPS, 'Text', 'Max frequency to plot (Hz):');
    uibutton(lblRowPS, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('coh_fmax', 'Power spectral density: Max frequency to plot (Hz)'));
    edtPSFmax = uieditfield(formPS, 'numeric', 'Value', 12, 'Limits', [1 inf]);

    uilabel(formPS, 'Text', 'Show individual animals:');
    chkPSIndividuals = uicheckbox(formPS, ...
        'Text', 'overlay each animal as a thin labeled line (colored by StudyGroup)', ...
        'WordWrap', 'on', ...
        'Value', false, ...
        'ValueChangedFcn', @onPSDisplayOptionChanged);

    ddPSColorBy = uidropdown(pnlPS, 'Items', {'StudyGroup'}, ...
        'ItemsData', {'TreatmentGroup'}, 'Value', 'TreatmentGroup', 'Visible', 'off', 'Position', [1 1 1 1]);

    chkPSShade = uicheckbox(pnlPS, 'Text', 'enabled', 'Value', true, 'Visible', 'off', 'Position', [1 1 1 1]);

    uilabel(formPS, 'Text', 'Actions:');
    btnRowPS = uigridlayout(formPS, [1 2]); btnRowPS.ColumnWidth = {153,153}; btnRowPS.Padding = [0 0 0 0]; btnRowPS.ColumnSpacing = 10;
    uibutton(btnRowPS, 'Text', 'Open plot window', 'ButtonPushedFcn', @onOpenPSPlot);
    uibutton(btnRowPS, 'Text', 'Save plot and data', 'ButtonPushedFcn', @onSavePSPlotData);

    lblOutPS = uilabel(formPS, 'Text', 'Output folder:', 'Visible', 'off'); %#ok<NASGU>
    edtOutPS = uieditfield(formPS, 'text', 'Editable', 'off', 'Value', project.outdir, 'Visible', 'off');

    axPS = uiaxes(gridPS);
    axPS.Layout.Row = 1; axPS.Layout.Column = 2;
    title(axPS, 'Power spectral density preview');

% Cached results tables (in memory)
    bandSummary = table();
    bandPerAnimal = table();
    bandSourceMode = "band";
    psFracSummary = table();
    psFracPerAnimal = table();
    psPreviewSpec = [];
    psPreviewFreq = [];
    psPreviewMeta = struct();
    ratioCurrent = table();
    ratioCurrentSpec = struct();

% ===== Results: Ratios tab =====
    gridRatio = uigridlayout(tabResultsRatio, [1 2]);
    gridRatio.ColumnWidth = {605,'1x'};
    gridRatio.RowHeight = {'1x'};

    pnlRatio = uipanel(gridRatio, 'Title', 'Power Ratios');
    pnlRatio.Layout.Row = 1; pnlRatio.Layout.Column = 1;

    formRatio = uigridlayout(pnlRatio, [14 2]);
    formRatio.RowHeight = {34,34,34,34,34,34,34,34,34,34,0,0,34,34};
    formRatio.ColumnWidth = {244,'1x'};

    btnLoadRatio = uibutton(formRatio, 'Text', 'Load project data', 'ButtonPushedFcn', @(~,~) refreshResultsMetadataDropdowns(), ...
        'BackgroundColor', [0.62 0.80 0.98], 'FontColor', [1 1 1], 'FontWeight', 'bold');
    btnLoadRatio.Layout.Row = 1; btnLoadRatio.Layout.Column = [1 2];

    uilabel(formRatio, 'Text', 'Source data for calculations:');
    srcRowRatio = uigridlayout(formRatio, [1 2]);
    srcRowRatio.ColumnWidth = {28,'1x'};
    srcRowRatio.Padding = [0 0 0 0];
    srcRowRatio.ColumnSpacing = 8;
    srcRowRatio.Layout.Row = 2; srcRowRatio.Layout.Column = 2;
    uibutton(srcRowRatio, 'Text', char(9432), 'Tooltip', 'More info', ...
        'ButtonPushedFcn', @(~,~) showHelp('ratio_source', 'Ratio source data for calculations'));
    ddRatioSource = uidropdown(srcRowRatio, 'Items', {'Normalized Band Power','Power Spectra (AUC)'}, ...
        'ItemsData', {'band','power'}, 'Value', 'band');

    uilabel(formRatio, 'Text', 'Numerator:');
    ddRatioNum = uidropdown(formRatio, 'Items', local_band_items(), 'ItemsData', local_band_values(), 'Value', 'delta');

    uilabel(formRatio, 'Text', 'Denominator:');
    ddRatioDen = uidropdown(formRatio, 'Items', local_band_items(), 'ItemsData', local_band_values(), 'Value', 'alpha');

    uilabel(formRatio, 'Text', 'Time:');
    ddRatioTime = uidropdown(formRatio, 'Items', {'day','night','combined (day and night)'}, 'ItemsData', {'day','night','average'}, 'Value', 'day');

    uilabel(formRatio, 'Text', 'Region:');
    ddRatioRegion = uidropdown(formRatio, 'Items', {'Average across all regions','Hippocampus','Barrel','Motor','Visual','Auditory'}, 'Value', 'Average across all regions');

    uilabel(formRatio, 'Text', 'Color data points by:');
    ddRatioColorBy = uidropdown(formRatio, 'Items', {'StudyGroup','Sex','LitterID','RecordingDate','Genotype','AnimalID'}, ...
        'ItemsData', {'TreatmentGroup','Sex','LitterID','RecordingDate','Genotype','MouseID'}, 'Value', 'TreatmentGroup');

    lblActionsRatio = uilabel(formRatio, 'Text', 'Actions:');
    lblActionsRatio.Layout.Row = 8; lblActionsRatio.Layout.Column = 1;
    btnRowRatio = uigridlayout(formRatio, [1 2]);
    btnRowRatio.Layout.Row = 8; btnRowRatio.Layout.Column = 2;
    btnRowRatio.ColumnWidth = {'1x','1x'};
    btnRowRatio.RowHeight = {34};
    btnRowRatio.Padding = [0 0 0 0];
    btnRowRatio.ColumnSpacing = 10;
    btnShowRatio = uibutton(btnRowRatio, 'Text', 'Show plot', 'ButtonPushedFcn', @onShowRatioPlot);
    btnShowRatio.Layout.Row = 1; btnShowRatio.Layout.Column = 1;
    btnDownloadRatio = uibutton(btnRowRatio, 'Text', 'Save plot and data', 'ButtonPushedFcn', @onDownloadRatioPlotData);
    btnDownloadRatio.Layout.Row = 1; btnDownloadRatio.Layout.Column = 2;

    lblRatioNote = uilabel(formRatio, 'Text', '*Ratio plots and data do not save automatically. Click save plot and data button for ratios/regions of interest.', 'FontAngle','italic');
    lblRatioNote.Layout.Row = 9; lblRatioNote.Layout.Column = [1 2];

    lblOutRatio = uilabel(formRatio, 'Text', 'Output folder:', 'Visible', 'off'); %#ok<NASGU>
    edtOutRatio = uieditfield(formRatio, 'text', 'Editable', 'off', 'Value', meeg_outdir(project,'qeeg','Ratio Analysis'), 'Visible', 'off');

    lblNotesRatio = uilabel(formRatio, 'Text', 'Notes:', 'Visible', 'off'); %#ok<NASGU>
    txtRatio = uitextarea(formRatio, 'Editable', 'off', ...
        'Value', {'Uses BandAnalysis_RegionPerAnimal.xlsx or Power Spectral Analysis *_band_power_spline.xlsx.', ...
                  'Computes one per-animal ratio value for the selected source, bands, time, and region.', ...
                  'For Average across all regions, values are averaged across all available regions before taking the ratio.'}, 'Visible', 'off');

    axRatio = uiaxes(gridRatio);
    axRatio.Layout.Row = 1; axRatio.Layout.Column = 2;
    title(axRatio, 'Power Ratios preview');
    grid(axRatio,'on');

% ===== Results: Corr tab =====
    gridCorr = uigridlayout(tabResultsCorr, [1 2]);
    gridCorr.ColumnWidth = {588,'1x'};
    gridCorr.RowHeight = {'1x'};

    pnlCorr = uipanel(gridCorr, 'Title', 'Correlation plots');
    pnlCorr.Layout.Row = 1; pnlCorr.Layout.Column = 1;

    formCorr = uigridlayout(pnlCorr, [7 1]);
    formCorr.RowHeight = {34,'fit','fit','fit','fit',0,0};
    formCorr.ColumnWidth = {'1x'};
    formCorr.Padding = [10 10 10 10];
    formCorr.RowSpacing = 10;

    btnCorrRefresh = uibutton(formCorr, 'Text', 'Load project data', 'ButtonPushedFcn', @(~,~) onCorrRefresh(), ...
        'BackgroundColor', [0.62 0.80 0.98], 'FontColor', [1 1 1], 'FontWeight', 'bold');
    btnCorrRefresh.Layout.Row = 1; btnCorrRefresh.Layout.Column = 1;

    pnlCorrGeneral = uipanel(formCorr, 'Title', 'General selection');
    pnlCorrGeneral.Layout.Row = 2; pnlCorrGeneral.Layout.Column = 1;
    generalCorr = uigridlayout(pnlCorrGeneral, [4 2]);
    generalCorr.RowHeight = {34,34,34,34};
    generalCorr.ColumnWidth = {235,'1x'};

    uilabel(generalCorr, 'Text', 'Group A:');
    ddCorrGroupA = uidropdown(generalCorr, 'Items', {'(none)'}, 'Value', '(none)');

    uilabel(generalCorr, 'Text', 'Group B:');
    ddCorrGroupB = uidropdown(generalCorr, 'Items', {'(none)'}, 'Value', '(none)');

    uilabel(generalCorr, 'Text', 'Time:');
    ddCorrTime = uidropdown(generalCorr, 'Items', {'day','night','combined (day and night)'}, 'ItemsData', {'day','night','all'}, 'Value', 'day');

    uilabel(generalCorr, 'Text', 'Color scale max (symmetric +/- 0-1):');
    sldCorrClim = uislider(generalCorr, 'Limits', [0.1 1], 'Value', 0.5);
    sldCorrClim.MajorTicks = [0.1 0.3 0.5 0.7 1];

    pnlCorrSingle = uipanel(formCorr, 'Title', 'Single matrix explorer');
    pnlCorrSingle.Layout.Row = 3; pnlCorrSingle.Layout.Column = 1;
    singleCorr = uigridlayout(pnlCorrSingle, [3 2]);
    singleCorr.RowHeight = {34,34,34};
    singleCorr.ColumnWidth = {235,'1x'};

    uilabel(singleCorr, 'Text', 'Frequency band:');
    ddCorrBand = uidropdown(singleCorr, 'Items', local_corr_band_items(), 'ItemsData', local_corr_band_values(), 'Value', 'delta');

    uilabel(singleCorr, 'Text', 'Matrix to view:');
    ddCorrMatrix = uidropdown(singleCorr, 'Items', {'Group A','Group B','Difference'}, 'Value', 'Difference');

    uilabel(singleCorr, 'Text', '');
    btnCorrShow = uibutton(singleCorr, 'Text', 'Show plot', 'ButtonPushedFcn', @(~,~) onCorrPreview());
    btnCorrShow.Layout.Column = 2;

    pnlCorrOverview = uipanel(formCorr, 'Title', 'Overview plot generator');
    pnlCorrOverview.Layout.Row = 4; pnlCorrOverview.Layout.Column = 1;
    overviewCorr = uigridlayout(pnlCorrOverview, [3 2]);
    overviewCorr.RowHeight = {34,34,34};
    overviewCorr.ColumnWidth = {235,'1x'};

    uilabel(overviewCorr, 'Text', 'Data to view:');
    ddCorrView = uidropdown(overviewCorr, 'Items', {'Amplitude overview','Frequency overview'}, 'Value', 'Amplitude overview');

    uilabel(overviewCorr, 'Text', '');
    btnCorrOpen = uibutton(overviewCorr, 'Text', 'Open plot window', 'ButtonPushedFcn', @(~,~) onCorrOpenWindow());
    btnCorrOpen.Layout.Column = 2;

    uilabel(overviewCorr, 'Text', '');
    btnCorrSave = uibutton(overviewCorr, 'Text', 'Save plot + data', 'ButtonPushedFcn', @(~,~) onCorrSavePlotData());
    btnCorrSave.Layout.Column = 2;

    lblCorrSaveNote = uilabel(formCorr, 'Text', sprintf('*Correlation and/or coherence do not save automatically. Please click "save plot and data" to save figures of interest\n**Disclaimer: Correlation and coherence analyses are not available for single channel recordings. These metrics quantify the relationship between signals and require two or more leads.'), 'FontAngle', 'italic', 'WordWrap', 'on');
    lblCorrSaveNote.Layout.Row = 5; lblCorrSaveNote.Layout.Column = 1;

    lblOutCorr = uilabel(formCorr, 'Text', 'Output folder:', 'Visible', 'off'); %#ok<NASGU>
    edtOutCorr = uieditfield(formCorr, 'text', 'Editable', 'off', 'Value', meeg_outdir(project,'qeeg','Correlation Analysis'), 'Visible', 'off');

    lblNotesCorr = uilabel(formCorr, 'Text', 'Notes:', 'Visible', 'off'); %#ok<NASGU>
    txtCorr = uitextarea(formCorr, 'Editable', 'off', 'Value', { ...
        'Single matrix shows Group A, Group B, or Difference (B-A).', ...
        'Amplitude overview shows Group A, Group B, and Difference.', ...
        'Frequency overview shows Group A, Group B, and Difference.', ...
        'Save plot + data writes PNG, FIG, and matrices.'}, 'Visible', 'off');

    axCorr = uiaxes(gridCorr);
    axCorr.Layout.Row = 1; axCorr.Layout.Column = 2;
    title(axCorr, 'Correlation preview'); axis(axCorr, 'image');
    set(axCorr, 'XTick', 1:numel(initLabels), 'YTick', 1:numel(initLabels));
    colormap(axCorr, 'parula');
    colorbar(axCorr);

% ===== Results: Coherence tab =====
    gridCoh = uigridlayout(tabResultsCoh, [1 2]);
    gridCoh.ColumnWidth = {588,'1x'};
    gridCoh.RowHeight = {'1x'};

    pnlCoh = uipanel(gridCoh, 'Title', 'Coherence plots');
    pnlCoh.Layout.Row = 1; pnlCoh.Layout.Column = 1;

    formCoh = uigridlayout(pnlCoh, [7 1]);
    formCoh.RowHeight = {34,'fit','fit','fit','fit',0,0};
    formCoh.ColumnWidth = {'1x'};
    formCoh.Padding = [10 10 10 10];
    formCoh.RowSpacing = 10;

    btnCohRefresh = uibutton(formCoh, 'Text', 'Load project data', 'ButtonPushedFcn', @(~,~) onCohRefresh(), ...
        'BackgroundColor', [0.62 0.80 0.98], 'FontColor', [1 1 1], 'FontWeight', 'bold');
    btnCohRefresh.Layout.Row = 1; btnCohRefresh.Layout.Column = 1;

    pnlCohGeneral = uipanel(formCoh, 'Title', 'General selection');
    pnlCohGeneral.Layout.Row = 2; pnlCohGeneral.Layout.Column = 1;
    generalCoh = uigridlayout(pnlCohGeneral, [4 2]);
    generalCoh.RowHeight = {34,34,34,34};
    generalCoh.ColumnWidth = {235,'1x'};

    uilabel(generalCoh, 'Text', 'Group A:');
    ddCohGroupA = uidropdown(generalCoh, 'Items', {'(none)'}, 'Value', '(none)');

    uilabel(generalCoh, 'Text', 'Group B:');
    ddCohGroupB = uidropdown(generalCoh, 'Items', {'(none)'}, 'Value', '(none)');

    uilabel(generalCoh, 'Text', 'Time:');
    ddCohTime = uidropdown(generalCoh, 'Items', {'day','night','combined (day and night)'}, 'ItemsData', {'day','night','all'}, 'Value', 'day');

    uilabel(generalCoh, 'Text', 'Color scale max (0-1):');
    sldCohClim = uislider(generalCoh, 'Limits', [0.1 1], 'Value', 0.6);
    sldCohClim.MajorTicks = [0.1 0.3 0.5 0.7 1];

    pnlCohSingle = uipanel(formCoh, 'Title', 'Single matrix explorer');
    pnlCohSingle.Layout.Row = 3; pnlCohSingle.Layout.Column = 1;
    singleCoh = uigridlayout(pnlCohSingle, [3 2]);
    singleCoh.RowHeight = {34,34,34};
    singleCoh.ColumnWidth = {235,'1x'};

    uilabel(singleCoh, 'Text', 'Frequency band:');
    ddCohBand = uidropdown(singleCoh, 'Items', local_band_items(), 'ItemsData', local_band_values(), 'Value', 'delta');

    uilabel(singleCoh, 'Text', 'Matrix to view:');
    ddCohMatrix = uidropdown(singleCoh, 'Items', {'Group A','Group B','Difference'}, 'Value', 'Difference');

    uilabel(singleCoh, 'Text', '');
    btnCohShow = uibutton(singleCoh, 'Text', 'Show plot', 'ButtonPushedFcn', @(~,~) onCohPreview());
    btnCohShow.Layout.Column = 2;

    pnlCohOverview = uipanel(formCoh, 'Title', 'Overview plot generator');
    pnlCohOverview.Layout.Row = 4; pnlCohOverview.Layout.Column = 1;
    overviewCoh = uigridlayout(pnlCohOverview, [3 2]);
    overviewCoh.RowHeight = {34,34,34};
    overviewCoh.ColumnWidth = {235,'1x'};

    uilabel(overviewCoh, 'Text', 'Data to view:');
    ddCohView = uidropdown(overviewCoh, 'Items', {'Single-band overview','Frequency overview'}, 'Value', 'Single-band overview');

    uilabel(overviewCoh, 'Text', '');
    btnCohOpen = uibutton(overviewCoh, 'Text', 'Open plot window', 'ButtonPushedFcn', @(~,~) onCohOpenWindow());
    btnCohOpen.Layout.Column = 2;

    uilabel(overviewCoh, 'Text', '');
    btnCohSave = uibutton(overviewCoh, 'Text', 'Save plot + data', 'ButtonPushedFcn', @(~,~) onCohSavePlotData());
    btnCohSave.Layout.Column = 2;

    lblCohSaveNote = uilabel(formCoh, 'Text', sprintf('*Correlation and/or coherence do not save automatically. Please click "save plot and data" to save figures of interest\n**Disclaimer: Correlation and coherence analyses are not available for single channel recordings. These metrics quantify the relationship between signals and require two or more leads.'), 'FontAngle', 'italic', 'WordWrap', 'on');
    lblCohSaveNote.Layout.Row = 5; lblCohSaveNote.Layout.Column = 1;

    ddCohReg1 = uidropdown(formCoh, 'Items', initLabels, 'Value', initLabels{1}, 'Visible','off');
    ddCohReg2 = uidropdown(formCoh, 'Items', initLabels, 'Value', initLabels{min(2, numel(initLabels))}, 'Visible','off');
    chkCohShowAnimals = uicheckbox(formCoh, 'Text', 'Show individual animals (thin lines)', 'Value', false, 'Visible','off');
    txtCohDiag = uitextarea(formCoh, 'Editable', 'off', 'Value', {'No coherence diagnostics yet.'}, 'Visible','off');

    axCoh = uiaxes(gridCoh);
    axCoh.Layout.Row = 1; axCoh.Layout.Column = 2;
    title(axCoh, 'Preview'); axis(axCoh, 'image');
    set(axCoh, 'XTick', 1:numel(initLabels), 'YTick', 1:numel(initLabels));
    colormap(axCoh, 'parula');
    colorbar(axCoh);

% ===== Results: Connectivity plots tab =====
    gridConn = uigridlayout(tabResultsConn, [1 2]);
    gridConn.ColumnWidth = {588,'1x'};
    gridConn.RowHeight = {'1x'};

    pnlConn = uipanel(gridConn, 'Title', 'Connectivity plots');
    pnlConn.Layout.Row = 1; pnlConn.Layout.Column = 1;

    formConn = uigridlayout(pnlConn, [15 2]);
    formConn.RowHeight = [repmat({34}, 1, 13), {'fit', '1x'}];
    formConn.ColumnWidth = {235,'1x'};

    btnConnRefresh = uibutton(formConn, 'Text', 'Load project data', 'ButtonPushedFcn', @(~,~) onConnRefresh(), ...
        'BackgroundColor', [0.62 0.80 0.98], 'FontColor', [1 1 1], 'FontWeight', 'bold');
    btnConnRefresh.Layout.Row = 1; btnConnRefresh.Layout.Column = [1 2];

    uilabel(formConn, 'Text', 'Source data for plots:');
    ddConnSource = uidropdown(formConn, 'Items', {'Correlation','Coherence'}, 'Value', 'Correlation', ...
        'ValueChangedFcn', @(~,~) updateConnColorScaleLabel());

    uilabel(formConn, 'Text', 'Group A:');
    ddConnGroupA = uidropdown(formConn, 'Items', {'(none)'}, 'Value', '(none)');

    uilabel(formConn, 'Text', 'Group B:');
    ddConnGroupB = uidropdown(formConn, 'Items', {'(none)'}, 'Value', '(none)');

    uilabel(formConn, 'Text', 'Frequency band:');
    ddConnBand = uidropdown(formConn, 'Items', local_corr_band_items(), 'ItemsData', local_corr_band_values(), 'Value', 'delta');

    uilabel(formConn, 'Text', 'Time:');
    ddConnTime = uidropdown(formConn, 'Items', {'day','night','combined (day and night)'}, 'ItemsData', {'day','night','all'}, 'Value', 'day');

    uilabel(formConn, 'Text', 'Data to view:');
    ddConnDisplay = uidropdown(formConn, 'Items', {'Group A','Group B','Difference'}, 'Value', 'Difference', ...
        'ValueChangedFcn', @(~,~) updateConnColorScaleLabel());

    lblConnClim = uilabel(formConn, 'Text', 'Color scale max (symmetric +/- 0-1):');
    sldConnClim = uislider(formConn, 'Limits', [0.1 1], 'Value', 0.5);
    sldConnClim.MajorTicks = [0.1 0.3 0.5 0.7 1];

    uilabel(formConn, 'Text', 'Plot style:');
    ddConnStyle = uidropdown(formConn, 'Items', {'Mouse network','3D mouse brain network','Circular network'}, 'Value', 'Mouse network');

    lblRowConnTop = uigridlayout(formConn, [1 2]); lblRowConnTop.ColumnWidth = {'1x', 28}; lblRowConnTop.Padding = [0 0 0 0]; lblRowConnTop.ColumnSpacing = 6;
    uilabel(lblRowConnTop, 'Text', 'Top edges to show:');
    uibutton(lblRowConnTop, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('connectivity_top_edges', 'Connectivity plots: Top edges to show'));
    edtConnTopN = uieditfield(formConn, 'numeric', 'Value', 12, 'Limits', [1 100], 'RoundFractionalValues','on');

    chkConnLabels = uicheckbox(formConn, 'Text', 'Show node labels', 'Value', true);
    chkConnLabels.Layout.Column = [1 2];

    uilabel(formConn, 'Text', 'Actions:');
    btnRowConn = uigridlayout(formConn, [2 2]); btnRowConn.ColumnWidth = {135,153}; btnRowConn.RowHeight = {34,34}; btnRowConn.Padding = [0 0 0 0]; btnRowConn.ColumnSpacing = 10; btnRowConn.RowSpacing = 6;
    uibutton(btnRowConn, 'Text', 'Show plot', 'ButtonPushedFcn', @(~,~) onConnPreview());
    uibutton(btnRowConn, 'Text', 'Open plot window', 'ButtonPushedFcn', @(~,~) onConnOpenWindow());
    btnConnSave = uibutton(btnRowConn, 'Text', 'Save plot + data', 'ButtonPushedFcn', @(~,~) onConnSavePlotData());
    btnConnSave.Layout.Row = 2; btnConnSave.Layout.Column = 1;

    lblConnSaveNote = uilabel(formConn, 'Text', sprintf('*Correlation and/or coherence do not save automatically. Please click "save plot and data" to save figures of interest\n**Disclaimer: Correlation and coherence analyses are not available for single channel recordings. These metrics quantify the relationship between signals and require two or more leads.'), 'FontAngle', 'italic', 'WordWrap', 'on');
    lblConnSaveNote.Layout.Row = 14; lblConnSaveNote.Layout.Column = [1 2];

    axConn = uiaxes(gridConn);
    axConn.Layout.Row = 1; axConn.Layout.Column = 2;
    title(axConn, 'Connectivity preview');
    axis(axConn, 'off');


% ===== Results: Spikes tab =====
    gridSpkR = uigridlayout(tabResultsSpikes, [1 2]);
    gridSpkR.ColumnWidth = {700,'1x'};
    gridSpkR.RowHeight = {'1x'};

    pnlSpkR = uipanel(gridSpkR, 'Title', 'Spike Analysis');
    pnlSpkR.Layout.Row = 1; pnlSpkR.Layout.Column = 1;

    formSpkR = uigridlayout(pnlSpkR, [12 2]);
    formSpkR.RowHeight = {34,34,34,34,34,34,34,34,34,34,'1x',34};
    formSpkR.ColumnWidth = {280,'1x'};

    btnSpkRefresh = uibutton(formSpkR, 'Text', 'Load project data', 'ButtonPushedFcn', @(~,~) onSpkRefresh(), ...
        'BackgroundColor', [0.62 0.80 0.98], 'FontColor', [1 1 1], 'FontWeight', 'bold');
    btnSpkRefresh.Layout.Row = 1; btnSpkRefresh.Layout.Column = [1 2];

    uilabel(formSpkR, 'Text', 'Time:');
    ddSpkTime = uidropdown(formSpkR, 'Items', {'day','night','combined (day and night)'}, 'ItemsData', {'day','night','all'}, 'Value', 'day', 'ValueChangedFcn', @(~,~) onSpkRefresh());

    uilabel(formSpkR, 'Text', 'Spike type:');
    ddSpkCountType = uidropdown(formSpkR, 'Items', {'Single-lead spikes','Multi-lead spikes'}, 'ItemsData', {'single','multilead'}, 'Value', 'single', 'ValueChangedFcn', @(~,~) onSpkRefresh());

    uilabel(formSpkR, 'Text', 'Y-axis units:');
    ddSpkScale = uidropdown(formSpkR, 'Items', {'Spikes per 30 mins','Spikes per 60 mins','Spikes per 12 hrs','Spikes per 24 hrs'}, ...
        'ItemsData', {0.5,1,12,24}, 'Value', 0.5, 'ValueChangedFcn', @(~,~) onSpkRefresh());

    uilabel(formSpkR, 'Text', 'Color data points by:');
    ddSpkColorBy = uidropdown(formSpkR, 'Items', {'StudyGroup','Sex','LitterID','RecordingDate','Genotype','AnimalID'}, 'ItemsData', {'TreatmentGroup','Sex','LitterID','RecordingDate','Genotype','MouseID'}, 'Value', 'TreatmentGroup', 'ValueChangedFcn', @(~,~) onSpkRefresh());

    uilabel(formSpkR, 'Text', 'Actions:');
    btnRowSpk = uigridlayout(formSpkR, [1 2]);
    btnRowSpk.ColumnWidth = {'1x','1x'}; btnRowSpk.RowHeight = {34}; btnRowSpk.Padding = [0 0 0 0]; btnRowSpk.ColumnSpacing = 10;
    btnRowSpk.Layout.Row = 6; btnRowSpk.Layout.Column = 2;
    btnSpkPlot = uibutton(btnRowSpk, 'Text', 'Open plot window', 'ButtonPushedFcn', @(~,~) onSpkOpenWindow());
    btnSpkSave = uibutton(btnRowSpk, 'Text', 'Save plot and data', 'ButtonPushedFcn', @(~,~) onSpkSavePlotData());

    lblSpkNote = uilabel(formSpkR, 'Text', '*Spike plots do not save automatically. Please click "save plot and data" to save figures of interest.', 'FontAngle','italic', 'WordWrap','on');
    lblSpkNote.Layout.Row = 7; lblSpkNote.Layout.Column = [1 2];

    axSpk = uiaxes(gridSpkR);
    axSpk.Layout.Row = 1; axSpk.Layout.Column = 2;
    title(axSpk, 'Preview'); grid(axSpk,'on');


% ===== Spike Browser tab =====
    gridSB = uigridlayout(tabSpikeBrowser, [1 2]);
    gridSB.ColumnWidth = {700,'1x'};
    gridSB.RowHeight = {'1x'};

    pnlSB = uipanel(gridSB, 'Title', 'Browse detected spikes (per animal)');
    pnlSB.Layout.Row = 1; pnlSB.Layout.Column = 1;

    formSB = uigridlayout(pnlSB, [15 2]);
    formSB.RowHeight = {34,34,34,34,34,34,34,34,34,34,'1x',34,34,34,90};
    formSB.ColumnWidth = {280,'1x'};

    btnSBRefresh = uibutton(formSB, 'Text', 'Load project data', 'ButtonPushedFcn', @(~,~) onSBRefreshAnimals(), ...
        'BackgroundColor', [0.62 0.80 0.98], 'FontColor', [1 1 1], 'FontWeight', 'bold');
    btnSBRefresh.Layout.Row = 1; btnSBRefresh.Layout.Column = [1 2];

    uilabel(formSB, 'Text', 'Animal:');
    ddSBAnimal = uidropdown(formSB, 'Items', {'(none)'}, 'Value', '(none)', 'ValueChangedFcn', @(~,~) onSBAnimalChanged());

    uilabel(formSB, 'Text', 'Lead:');
    ddSBLead = uidropdown(formSB, 'Items', {'(none)'}, 'Value', '(none)', 'ValueChangedFcn', @(~,~) onSBRefreshEvents());

    uilabel(formSB, 'Text', 'Time filter:');
    ddSBTime = uidropdown(formSB, 'Items', {'day','night','combined (day and night)'}, 'ItemsData', {'day','night','all'}, 'Value', 'all', 'ValueChangedFcn', @(~,~) onSBRefreshEvents());

    uilabel(formSB, 'Text', 'Event type:');
    ddSBEventType = uidropdown(formSB, 'Items', {'Single-lead spikes','Multilead events'}, 'Value', 'Single-lead spikes', 'ValueChangedFcn', @(~,~) onSBRefreshEvents());

    uilabel(formSB, 'Text', 'Multilead min leads:');
    edtSBMinLeads = uieditfield(formSB, 'numeric', 'Value', 2, 'Limits', [2 10], 'RoundFractionalValues','on', 'ValueChangedFcn', @(~,~) onSBRefreshEvents());

    uilabel(formSB, 'Text', 'Window (sec) around spike:');
    edtSBWin = uieditfield(formSB, 'numeric', 'Value', 2, 'Limits', [0.2 20]);

    chkSBNotch = uicheckbox(formSB, 'Text', 'Apply notch for display', 'Value', true);
    chkSBNotch.Layout.Column = [1 2];

    uilabel(formSB, 'Text', 'Events:');
    lbSB = uilistbox(formSB, 'Items', {}, 'ValueChangedFcn', @(~,~) onSBPlotSelected());
    lbSB.Layout.Column = [1 2];
    lbSB.Layout.Row = [9 11];

    btnSBPrev = uibutton(formSB, 'Text', 'Prev', 'ButtonPushedFcn', @(~,~) onSBPrev());
    btnSBPrev.Layout.Row = 12; btnSBPrev.Layout.Column = 1;
    btnSBNext = uibutton(formSB, 'Text', 'Next', 'ButtonPushedFcn', @(~,~) onSBNext());
    btnSBNext.Layout.Row = 12; btnSBNext.Layout.Column = 2;

    btnSBReject = uibutton(formSB, 'Text', 'Remove current spike from analyses', 'ButtonPushedFcn', @(~,~) onSBRejectCurrent(), ...
        'BackgroundColor', [1.00 0.78 0.86], 'FontWeight', 'bold');
    btnSBReject.Layout.Row = 13; btnSBReject.Layout.Column = [1 2];

    btnSBRestore = uibutton(formSB, 'Text', 'Restore current spike to analyses', 'ButtonPushedFcn', @(~,~) onSBRestoreCurrent());
    btnSBRestore.Layout.Row = 14; btnSBRestore.Layout.Column = [1 2];

    txtSBInfo = uitextarea(formSB, 'Editable', 'off');
    txtSBInfo.Layout.Column = [1 2];
    txtSBInfo.Layout.Row = 15;

    axSB = uiaxes(gridSB);
    axSB.Layout.Row = 1; axSB.Layout.Column = 2;
    title(axSB, 'Spike snippet');
    grid(axSB,'on');


% ===== SWD Settings tab =====
    gridSWD = uigridlayout(tabSWDSettings, [1 2]);
    gridSWD.ColumnWidth = {760,'1x'};
    gridSWD.RowHeight = {'1x'};

    pnlSWD = uipanel(gridSWD, 'Title', 'SWD detector settings', 'BackgroundColor',[1 1 1]);
    pnlSWD.Layout.Row = 1; pnlSWD.Layout.Column = 1;

    formSWD = uigridlayout(pnlSWD, [8 2]);
    % v101: keep the SWD Run button visible on shorter displays by making
    % the advanced settings panel ~25% shorter and reducing vertical gaps.
    formSWD.RowHeight = {34,34,34,34,34,34,278,40};
    formSWD.RowSpacing = 6;
    formSWD.ColumnWidth = {380,'1x'};

    lblRowSWD = uigridlayout(formSWD, [1 2]);
    lblRowSWD.ColumnWidth = {'1x',28}; lblRowSWD.Padding = [0 0 0 0]; lblRowSWD.ColumnSpacing = 6;
    uilabel(lblRowSWD, 'Text', 'Sampling rate (Hz):');
    uibutton(lblRowSWD, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('sampling_rate', 'SWD: Sampling rate (Hz)'));
    edtSWDFs = uieditfield(formSWD, 'numeric', 'Value', 2500, 'Limits', [1 100000]);

    lblRowSWD = uigridlayout(formSWD, [1 2]);
    lblRowSWD.ColumnWidth = {'1x',28}; lblRowSWD.Padding = [0 0 0 0]; lblRowSWD.ColumnSpacing = 6;
    uilabel(lblRowSWD, 'Text', 'SWD frequency band min (Hz):');
    uibutton(lblRowSWD, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('swd_freq_band', 'SWD: Frequency band min (Hz)'));
    edtSWDFmin = uieditfield(formSWD, 'numeric', 'Value', 5, 'Limits', [0.1 100]);

    lblRowSWD = uigridlayout(formSWD, [1 2]);
    lblRowSWD.ColumnWidth = {'1x',28}; lblRowSWD.Padding = [0 0 0 0]; lblRowSWD.ColumnSpacing = 6;
    uilabel(lblRowSWD, 'Text', 'SWD frequency band max (Hz):');
    uibutton(lblRowSWD, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('swd_freq_band', 'SWD: Frequency band max (Hz)'));
    edtSWDFmax = uieditfield(formSWD, 'numeric', 'Value', 9, 'Limits', [0.5 200]);

    lblRowSWD = uigridlayout(formSWD, [1 2]);
    lblRowSWD.ColumnWidth = {'1x',28}; lblRowSWD.Padding = [0 0 0 0]; lblRowSWD.ColumnSpacing = 6;
    uilabel(lblRowSWD, 'Text', 'Minimum SWD duration (sec):');
    uibutton(lblRowSWD, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('swd_min_duration', 'SWD: Minimum SWD duration (sec)'));
    edtSWDMinDur = uieditfield(formSWD, 'numeric', 'Value', 1.0, 'Limits', [0.1 60]);

    lblRowSWD = uigridlayout(formSWD, [1 2]);
    lblRowSWD.ColumnWidth = {'1x',28}; lblRowSWD.Padding = [0 0 0 0]; lblRowSWD.ColumnSpacing = 6;
    uilabel(lblRowSWD, 'Text', 'Minimum number of cycles:');
    uibutton(lblRowSWD, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('swd_min_cycles', 'SWD: Minimum number of cycles'));
    edtSWDMinGap = uieditfield(formSWD, 'numeric', 'Value', 3, 'Limits', [1 50], 'RoundFractionalValues','on');

    lblRowSWD = uigridlayout(formSWD, [1 2]);
    lblRowSWD.ColumnWidth = {'1x',28}; lblRowSWD.Padding = [0 0 0 0]; lblRowSWD.ColumnSpacing = 6;
    uilabel(lblRowSWD, 'Text', 'Artifact filtering:');
    uibutton(lblRowSWD, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('swd_artifact_filtering', 'SWD: Artifact filtering'));
    ddSWDArtifact = uidropdown(formSWD, 'Items', {'Use low QC filter from preprocessing (most stringent)','Remove poor quality channels only','No artifact exclusion (least stringent)'}, 'ItemsData', {'use_preprocessing_masks','bad_channel_selection_only','none'}, 'Value', 'use_preprocessing_masks');

    pnlSWDExtra = uipanel(formSWD, 'Title', 'Advanced detection settings');
    pnlSWDExtra.Layout.Row = 7; pnlSWDExtra.Layout.Column = [1 2];
    gridSWDExtra = uigridlayout(pnlSWDExtra, [6 2]);
    gridSWDExtra.RowHeight = {34,34,34,34,34,34};
    gridSWDExtra.ColumnWidth = {380,'1x'};
    gridSWDExtra.Padding = [8 8 8 8];
    gridSWDExtra.RowSpacing = 0;
    lblRowSWDEx = uigridlayout(gridSWDExtra, [1 2]);
    lblRowSWDEx.ColumnWidth = {'1x',28}; lblRowSWDEx.Padding = [0 0 0 0]; lblRowSWDEx.ColumnSpacing = 6;
    uilabel(lblRowSWDEx, 'Text', 'Envelope threshold (z-score):');
    uibutton(lblRowSWDEx, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('swd_envelope_threshold', 'SWD: Envelope threshold (z-score)'));
    edtSWDZ = uieditfield(gridSWDExtra, 'numeric', 'Value', 3.0, 'Limits', [0.5 20]);
    lblRowSWDEx = uigridlayout(gridSWDExtra, [1 2]);
    lblRowSWDEx.ColumnWidth = {'1x',28}; lblRowSWDEx.Padding = [0 0 0 0]; lblRowSWDEx.ColumnSpacing = 6;
    uilabel(lblRowSWDEx, 'Text', 'Rhythmicity threshold:');
    uibutton(lblRowSWDEx, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('swd_rhythmicity_threshold', 'SWD: Rhythmicity threshold'));
    edtSWDMerge = uieditfield(gridSWDExtra, 'numeric', 'Value', 0.55, 'Limits', [0 1]);
    lblRowSWDEx = uigridlayout(gridSWDExtra, [1 2]);
    lblRowSWDEx.ColumnWidth = {'1x',28}; lblRowSWDEx.Padding = [0 0 0 0]; lblRowSWDEx.ColumnSpacing = 6;
    uilabel(lblRowSWDEx, 'Text', 'Harmonic score threshold:');
    uibutton(lblRowSWDEx, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('swd_harmonic_score', 'SWD: Harmonic score threshold'));
    edtSWDHarm = uieditfield(gridSWDExtra, 'numeric', 'Value', 0.20, 'Limits', [0 1]);
    lblRowSWDEx = uigridlayout(gridSWDExtra, [1 2]);
    lblRowSWDEx.ColumnWidth = {'1x',28}; lblRowSWDEx.Padding = [0 0 0 0]; lblRowSWDEx.ColumnSpacing = 6;
    uilabel(lblRowSWDEx, 'Text', 'Artifact score threshold:');
    uibutton(lblRowSWDEx, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('swd_artifact_score', 'SWD: Artifact score threshold'));
    edtSWDArtifactScore = uieditfield(gridSWDExtra, 'numeric', 'Value', 0.60, 'Limits', [0 5]);
    lblRowSWDEx = uigridlayout(gridSWDExtra, [1 2]);
    lblRowSWDEx.ColumnWidth = {'1x',28}; lblRowSWDEx.Padding = [0 0 0 0]; lblRowSWDEx.ColumnSpacing = 6;
    chkSWDLegacy = uicheckbox(lblRowSWDEx, 'Text', 'Allow single-lead SWDs', 'Value', true);
    chkSWDLegacy.Layout.Column = 1;
    uibutton(lblRowSWDEx, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showHelp('swd_single_lead', 'SWD: Allow single-lead SWDs'));

    lblRowSWDEx = uigridlayout(gridSWDExtra, [1 2]);
    lblRowSWDEx.ColumnWidth = {'1x',28}; lblRowSWDEx.Padding = [0 0 0 0]; lblRowSWDEx.ColumnSpacing = 6;
    chkSWDCalibration = uicheckbox(lblRowSWDEx, 'Text', 'Calibration / Discovery mode', 'Value', false, ...
        'Tooltip', 'Retain a broader SWD candidate pool, including automatic near-misses, for manual review and threshold calibration.');
    chkSWDCalibration.Layout.Column = 1;
    uibutton(lblRowSWDEx, 'Text','ⓘ', 'Tooltip','More info', 'ButtonPushedFcn', @(~,~) showInfo( ...
        'SWD: Calibration / Discovery mode', ...
        ['Retains a broader candidate pool so the SWD Viewer can include both detector-passing events and automatic near-misses. ' ...
         'After marking candidates Keep or Exclude, use Export SWD feature list and Threshold Assistant. ' ...
         'The automatic detector thresholds shown above are still used for the original automatic decision. Discovery mode can produce more candidates and larger review files.']));

    btnSWDRun = uibutton(formSWD, 'Text', '▶ Run SWD Identifier Lite', 'ButtonPushedFcn', @(~,~) onRunSWD(), ...
        'BackgroundColor', [0.55 0.82 0.55], 'FontColor', [1 1 1], 'FontWeight', 'bold');
    btnSWDRun.Layout.Row = 8; btnSWDRun.Layout.Column = [1 2];

    txtSWD = uitextarea(gridSWD, 'Editable', 'off');
    txtSWD.Layout.Row = 1; txtSWD.Layout.Column = 2;
    txtSWD.Value = {'Use the settings on the left to run the automated SWD Identifier Lite.', 'For a new dataset, Calibration / Discovery mode retains a broader candidate pool for manual Keep/Exclude review.', 'SWD Analysis uses only candidates currently marked Keep.'};

% ===== SWD Analysis tab =====
    gridSWDR = uigridlayout(tabSWDAnalysis, [1 2]);
    gridSWDR.ColumnWidth = {700,'1x'};
    gridSWDR.RowHeight = {'1x'};

    pnlSWDR = uipanel(gridSWDR, 'Title', 'Spike-Wave-Discharge Analysis');
    pnlSWDR.Layout.Row = 1; pnlSWDR.Layout.Column = 1;

    formSWDR = uigridlayout(pnlSWDR, [10 2]);
    formSWDR.RowHeight = {34,34,34,34,34,34,34,34,'1x',34};
    formSWDR.ColumnWidth = {280,'1x'};

    btnSWDLoad = uibutton(formSWDR, 'Text', 'Load project data', 'ButtonPushedFcn', @(~,~) onSWDLoad(), ...
        'BackgroundColor', [0.62 0.80 0.98], 'FontColor', [1 1 1], 'FontWeight', 'bold');
    btnSWDLoad.Layout.Row = 1; btnSWDLoad.Layout.Column = [1 2];

    uilabel(formSWDR, 'Text', 'Time:');
    ddSWDTime = uidropdown(formSWDR, 'Items', {'day','night','combined (day and night)'}, 'ItemsData', {'day','night','all'}, 'Value', 'day', 'ValueChangedFcn', @(~,~) onSWDLoad());

    uilabel(formSWDR, 'Text', 'SWD metric:');
    ddSWDMetric = uidropdown(formSWDR, 'Items', {'SWD count','Total SWD duration','Average SWD duration','Average dominant frequency','SWD burden (%)'}, 'ItemsData', {'count','duration','meanduration','meanfreq','burden'}, 'Value', 'count', 'ValueChangedFcn', @(~,~) onSWDLoad());

    uilabel(formSWDR, 'Text', 'Y-axis units:');
    ddSWDScale = uidropdown(formSWDR, 'Items', {'Per 30 mins','Per 60 mins','Per 12 hrs','Per 24 hrs'}, 'ItemsData', {0.5,1,12,24}, 'Value', 0.5, 'ValueChangedFcn', @(~,~) onSWDLoad());

    uilabel(formSWDR, 'Text', 'Color data points by:');
    ddSWDColorBy = uidropdown(formSWDR, 'Items', {'StudyGroup','Sex','LitterID','RecordingDate','Genotype','AnimalID'}, 'ItemsData', {'TreatmentGroup','Sex','LitterID','RecordingDate','Genotype','MouseID'}, 'Value', 'TreatmentGroup', 'ValueChangedFcn', @(~,~) onSWDLoad());

    uilabel(formSWDR, 'Text', 'Actions:');
    btnRowSWD = uigridlayout(formSWDR, [1 2]);
    btnRowSWD.ColumnWidth = {'1x','1x'}; btnRowSWD.RowHeight = {34}; btnRowSWD.Padding = [0 0 0 0]; btnRowSWD.ColumnSpacing = 10;
    btnRowSWD.Layout.Row = 6; btnRowSWD.Layout.Column = 2;
    uibutton(btnRowSWD, 'Text', 'Open plot window', 'ButtonPushedFcn', @(~,~) onSWDOpenWindow());
    uibutton(btnRowSWD, 'Text', 'Save plot and data', 'ButtonPushedFcn', @(~,~) onSWDSavePlotData());

    lblSWDNote = uilabel(formSWDR, 'Text', '*SWD plots and data do not save automatically. Please click "save plot and data" to save figures of interest.', 'FontAngle','italic', 'WordWrap','on');
    lblSWDNote.Layout.Row = 7; lblSWDNote.Layout.Column = [1 2];

    axSWD = uiaxes(gridSWDR);
    axSWD.Layout.Row = 1; axSWD.Layout.Column = 2;
    title(axSWD, 'SWD preview'); grid(axSWD,'on');
    text(axSWD, 0.5, 0.5, 'Dummy SWD preview placeholder', 'HorizontalAlignment','center');

% ===== SWD Viewer tab =====
    gridSWDV = uigridlayout(tabSWDViewer, [1 2]);
    gridSWDV.ColumnWidth = {700,'1x'};
    gridSWDV.RowHeight = {'1x'};

    pnlSWDV = uipanel(gridSWDV, 'Title', 'SWD Viewer');
    pnlSWDV.Layout.Row = 1; pnlSWDV.Layout.Column = 1;

    formSWDV = uigridlayout(pnlSWDV, [13 2]);
    formSWDV.RowHeight = {34,34,34,34,34,34,34,'1x',34,34,34,38,90};
    formSWDV.ColumnWidth = {280,'1x'};

    btnSWDVLoad = uibutton(formSWDV, 'Text', 'Load project data', 'ButtonPushedFcn', @(~,~) onSWDViewerLoad(), ...
        'BackgroundColor', [0.62 0.80 0.98], 'FontColor', [1 1 1], 'FontWeight', 'bold');
    btnSWDVLoad.Layout.Row = 1; btnSWDVLoad.Layout.Column = [1 2];

    uilabel(formSWDV, 'Text', 'Animal:');
    ddSWDAnimal = uidropdown(formSWDV, 'Items', {'(none)'}, 'Value', '(none)', 'ValueChangedFcn', @(~,~) onSWDViewerLoad());

    uilabel(formSWDV, 'Text', 'Lead:');
    ddSWDLead = uidropdown(formSWDV, 'Items', {'(all leads)'}, 'Value', '(all leads)', 'ValueChangedFcn', @(~,~) onSWDViewerLoad());

    uilabel(formSWDV, 'Text', 'Time filter:');
    ddSWDVTime = uidropdown(formSWDV, 'Items', {'day','night','combined (day and night)'}, 'ItemsData', {'day','night','all'}, 'Value', 'all', 'ValueChangedFcn', @(~,~) onSWDViewerLoad());

    uilabel(formSWDV, 'Text', 'Show events:');
    ddSWDShow = uidropdown(formSWDV, 'Items', {'Keep / included only','Exclude / rejected only','All candidates'}, 'ItemsData', {'included','rejected','all'}, 'Value', 'included', 'ValueChangedFcn', @(~,~) onSWDViewerLoad());

    uilabel(formSWDV, 'Text', 'Window (sec) around SWD:');
    edtSWDWin = uieditfield(formSWDV, 'numeric', 'Value', 5, 'Limits', [0.5 60]);

    uilabel(formSWDV, 'Text', 'Events:');
    lbSWD = uilistbox(formSWDV, 'Items', {'No SWD events loaded yet'}, 'ValueChangedFcn', @(~,~) onSWDViewerSelectionChanged());
    lbSWD.Layout.Column = [1 2];
    lbSWD.Layout.Row = [6 8];

    btnSWDPrev = uibutton(formSWDV, 'Text', 'Prev', 'ButtonPushedFcn', @(~,~) onSWDViewerPrev());
    btnSWDPrev.Layout.Row = 9; btnSWDPrev.Layout.Column = 1;
    btnSWDNext = uibutton(formSWDV, 'Text', 'Next', 'ButtonPushedFcn', @(~,~) onSWDViewerNext());
    btnSWDNext.Layout.Row = 9; btnSWDNext.Layout.Column = 2;

    btnSWDReject = uibutton(formSWDV, 'Text', 'Exclude current candidate (not a real SWD)', 'ButtonPushedFcn', @(~,~) onSWDRejectCurrent(), 'BackgroundColor', [1.00 0.78 0.86], 'FontWeight', 'bold');
    btnSWDReject.Layout.Row = 10; btnSWDReject.Layout.Column = [1 2];
    btnSWDRestore = uibutton(formSWDV, 'Text', 'Keep current candidate (real SWD)', 'ButtonPushedFcn', @(~,~) onSWDRestoreCurrent(), 'BackgroundColor', [0.78 0.94 0.78], 'FontWeight','bold');
    btnSWDRestore.Layout.Row = 11; btnSWDRestore.Layout.Column = [1 2];

    swdActionRow = uigridlayout(formSWDV,[1 2]);
    swdActionRow.Layout.Row = 12; swdActionRow.Layout.Column = [1 2];
    swdActionRow.ColumnWidth = {'1x','1x'}; swdActionRow.Padding = [0 0 0 0]; swdActionRow.ColumnSpacing = 8;
    uibutton(swdActionRow,'Text','Export SWD feature list','ButtonPushedFcn',@(~,~) onSWDExportFeatureList(), ...
        'BackgroundColor',[0.62 0.80 0.98],'FontWeight','bold');
    uibutton(swdActionRow,'Text','Threshold Assistant','ButtonPushedFcn',@(~,~) onSWDThresholdAssistant(), ...
        'BackgroundColor',[0.82 0.74 0.96],'FontWeight','bold');

    txtSWDInfo = uitextarea(formSWDV, 'Editable', 'off', 'Value', {'SWD event summary.'});
    txtSWDInfo.Layout.Column = [1 2]; txtSWDInfo.Layout.Row = 13;

    axSWDV = uiaxes(gridSWDV);
    axSWDV.Layout.Row = 1; axSWDV.Layout.Column = 2;
    title(axSWDV, 'SWD snippet'); grid(axSWDV,'on');
    text(axSWDV, 0.5, 0.5, 'Dummy SWD viewer placeholder', 'HorizontalAlignment','center');

    % SWD Viewer state must be initialized before the first load. Keeping the
    % source-row map separate from the filtered list makes review updates stable
    % even when lead/time/status filters are active.
    swdViewerTable = table();
    swdViewerFile = "";
    swdViewerRowMap = [];

    refreshResultsMetadataDropdowns();
    try, onSpkRefresh(); catch, end
    try, onSBRefreshAnimals(); catch, end
    try, onSWDLoad(); catch, end
    try, onSWDViewerLoad(); catch, end



% ===== Event Detection (beta) main module =====
    gridEvtSet = uigridlayout(tabEventSettings, [1 2]);
    gridEvtSet.ColumnWidth = {'1x', 380};
    gridEvtSet.RowHeight = {'1x'};
    gridEvtSet.Padding = [8 8 8 8];
    gridEvtSet.ColumnSpacing = 10;

    pnlEvtSet = uipanel(gridEvtSet, 'Title', 'Event Detection settings');
    pnlEvtSet.Layout.Row = 1; pnlEvtSet.Layout.Column = 1;
    formEvt = uigridlayout(pnlEvtSet, [16 4]);
    formEvt.ColumnWidth = {220,110,32,'1x'};
    formEvt.RowHeight = {28,28,28,28,28,28,28,28,28,28,28,28,28,34,34,'1x'};
    formEvt.RowSpacing = 4; formEvt.Padding = [8 8 8 8];

    lblEvt1 = uilabel(formEvt,'Text','Sampling rate (Hz):'); lblEvt1.Layout.Row=1; lblEvt1.Layout.Column=1;
    edtEvtFs = uieditfield(formEvt,'numeric','Value',2500,'Limits',[1 Inf]); edtEvtFs.Layout.Row=1; edtEvtFs.Layout.Column=2;
    btnEvtInfo1 = uibutton(formEvt,'Text','ⓘ','Tooltip','More info','ButtonPushedFcn',@(~,~)showHelp('sampling_rate','Event Detection: Sampling rate')); btnEvtInfo1.Layout.Row=1; btnEvtInfo1.Layout.Column=3;

    lblEvt2 = uilabel(formEvt,'Text','Local baseline window (sec):'); lblEvt2.Layout.Row=2; lblEvt2.Layout.Column=1;
    edtEvtBase = uieditfield(formEvt,'numeric','Value',60,'Limits',[5 Inf]); edtEvtBase.Layout.Row=2; edtEvtBase.Layout.Column=2;
    btnEvtInfo2 = uibutton(formEvt,'Text','ⓘ','Tooltip','More info','ButtonPushedFcn',@(~,~)showInfo('Event Detection: local baseline window','Defines how much neighboring data mEEG uses to estimate the local baseline before judging whether a segment is abnormal. Larger windows make the baseline steadier; shorter windows adapt more quickly.')); btnEvtInfo2.Layout.Row=2; btnEvtInfo2.Layout.Column=3;
    lblEvt3 = uilabel(formEvt,'Text','Candidate window (sec):'); lblEvt3.Layout.Row=3; lblEvt3.Layout.Column=1;
    edtEvtCand = uieditfield(formEvt,'numeric','Value',1,'Limits',[0.1 Inf]); edtEvtCand.Layout.Row=3; edtEvtCand.Layout.Column=2;
    btnEvtInfo3 = uibutton(formEvt,'Text','ⓘ','Tooltip','More info','ButtonPushedFcn',@(~,~)showInfo('Event Detection: candidate window','This is the short analysis window in which mEEG measures abnormality features such as RMS, line length, spike density, and rhythmicity.')); btnEvtInfo3.Layout.Row=3; btnEvtInfo3.Layout.Column=3;
    lblEvt4 = uilabel(formEvt,'Text','Window overlap (0–0.95):'); lblEvt4.Layout.Row=4; lblEvt4.Layout.Column=1;
    edtEvtOverlap = uieditfield(formEvt,'numeric','Value',0.5,'Limits',[0 0.95]); edtEvtOverlap.Layout.Row=4; edtEvtOverlap.Layout.Column=2;
    btnEvtInfo4 = uibutton(formEvt,'Text','ⓘ','Tooltip','More info','ButtonPushedFcn',@(~,~)showInfo('Event Detection: overlap','Controls how much neighboring candidate windows overlap. Higher overlap gives denser scanning but increases computation.')); btnEvtInfo4.Layout.Row=4; btnEvtInfo4.Layout.Column=3;
    chkEvtDetrend = uicheckbox(formEvt,'Text','Detrend each chunk before feature extraction','Value',true,'Tooltip','Removes slow local drift before computing abnormality features.'); chkEvtDetrend.Layout.Row=5; chkEvtDetrend.Layout.Column=[1 4];
    lblEvt5 = uilabel(formEvt,'Text','Amplitude (RMS) z-threshold:'); lblEvt5.Layout.Row=6; lblEvt5.Layout.Column=1;
    edtEvtRMS = uieditfield(formEvt,'numeric','Value',3.5,'Limits',[0 Inf]); edtEvtRMS.Layout.Row=6; edtEvtRMS.Layout.Column=2;
    btnEvtInfo5 = uibutton(formEvt,'Text','ⓘ','Tooltip','More info','ButtonPushedFcn',@(~,~)showInfo('Event Detection: amplitude threshold','Windows are flagged when their RMS amplitude is several baseline standard deviations above the rolling local baseline.')); btnEvtInfo5.Layout.Row=6; btnEvtInfo5.Layout.Column=3;
    lblEvt6 = uilabel(formEvt,'Text','Line-length z-threshold:'); lblEvt6.Layout.Row=7; lblEvt6.Layout.Column=1;
    edtEvtLine = uieditfield(formEvt,'numeric','Value',3.0,'Limits',[0 Inf]); edtEvtLine.Layout.Row=7; edtEvtLine.Layout.Column=2;
    btnEvtInfo6 = uibutton(formEvt,'Text','ⓘ','Tooltip','More info','ButtonPushedFcn',@(~,~)showInfo('Event Detection: line length threshold','Line length measures how jagged or busy the trace is within a window. Bursts of sharp activity often increase this feature.')); btnEvtInfo6.Layout.Row=7; btnEvtInfo6.Layout.Column=3;
    lblEvt7 = uilabel(formEvt,'Text','Spike-rate z-threshold:'); lblEvt7.Layout.Row=8; lblEvt7.Layout.Column=1;
    edtEvtSpike = uieditfield(formEvt,'numeric','Value',3.0,'Limits',[0 Inf]); edtEvtSpike.Layout.Row=8; edtEvtSpike.Layout.Column=2;
    btnEvtInfo7 = uibutton(formEvt,'Text','ⓘ','Tooltip','More info','ButtonPushedFcn',@(~,~)showInfo('Event Detection: spike-rate threshold','Counts unusually dense sharp peaks relative to the local baseline. Useful for spike bursts or polyspike-like segments.')); btnEvtInfo7.Layout.Row=8; btnEvtInfo7.Layout.Column=3;
    lblEvt8 = uilabel(formEvt,'Text','Rhythmicity z-threshold:'); lblEvt8.Layout.Row=9; lblEvt8.Layout.Column=1;
    edtEvtRhythm = uieditfield(formEvt,'numeric','Value',2.5,'Limits',[0 Inf]); edtEvtRhythm.Layout.Row=9; edtEvtRhythm.Layout.Column=2;
    btnEvtInfo8 = uibutton(formEvt,'Text','ⓘ','Tooltip','More info','ButtonPushedFcn',@(~,~)showInfo('Event Detection: rhythmicity threshold','Flags windows with unusually regular repeated activity compared with the nearby baseline.')); btnEvtInfo8.Layout.Row=9; btnEvtInfo8.Layout.Column=3;
    lblEvt9 = uilabel(formEvt,'Text','Peak prominence z-scale:'); lblEvt9.Layout.Row=10; lblEvt9.Layout.Column=1;
    edtEvtPeakProm = uieditfield(formEvt,'numeric','Value',1.5,'Limits',[0 Inf]); edtEvtPeakProm.Layout.Row=10; edtEvtPeakProm.Layout.Column=2;
    btnEvtInfo9 = uibutton(formEvt,'Text','ⓘ','Tooltip','More info','ButtonPushedFcn',@(~,~)showInfo('Event Detection: peak prominence scaling','Scales how large a peak must be, relative to local variability, to count toward spike-like activity.')); btnEvtInfo9.Layout.Row=10; btnEvtInfo9.Layout.Column=3;
    lblEvt10 = uilabel(formEvt,'Text','Maximum physiologic peak-to-peak (µV):'); lblEvt10.Layout.Row=11; lblEvt10.Layout.Column=1;
    edtEvtMaxP2P = uieditfield(formEvt,'numeric','Value',3000,'Limits',[10 Inf]); edtEvtMaxP2P.Layout.Row=11; edtEvtMaxP2P.Layout.Column=2;
    btnEvtInfo10 = uibutton(formEvt,'Text','ⓘ','Tooltip','More info','ButtonPushedFcn',@(~,~)showInfo('Event Detection: physiologic ceiling','Events above this peak-to-peak ceiling are treated as likely artifact rather than physiologic brain activity.')); btnEvtInfo10.Layout.Row=11; btnEvtInfo10.Layout.Column=3;
    lblEvt11 = uilabel(formEvt,'Text','Merge nearby events if gap < (sec):'); lblEvt11.Layout.Row=12; lblEvt11.Layout.Column=1;
    edtEvtMerge = uieditfield(formEvt,'numeric','Value',0.5,'Limits',[0 Inf]); edtEvtMerge.Layout.Row=12; edtEvtMerge.Layout.Column=2;
    btnEvtInfo11 = uibutton(formEvt,'Text','ⓘ','Tooltip','More info','ButtonPushedFcn',@(~,~)showInfo('Event Detection: merge gap','Nearby abnormal windows separated by less than this gap are merged into one event.')); btnEvtInfo11.Layout.Row=12; btnEvtInfo11.Layout.Column=3;
    lblEvt12 = uilabel(formEvt,'Text','Minimum event duration (sec):'); lblEvt12.Layout.Row=13; lblEvt12.Layout.Column=1;
    edtEvtMinDur = uieditfield(formEvt,'numeric','Value',0.5,'Limits',[0.05 Inf]); edtEvtMinDur.Layout.Row=13; edtEvtMinDur.Layout.Column=2;
    btnEvtInfo12 = uibutton(formEvt,'Text','ⓘ','Tooltip','More info','ButtonPushedFcn',@(~,~)showInfo('Event Detection: minimum duration','Rejects very brief abnormal windows so that only sustained events remain in the final event table.')); btnEvtInfo12.Layout.Row=13; btnEvtInfo12.Layout.Column=3;
    btnEvtRun = uibutton(formEvt,'Text','▶ Run Event Detection (beta)','ButtonPushedFcn',@(~,~)onRunEventDetect(), 'BackgroundColor',[0.72 0.88 0.74],'FontWeight','bold'); btnEvtRun.Layout.Row=14; btnEvtRun.Layout.Column=[1 3];
    lblEvt13 = uilabel(formEvt,'Text','This beta detector flags locally abnormal events relative to each animal''s recent baseline.'); lblEvt13.Layout.Row=15; lblEvt13.Layout.Column=[1 4];
    lblEvt14 = uilabel(formEvt,'Text','Use it to detect seizure-like or other atypical EEG segments, then review manually.','FontAngle','italic'); lblEvt14.Layout.Row=16; lblEvt14.Layout.Column=[1 4];

    pnlEvtLog = uipanel(gridEvtSet,'Title','Event Detection log'); pnlEvtLog.Layout.Row=1; pnlEvtLog.Layout.Column=2;
    glEvtLog = uigridlayout(pnlEvtLog,[1 1]); glEvtLog.RowHeight={'1x'}; glEvtLog.ColumnWidth={'1x'};
    txtEvtLog = uitextarea(glEvtLog,'Editable','off','Value',{'Event Detection log will appear here during processing.'});

    % Event Viewer
    gridEvtView = uigridlayout(tabEventViewer,[1 2]); gridEvtView.ColumnWidth={410,'1x'}; gridEvtView.RowHeight={'1x'}; gridEvtView.Padding=[8 8 8 8]; gridEvtView.ColumnSpacing=10;
    pnlEvtV = uipanel(gridEvtView,'Title','Event Viewer'); pnlEvtV.Layout.Row=1; pnlEvtV.Layout.Column=1;
    formEvtV = uigridlayout(pnlEvtV,[13 2]); formEvtV.RowHeight={34,34,34,34,34,34,34,'1x',34,34,34,34,90}; formEvtV.ColumnWidth={160,'1x'};
    btnEvtVLoad = uibutton(formEvtV,'Text','Load project data','ButtonPushedFcn',@(~,~)onEventViewerLoad(),'BackgroundColor',[0.80 0.90 1.00],'FontWeight','bold'); btnEvtVLoad.Layout.Row=1; btnEvtVLoad.Layout.Column=[1 2];
    lblEvtV1 = uilabel(formEvtV,'Text','Animal:'); lblEvtV1.Layout.Row=2; lblEvtV1.Layout.Column=1;
    ddEvtAnimal = uidropdown(formEvtV,'Items',{'(none)'},'Value','(none)','ValueChangedFcn',@(~,~)onEventViewerLoad()); ddEvtAnimal.Layout.Row=2; ddEvtAnimal.Layout.Column=2;
    lblEvtV2 = uilabel(formEvtV,'Text','Lead:'); lblEvtV2.Layout.Row=3; lblEvtV2.Layout.Column=1;
    ddEvtLead = uidropdown(formEvtV,'Items',{'(all leads)'},'Value','(all leads)','ValueChangedFcn',@(~,~)onEventViewerLoad()); ddEvtLead.Layout.Row=3; ddEvtLead.Layout.Column=2;
    lblEvtV3 = uilabel(formEvtV,'Text','Time filter:'); lblEvtV3.Layout.Row=4; lblEvtV3.Layout.Column=1;
    ddEvtTime = uidropdown(formEvtV,'Items',{'day','night','combined (day and night)'},'ItemsData',{'day','night','all'},'Value','all','ValueChangedFcn',@(~,~)onEventViewerLoad()); ddEvtTime.Layout.Row=4; ddEvtTime.Layout.Column=2;
    lblEvtV4 = uilabel(formEvtV,'Text','Show events:'); lblEvtV4.Layout.Row=5; lblEvtV4.Layout.Column=1;
    ddEvtShow = uidropdown(formEvtV,'Items',{'Included only','Rejected only','All reviewed events'},'ItemsData',{'included','rejected','all'},'Value','included','ValueChangedFcn',@(~,~)onEventViewerLoad()); ddEvtShow.Layout.Row=5; ddEvtShow.Layout.Column=2;
    lblEvtV5 = uilabel(formEvtV,'Text','Event type:'); lblEvtV5.Layout.Row=6; lblEvtV5.Layout.Column=1;
    ddEvtVType = uidropdown(formEvtV,'Items',{'All detected event types','amplitude burst','line-length burst','spike-rate burst','rhythmic burst','mixed abnormality'},'ItemsData',{'all','amplitude burst','line-length burst','spike-rate burst','rhythmic burst','mixed abnormality'},'Value','all','ValueChangedFcn',@(~,~)onEventViewerLoad()); ddEvtVType.Layout.Row=6; ddEvtVType.Layout.Column=2;
    lblEvtV6 = uilabel(formEvtV,'Text','Window around event (sec):'); lblEvtV6.Layout.Row=7; lblEvtV6.Layout.Column=1;
    edtEvtViewWin = uieditfield(formEvtV,'numeric','Value',5,'Limits',[0.5 60]); edtEvtViewWin.Layout.Row=7; edtEvtViewWin.Layout.Column=2;
    lbEvt = uilistbox(formEvtV,'Items',{'No events loaded yet'},'ValueChangedFcn',@(~,~)onEventViewerSelectionChanged()); lbEvt.Layout.Row=8; lbEvt.Layout.Column=[1 2];
    btnEvtPrev = uibutton(formEvtV,'Text','Prev','ButtonPushedFcn',@(~,~)onEventViewerPrev()); btnEvtPrev.Layout.Row=9; btnEvtPrev.Layout.Column=1;
    btnEvtNext = uibutton(formEvtV,'Text','Next','ButtonPushedFcn',@(~,~)onEventViewerNext()); btnEvtNext.Layout.Row=9; btnEvtNext.Layout.Column=2;
    btnEvtReject = uibutton(formEvtV,'Text','Remove current event from analyses','ButtonPushedFcn',@(~,~)onEventRejectCurrent(),'BackgroundColor',[1.00 0.78 0.86],'FontWeight','bold'); btnEvtReject.Layout.Row=10; btnEvtReject.Layout.Column=[1 2];
    btnEvtRestore = uibutton(formEvtV,'Text','Restore current event to analyses','ButtonPushedFcn',@(~,~)onEventRestoreCurrent()); btnEvtRestore.Layout.Row=11; btnEvtRestore.Layout.Column=[1 2];
    txtEvtInfo = uitextarea(formEvtV,'Editable','off','Value',{'Event summary.'}); txtEvtInfo.Layout.Row=[12 13]; txtEvtInfo.Layout.Column=[1 2];
    axEvt = uiaxes(gridEvtView); axEvt.Layout.Row=1; axEvt.Layout.Column=2; title(axEvt,'Event snippet'); grid(axEvt,'on');

    % Event Analysis
    gridEvtA = uigridlayout(tabEventAnalysis,[1 2]); gridEvtA.ColumnWidth={380,'1x'}; gridEvtA.RowHeight={'1x'}; gridEvtA.Padding=[8 8 8 8]; gridEvtA.ColumnSpacing=10;
    pnlEvtA = uipanel(gridEvtA,'Title','Event Analysis'); pnlEvtA.Layout.Row=1; pnlEvtA.Layout.Column=1;
    formEvtA = uigridlayout(pnlEvtA,[11 2]); formEvtA.RowHeight={34,34,34,34,34,34,34,34,34,34,'1x'}; formEvtA.ColumnWidth={170,'1x'};
    btnEvtALoad = uibutton(formEvtA,'Text','Load project data','ButtonPushedFcn',@(~,~)onEventAnalysisRefresh(),'BackgroundColor',[0.80 0.90 1.00],'FontWeight','bold'); btnEvtALoad.Layout.Row=1; btnEvtALoad.Layout.Column=[1 2];
    lblEvtA1 = uilabel(formEvtA,'Text','Metric:'); lblEvtA1.Layout.Row=2; lblEvtA1.Layout.Column=1;
    ddEvtMetric = uidropdown(formEvtA,'Items',{'Event count','Total event duration','Average event duration'},'ItemsData',{'count','duration','mean_duration'},'Value','count','ValueChangedFcn',@(~,~)onEventAnalysisRefresh()); ddEvtMetric.Layout.Row=2; ddEvtMetric.Layout.Column=2;
    lblEvtA2 = uilabel(formEvtA,'Text','Event type:'); lblEvtA2.Layout.Row=3; lblEvtA2.Layout.Column=1;
    ddEvtType = uidropdown(formEvtA,'Items',{'All detected event types','amplitude burst','line-length burst','spike-rate burst','rhythmic burst','mixed abnormality'},'ItemsData',{'all','amplitude burst','line-length burst','spike-rate burst','rhythmic burst','mixed abnormality'},'Value','all','ValueChangedFcn',@(~,~)onEventAnalysisRefresh()); ddEvtType.Layout.Row=3; ddEvtType.Layout.Column=2;
    lblEvtA3 = uilabel(formEvtA,'Text','Time:'); lblEvtA3.Layout.Row=4; lblEvtA3.Layout.Column=1;
    ddEvtATime = uidropdown(formEvtA,'Items',{'day','night','combined (day and night)'},'ItemsData',{'day','night','all'},'Value','all','ValueChangedFcn',@(~,~)onEventAnalysisRefresh()); ddEvtATime.Layout.Row=4; ddEvtATime.Layout.Column=2;
    lblEvtA4 = uilabel(formEvtA,'Text','Y-axis units:'); lblEvtA4.Layout.Row=5; lblEvtA4.Layout.Column=1;
    ddEvtScale = uidropdown(formEvtA,'Items',{'per 30 min','per 60 min','per 12 h','per 24 h'},'ItemsData',[0.5 1 12 24],'Value',0.5,'ValueChangedFcn',@(~,~)onEventAnalysisRefresh()); ddEvtScale.Layout.Row=5; ddEvtScale.Layout.Column=2;
    lblEvtA5 = uilabel(formEvtA,'Text','Color data points by:'); lblEvtA5.Layout.Row=6; lblEvtA5.Layout.Column=1;
    ddEvtColor = uidropdown(formEvtA,'Items',{'StudyGroup','Sex','LitterID','RecordingDate','Genotype','AnimalID'},'ItemsData',{'TreatmentGroup','Sex','LitterID','RecordingDate','Genotype','MouseID'},'Value','TreatmentGroup','ValueChangedFcn',@(~,~)onEventAnalysisRefresh()); ddEvtColor.Layout.Row=6; ddEvtColor.Layout.Column=2;
    btnEvtOpen = uibutton(formEvtA,'Text','Open plot window','ButtonPushedFcn',@(~,~)onEventAnalysisOpenWindow()); btnEvtOpen.Layout.Row=7; btnEvtOpen.Layout.Column=[1 2];
    btnEvtSave = uibutton(formEvtA,'Text','Save plot and data','ButtonPushedFcn',@(~,~)onEventAnalysisSave()); btnEvtSave.Layout.Row=8; btnEvtSave.Layout.Column=[1 2];
    txtEvtAInfo = uitextarea(formEvtA,'Editable','off','Value',{'Load project data to build event summaries from included events.'}); txtEvtAInfo.Layout.Row=[9 11]; txtEvtAInfo.Layout.Column=[1 2];
    axEvtA = uiaxes(gridEvtA); axEvtA.Layout.Row=1; axEvtA.Layout.Column=2; title(axEvtA,'Event Analysis preview'); grid(axEvtA,'on');

    eventViewerTable = table();
    eventViewerFile = "";
    eventViewerRowMap = [];

% ===== Raw Data Viewer / Annotator main tab =====
    gridRaw = uigridlayout(tabRaw, [1 2]);
    gridRaw.ColumnWidth = {430, '1x'};
    gridRaw.RowHeight = {'1x'};
    gridRaw.Padding = [8 8 8 8];
    gridRaw.ColumnSpacing = 10;

    formRaw = uigridlayout(gridRaw, [25 3]);
    formRaw.Layout.Column = 1;
    formRaw.RowHeight = {32,20,32,20,82,20,30,30,30,30,20,30,30,30,30,30,30,30,28,28,30,30,30,8};
    formRaw.ColumnWidth = {150,'1x',90};
    formRaw.RowSpacing = 4;
    formRaw.Padding = [8 8 8 8];

    btnRawLoad = uibutton(formRaw, 'Text', 'Load project data', 'ButtonPushedFcn', @(~,~) onRawLoadProject(), ...
        'BackgroundColor', [0.80 0.90 1.00], 'FontWeight','bold');
    btnRawLoad.Layout.Row = 1; btnRawLoad.Layout.Column = [1 3];

    lblRaw1 = uilabel(formRaw, 'Text', 'Animal:');
    lblRaw1.Layout.Row = 2; lblRaw1.Layout.Column = 1;
    ddRawAnimal = uidropdown(formRaw, 'Items', {'(none)'}, 'Value', '(none)', 'ValueChangedFcn', @(~,~) onRawAnimalChanged());
    ddRawAnimal.Layout.Row = 3; ddRawAnimal.Layout.Column = [1 3];

    lblRaw2 = uilabel(formRaw, 'Text', 'Lead(s) to display:');
    lblRaw2.Layout.Row = 4; lblRaw2.Layout.Column = 1;
    lbRawLeads = uilistbox(formRaw, 'Items', {'(none)'}, 'Multiselect', 'on', 'Value', {'(none)'}, 'ValueChangedFcn', @(~,~) onRawPlot());
    lbRawLeads.Layout.Row = 5; lbRawLeads.Layout.Column = [1 3];

    lblRaw3 = uilabel(formRaw, 'Text', 'Viewer controls', 'FontWeight','bold');
    lblRaw3.Layout.Row = 6; lblRaw3.Layout.Column = 1;
    lblRaw4 = uilabel(formRaw, 'Text', 'Start time (sec):');
    lblRaw4.Layout.Row = 7; lblRaw4.Layout.Column = 1;
    edtRawStart = uieditfield(formRaw, 'numeric', 'Value', 0, 'Limits', [0 Inf], 'ValueChangedFcn', @(~,~) onRawPlot());
    edtRawStart.Layout.Row = 7; edtRawStart.Layout.Column = 2;
    btnRawGo = uibutton(formRaw, 'Text', 'Plot', 'ButtonPushedFcn', @(~,~) onRawPlot());
    btnRawGo.Layout.Row = 7; btnRawGo.Layout.Column = 3;

    lblRaw5 = uilabel(formRaw, 'Text', 'Window (sec):');
    lblRaw5.Layout.Row = 8; lblRaw5.Layout.Column = 1;
    edtRawWin = uieditfield(formRaw, 'numeric', 'Value', 30, 'Limits', [0.1 Inf], 'ValueChangedFcn', @(~,~) onRawPlot());
    edtRawWin.Layout.Row = 8; edtRawWin.Layout.Column = 2;
    chkRawNotch = uicheckbox(formRaw, 'Text', 'notch', 'Value', true, 'ValueChangedFcn', @(~,~) onRawPlot());
    chkRawNotch.Layout.Row = 8; chkRawNotch.Layout.Column = 3;

    lblRaw6 = uilabel(formRaw, 'Text', 'Display max points:');
    lblRaw6.Layout.Row = 9; lblRaw6.Layout.Column = 1;
    edtRawMaxPts = uieditfield(formRaw, 'numeric', 'Value', 8000, 'Limits', [500 Inf], 'RoundFractionalValues','on', 'ValueChangedFcn', @(~,~) onRawPlot());
    edtRawMaxPts.Layout.Row = 9; edtRawMaxPts.Layout.Column = 2;
    btnRawPrev = uibutton(formRaw, 'Text', '◀', 'ButtonPushedFcn', @(~,~) onRawStep(-1));
    btnRawPrev.Layout.Row = 9; btnRawPrev.Layout.Column = 3;

    lblRaw7 = uilabel(formRaw, 'Text', 'Sampling rate (Hz):');
    lblRaw7.Layout.Row = 10; lblRaw7.Layout.Column = 1;
    edtRawFs = uieditfield(formRaw, 'numeric', 'Value', localRawDefaultFs(), 'Limits', [1 Inf]);
    edtRawFs.Layout.Row = 10; edtRawFs.Layout.Column = 2;
    btnRawNext = uibutton(formRaw, 'Text', '▶', 'ButtonPushedFcn', @(~,~) onRawStep(1));
    btnRawNext.Layout.Row = 10; btnRawNext.Layout.Column = 3;

    lblRaw8 = uilabel(formRaw, 'Text', 'Annotation', 'FontWeight','bold');
    lblRaw8.Layout.Row = 11; lblRaw8.Layout.Column = 1;
    lblRaw9 = uilabel(formRaw, 'Text', 'Event type:');
    lblRaw9.Layout.Row = 12; lblRaw9.Layout.Column = 1;
    edtRawEventType = uieditfield(formRaw, 'text', 'Value', 'manual_event');
    edtRawEventType.Layout.Row = 12; edtRawEventType.Layout.Column = [2 3];

    lblRaw10 = uilabel(formRaw, 'Text', 'Event start (sec):');
    lblRaw10.Layout.Row = 13; lblRaw10.Layout.Column = 1;
    edtRawAnnStart = uieditfield(formRaw, 'numeric', 'Value', 0, 'Limits', [0 Inf]);
    edtRawAnnStart.Layout.Row = 13; edtRawAnnStart.Layout.Column = [2 3];

    lblRaw11 = uilabel(formRaw, 'Text', 'Event end (sec):');
    lblRaw11.Layout.Row = 14; lblRaw11.Layout.Column = 1;
    edtRawAnnEnd = uieditfield(formRaw, 'numeric', 'Value', 1, 'Limits', [0 Inf]);
    edtRawAnnEnd.Layout.Row = 14; edtRawAnnEnd.Layout.Column = [2 3];

    lblRaw12 = uilabel(formRaw, 'Text', 'Lead label:');
    lblRaw12.Layout.Row = 15; lblRaw12.Layout.Column = 1;
    ddRawAnnLead = uidropdown(formRaw, 'Items', {'(visible/all)'}, 'Value', '(visible/all)');
    ddRawAnnLead.Layout.Row = 15; ddRawAnnLead.Layout.Column = [2 3];

    lblRaw13 = uilabel(formRaw, 'Text', 'Notes:');
    lblRaw13.Layout.Row = 16; lblRaw13.Layout.Column = 1;
    edtRawNotes = uieditfield(formRaw, 'text', 'Value', '');
    edtRawNotes.Layout.Row = 16; edtRawNotes.Layout.Column = [2 3];

    btnRawUseWindow = uibutton(formRaw, 'Text', 'Use current window', 'ButtonPushedFcn', @(~,~) onRawUseWindowForAnnotation());
    btnRawUseWindow.Layout.Row = 17; btnRawUseWindow.Layout.Column = [1 3];
    btnRawAdd = uibutton(formRaw, 'Text', 'Add / save annotation', 'ButtonPushedFcn', @(~,~) onRawAddAnnotation(), ...
        'BackgroundColor', [0.75 0.92 0.78], 'FontWeight','bold');
    btnRawAdd.Layout.Row = 18; btnRawAdd.Layout.Column = [1 3];

    lbRawAnn = uilistbox(formRaw, 'Items', {'(none)'}, 'Value', '(none)', 'ValueChangedFcn', @(~,~) onRawAnnotationSelection());
    lbRawAnn.Layout.Row = [19 20]; lbRawAnn.Layout.Column = [1 3];

    btnRawDelete = uibutton(formRaw, 'Text', 'Mark selected annotation excluded', 'ButtonPushedFcn', @(~,~) onRawToggleAnnotation(false));
    btnRawDelete.Layout.Row = 21; btnRawDelete.Layout.Column = [1 3];
    btnRawRestore = uibutton(formRaw, 'Text', 'Restore selected annotation', 'ButtonPushedFcn', @(~,~) onRawToggleAnnotation(true));
    btnRawRestore.Layout.Row = 22; btnRawRestore.Layout.Column = [1 3];
    btnRawSaveCopy = uibutton(formRaw, 'Text', 'Open annotation folder', 'ButtonPushedFcn', @(~,~) onRawOpenAnnotationFolder());
    btnRawSaveCopy.Layout.Row = 23; btnRawSaveCopy.Layout.Column = [1 3];

    rightRaw = uigridlayout(gridRaw, [2 1]);
    rightRaw.Layout.Column = 2;
    rightRaw.RowHeight = {'1x', 90};
    axRaw = uiaxes(rightRaw);
    axRaw.Layout.Row = 1;
    title(axRaw, 'Raw Data Viewer');
    xlabel(axRaw, 'Time (sec)'); ylabel(axRaw, 'Signal (µV, offset by lead)');
    txtRawInfo = uitextarea(rightRaw, 'Editable','off', 'Value', {'Load a project and select an animal to view raw traces.'});
    txtRawInfo.Layout.Row = 2;

    rawAnnotations = table();
    rawAnnotationFile = "";

% ---------------- helpers ----------------
    function syncProjectFromTable()
        project.manifest(:, {'Include','MouseID','TreatmentGroup','Genotype','Sex','DOB','RecordingDate','StartTime','LitterID','Notes'}) = ...
            tbl.Data(:, {'Include','MouseID','TreatmentGroup','Genotype','Sex','DOB','RecordingDate','StartTime','LitterID','Notes'});
    end

    function logmsg(msg)
        line = sprintf('[%s] %s', datestr(now,'HH:MM:SS'), char(string(msg)));
        txtStatus.Value = [txtStatus.Value; {line}];
        txtStatus.Value = txtStatus.Value(max(1,end-300):end);
        try
            if isappdata(fig, 'MEEG_ACTIVE_RUN_LOG_FILE')
                runLogFile0 = getappdata(fig, 'MEEG_ACTIVE_RUN_LOG_FILE');
                if ~isempty(runLogFile0)
                    fid0 = fopen(char(runLogFile0), 'a');
                    if fid0 ~= -1
                        fprintf(fid0, '%s\n', line);
                        fclose(fid0);
                    end
                end
            end
        catch
        end
        drawnow;
    end

    function qlogmsg(msg)
        try
            line = sprintf('[%s] %s', datestr(now,'HH:MM:SS'), msg);
            txtQLog.Value = [txtQLog.Value; {line}];
            txtQLog.Value = txtQLog.Value(max(1,end-500):end);
            drawnow limitrate;
        catch
        end
        logmsg(msg);
    end

    function runLogFile = localStartRunLog(outDir, stem, opts)
        runLogFile = '';
        try
            if nargin < 3, opts = struct(); end
            outDir = char(outDir);
            if ~isfolder(outDir), mkdir(outDir); end
            stamp = datestr(now, 'yyyymmdd_HHMMSS');
            stem = regexprep(char(stem), '[^a-zA-Z0-9_\-]', '_');
            runLogFile = fullfile(outDir, [stem '_' stamp '.txt']);
            fid = fopen(runLogFile, 'w');
            if fid == -1, return; end
            fprintf(fid, 'mEEG process log\n');
            fprintf(fid, 'Process: %s\n', stem);
            fprintf(fid, 'Started: %s\n', datestr(now, 'yyyy-mm-dd HH:MM:SS'));
            try, fprintf(fid, 'MATLAB: %s\n', version); catch, end
            try, fprintf(fid, 'Output folder: %s\n', char(project.outdir)); catch, end
            fprintf(fid, '\nSettings:\n');
            localWriteStructToLog(fid, opts, '  ');
            fprintf(fid, '\nProgress:\n');
            fclose(fid);
        catch
            try, if exist('fid','var') && fid~=-1, fclose(fid); end, catch, end
            runLogFile = '';
        end
    end

    function localWriteStructToLog(fid, S, indent)
        if nargin < 3, indent = ''; end
        try
            if ~isstruct(S)
                fprintf(fid, '%s%s\n', indent, localValueToLogString(S));
                return;
            end
            fns = fieldnames(S);
            for kk = 1:numel(fns)
                val = S.(fns{kk});
                if isstruct(val)
                    fprintf(fid, '%s%s:\n', indent, fns{kk});
                    localWriteStructToLog(fid, val, [indent '  ']);
                else
                    fprintf(fid, '%s%s: %s\n', indent, fns{kk}, localValueToLogString(val));
                end
            end
        catch MElog
            fprintf(fid, '%s[settings log error: %s]\n', indent, MElog.message);
        end
    end

    function out = localValueToLogString(val)
        try
            if isnumeric(val) || islogical(val)
                out = mat2str(val);
            elseif isstring(val) || ischar(val)
                out = char(strjoin(string(val(:)).', ', '));
            elseif iscell(val)
                out = char(strjoin(string(val(:)).', ', '));
            elseif isa(val, 'datetime')
                out = char(string(val));
            else
                out = char(string(val));
            end
        catch
            out = '<unprintable>';
        end
    end

    function localSetActiveRunLog(runLogFile)
        try
            if isempty(runLogFile)
                if isappdata(fig, 'MEEG_ACTIVE_RUN_LOG_FILE'), rmappdata(fig, 'MEEG_ACTIVE_RUN_LOG_FILE'); end
            else
                setappdata(fig, 'MEEG_ACTIVE_RUN_LOG_FILE', char(runLogFile));
            end
        catch
        end
    end
    
    function cleanupObj = localAnalysisBusyLock(processName)
        % Disable interactive GUI controls while a long analysis is running.
        % The controls remain visible/greyed-out; their previous Enable states are restored automatically.
        cleanupObj = onCleanup(@() localRestoreAnalysisBusyState());
        try
            processName = char(string(processName));
        catch
            processName = 'Analysis';
        end
        try
            if isappdata(fig, 'MEEG_ANALYSIS_BUSY') && getappdata(fig, 'MEEG_ANALYSIS_BUSY')
                return;
            end
        catch
        end
        try
            hs = findall(fig);
            states = struct('Handle', {}, 'Enable', {});
            for ii = 1:numel(hs)
                h = hs(ii);
                try
                    if ~isvalid(h) || isequal(h, fig) || ~isprop(h, 'Enable')
                        continue;
                    end
                    states(end+1).Handle = h; %#ok<AGROW>
                    states(end).Enable = h.Enable;
                    try, h.Enable = 'off'; catch, end
                catch
                end
            end
            setappdata(fig, 'MEEG_ANALYSIS_BUSY_STATES', states);
            setappdata(fig, 'MEEG_ANALYSIS_BUSY', true);
            try, fig.Pointer = 'watch'; catch, end
            try, logmsg(string(processName) + " is running; GUI controls are temporarily disabled."); catch, end
            drawnow;
        catch MEbusy
            try, logmsg("Could not fully disable GUI during analysis: " + string(MEbusy.message)); catch, end
        end
    end

    function localRestoreAnalysisBusyState()
        try
            states = struct('Handle', {}, 'Enable', {});
            if isappdata(fig, 'MEEG_ANALYSIS_BUSY_STATES')
                states = getappdata(fig, 'MEEG_ANALYSIS_BUSY_STATES');
            end
            for ii = 1:numel(states)
                try
                    h = states(ii).Handle;
                    if isvalid(h) && isprop(h, 'Enable')
                        h.Enable = states(ii).Enable;
                    end
                catch
                end
            end
            if isappdata(fig, 'MEEG_ANALYSIS_BUSY_STATES'), rmappdata(fig, 'MEEG_ANALYSIS_BUSY_STATES'); end
            if isappdata(fig, 'MEEG_ANALYSIS_BUSY'), rmappdata(fig, 'MEEG_ANALYSIS_BUSY'); end
            try, fig.Pointer = 'arrow'; catch, end
            drawnow;
        catch
        end
    end

function refreshResultsMetadataDropdowns()
    itemsData = {'TreatmentGroup','Sex','LitterID','RecordingDate','Genotype','MouseID'};
    try
        if ~isempty(project) && isfield(project,'manifest') && ~isempty(project.manifest)
            v = string(project.manifest.Properties.VariableNames);
            v = v(v ~= "Include");
            if ~isempty(v), itemsData = cellstr(v); end
        end
    catch
    end
    items = localDisplayNames(itemsData);
    try
        old = ddColorBy.Value;
        ddColorBy.Items = items;
        ddColorBy.ItemsData = itemsData;
        if any(strcmp(itemsData, old)), ddColorBy.Value = old; else, ddColorBy.Value = itemsData{1}; end
    catch
    end
    try
        old = ddPSColorBy.Value;
        ddPSColorBy.Items = items;
        ddPSColorBy.ItemsData = itemsData;
        if any(strcmp(itemsData, old)), ddPSColorBy.Value = old; else, ddPSColorBy.Value = itemsData{1}; end
    catch
    end
    try
        old = ddRatioColorBy.Value;
        ddRatioColorBy.Items = items;
        ddRatioColorBy.ItemsData = itemsData;
        if any(strcmp(itemsData, old)), ddRatioColorBy.Value = old; else, ddRatioColorBy.Value = itemsData{1}; end
    catch
    end
    try
        old = ddSpkColorBy.Value;
        ddSpkColorBy.Items = items;
        ddSpkColorBy.ItemsData = itemsData;
        if any(strcmp(itemsData, old)), ddSpkColorBy.Value = old; else, ddSpkColorBy.Value = itemsData{1}; end
    catch
    end
    try
        % Ratios use five bilateral region averages for the standard Intan
        % 10-electrode workflow, but retain the actual user-assigned lead/
        % region labels for EDF projects.
        ratioRegionItems = local_available_ratio_region_items();
        oldR = string(ddRatioRegion.Value);
        ddRatioRegion.Items = ratioRegionItems;
        if any(strcmp(ratioRegionItems, char(oldR)))
            ddRatioRegion.Value = char(oldR);
        else
            ddRatioRegion.Value = ratioRegionItems{1};
        end

        % Keep the Power Spectra region selector independent from the ratio
        % selector so EDF projects continue to expose their true labels.
        psRegionItems = local_available_region_items();
        oldP = string(ddPSRegion.Value);
        ddPSRegion.Items = psRegionItems(2:end);
        if isempty(ddPSRegion.Items)
            ddPSRegion.Items = {'Region 1'};
        end
        if any(strcmp(ddPSRegion.Items, char(oldP)))
            ddPSRegion.Value = char(oldP);
        else
            ddPSRegion.Value = ddPSRegion.Items{1};
        end
    catch
    end
    try, edtOutRatio.Value = meeg_outdir(project,'qeeg','Ratio Analysis'); catch, end
    try, edtOutCorr.Value = meeg_outdir(project,'qeeg','Correlation Analysis'); catch, end
end


function items = local_available_ratio_region_items()
    % Standard Intan 10-electrode projects are reduced to five bilateral
    % regional averages during qEEG post-processing. Do not offer separate
    % L/R choices for ratios because those source tables no longer contain
    % independent left and right values. EDF projects retain the actual
    % user-assigned labels and therefore keep side-specific choices.
    if ~local_project_is_edf()
        items = {'Average across all regions'; 'Hippocampus'; 'Barrel'; 'Motor'; 'Visual'; 'Auditory'};
        return;
    end
    items = local_available_region_items();
end

function tf = local_project_is_edf()
    tf = false;
    try
        if isfield(project,'profile') && isfield(project.profile,'systemId')
            tf = strcmpi(string(project.profile.systemId), 'standard-edf');
        elseif isfield(project,'systemId')
            tf = strcmpi(string(project.systemId), 'standard-edf');
        end
    catch
        tf = false;
    end
end

function items = local_available_region_items()
    regs = strings(0,1);
    try
        if isfield(project,'animals') && ~isempty(project.animals)
            for kk = 1:numel(project.animals)
                a = project.animals(kk);
                if isfield(a,'assignedRegionLabels') && ~isempty(a.assignedRegionLabels)
                    rr = string(a.assignedRegionLabels(:));
                elseif isfield(a,'fileOrder') && ~isempty(a.fileOrder)
                    rr = string(a.fileOrder(:));
                else
                    rr = strings(0,1);
                end
                rr = local_pretty_region_list(rr);
                regs = [regs; rr(:)]; %#ok<AGROW>
            end
        end
    catch
    end
    regs = regs(regs~="");
    regs = unique(regs, 'stable');
    if isempty(regs)
        regs = ["Hippocampus";"Barrel";"Motor";"Visual";"Auditory"];
    end
    items = [{'Average across all regions'}; cellstr(regs)];
end

function regs = local_pretty_region_list(regs)
    regs = string(regs(:));
    for jj = 1:numel(regs)
        regs(jj) = meeg_pretty_region_label(regs(jj));
    end
end

function names = localDisplayNames(itemsData)
    names = cell(size(itemsData));
    for ii = 1:numel(itemsData)
        switch char(string(itemsData{ii}))
            case 'TreatmentGroup'
                names{ii} = 'StudyGroup';
            case 'MouseID'
                names{ii} = 'AnimalID';
            otherwise
                names{ii} = char(string(itemsData{ii}));
        end
    end
end

function refreshGroupDropdowns(ddA, ddB)
    if isempty(project) || isempty(project.manifest) || height(project.manifest)==0
        ddA.Items = {'(none)'}; ddA.Value = '(none)';
        ddB.Items = {'(none)'}; ddB.Value = '(none)';
        return;
    end
    includeMask = true(height(project.manifest),1);
    try
        inc = project.manifest.Include;
        if islogical(inc)
            includeMask = inc;
        elseif isnumeric(inc)
            includeMask = inc ~= 0;
        else
            incs = lower(strtrim(string(inc)));
            includeMask = ismember(incs, ["true","1","yes","y"]);
        end
    catch
    end
    groups = unique(string(project.manifest.TreatmentGroup(includeMask)), 'stable');
    groups = groups(strlength(groups) > 0);
    if isempty(groups)
        ddA.Items = {'(none)'}; ddA.Value = '(none)';
        ddB.Items = {'(none)'}; ddB.Value = '(none)';
        return;
    end
    oldA = ""; oldB = "";
    try, oldA = string(ddA.Value); end
    try, oldB = string(ddB.Value); end
    ddA.Items = cellstr(groups);
    ddB.Items = cellstr(groups);
    if any(groups == oldA)
        ddA.Value = char(oldA);
    else
        ddA.Value = ddA.Items{1};
    end
    if any(groups == oldB)
        ddB.Value = char(oldB);
    elseif numel(ddB.Items) >= 2
        ddB.Value = ddB.Items{2};
    else
        ddB.Value = ddB.Items{1};
    end
end

function onCorrRefresh()
    refreshGroupDropdowns(ddCorrGroupA, ddCorrGroupB);
end

function S = computeCorrStatsSingle(bandName)
    gA = string(ddCorrGroupA.Value);
    gB = string(ddCorrGroupB.Value);
    timePoint = string(ddCorrTime.Value);
    d0 = edtDayStart.Value;
    d1 = edtDayEnd.Value;
    S = meeg_corr_compare_stats(project, bandName, d0, d1, timePoint, gA, gB);
end

function Sall = computeCorrStatsOverview()
    bands = {'delta','theta','alpha','beta','gamma','fastGamma'};
    Sall = cell(1, numel(bands));
    for ii = 1:numel(bands)
        Sall{ii} = computeCorrStatsSingle(bands{ii});
    end
end

function [M, modeName, labelText] = getCorrPreviewMatrix(S)
    modeName = char(ddCorrMatrix.Value);
    switch lower(modeName)
        case 'group a'
            M = S.meanA;
        case 'group b'
            M = S.meanB;
        case 'difference'
            M = S.diff;
        otherwise
            M = S.diff;
            modeName = 'Difference';
    end
    labelText = sprintf('%s: %s (%s, %s vs %s)', modeName, S.bandName, local_time_label(S.timePoint), S.groupA, S.groupB);
end

function onCorrPreview()
    if strcmp(ddCorrGroupA.Value,'(none)') || strcmp(ddCorrGroupB.Value,'(none)')
        logmsg("Load a manifest and refresh groups first.");
        return;
    end

    clim = sldCorrClim.Value;
    S = computeCorrStatsSingle(string(ddCorrBand.Value));
    [M, modeName, labelText] = getCorrPreviewMatrix(S);
    corrLabels = local_corr_labels(S);
    meeg_corr_plot_matrix(axCorr, M, modeName, corrLabels, clim);
    title(axCorr, labelText, 'Interpreter','none');
    drawnow;
end

function plotFig = buildCorrFigure()
    clim = sldCorrClim.Value;
    viewMode = string(ddCorrView.Value);
    if strcmp(viewMode, "Single matrix")
        S = computeCorrStatsSingle(string(ddCorrBand.Value));
        [M, modeName, labelText] = getCorrPreviewMatrix(S);
        plotFig = figure('Color','w', 'Units','pixels', 'Position', [80 80 900 760]);
        ax = axes(plotFig);
        corrLabels = local_corr_labels(S);
        meeg_corr_plot_matrix(ax, M, modeName, corrLabels, clim);
        title(ax, labelText, 'Interpreter','none', 'FontSize', 16);
    elseif strcmp(viewMode, "Amplitude overview")
        S = computeCorrStatsSingle('amp');
        corrLabels = local_corr_labels(S);
        plotFig = meeg_corr_plot_overview(S, corrLabels, 'amplitude overview', clim);
    else
        Sall = computeCorrStatsOverview();
        corrLabels = local_corr_labels(Sall{1});
        plotFig = meeg_corr_plot_overview([Sall{:}], corrLabels, 'frequency overview', clim);
    end
end

function onCorrOpenWindow()
    if strcmp(ddCorrGroupA.Value,'(none)') || strcmp(ddCorrGroupB.Value,'(none)')
        logmsg("Load a manifest and refresh groups first.");
        return;
    end
    plotFig = buildCorrFigure(); %#ok<NASGU>
end

function onCorrSavePlotData()
    if strcmp(ddCorrGroupA.Value,'(none)') || strcmp(ddCorrGroupB.Value,'(none)')
        logmsg("Load a manifest and refresh groups first.");
        return;
    end

    outDir = meeg_outdir(project,'qeeg','Correlation Analysis');
    if ~isfolder(outDir), mkdir(outDir); end
    edtOutCorr.Value = outDir;

    viewMode = string(ddCorrView.Value);
    timePoint = string(ddCorrTime.Value);
    gA = matlab.lang.makeValidName(char(ddCorrGroupA.Value));
    gB = matlab.lang.makeValidName(char(ddCorrGroupB.Value));

    if strcmp(viewMode, "Single matrix")
        bandName = string(ddCorrBand.Value);
        S = computeCorrStatsSingle(bandName);
        plotFig = buildCorrFigure();
        base = sprintf('Correlation_%s_%s_%s_vs_%s_%s', bandName, timePoint, gA, gB, matlab.lang.makeValidName(char(ddCorrMatrix.Value)));
        pngPath = fullfile(outDir, [base '.png']);
        figPath = fullfile(outDir, [base '.fig']);
        xlsxPath = fullfile(outDir, [base '.xlsx']);
        meeg_save_png_svg(plotFig, pngPath, 'Resolution', 300);
        savefig(plotFig, figPath);
        writematrix(S.meanA, xlsxPath, 'Sheet', 'GroupA');
        writematrix(S.meanB, xlsxPath, 'Sheet', 'GroupB');
        writematrix(S.diff,  xlsxPath, 'Sheet', 'Difference_BminusA');
        logmsg("Saved: " + string(pngPath));
        close(plotFig);
    elseif strcmp(viewMode, "Amplitude overview")
        S = computeCorrStatsSingle('amp');
        plotFig = buildCorrFigure();
        base = sprintf('Correlation_Amplitude_%s_%s_vs_%s', timePoint, gA, gB);
        pngPath = fullfile(outDir, [base '.png']);
        figPath = fullfile(outDir, [base '.fig']);
        xlsxPath = fullfile(outDir, [base '.xlsx']);
        meeg_save_png_svg(plotFig, pngPath, 'Resolution', 300);
        savefig(plotFig, figPath);
        writematrix(S.meanA, xlsxPath, 'Sheet', 'GroupA');
        writematrix(S.meanB, xlsxPath, 'Sheet', 'GroupB');
        writematrix(S.diff,  xlsxPath, 'Sheet', 'Difference_BminusA');
        logmsg("Saved: " + string(pngPath));
        close(plotFig);
    else
        bands = {'delta','theta','alpha','beta','gamma','fastGamma'};
        Sall = computeCorrStatsOverview();
        plotFig = buildCorrFigure();
        base = sprintf('Correlation_Frequency_%s_%s_vs_%s', timePoint, gA, gB);
        pngPath = fullfile(outDir, [base '.png']);
        figPath = fullfile(outDir, [base '.fig']);
        xlsxPath = fullfile(outDir, [base '.xlsx']);
        meeg_save_png_svg(plotFig, pngPath, 'Resolution', 300);
        savefig(plotFig, figPath);
        for ii = 1:numel(bands)
            sheetStem = matlab.lang.makeValidName(bands{ii});
            Si = Sall{ii};
            writematrix(Si.meanA, xlsxPath, 'Sheet', [sheetStem '_A']);
            writematrix(Si.meanB, xlsxPath, 'Sheet', [sheetStem '_B']);
            writematrix(Si.diff,  xlsxPath, 'Sheet', [sheetStem '_Diff']);
        end
        logmsg("Saved: " + string(pngPath));
        close(plotFig);
    end
end

function onCohRefresh()
    refreshGroupDropdowns(ddCohGroupA, ddCohGroupB);
end

function S = computeCohStatsSingle(bandName)
    gA = string(ddCohGroupA.Value);
    gB = string(ddCohGroupB.Value);
    timePoint = string(ddCohTime.Value);
    d0 = edtDayStart.Value;
    d1 = edtDayEnd.Value;
    S = meeg_coh_compare_stats(project, bandName, d0, d1, timePoint, gA, gB);
end

function Sall = computeCohStatsOverview()
    bands = {'delta','theta','alpha','beta','gamma','fastGamma'};
    Sall = cell(1, numel(bands));
    for ii = 1:numel(bands)
        Sall{ii} = computeCohStatsSingle(bands{ii});
    end
end

function [M, modeName, labelText] = getCohPreviewMatrix(S)
    pick = string(ddCohMatrix.Value);
    switch pick
        case "Group A"
            M = S.meanA;
            modeName = 'Group A';
        case "Group B"
            M = S.meanB;
            modeName = 'Group B';
        otherwise
            M = S.diff;
            modeName = 'Difference';
    end
    labelText = sprintf('Coherence %s: %s (%s, %s vs %s)', modeName, char(S.bandName), local_time_label(S.timePoint), char(S.groupA), char(S.groupB));
end

function updateCohDiag(S)
    if isempty(S) || ~isstruct(S)
        txtCohDiag.Value = {'No coherence diagnostics available.'};
        return;
    end
    nSelA = numel(S.animalIDsA); nSelB = numel(S.animalIDsB);
    nFileA = sum(S.fileFoundA); nFileB = sum(S.fileFoundB);
    nFinA = sum(S.anyFiniteA); nFinB = sum(S.anyFiniteB);
    lines = { ...
        sprintf('Group A (%s): selected=%d, files found=%d, animals with finite data=%d', S.groupA, nSelA, nFileA, nFinA), ...
        sprintf('Group B (%s): selected=%d, files found=%d, animals with finite data=%d', S.groupB, nSelB, nFileB, nFinB)};
    if nSelA > 0
        for kk = 1:nSelA
            f = ''; if kk <= numel(S.filesA), f = S.filesA{kk}; end
            if isempty(f), f='(missing file)'; end
            lines{end+1} = sprintf('A %s | finite=%d | %s', S.animalIDsA{kk}, S.anyFiniteA(kk), f); %#ok<AGROW>
        end
    end
    if nSelB > 0
        for kk = 1:nSelB
            f = ''; if kk <= numel(S.filesB), f = S.filesB{kk}; end
            if isempty(f), f='(missing file)'; end
            lines{end+1} = sprintf('B %s | finite=%d | %s', S.animalIDsB{kk}, S.anyFiniteB(kk), f); %#ok<AGROW>
        end
    end
    txtCohDiag.Value = lines;
    fprintf('[Coherence diagnostics]\n');
    for kk = 1:numel(lines), fprintf('  %s\n', lines{kk}); end
end

function onCohPreview()
    if strcmp(ddCohGroupA.Value,'(none)') || strcmp(ddCohGroupB.Value,'(none)')
        logmsg("Load a manifest and refresh groups first.");
        return;
    end

    S = computeCohStatsSingle(string(ddCohBand.Value));
    regLabels = local_coh_labels(S);
    [M, modeName, labelText] = getCohPreviewMatrix(S);
    meeg_coh_plot_matrix(axCoh, M, modeName, regLabels, sldCohClim.Value);
    title(axCoh, labelText, 'Interpreter','none', 'FontSize', 14);
    drawnow;
end

function plotFig = buildCohFigure()
    clim = sldCohClim.Value;
    viewMode = string(ddCohView.Value);
    if strcmp(viewMode, "Single matrix")
        S = computeCohStatsSingle(string(ddCohBand.Value));
        regLabels = local_coh_labels(S);
        [M, modeName, labelText] = getCohPreviewMatrix(S);
        plotFig = figure('Color','w', 'Units','pixels', 'Position', [80 80 900 760]);
        ax = axes(plotFig);
        meeg_coh_plot_matrix(ax, M, modeName, regLabels, clim);
        title(ax, labelText, 'Interpreter','none', 'FontSize', 16);
    elseif strcmp(viewMode, "Single-band overview")
        S = computeCohStatsSingle(string(ddCohBand.Value));
        regLabels = local_coh_labels(S);
        plotFig = meeg_coh_plot_overview(S, regLabels, 'single-band overview', clim);
    else
        Sall = computeCohStatsOverview();
        regLabels = local_coh_labels(Sall{1});
        plotFig = meeg_coh_plot_overview(Sall, regLabels, 'frequency overview', clim);
    end
end

function onCohOpenWindow()
    if strcmp(ddCohGroupA.Value,'(none)') || strcmp(ddCohGroupB.Value,'(none)')
        logmsg("Load a manifest and refresh groups first.");
        return;
    end
    plotFig = buildCohFigure(); %#ok<NASGU>
end

function onCohSavePlotData()
    if strcmp(ddCohGroupA.Value,'(none)') || strcmp(ddCohGroupB.Value,'(none)')
        logmsg("Load a manifest and refresh groups first.");
        return;
    end

    outDir = meeg_outdir(project,'qeeg','Coherence Analysis');
    if ~isfolder(outDir), mkdir(outDir); end

    viewMode = string(ddCohView.Value);
    timePoint = string(ddCohTime.Value);
    gA = matlab.lang.makeValidName(char(ddCohGroupA.Value));
    gB = matlab.lang.makeValidName(char(ddCohGroupB.Value));

    if strcmp(viewMode, "Single matrix") || strcmp(viewMode, "Single-band overview")
        bandName = string(ddCohBand.Value);
        S = computeCohStatsSingle(bandName);
        plotFig = buildCohFigure();
        suffix = matlab.lang.makeValidName(char(ddCohMatrix.Value));
        if strcmp(viewMode, "Single-band overview"), suffix = 'overview'; end
        base = sprintf('Coherence_%s_%s_%s_vs_%s_%s', bandName, timePoint, gA, gB, suffix);
        pngPath = fullfile(outDir, [base '.png']);
        figPath = fullfile(outDir, [base '.fig']);
        xlsxPath = fullfile(outDir, [base '.xlsx']);
        meeg_save_png_svg(plotFig, pngPath, 'Resolution', 300);
        savefig(plotFig, figPath);
        writematrix(S.meanA, xlsxPath, 'Sheet', 'GroupA');
        writematrix(S.meanB, xlsxPath, 'Sheet', 'GroupB');
        writematrix(S.diff,  xlsxPath, 'Sheet', 'Difference_BminusA');
        logmsg("Saved: " + string(pngPath));
        close(plotFig);
    else
        bands = {'delta','theta','alpha','beta','gamma','fastGamma'};
        Sall = computeCohStatsOverview();
        plotFig = buildCohFigure();
        base = sprintf('Coherence_Frequency_%s_%s_vs_%s', timePoint, gA, gB);
        pngPath = fullfile(outDir, [base '.png']);
        figPath = fullfile(outDir, [base '.fig']);
        xlsxPath = fullfile(outDir, [base '.xlsx']);
        meeg_save_png_svg(plotFig, pngPath, 'Resolution', 300);
        savefig(plotFig, figPath);
        for ii = 1:numel(bands)
            sheetStem = matlab.lang.makeValidName(bands{ii});
            Si = Sall{ii};
            writematrix(Si.meanA, xlsxPath, 'Sheet', [sheetStem '_A']);
            writematrix(Si.meanB, xlsxPath, 'Sheet', [sheetStem '_B']);
            writematrix(Si.diff,  xlsxPath, 'Sheet', [sheetStem '_Diff']);
        end
        logmsg("Saved: " + string(pngPath));
        close(plotFig);
    end
end

function [f, YA, YB, idsA, idsB] = getCohPairData()
    if strcmp(ddCohGroupA.Value,'(none)') || strcmp(ddCohGroupB.Value,'(none)')
        error('Load a manifest and refresh groups first.');
    end

    reg1 = string(ddCohReg1.Value);
    reg2 = string(ddCohReg2.Value);
    if reg1 == reg2
        error('Pick two different leads.');
    end

    [fA, YA, idsA] = meeg_coh_collect_pair_spectra(project, ddCohGroupA.Value, reg1, reg2, ddCohTime.Value);
    [fB, YB, idsB] = meeg_coh_collect_pair_spectra(project, ddCohGroupB.Value, reg1, reg2, ddCohTime.Value);

    if isempty(fA) || isempty(YA)
        error("No spectra found for Group A. Re-run coherence with 'Save pair-spectrum coherence data' enabled.");
    end
    if isempty(fB) || isempty(YB)
        error("No spectra found for Group B. Re-run coherence with 'Save pair-spectrum coherence data' enabled.");
    end

    f = fA;
    if isempty(f) || numel(f) ~= size(YA,2) || numel(f) ~= size(YB,2)
        error('Coherence spectra dimensions are inconsistent.');
    end
end

function plotFig = buildCohPairFigure()
    [f, YA, YB, ~, ~] = getCohPairData();
    reg1 = string(ddCohReg1.Value);
    reg2 = string(ddCohReg2.Value);
    gA = string(ddCohGroupA.Value);
    gB = string(ddCohGroupB.Value);

    cols = meeg_get_group_colors([gA; gB]);
    cA = cols(1,:);
    cB = cols(2,:);
    cAthin = 0.55*cA + 0.45;
    cBthin = 0.55*cB + 0.45;

    plotFig = figure('Color','w', 'WindowState','maximized', 'Name','Coherence Pair Spectrum', 'NumberTitle','off', 'Visible','on');
    ax = axes(plotFig); hold(ax,'on');

    if chkCohShowAnimals.Value
        for i = 1:size(YA,1)
            plot(ax, f, YA(i,:), 'Color', cAthin, 'LineWidth', 0.6, 'HandleVisibility','off');
        end
        for i = 1:size(YB,1)
            plot(ax, f, YB(i,:), 'Color', cBthin, 'LineWidth', 0.6, 'HandleVisibility','off');
        end
    end

    mA = mean(YA,1,'omitnan'); seA = std(YA,0,1,'omitnan') ./ sqrt(max(1,sum(~isnan(YA),1)));
    mB = mean(YB,1,'omitnan'); seB = std(YB,0,1,'omitnan') ./ sqrt(max(1,sum(~isnan(YB),1)));

    fill(ax, [f fliplr(f)], [mA-seA fliplr(mA+seA)], cA, 'FaceAlpha', 0.18, 'EdgeColor','none', 'HandleVisibility','off');
    fill(ax, [f fliplr(f)], [mB-seB fliplr(mB+seB)], cB, 'FaceAlpha', 0.18, 'EdgeColor','none', 'HandleVisibility','off');
    plot(ax, f, mA, 'Color', cA, 'LineWidth', 2.2);
    plot(ax, f, mB, 'Color', cB, 'LineWidth', 2.2);

    xlabel(ax, 'Frequency (Hz)');
    ylabel(ax, 'Coherence');
    title(ax, sprintf('Coherence spectrum: %s ↔ %s (%s)', reg1, reg2, local_time_label(ddCohTime.Value)), 'Interpreter','none');
    legend(ax, {char(gA), char(gB)}, 'Interpreter','none', 'Location','best');
    grid(ax, 'on');
    xlim(ax, [min(f) max(f)]);
    ylim(ax, [0 1]);
end

function onCohPairSpectrum()
    try
        figPair = buildCohPairFigure();
        figure(figPair);
    catch ME
        logmsg("Coherence pair spectrum error: " + string(ME.message));
        try, uialert(fig, char("Coherence pair spectrum error: " + string(ME.message)), 'Coherence'); catch, end
    end
end

function onCohSavePairSpectrum()
    try
        [f, YA, YB, idsA, idsB] = getCohPairData();
    catch ME
        logmsg(string(ME.message));
        return;
    end

    reg1 = string(ddCohReg1.Value);
    reg2 = string(ddCohReg2.Value);
    timePoint = string(ddCohTime.Value);
    gA = string(ddCohGroupA.Value);
    gB = string(ddCohGroupB.Value);

    outDir = meeg_outdir(project,'qeeg','Coherence Analysis');
    if ~isfolder(outDir), mkdir(outDir); end

    plotFig = buildCohPairFigure();
    base = sprintf('CoherencePair_%s_%s_%s_%s_vs_%s', matlab.lang.makeValidName(char(reg1)), matlab.lang.makeValidName(char(reg2)), char(timePoint), matlab.lang.makeValidName(char(gA)), matlab.lang.makeValidName(char(gB)));
    pngPath = fullfile(outDir, [base '.png']);
    figPath = fullfile(outDir, [base '.fig']);
    xlsxPath = fullfile(outDir, [base '.xlsx']);
    meeg_save_png_svg(plotFig, pngPath, 'Resolution', 300);
    savefig(plotFig, figPath);

    statsA = table(idsA(:), repmat({char(gA)}, numel(idsA),1), mean(YA,2,'omitnan'), 'VariableNames', {'Animal','Group','MeanCoherence'});
    statsB = table(idsB(:), repmat({char(gB)}, numel(idsB),1), mean(YB,2,'omitnan'), 'VariableNames', {'Animal','Group','MeanCoherence'});
    summaryT = table(f(:), mean(YA,1,'omitnan')', (std(YA,0,1,'omitnan')./sqrt(max(1,sum(~isnan(YA),1))))', mean(YB,1,'omitnan')', (std(YB,0,1,'omitnan')./sqrt(max(1,sum(~isnan(YB),1))))', ...
        'VariableNames', {'FrequencyHz','GroupA_Mean','GroupA_SEM','GroupB_Mean','GroupB_SEM'});
    writetable(summaryT, xlsxPath, 'Sheet', 'SpectrumSummary');
    writetable(statsA, xlsxPath, 'Sheet', 'GroupA_Animals');
    writetable(statsB, xlsxPath, 'Sheet', 'GroupB_Animals');
    writematrix(YA, xlsxPath, 'Sheet', 'GroupA_Spectra', 'Range', 'B2');
    writecell([{'Animal'}, cellstr(compose('Hz_%g', f))'], xlsxPath, 'Sheet', 'GroupA_Spectra', 'Range', 'A1');
    writecell(idsA(:), xlsxPath, 'Sheet', 'GroupA_Spectra', 'Range', 'A2');
    writematrix(YB, xlsxPath, 'Sheet', 'GroupB_Spectra', 'Range', 'B2');
    writecell([{'Animal'}, cellstr(compose('Hz_%g', f))'], xlsxPath, 'Sheet', 'GroupB_Spectra', 'Range', 'A1');
    writecell(idsB(:), xlsxPath, 'Sheet', 'GroupB_Spectra', 'Range', 'A2');

    logmsg("Saved: " + string(pngPath));
    close(plotFig);
end

function [parentFig, createdTemp] = local_progress_parent()
    createdTemp = false;
    parentFig = [];
    try
        if ~isempty(fig) && isgraphics(fig, 'figure')
            parentFig = fig;
            return;
        end
    catch
    end
    try
        allFigs = findall(groot, 'Type', 'figure');
        for ii = 1:numel(allFigs)
            try
                if isa(allFigs(ii), 'matlab.ui.Figure') && isvalid(allFigs(ii))
                    parentFig = allFigs(ii);
                    return;
                end
            catch
            end
        end
    catch
    end
    try
        parentFig = uifigure('Visible','off', 'HandleVisibility','off', 'Tag','mEEGTempProgressHost');
        createdTemp = true;
    catch
        error('Could not create a valid figure for the progress dialog.');
    end
end

function local_cleanup_progress_parent(parentFig, createdTemp)
    if nargin < 2 || ~createdTemp, return; end
    try
        if ~isempty(parentFig) && isvalid(parentFig)
            delete(parentFig);
        end
    catch
    end
end

function labels = local_default_display_labels(n)
    canonical10 = {'auditory_R','visual_R','hippocampus_R','barrel_R','motor_R','auditory_L','visual_L','hippocampus_L','barrel_L','motor_L'};
    if nargin < 1 || isempty(n), n = 0; end
    if n == 10
        labels = canonical10;
    else
        labels = cellstr(compose('Lead %d', 1:n));
    end
    try
        tmp = string(labels(:));
        for jj = 1:numel(tmp)
            tmp(jj) = meeg_pretty_region_label(tmp(jj));
        end
        labels = cellstr(tmp(:));
    catch
    end
end

function tf = local_labels_are_generic(labels)
    tf = false;
    try
        s = lower(strtrim(string(labels(:))));
        if isempty(s), tf = true; return; end
        genericSet = lower([compose('r%d', 1:numel(s))'; compose('lead %d', 1:numel(s))'; compose('ch%d', 1:numel(s))']);
        tf = all(ismember(s, genericSet));
    catch
    end
end


function labels = local_corr_labels(S)
    labels = {};
    try
        if isstruct(S) && isfield(S,'labels') && ~isempty(S.labels)
            labels = cellstr(string(S.labels(:))');
        end
    catch
    end
    if isempty(labels)
        try
            n = size(S.meanA,1);
        catch
            n = numel(profile.channelLabels);
        end
        labels = local_default_display_labels(n);
    elseif local_labels_are_generic(labels)
        labels = local_default_display_labels(numel(labels));
    end
end

function labels = local_coh_labels(S)
    labels = {};
    try
        if isstruct(S) && isfield(S,'labels') && ~isempty(S.labels)
            labels = cellstr(string(S.labels(:))');
        end
    catch
    end
    if isempty(labels)
        try
            n = size(S.meanA,1);
        catch
            n = numel(profile.channelLabels);
        end
        labels = local_default_display_labels(n);
    elseif local_labels_are_generic(labels)
        labels = local_default_display_labels(numel(labels));
    end
end

function onConnRefresh()
    refreshGroupDropdowns(ddConnGroupA, ddConnGroupB);
end

function updateConnColorScaleLabel()
    % Keep the Connectivity color-scale description aligned with the
    % selected metric and view. Correlation is signed. Magnitude-squared
    % coherence is non-negative, while a between-group coherence
    % difference can still be negative.
    try
        src = string(ddConnSource.Value);
        viewName = string(ddConnDisplay.Value);
        if src == "Coherence" && viewName ~= "Difference"
            lblConnClim.Text = 'Color scale max (0 to selected value):';
        elseif src == "Coherence"
            lblConnClim.Text = 'Color scale max (coherence difference +/-):';
        else
            lblConnClim.Text = 'Color scale max (symmetric +/- 0-1):';
        end
    catch
    end
end

function S = computeConnStatsSingle()
    gA = string(ddConnGroupA.Value);
    gB = string(ddConnGroupB.Value);
    timePoint = string(ddConnTime.Value);
    d0 = edtDayStart.Value;
    d1 = edtDayEnd.Value;
    src = string(ddConnSource.Value);
    bandName = string(ddConnBand.Value);
    if src == "Correlation"
        S = meeg_corr_compare_stats(project, bandName, d0, d1, timePoint, gA, gB);
        S.sourceType = 'Correlation';
        if ~isfield(S,'labels') || isempty(S.labels)
            S.labels = local_default_display_labels(size(S.meanA,1));
        end
    else
        if bandName == "amp"
            error('Coherence does not have an amplitude band. Pick delta, theta, alpha, beta, gamma, or fastGamma.');
        end
        S = meeg_coh_compare_stats(project, bandName, d0, d1, timePoint, gA, gB);
        S.sourceType = 'Coherence';
        if ~isfield(S,'labels') || isempty(S.labels)
            S.labels = local_default_display_labels(size(S.meanA,1));
        end
    end
end

function [M, contentName] = getConnMatrix(S)
    pick = string(ddConnDisplay.Value);
    switch pick
        case "Group A"
            M = S.meanA; contentName = 'Group A';
        case "Group B"
            M = S.meanB; contentName = 'Group B';
        otherwise
            M = S.diff; contentName = 'Difference';
    end
end

function plotFig = buildConnFigure(targetAx)
    if nargin < 1, targetAx = []; end
    if strcmp(ddConnGroupA.Value,'(none)') || strcmp(ddConnGroupB.Value,'(none)')
        error('Load a manifest and refresh groups first.');
    end
    S = computeConnStatsSingle();
    [M, contentName] = getConnMatrix(S);
    style = string(ddConnStyle.Value);
    opts = struct();
    opts.sourceType = S.sourceType;
    opts.labels = S.labels;
    opts.pValue = S.pValue;
    opts.filterByP = false;
    opts.pThresh = NaN;
    opts.topN = round(edtConnTopN.Value);
    opts.showLabels = logical(chkConnLabels.Value);
    opts.contentName = contentName;
    opts.climMax = sldConnClim.Value;
    opts.titleText = sprintf('%s %s — %s (%s) %s vs %s', S.sourceType, contentName, S.bandName, local_time_label(S.timePoint), S.groupA, S.groupB);
    if isempty(targetAx)
        plotFig = figure('Color','w','Units','pixels','Position',[90 70 1100 850]);
        ax = axes(plotFig);
    else
        plotFig = ancestor(targetAx, 'figure');
        ax = targetAx;
    end
    meeg_connectivity_plot(ax, M, style, opts);
end

function onConnPreview()
    try
        buildConnFigure(axConn);
    catch ME
        cla(axConn); axis(axConn,'off');
        text(axConn, 0.5, 0.5, char(ME.message), 'Units','normalized', 'HorizontalAlignment','center', 'Interpreter','none');
        logmsg("Connectivity preview error: " + string(ME.message));
    end
end

function onConnOpenWindow()
    try
        f = buildConnFigure([]); %#ok<NASGU>
    catch ME
        logmsg("Connectivity plot error: " + string(ME.message));
        try, uialert(fig, char("Connectivity plot error: " + string(ME.message)), 'Connectivity'); catch, end
    end
end

function onConnSavePlotData()
    try
        S = computeConnStatsSingle();
        [M, contentName] = getConnMatrix(S);
        figConn = buildConnFigure([]);
    catch ME
        logmsg("Connectivity save error: " + string(ME.message));
        return;
    end
    outDir = meeg_outdir(project,'qeeg','Connectivity Analysis');
    if ~isfolder(outDir), mkdir(outDir); end
    base = sprintf('Connectivity_%s_%s_%s_%s_vs_%s_%s', matlab.lang.makeValidName(S.sourceType), matlab.lang.makeValidName(char(contentName)), matlab.lang.makeValidName(char(S.bandName)), matlab.lang.makeValidName(char(S.timePoint)), matlab.lang.makeValidName(char(S.groupA)), matlab.lang.makeValidName(char(S.groupB)));
    pngPath = fullfile(outDir, [base '.png']);
    figPath = fullfile(outDir, [base '.fig']);
    xlsxPath = fullfile(outDir, [base '.xlsx']);
    meeg_save_png_svg(figConn, pngPath, 'Resolution', 300);
    savefig(figConn, figPath);
    writematrix(S.meanA, xlsxPath, 'Sheet', 'GroupA');
    writematrix(S.meanB, xlsxPath, 'Sheet', 'GroupB');
    writematrix(S.diff,  xlsxPath, 'Sheet', 'Difference_BminusA');
    writematrix(M, xlsxPath, 'Sheet', 'DisplayedMatrix');
    T = S.edgeTable;
    if ~isempty(T)
        labels = string(S.labels(:));
        T.RowNode = labels(T.RowLeadIdx);
        T.ColNode = labels(T.ColLeadIdx);
        T = movevars(T, {'RowNode','ColNode'}, 'Before', 1);
        writetable(T, xlsxPath, 'Sheet', 'EdgeTable_All');
        Tshow = T;
        if ~isempty(Tshow)
            [~,ord] = sort(abs(Tshow.Difference_BminusA), 'descend', 'MissingPlacement','last');
            ord = ord(1:min(height(Tshow), round(edtConnTopN.Value)));
            Tshow = Tshow(ord,:);
            writetable(Tshow, xlsxPath, 'Sheet', 'EdgeTable_DisplayedTopN');
        end
    end
    logmsg("Saved: " + string(pngPath));
    close(figConn);
end

function onRunSpikes()

    spikeResultsDir = meeg_outdir(project,'qeeg','Spike Analysis');
    if ~isfolder(spikeResultsDir), mkdir(spikeResultsDir); end
    spikeLogFile = '';

    % Provide immediate visible feedback in the Spikes tab log
    appendSpkLog("=== Run Spike Analysis ===");
    appendSpkLog("Spike Analysis output folder: " + string(spikeResultsDir));
    drawnow;

    if isempty(project) || isempty(project.manifest) || height(project.manifest)==0
        appendSpkLog("ERROR: No manifest loaded. Go to Manifest tab and load/save a project first.");
        return;
    end
    if ~ismember('Include', project.manifest.Properties.VariableNames) || ~any(project.manifest.Include)
        appendSpkLog("ERROR: No animals are selected (Include=false for all). Select at least one animal in the Manifest tab.");
        return;
    end

    % Collect options with validation
    spikeOpts = struct();
    spikeOpts.fs = edtSpkFs.Value;
    if isempty(spikeOpts.fs) || ~isfinite(spikeOpts.fs) || spikeOpts.fs <= 0
        appendSpkLog("ERROR: Sampling rate (Hz) must be a positive number.");
        try, uialert(fig, 'Sampling rate (Hz) must be a positive number.', 'Spike Analysis'); catch, end
        return;
    end
    spikeOpts.Zspike = edtSpkZ.Value;
    spikeOpts.minDist_sec = edtSpkMinDist.Value;
    spikeOpts.width_min_sec = edtSpkWmin.Value;
    spikeOpts.width_max_sec = edtSpkWmax.Value;
    spikeOpts.multilead_win_sec = edtSpkML.Value;
    spikeOpts.cleanupWindow_sec = edtSpkCleanup.Value;
    spikeOpts.lowpass_hz = edtSpkLowpass.Value;
    spikeOpts.legacyNotchFilter = chkSpkLegacyFilter.Value;
    spikeOpts.artifactMode = string(ddSpkArtifact.Value);
    spikeOpts.useMasks = spikeOpts.artifactMode == "use_preprocessing_masks";
    spikeOpts.hourStart = 0;

    spikeLogFile = localStartRunLog(spikeResultsDir, 'SpikeAnalysis_log', spikeOpts);
    localSetActiveRunLog(spikeLogFile);
    appendSpkLog("Spike Analysis log file: " + string(spikeLogFile));

    appendSpkLog(sprintf('Options: fs=%.1f Hz, Z=%.1f, minDist=%.3f s, width=[%.3f..%.3f] s, multileadWin=%.3f s, cleanup=%.3f s, lowpass=%.1f Hz, artifactMode=%s, legacyFilter=%d', ...
        spikeOpts.fs, spikeOpts.Zspike, spikeOpts.minDist_sec, spikeOpts.width_min_sec, spikeOpts.width_max_sec, spikeOpts.multilead_win_sec, spikeOpts.cleanupWindow_sec, spikeOpts.lowpass_hz, char(spikeOpts.artifactMode), spikeOpts.legacyNotchFilter));
    drawnow;

    appendSpkLog("Running spike analysis (this can take a while)...");
    drawnow;

    spikeUsePar = false;
    try
        spikeUsePar = license('test','Distrib_Computing_Toolbox');
    catch
    end
    spikeOpts.useParallel = spikeUsePar;
    cleanupSpikeUi = localAnalysisBusyLock('Spike Analysis'); %#ok<NASGU>

    try
        meeg_spike_runall_10e(project, spikeOpts, @(m) appendSpkLog(m));
        appendSpkLog("Spike analysis done.");
        localSetActiveRunLog('');
        try, onSpkRefresh(); catch, end
        try, onSBRefreshAnimals(); catch, end
    catch ME
        appendSpkLog("Spike analysis error: " + string(ME.message));
        localSetActiveRunLog('');
        try
            uialert(fig, char("Spike analysis error: " + string(ME.message)), 'Spike Analysis');
        catch
        end
    end
end
function appendSpkLog(msg)
    try
        txtSpk.Value = [txtSpk.Value; {char(msg)}];
    catch
    end
    % Run-log file writing is handled centrally by logmsg() while a process is active.
    logmsg(msg);
    drawnow;
end

function onSpkRefresh()
    try
        onSBRefreshAnimals();
    catch
    end
    cla(axSpk);
    try
        countType = string(ddSpkCountType.Value);
        yScaleHours = ddSpkScale.Value;
        Tspk = meeg_spike_collect_per_animal(project, ddSpkTime.Value, edtDayStart.Value, edtDayEnd.Value, countType);
    catch ME
        title(axSpk, 'Spike preview');
        text(axSpk, 0.5, 0.5, char("Could not load spike tables: " + string(ME.message)), 'HorizontalAlignment','center');
        return;
    end
    if isempty(Tspk) || height(Tspk)==0
        title(axSpk, 'Spike preview');
        text(axSpk, 0.5, 0.5, 'No spike tables found. Run spike analysis or load project data.', 'HorizontalAlignment','center');
        return;
    end

    groups = unique(string(Tspk.TreatmentGroup), 'stable');
    groups(groups=="") = [];
    leads = unique(string(Tspk.Lead), 'stable');
    leads(leads=="") = [];
    if isempty(groups) || isempty(leads)
        title(axSpk, 'Spike preview');
        text(axSpk, 0.5, 0.5, 'No spike data found for the current selection.', 'HorizontalAlignment','center');
        return;
    end

    scaleFactor = ddSpkScale.Value / 0.5;
    Tspk.DisplaySpikeCount = Tspk.SpikeCount * scaleFactor;
    Cg = meeg_get_group_colors(groups);
    colorVar = string(ddSpkColorBy.Value);
    dotUsesSelectedMetadata = ismember(char(colorVar), Tspk.Properties.VariableNames);
    if dotUsesSelectedMetadata
        dotGroups = string(Tspk.(colorVar));
        dotCats = unique(dotGroups, 'stable');
        dotCats(dotCats=="") = [];
    else
        dotGroups = string(Tspk.TreatmentGroup);
        dotCats = groups;
    end
    if isempty(dotCats), dotCats = groups; dotGroups = string(Tspk.TreatmentGroup); end
    Cd = meeg_get_metadata_colors(max(1,numel(dotCats)));

    mu = nan(numel(groups), numel(leads));
    se = nan(numel(groups), numel(leads));
    for gi = 1:numel(groups)
        for ri = 1:numel(leads)
            idx = string(Tspk.TreatmentGroup)==groups(gi) & string(Tspk.Lead)==leads(ri);
            y = Tspk.DisplaySpikeCount(idx);
            mu(gi,ri) = mean(y,'omitnan');
            se(gi,ri) = std(y,0,'omitnan') ./ max(1, sqrt(sum(~isnan(y))));
        end
    end

    hold(axSpk,'on');
    [~, xPos] = meeg_grouped_bar_manual(axSpk, mu', Cg, 0.78);
    for gi = 1:numel(groups)
        errorbar(axSpk, xPos(:,gi)', mu(gi,:), se(gi,:), 'k', 'LineStyle','none', 'LineWidth', 1);
    end

    rng(0);
    for ri = 1:numel(leads)
        for gi = 1:numel(groups)
            idx = string(Tspk.Lead)==leads(ri) & string(Tspk.TreatmentGroup)==groups(gi);
            if ~any(idx), continue; end
            y = Tspk.DisplaySpikeCount(idx);
            x0 = xPos(ri, gi);
            x = x0 + (rand(size(y))-0.5)*0.12;
            cats = dotGroups(idx);
            for ci = 1:numel(dotCats)
                idc = cats==dotCats(ci);
                if ~any(idc), continue; end
                scatter(axSpk, x(idc), y(idc), 32, 'MarkerFaceColor', Cd(ci,:), 'MarkerEdgeColor', 'k', 'LineWidth', 0.5);
            end
        end
    end

    axSpk.XLim = [0.5, numel(leads)+0.5];
    axSpk.XTick = 1:numel(leads);
    axSpk.XTickLabel = cellstr(leads);
    axSpk.XTickLabelRotation = 35;
    ylabel(axSpk, sprintf('Avg spikes per %.1f hr', ddSpkScale.Value));
    countLabel = 'Single-lead spikes';
    if string(ddSpkCountType.Value) == "multilead", countLabel = 'Multi-lead spikes'; end
    title(axSpk, sprintf('Spike Analysis — %s (%s)', countLabel, ddSpkTime.Value), 'Interpreter','none');
    grid(axSpk,'on');

    dummyBar = gobjects(numel(groups),1);
    for gi = 1:numel(groups)
        dummyBar(gi) = scatter(axSpk, nan, nan, 40, 's', 'MarkerFaceColor', Cg(gi,:), 'MarkerEdgeColor','k');
    end
    dummyDot = gobjects(numel(dotCats),1);
    for ci = 1:numel(dotCats)
        dummyDot(ci) = scatter(axSpk, nan, nan, 32, 'MarkerFaceColor', Cd(ci,:), 'MarkerEdgeColor','k');
    end
    legHandles = dummyBar(:);
    legLabels = strcat('Bar: ', cellstr(groups));
    if ~isequal(cellstr(groups), cellstr(dotCats)) || colorVar ~= "TreatmentGroup"
        legHandles = [legHandles; dummyDot(:)]; %#ok<AGROW>
        legLabels = [legLabels; strcat('Dot: ', cellstr(dotCats))]; %#ok<AGROW>
    end
    legend(axSpk, legHandles, legLabels, 'Location', 'northeast', 'Interpreter','none');
    hold(axSpk,'off');
end

function onSpkOpenWindow()
    try
        selectedGroups = strings(0,1);
        hFig = meeg_plot_spike_group_counts(project, ddSpkTime.Value, edtDayStart.Value, edtDayEnd.Value, ddSpkCountType.Value, ddSpkScale.Value, ddSpkColorBy.Value, '', selectedGroups);
        try, figure(hFig); drawnow; catch, end
        logmsg("Opened Spike Analysis plot window.");
    catch ME
        logmsg("Spike plot error: " + string(ME.message));
        try, uialert(fig, char(string(ME.message)), 'Spike plot error'); catch, end
    end
end

function onSpkSavePlotData()
    outDir = meeg_outdir(project,'qeeg','Spike Analysis');
    if ~isfolder(outDir), mkdir(outDir); end
    stem = sprintf('Spikes_%s_%s_per_%ghr', char(ddSpkCountType.Value), char(ddSpkTime.Value), ddSpkScale.Value);
    stem = strrep(stem, ' ', '_');
    outPng = fullfile(outDir, [stem '.png']);
    try
        [hFig, exportTbl] = meeg_plot_spike_group_counts(project, ddSpkTime.Value, edtDayStart.Value, edtDayEnd.Value, ddSpkCountType.Value, ddSpkScale.Value, ddSpkColorBy.Value, outPng, strings(0,1));
        try
            writetable(exportTbl, fullfile(outDir, [stem '.xlsx']), 'Sheet', 'SpikeData');
        catch
            writetable(exportTbl, fullfile(outDir, [stem '.csv']));
        end
        if ~isempty(hFig) && isvalid(hFig), close(hFig); end
        logmsg("Saved: " + string(outPng));
        try, uialert(fig, sprintf('Saved current spike plot and data into:\n%s', outDir), 'Saved'); catch, end
    catch ME
        logmsg("Spike save error: " + string(ME.message));
        try, uialert(fig, char(string(ME.message)), 'Spike save error'); catch, end
    end
end


function onSBAnimalChanged()
    localUpdateSpikeViewerLeadDropdown();
    onSBRefreshEvents();
end

function [leadVec, leadLabel] = sbRegionToLeads(regionName)
    % Map the Spike Viewer lead dropdown value to the current project's lead index.
    % EDF projects can have any 1-10 user-assigned lead labels (Area A, Motor (L), etc.).
    [items, idxs] = localSpikeViewerLeadChoices();
    selected = string(regionName);
    hit = find(string(items) == selected, 1, 'first');
    if isempty(hit)
        prettySel = meeg_pretty_region_label(selected);
        hit = find(string(items) == prettySel, 1, 'first');
    end
    if isempty(hit)
        safeSel = string(meeg_sanitize_lead_label(selected));
        safeItems = string(meeg_sanitize_lead_label(string(items)));
        hit = find(safeItems == safeSel, 1, 'first');
    end
    if ~isempty(hit)
        leadVec = idxs(hit);
        leadLabel = char(items(hit));
        return;
    end

    % Backward-compatible fallback for old 10-lead names/projects.
    r = lower(string(regionName));
    switch r
        case {"hippocampus_r", "hippocampus", "hippocampus (r)", "rhip"}
            leadVec = 1; leadLabel = 'Hippocampus (R)';
        case {"barrel_r", "barrel", "barrel (r)", "rbar"}
            leadVec = 2; leadLabel = 'Barrel (R)';
        case {"motor_r", "motor", "motor (r)", "rmot"}
            leadVec = 3; leadLabel = 'Motor (R)';
        case {"auditory_r", "auditory", "auditory (r)", "raud"}
            leadVec = 4; leadLabel = 'Auditory (R)';
        case {"visual_r", "visual", "visual (r)", "rvis"}
            leadVec = 5; leadLabel = 'Visual (R)';
        case {"hippocampus_l","hippocampus (l)","hippocampus.l", "lhip"}
            leadVec = 6; leadLabel = 'Hippocampus (L)';
        case {"barrel_l","barrel (l)","barrel.l", "lbar"}
            leadVec = 7; leadLabel = 'Barrel (L)';
        case {"motor_l","motor (l)","motor.l", "lmot"}
            leadVec = 8; leadLabel = 'Motor (L)';
        case {"auditory_l","auditory (l)","auditory.l", "laud"}
            leadVec = 9; leadLabel = 'Auditory (L)';
        case {"visual_l","visual (l)","visual.l", "lvis"}
            leadVec = 10; leadLabel = 'Visual (L)';
        otherwise
            leadVec = 1; leadLabel = char(regionName);
    end
end

function localUpdateSpikeViewerLeadDropdown()
    try
        [items, ~] = localSpikeViewerLeadChoices();
        if isempty(items)
            items = {'(none)'};
        end
        oldVal = string(ddSBLead.Value);
        ddSBLead.Items = items;
        if any(string(items) == oldVal)
            ddSBLead.Value = char(oldVal);
        else
            ddSBLead.Value = items{1};
        end
        try
            nLead = numel(items);
            edtSBMinLeads.Limits = [1 max(1,nLead)];
            edtSBMinLeads.Value = min(max(round(edtSBMinLeads.Value), 1), max(1,nLead));
        catch
        end
    catch
        ddSBLead.Items = {'(none)'};
        ddSBLead.Value = '(none)';
    end
end

function [items, idxs] = localSpikeViewerLeadChoices()
    labels = strings(0,1);

    % Prefer the selected animal's saved spike-output channel labels.
    try
        if exist('ddSBAnimal','var') && ~strcmp(char(string(ddSBAnimal.Value)), '(none)')
            [matf, ~, ~] = meeg_spike_find_outputs(project, ddSBAnimal.Value);
            if strlength(string(matf)) > 0 && isfile(char(matf))
                S = load(char(matf), 'channelLabels', 'spikesCount');
                if isfield(S, 'channelLabels') && ~isempty(S.channelLabels)
                    labels = string(S.channelLabels(:));
                elseif isfield(S, 'spikesCount') && ~isempty(S.spikesCount)
                    labels = "Lead " + string((1:size(S.spikesCount,1))');
                end
            end
        end
    catch
    end

    % Fall back to current project/profile labels, which are set during EDF assignment.
    if isempty(labels)
        try
            if isfield(project,'profile') && isfield(project.profile,'channelLabels') && ~isempty(project.profile.channelLabels)
                labels = string(project.profile.channelLabels(:));
            end
        catch
        end
    end
    if isempty(labels)
        try
            if isfield(project,'animals') && ~isempty(project.animals) && isfield(project.animals,'fileOrder') && ~isempty(project.animals(1).fileOrder)
                labels = string(project.animals(1).fileOrder(:));
            end
        catch
        end
    end
    if isempty(labels)
        try
            n = meeg_profile_nch(project.profile);
        catch
            n = 10;
        end
        labels = "Lead " + string((1:n)');
    end

    labels = labels(:);
    idxs = (1:numel(labels))';
    pretty = strings(size(labels));
    for ii = 1:numel(labels)
        pretty(ii) = meeg_pretty_region_label(labels(ii));
    end
    items = cellstr(pretty(:));
    try
        items = matlab.lang.makeUniqueStrings(items);
    catch
    end
end
function sbHost = localSBStateHost()
    % Resolve the persistent state host from a live Spike Browser component.
    % Do not use temporary qEEG plot figures for viewer state.
    sbHost = [];
    try
        sbHost = ancestor(lbSB, 'figure');
    catch
    end
    try
        if isempty(sbHost) || ~isgraphics(sbHost, 'figure')
            if ~isempty(fig) && isgraphics(fig, 'figure')
                sbHost = fig;
            else
                sbHost = [];
            end
        end
    catch
        sbHost = [];
    end
end

function onSBRefreshAnimals()
    if isempty(project) || isempty(project.manifest) || height(project.manifest)==0
        ddSBAnimal.Items = {'(none)'}; ddSBAnimal.Value='(none)';
        return;
    end
    idx = find(project.manifest.Include);
    items = cell(numel(idx),1);
    keep = false(numel(idx),1);
    for k = 1:numel(idx)
        [matf, ~, resolvedPrefix] = meeg_spike_find_outputs(project, idx(k));
        if strlength(string(matf)) > 0
            items{k} = char(resolvedPrefix);
            keep(k) = true;
        end
    end
    items = items(keep);
    if isempty(items)
        ddSBAnimal.Items = {'(none)'}; ddSBAnimal.Value='(none)';
        lbSB.Items = {};
        txtSBInfo.Value = {'No saved spike tables found.'};
    else
        ddSBAnimal.Items = items;
        if ~ismember(string(ddSBAnimal.Value), string(items))
            ddSBAnimal.Value = items{1};
        end
        localUpdateSpikeViewerLeadDropdown();
        lbSB.Items = {};
        txtSBInfo.Value = {'Select an animal, then click Load project data or choose a spike event to view snippets.'};
        cla(axSB);
        title(axSB, 'Spike snippet viewer');
        xlabel(axSB, 'Time around event (sec)');
        ylabel(axSB, 'uV');
        grid(axSB,'on');
    end
end

function onSBRefreshEvents()

    if strcmp(ddSBAnimal.Value,'(none)')
        lbSB.Items = {};
        txtSBInfo.Value = {'No animal selected.'};
        return;
    end

    prefix = ddSBAnimal.Value;
    timePoint = ddSBTime.Value;
    d0 = edtDayStart.Value;
    d1 = edtDayEnd.Value;

    eventType = ddSBEventType.Value;
    if strcmp(eventType, 'Multilead events')
        winSec = 0.1;
        try, winSec = edtSpkML.Value; catch, end
        if isempty(winSec) || isnan(winSec), winSec = 0.1; end
        [events, meta] = meeg_spike_list_multilead_events(project, prefix, timePoint, d0, d1, winSec, edtSBMinLeads.Value);
        meta.leadLabel = sprintf('Multilead (>= %d leads)', round(edtSBMinLeads.Value));
    else
        [leadVec, leadLabel] = sbRegionToLeads(ddSBLead.Value);
        [events, meta] = meeg_spike_list_events(project, prefix, leadVec, timePoint, d0, d1);
        meta.leadLabel = leadLabel;
    end

    startDT = meeg_manifest_get_start_datetime(project, prefix);
    sbHost = localSBStateHost();
    if isempty(sbHost)
        logmsg("Spike Browser state error: the owning mEEG window is not available.");
        return;
    end
    % Store all viewer state on the Spike Browser's live owning window. This
    % avoids dependence on any temporary plot figure created elsewhere.
    setappdata(sbHost, 'SB_startDT', startDT);
    setappdata(sbHost, 'SB_events', events);
    setappdata(sbHost, 'SB_meta', meta);

    if isempty(events) || height(events)==0
        lbSB.Items = {};
        txtSBInfo.Value = {sprintf('No events found for %s', prefix)};
        return;
    end

    items = cell(height(events),1);
    for i = 1:height(events)
        if strcmp(eventType, 'Multilead events')
            status = ternary(~ismember('UserIncluded', events.Properties.VariableNames) || logical(events.UserIncluded(i)), 'included', 'rejected');
            items{i} = sprintf('#%d  sec=%.2f  hr=%.2f  n=%d  z=%.1f  [%s]', i, events.sec(i), events.hour(i), events.nLeads(i), events.zMax(i), status);
        else
            if isempty(startDT)
                status = ternary(~ismember('UserIncluded', events.Properties.VariableNames) || logical(events.UserIncluded(i)), 'included', 'rejected');
                items{i} = sprintf('#%d  sec=%.2f  hr=%.2f  lead=%d  z=%.1f  [%s]', i, events.sec(i), events.hour(i), events.leadIdx(i), events.z(i), status);
            else
                absT = startDT + seconds(events.sec(i));
                status = ternary(~ismember('UserIncluded', events.Properties.VariableNames) || logical(events.UserIncluded(i)), 'included', 'rejected');
                items{i} = sprintf('#%d  %s  z=%.1f  [%s]', i, datestr(absT, 'yyyy-mm-dd HH:MM:SS'), events.z(i), status);
            end
        end
    end
    lbSB.Items = items;
    lbSB.Value = items{1};

    if isempty(startDT)
        txtSBInfo.Value = {sprintf('Events: %d', height(events)), sprintf('fs=%.1f Hz', meta.fs), sprintf('%s', meta.leadLabel)};
    else
        txtSBInfo.Value = {sprintf('Events: %d', height(events)), sprintf('fs=%.1f Hz', meta.fs), sprintf('%s', meta.leadLabel), ...
                           ['Start: ' datestr(startDT, 'yyyy-mm-dd HH:MM:SS')]};
    end
    onSBPlotSelected();
end
function filesOut = local_resolve_existing_files(filesIn, prefix)
    filesOut = filesIn;
    if isempty(filesIn), return; end

    try
        filesOut = cellstr(string(filesIn(:))');
    catch
        return;
    end

    allExist = true;
    for ii = 1:numel(filesOut)
        if ~isfile(filesOut{ii})
            allExist = false;
            break;
        end
    end
    if allExist, return; end

    roots = strings(0,1);
    try
        if isfield(project,'outdir') && strlength(string(project.outdir)) > 0
            roots(end+1,1) = string(project.outdir);
            roots(end+1,1) = string(fileparts(char(project.outdir)));
            roots(end+1,1) = string(fileparts(fileparts(char(project.outdir))));
        end
    catch
    end
    try
        if ~isempty(projectPath) && isfile(projectPath)
            roots(end+1,1) = string(fileparts(projectPath));
            roots(end+1,1) = string(fileparts(fileparts(projectPath)));
        end
    catch
    end
    try
        roots(end+1,1) = string(pwd);
    catch
    end

    roots = roots(strlength(roots) > 0);
    if isempty(roots), return; end
    [~, ia] = unique(cellstr(roots), 'stable');
    roots = roots(sort(ia));

    for ii = 1:numel(filesOut)
        f = filesOut{ii};
        if isfile(f), continue; end
        [~, name, ext] = fileparts(f);
        target = [name ext];
        found = '';
        for rr = 1:numel(roots)
            root = char(roots(rr));
            if ~isfolder(root), continue; end
            try
                hits = dir(fullfile(root, '**', target));
            catch
                hits = [];
            end
            if isempty(hits), continue; end
            % Prefer a path containing the original parent-folder name if available.
            parentHint = '';
            try, parentHint = string(fileparts(f)); catch, end
            pick = 1;
            if strlength(parentHint) > 0
                for hh = 1:numel(hits)
                    cand = string(fullfile(hits(hh).folder, hits(hh).name));
                    if contains(lower(cand), lower(extractAfter(parentHint, max(strfind(char(parentHint), filesep)))) )
                        pick = hh; break;
                    end
                end
            end
            found = fullfile(hits(pick).folder, hits(pick).name);
            break;
        end
        if ~isempty(found)
            filesOut{ii} = found;
        end
    end

    missing = false;
    for ii = 1:numel(filesOut)
        if ~isfile(filesOut{ii})
            missing = true;
            break;
        end
    end
    if missing
        logmsg("Spike Browser warning: some raw files for " + string(prefix) + " could not be relocated.");
    end
end

function onSBPlotSelected()

    if isempty(lbSB.Items)
        return;
    end
    sbHost = localSBStateHost();
    if isempty(sbHost), return; end
    events = getappdata(sbHost, 'SB_events');
    meta = getappdata(sbHost, 'SB_meta');
    startDT = getappdata(sbHost, 'SB_startDT');
    if isempty(events) || height(events)==0, return; end

    val = lbSB.Value;
    sel = find(strcmp(lbSB.Items, val), 1);
    if isempty(sel), sel = 1; end

    idx = events.idx(sel);
    fs = meta.fs;

    winSec = edtSBWin.Value;
    nSamp = max(10, round(winSec*fs));
    half = floor(nSamp/2);
    startSample = max(1, double(idx) - half);

    prefix = char(ddSBAnimal.Value);
    [a,~] = meeg_project_get_animal(project, prefix);
        if isempty(a)
            uialert(fig, sprintf('No files found for %s', prefix), 'Spike Browser');
            return;
        end
        files = a.files;
        files = local_resolve_existing_files(files, prefix);
    if isfield(project,'profile')
        profile = project.profile;
    else
        if isfield(project,'profile')
        profile = project.profile;
    else
        profile = meeg_getSystemProfile(project.systemId);
    end;
    end

    eventType = ddSBEventType.Value;
    if strcmp(eventType, 'Multilead events')
        chVec = 1:meeg_profile_nch(profile);
    else
        [chVec, ~] = sbRegionToLeads(ddSBLead.Value);
    end

    try
        [tsec, Y] = meeg_spike_read_snippet(files, chVec, startSample, nSamp, fs, profile.scale_uV, chkSBNotch.Value);
    catch ME
        cla(axSB);
        grid(axSB,'on');
        xlabel(axSB, 'Time around event (sec)');
        ylabel(axSB, 'uV');
        title(axSB, sprintf('%s — snippet unavailable', prefix), 'Interpreter','none');
        text(axSB, 0.5, 0.55, 'Saved spike event metadata loaded, but raw snippet could not be opened.', ...
            'Units','normalized', 'HorizontalAlignment','center', 'Interpreter','none');
        text(axSB, 0.5, 0.42, char(string(ME.message)), ...
            'Units','normalized', 'HorizontalAlignment','center', 'Interpreter','none');
        if strcmp(eventType, 'Multilead events')
            infoLine = sprintf('Event #%d/%d  sec=%.2f  hr=%.2f  n=%d  z=%.1f', sel, height(events), events.sec(sel), events.hour(sel), events.nLeads(sel), events.zMax(sel));
        else
            infoLine = sprintf('Event #%d/%d  sec=%.2f  hr=%.2f  lead=%d  z=%.1f', sel, height(events), events.sec(sel), events.hour(sel), events.leadIdx(sel), events.z(sel));
        end
        txtSBInfo.Value = {infoLine, local_spike_status_line(events, sel), 'Raw snippet unavailable. Spike event tables are still loaded correctly.'};
        return;
    end

    cla(axSB);
    hold(axSB,'on');
    for k = 1:size(Y,1)
        plot(axSB, tsec - (double(idx)-startSample)/fs, Y(k,:), 'LineWidth', 1);
    end
    xline(axSB, 0, 'r--', 'LineWidth', 1.2);
    xlabel(axSB, 'Time around event (sec)');
    ylabel(axSB, 'uV');
    grid(axSB,'on');
    hold(axSB,'off');

    if strcmp(eventType, 'Multilead events')
        title(axSB, sprintf('%s — Multilead event #%d (n=%d)', prefix, sel, events.nLeads(sel)), 'Interpreter','none');
        infoLine = sprintf('sample=%d  sec=%.2f  hr=%.2f  n=%d  z=%.1f', idx, events.sec(sel), events.hour(sel), events.nLeads(sel), events.zMax(sel));
        if ~isempty(startDT)
            absT = startDT + seconds(events.sec(sel));
            infoLine = sprintf('%s  abs=%s', infoLine, datestr(absT, 'yyyy-mm-dd HH:MM:SS'));
        end
        if ismember('leads', events.Properties.VariableNames)
            txtSBInfo.Value = {sprintf('Event #%d/%d', sel, height(events)), infoLine, local_spike_status_line(events, sel), ['Leads: ' char(events.leads(sel))]};
        else
            txtSBInfo.Value = {sprintf('Event #%d/%d', sel, height(events)), infoLine, local_spike_status_line(events, sel)};
        end
    else
        title(axSB, sprintf('%s — %s event #%d', prefix, meta.leadLabel, sel), 'Interpreter','none');
        infoLine = sprintf('sample=%d  sec=%.2f  hr=%.2f  lead=%d  z=%.1f', idx, events.sec(sel), events.hour(sel), events.leadIdx(sel), events.z(sel));
        if ~isempty(startDT)
            absT = startDT + seconds(events.sec(sel));
            infoLine = sprintf('%s  abs=%s', infoLine, datestr(absT, 'yyyy-mm-dd HH:MM:SS'));
        end
        txtSBInfo.Value = {sprintf('Event #%d/%d', sel, height(events)), infoLine, local_spike_status_line(events, sel)};
    end
end

function onSBRejectCurrent()
    local_set_spike_current_inclusion(false, "user-rejected");
end

function onSBRestoreCurrent()
    local_set_spike_current_inclusion(true, "user-restored");
end

function local_set_spike_current_inclusion(tf, decision)
    try
        sbHost = localSBStateHost();
        if isempty(sbHost), return; end
        events = getappdata(sbHost, 'SB_events');
        if isempty(events) || height(events)==0 || isempty(lbSB.Items), return; end
        sel = find(strcmp(lbSB.Items, lbSB.Value), 1);
        if isempty(sel), sel = 1; end
        prefix = char(ddSBAnimal.Value);
        R = meeg_spike_load_review(project, prefix);
        eventType = ddSBEventType.Value;
        if strcmp(eventType, 'Multilead events')
            et = "multilead";
            leadIdx = NaN;
            leadIndices = "";
            if ismember('leads', events.Properties.VariableNames)
                leadIndices = string(events.leads(sel));
            end
        else
            et = "single";
            if ismember('leadIdx', events.Properties.VariableNames), leadIdx = double(events.leadIdx(sel)); else, leadIdx = NaN; end
            leadIndices = string(leadIdx);
        end
        keyIdx = double(events.idx(sel));
        if isempty(R) || height(R)==0
            R = table(string.empty(0,1), nan(0,1), nan(0,1), strings(0,1), true(0,1), strings(0,1), strings(0,1), ...
                'VariableNames', {'EventType','LeadIndex','Idx','LeadIndices','UserIncluded','UserDecision','ReviewTimestamp'});
        end
        if ~ismember('LeadIndices', R.Properties.VariableNames), R.LeadIndices = strings(height(R),1); end
        mask = lower(string(R.EventType)) == et & double(R.Idx) == keyIdx;
        if et == "single"
            mask = mask & double(R.LeadIndex) == double(leadIdx);
        end
        hit = find(mask, 1, 'last');
        if isempty(hit)
            if height(R)==0
                newRow = table(et, leadIdx, keyIdx, leadIndices, logical(tf), string(decision), string(datestr(now,'yyyy-mm-dd HH:MM:SS')), ...
                    'VariableNames', {'EventType','LeadIndex','Idx','LeadIndices','UserIncluded','UserDecision','ReviewTimestamp'});
                R = newRow;
            else
                newRow = R(1,:);
                newRow.EventType = et;
                newRow.LeadIndex = leadIdx;
                newRow.Idx = keyIdx;
                newRow.LeadIndices = leadIndices;
                newRow.UserIncluded = logical(tf);
                newRow.UserDecision = string(decision);
                newRow.ReviewTimestamp = string(datestr(now,'yyyy-mm-dd HH:MM:SS'));
                R = [R; newRow]; %#ok<AGROW>
            end
        else
            R.UserIncluded(hit) = logical(tf);
            R.UserDecision(hit) = string(decision);
            R.ReviewTimestamp(hit) = string(datestr(now,'yyyy-mm-dd HH:MM:SS'));
            if ismember('LeadIndices', R.Properties.VariableNames), R.LeadIndices(hit) = leadIndices; end
        end
        meeg_spike_save_review(project, prefix, R);
        % Immediate in-memory/UI update so included/rejected status changes right away.
        if ~ismember('UserIncluded', events.Properties.VariableNames), events.UserIncluded = true(height(events),1); end
        if ~ismember('UserDecision', events.Properties.VariableNames), events.UserDecision = repmat("auto-kept", height(events), 1); end
        events.UserIncluded(sel) = logical(tf);
        events.UserDecision(sel) = string(decision);
        setappdata(sbHost, 'SB_events', events);
        logmsg("Spike review updated: " + string(prefix) + " event sample " + string(keyIdx) + " -> " + string(decision));
        % Refresh list labels and current event status immediately.
        items = lbSB.Items;
        if ~isempty(items) && numel(items) >= sel
            it = char(items{sel});
            if logical(tf)
                newStatus = 'included';
            else
                newStatus = 'rejected';
            end
            it = regexprep(it, '\[(included|rejected)\]$', ['[' newStatus ']']);
            items{sel} = it;
            lbSB.Items = items;
            lbSB.Value = items{sel};
        end
        try, onSBPlotSelected(); catch, end
        % Do not rebuild the full spike list here; keep the user's current place in the viewer.
    catch ME
        logmsg("Spike review update error: " + string(ME.message));
        try, uialert(fig, char(string(ME.message)), 'Spike review update error'); catch, end
    end
end

function s = local_spike_status_line(events, sel)
    s = 'Included in analyses: yes';
    try
        if ismember('UserIncluded', events.Properties.VariableNames)
            s = sprintf('Included in analyses: %s', ternary(logical(events.UserIncluded(sel)), 'yes', 'no'));
        end
    catch
    end
end

function onSBPrev()
    if isempty(lbSB.Items), return; end
    cur = find(strcmp(lbSB.Items, lbSB.Value),1);
    if isempty(cur), cur = 1; end
    cur = max(1, cur-1);
    lbSB.Value = lbSB.Items{cur};
    onSBPlotSelected();
end

function onSBNext()
    if isempty(lbSB.Items), return; end
    cur = find(strcmp(lbSB.Items, lbSB.Value),1);
    if isempty(cur), cur = 1; end
    cur = min(numel(lbSB.Items), cur+1);
    lbSB.Value = lbSB.Items{cur};
    onSBPlotSelected();
end

function showHelp(topicKey, titleStr)
    % Scrollable HTML help popup loaded from assets/help/<topicKey>.html
        try
            here = fileparts(mfilename('fullpath'));
            helpFile = fullfile(here, 'assets', 'help', [char(topicKey) '.html']);

            if ~isfile(helpFile)
                uialert(fig, sprintf('Missing help file:\n%s', helpFile), 'Help not found');
                return;
            end

            htmlStr = fileread(helpFile);

            hf = uifigure('Name', char(titleStr), 'Color', 'white', 'Position', [420 180 720 620]);
            
            gl = uigridlayout(hf, [1 1]);
            gl.RowHeight = {'1x'};
            gl.Padding = [10 10 10 10];
            gl.BackgroundColor = [1 1 1];


            %uilabel(gl, 'Text', char(titleStr), 'FontSize', 15, 'FontWeight', 'bold');

            h = uihtml(gl);
            h.HTMLSource = htmlStr;  % scrolls automatically

        % Optional: ESC closes the help window
            hf.KeyPressFcn = @(~,e) (strcmp(e.Key,'escape') && close(hf));

        catch ME
            uialert(fig, ME.message, 'Help error');
        end
    end

    function showInfo(titleStr, bodyStr)
        % Small helper for info popups with a blue question mark icon.
        try
            infoFig = uifigure('Name', char(titleStr), 'Position', [420 280 520 220], 'WindowStyle', 'modal');
            gl = uigridlayout(infoFig, [2 2]);
            gl.RowHeight = {'1x', 40};
            gl.ColumnWidth = {70, '1x'};
            gl.Padding = [14 14 14 14];
            gl.RowSpacing = 10;
            gl.ColumnSpacing = 12;

            qlbl = uilabel(gl, 'Text', '?', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'center', ...
                'FontSize', 28, 'FontWeight', 'bold', 'FontColor', [0 0.447 0.741]);
            qlbl.Layout.Row = 1; qlbl.Layout.Column = 1;

            body = uitextarea(gl, 'Editable', 'off', 'Value', {char(bodyStr)}, ...
                'FontSize', 12, 'BackgroundColor', [1 1 1]);
            body.Layout.Row = 1; body.Layout.Column = 2;

            ok = uibutton(gl, 'Text', 'OK', 'ButtonPushedFcn', @(~,~) delete(infoFig));
            ok.Layout.Row = 2; ok.Layout.Column = [1 2];
        catch
            uialert(fig, char(bodyStr), char(titleStr));
        end
    end

    function txt = local_ratio_source_label(sourceKind)
        switch lower(char(string(sourceKind)))
            case 'band'
                txt = 'Normalized band power';
            case 'power'
                txt = 'Power Spectra (AUC)';
            otherwise
                txt = char(string(sourceKind));
        end
    end


    function items = local_band_items()
        items = {'delta (0.4-4 Hz)','theta (4-8 Hz)','alpha (8-13 Hz)','beta (13-30 Hz)','gamma (30-50 Hz)','fastGamma (50-100 Hz)'};
    end

    function vals = local_band_values()
        vals = {'delta','theta','alpha','beta','gamma','fastGamma'};
    end

    function items = local_corr_band_items()
        items = [local_band_items(), {'amplitude (all frequency bands)'}];
    end

    function vals = local_corr_band_values()
        vals = [local_band_values(), {'amp'}];
    end

    function txt = local_band_label(bandName)
        vals = string(local_band_values());
        items = string(local_band_items());
        idx = find(strcmpi(string(bandName), vals), 1);
        if ~isempty(idx)
            txt = char(items(idx));
        elseif strcmpi(string(bandName), 'amp')
            txt = 'amplitude (all frequency bands)';
        else
            txt = char(string(bandName));
        end
    end

    function txt = local_time_label(timeName)
        switch lower(char(string(timeName)))
            case 'average'
                txt = 'combined (day and night)';
            case 'all'
                txt = 'combined (day and night)';
            otherwise
                txt = char(string(timeName));
        end
    end

    % ---------------- callbacks ----------------
    function onBrowseOut(~,~)
        p = uigetdir(project.outdir, 'Select project output folder');
        if isequal(p,0), return; end
        project.outdir = p;
        edtOut.Value = p;
        edtOutR.Value = p;
        try, edtOutPS.Value = p; catch, end
        logmsg(sprintf('Output folder set to: %s', p));
        refreshResultsMetadataDropdowns();
    end

    function onAddAnimal(~,~)
        isEDF = isfield(project,'profile') && isfield(project.profile,'systemId') && strcmpi(string(project.profile.systemId), 'standard-edf');
        animalInfo = struct();

        if isEDF
            [file, folder] = uigetfile({'*.edf;*.EDF','EDF files (*.edf, *.EDF)'}, ...
                'Select EDF file for this animal', 'MultiSelect', 'off');
            if isequal(file,0), return; end
            edfPath = fullfile(folder, file);
            assignCfg = meeg_edf_assign_dialog(edfPath);
            if isempty(assignCfg), return; end
            fullpaths = {};
            animalInfo.assignCfg = assignCfg;
        else
            [files, folder] = uigetfile({'*.dat','DAT files (*.dat)'}, ...
                'Select EXACTLY 10 .dat files (10-electrode system)', 'MultiSelect', 'on');
            if isequal(files,0), return; end
            if ischar(files), files = {files}; end
            if numel(files) ~= 10
                uialert(fig, sprintf('You selected %d files. Please select exactly 10.', numel(files)), 'Selection error');
                return;
            end
            files = sort(files);
            fullpaths = fullfile(folder, files);
            animalInfo.fileOrder = project.profile.channelLabels(:);

            if enableIntanSettingsXmlImport
                try
                    pickXml = questdlg('Would you like to select an Intan settings XML for this animal?', ...
                        'Intan channel labels', 'Yes','No','Yes');
                catch
                    pickXml = 'No';
                end
                if strcmpi(string(pickXml), 'Yes')
                [xmlFile, xmlFolder] = uigetfile({'*.xml','XML files (*.xml)'}, ...
                    'Select Intan settings XML for this animal', folder, 'MultiSelect', 'off');
                if ~isequal(xmlFile,0)
                    xmlPath = fullfile(xmlFolder, xmlFile);
                    try
                        xmlInfo = meeg_intan_read_settings_xml(xmlPath, fullpaths);
                        animalInfo.fileOrder = cellstr(string(meeg_sanitize_lead_label(xmlInfo.fileOrder(:))));
                        animalInfo.sourceSignalLabels = xmlInfo.sourceSignalLabels(:);
                        animalInfo.nativeChannelNames = xmlInfo.nativeChannelNames(:);
                        animalInfo.sourceFile = xmlInfo.settingsXmlPath;

                        desiredLabels = string(animalInfo.fileOrder(:));
                        if isempty(project.animals)
                            project.profile.channelLabels = cellstr(desiredLabels');
                            project.profile.nChannels = numel(desiredLabels);
                            profile = project.profile;
                            refreshChannelDependentUI();
                        else
                            haveLabels = string(project.profile.channelLabels(:));
                            wantLabels = desiredLabels(:);
                            haveNorm = localNormalizeIntanXmlLabels(haveLabels);
                            wantNorm = localNormalizeIntanXmlLabels(wantLabels);
                            if numel(haveNorm) ~= numel(wantNorm) || any(haveNorm ~= wantNorm)
                                uialert(fig, sprintf(['This XML-derived channel layout does not match the current project.\n\n' ...
                                    'Current project labels:\n%s\n\nNew animal labels:\n%s\n\n' ...
                                    'Please keep one consistent Intan mapping per project.'], ...
                                    strjoin(cellstr(haveLabels'), ', '), strjoin(cellstr(wantLabels'), ', ')), 'Channel layout mismatch');
                                return;
                            else
                                if any(haveLabels ~= wantNorm)
                                    project.profile.channelLabels = cellstr(wantNorm');
                                    profile = project.profile;
                                    refreshChannelDependentUI();
                                end
                            end
                        end
                        logmsg(sprintf('Loaded Intan XML labels for this animal from: %s', xmlPath));
                    catch ME
                        uialert(fig, sprintf('Could not read Intan settings XML:\n%s', ME.message), 'XML import error');
                        return;
                    end
                end
                end
            end
        end

        prompts = {'Animal ID', 'Study group', 'Genotype', 'Sex', 'DOB (YYYY-MM-DD)', 'Recording date (YYYY-MM-DD)', 'Start time (hour, e.g., 6.5)', 'Litter ID', 'Notes'};
        defaults = {'','', '', '', '', '', '', '', ''};
        if isEDF
            try
                dtStart = meeg_edf_get_start_datetime(animalInfo.assignCfg.edfPath);
                if ~isempty(dtStart) && ~isnat(dtStart)
                    defaults{6} = char(string(datestr(dtStart, 'yyyy-mm-dd')));
                    defaults{7} = local_decimal_hour_string(dtStart);
                end
            catch
            end
        end
        answ = inputdlg(prompts, 'Add animal', [1 60], defaults);
        if isempty(answ), return; end

        row = meeg_animalrow_from_input(answ);
        row.Include = true;

        if isEDF
            try
                imported = meeg_edf_import_to_cache(project, row, animalInfo.assignCfg);
            catch ME
                uialert(fig, sprintf('EDF import failed:\n%s', ME.message), 'EDF import error');
                return;
            end

            desiredLabels = imported.fileOrder(:);
            if isempty(project.profile.channelLabels)
                project.profile.channelLabels = desiredLabels;
                project.profile.nChannels = numel(desiredLabels);
                project.profile.defaultFs = imported.fs;
                profile = project.profile;
                refreshChannelDependentUI();
            else
                haveLabels = string(project.profile.channelLabels(:));
                wantLabels = string(desiredLabels(:));
                if numel(haveLabels) ~= numel(wantLabels) || any(haveLabels ~= wantLabels)
                    uialert(fig, sprintf(['This EDF uses a different channel layout than the current project.\n\n' ...
                        'Current project labels:\n%s\n\nNew EDF labels:\n%s\n\n' ...
                        'Please keep one consistent mapping per project.'], ...
                        strjoin(cellstr(haveLabels'), ', '), strjoin(cellstr(wantLabels'), ', ')), 'EDF layout mismatch');
                    return;
                end
                if isfield(project.profile,'defaultFs') && ~isempty(project.profile.defaultFs) && abs(double(project.profile.defaultFs) - double(imported.fs)) > 1e-6
                    uialert(fig, sprintf('This EDF has sampling rate %.6g Hz, but the project is set to %.6g Hz.', imported.fs, project.profile.defaultFs), 'Sampling rate mismatch');
                    return;
                end
            end
            fullpaths = imported.files;
            animalInfo = imported;
        end

        project = meeg_manifest_add(project, row, fullpaths, animalInfo);

        tbl.Data = project.manifest(:, {'Include','MouseID','TreatmentGroup','Genotype','Sex','DOB','RecordingDate','StartTime','LitterID','Notes'});
        logmsg(sprintf('Added animal: %s (%s)', row.MouseID, row.TreatmentGroup));
        refreshResultsMetadataDropdowns();
    end

    function refreshChannelDependentUI()
        try
            labels = cellstr(string(project.profile.channelLabels(:))');
            if isempty(labels), return; end
            profile = project.profile;
            ddCohReg1.Items = labels;
            ddCohReg2.Items = labels;
            ddCohReg1.Value = labels{1};
            ddCohReg2.Value = labels{min(2, numel(labels))};
            set(axCorr, 'XTick', 1:numel(labels), 'YTick', 1:numel(labels));
            set(axCoh, 'XTick', 1:numel(labels), 'YTick', 1:numel(labels));
        catch
        end
    end


    function s = local_decimal_hour_string(dt)
        h = hour(dt) + minute(dt)/60 + second(dt)/3600;
        s = sprintf('%.4f', h);
        s = regexprep(s, '0+$', '');
        s = regexprep(s, '\.$', '');
    end

    function out = localNormalizeIntanXmlLabels(labelsIn)
        vals = string(labelsIn(:));
        out = string(meeg_sanitize_lead_label(vals));
        for jj = 1:numel(vals)
            s = lower(regexprep(vals(jj), '[^a-z0-9]', ''));
            if contains(s,'004')
                out(jj) = "hippocampus_R";
            elseif contains(s,'011')
                out(jj) = "hippocampus_L";
            elseif contains(s,'006')
                out(jj) = "barrel_R";
            elseif contains(s,'009')
                out(jj) = "barrel_L";
            elseif contains(s,'007')
                out(jj) = "motor_R";
            elseif contains(s,'008')
                out(jj) = "motor_L";
            elseif contains(s,'021')
                out(jj) = "visual_R";
            elseif contains(s,'026')
                out(jj) = "visual_L";
            elseif contains(s,'022')
                out(jj) = "auditory_R";
            elseif contains(s,'025')
                out(jj) = "auditory_L";
            end
        end
    end


    function onManifestTableSelect(~, evt)
        try
            if isempty(evt.Indices)
                selectedManifestRows = [];
            else
                selectedManifestRows = unique(evt.Indices(:,1));
            end
        catch
            selectedManifestRows = [];
        end
    end

    function onRemoveAnimal(~,~)
        syncProjectFromTable();
        if isempty(project.animals), return; end
        r = selectedManifestRows;
        if isempty(r)
            try
                r = unique(tbl.Selection(:,1));
            catch
                r = [];
            end
        end
        if isempty(r)
            uialert(fig, 'Select one or more animal rows in the Project table, then click Remove.', 'No animals selected');
            return;
        end
        r = unique(r(:))';
        project = meeg_manifest_remove(project, r);
        selectedManifestRows = [];
        tbl.Data = project.manifest(:, {'Include','MouseID','TreatmentGroup','Genotype','Sex','DOB','RecordingDate','StartTime','LitterID','Notes'});
        logmsg(sprintf('Removed %d animal(s).', numel(r)));
        refreshResultsMetadataDropdowns();
    end

    function onSaveManifest(~,~)
        syncProjectFromTable();
        project.outdir = edtOut.Value;
        project = localSanitizeProjectLabels(project);
        profile = project.profile;
        edtOutR.Value = project.outdir;
        try, edtOutPS.Value = project.outdir; catch, end
        meeg_manifest_save(project);
        logmsg(sprintf('Saved manifest to %s', project.outdir));
        % Refresh preprocessing preview list so users can browse existing QC without rerunning
        onRefreshPreprocPreview();
        refreshResultsMetadataDropdowns();
    end

    function onLoadManifest(~,~)
        [f,p] = uigetfile({'*.mat','MAT-files (*.mat)'}, 'Select a saved project.mat');
        if isequal(f,0), return; end
        s = load(fullfile(p,f), 'project');
        project = localSanitizeProjectLabels(s.project);
        if isfield(project,'profile') && ~isempty(project.profile)
            profile = project.profile;
            refreshChannelDependentUI();
        end
        edtOut.Value = project.outdir;
        edtOutR.Value = project.outdir;
        try, edtOutPS.Value = project.outdir; catch, end
        tbl.Data = project.manifest(:, {'Include','MouseID','TreatmentGroup','Genotype','Sex','DOB','RecordingDate','StartTime','LitterID','Notes'});
        logmsg(sprintf('Loaded manifest with %d animals.', height(project.manifest)));
        % Refresh preprocessing preview list so users can browse existing QC without rerunning
        onRefreshPreprocPreview();
        refreshResultsMetadataDropdowns();
    end

    function onRefreshPreprocPreview()
        % Refresh Preview animal dropdown by scanning preprocessing outputs.
        % This enables browsing QC plots without rerunning preprocessing.
        try
            refreshPreprocPreviewItems();
            onPreprocPreviewChanged();
        catch ME
            logmsg(sprintf('Preprocessing preview refresh error: %s', ME.message));
        end
    end

    function refreshPreprocPreviewItems()
        % Build list of animals that have preprocessing outputs.
        % IMPORTANT: Use disk-discovered folder paths as dropdown Values
        % (ItemsData) to avoid MouseID<->folder mismatches and
        % string-vs-char issues on Windows.
        if isempty(project) || ~isfield(project,'outdir') || isempty(project.outdir)
            ddPreprocPreview.Items = {'(no project)'};
            ddPreprocPreview.ItemsData = {'(no project)'};
            ddPreprocPreview.Value = '(no project)';
            return;
        end

        preRoot = getExistingPreprocRoot();
        if isempty(preRoot) || ~isfolder(preRoot)
            ddPreprocPreview.Items = {'(none found)'};
            ddPreprocPreview.ItemsData = {'(none found)'};
            ddPreprocPreview.Value = '(none found)';
            return;
        end

        d = dir(preRoot);
        d = d([d.isdir]);
        d = d(~ismember({d.name},{'.','..'}));

        labels = {};
        folders = {};
        for k = 1:numel(d)
            candFolder = fullfile(preRoot, d(k).name);
            hasAny = isfile(fullfile(candFolder,'qc_summary.csv')) || ...
                     ~isempty(dir(fullfile(candFolder,'qc_lowQEpochPercent_*.png'))) || ...
                     ~isempty(dir(fullfile(candFolder,'qc_badEpochHeatmap_*.png'))) || ...
                     ~isempty(dir(fullfile(candFolder,'qc_goodQChannelPct_*.png')));
            if hasAny
                labels{end+1,1} = d(k).name; %#ok<AGROW>
                folders{end+1,1} = candFolder; %#ok<AGROW>
            end
        end

        if isempty(labels)
            ddPreprocPreview.Items = {'(none found)'};
            ddPreprocPreview.ItemsData = {'(none found)'};
            ddPreprocPreview.Value = '(none found)';
            return;
        end

        [labels, ord] = sort(labels);
        folders = folders(ord);

        curVal = '';
        try, curVal = char(ddPreprocPreview.Value); catch, end

        ddPreprocPreview.Items = labels;
        ddPreprocPreview.ItemsData = folders;
        if ~isempty(curVal) && any(strcmp(folders, curVal))
            ddPreprocPreview.Value = curVal;
        else
            ddPreprocPreview.Value = folders{1};
        end
    end

    function preRoot = getExistingPreprocRoot()
        outdir = char(project.outdir);
        candidates = {};
        try
            candidates{end+1} = fullfile(outdir, char(project.outNames.preprocessing));
        catch
        end
        candidates{end+1} = fullfile(outdir, 'preprocessing');
        candidates{end+1} = fullfile(outdir, 'preproc');
        preRoot = '';
        for iC = 1:numel(candidates)
            if isfolder(candidates{iC})
                preRoot = candidates{iC};
                return;
            end
        end
    end

    function onRunPreproc(~,~)
        syncProjectFromTable();
        if isempty(project.animals)
            uialert(fig, 'Manifest is empty. Add animals first.', 'No animals'); return;
        end
        project.outdir = edtOut.Value;
        edtOutR.Value = project.outdir;
        try, edtOutPS.Value = project.outdir; catch, end
        if isempty(project.outdir) || ~isfolder(project.outdir)
            uialert(fig, 'Choose a valid output folder first.', 'Missing output folder'); return;
        end

        params.fs = edtFsP.Value;
        params.rmsBinSec = edtRmsBin.Value;
        params.epochSec = edtEpoch.Value;
        params.zThresh = edtZ.Value;
        params.rmsLow = edtRmsLow.Value;
        params.rmsHigh = edtRmsHigh.Value;
        params.skwHigh = edtSkw.Value;
        params.notch.enabled = chkNotch.Value;
        params.notch.f1 = edtF1.Value;
        params.notch.f2 = edtF2.Value;
        if params.notch.enabled
            nyquistHz = params.fs / 2;
            if ~all(isfinite([params.notch.f1 params.notch.f2])) || ...
                    params.notch.f1 <= 0 || params.notch.f2 <= params.notch.f1 || ...
                    params.notch.f2 >= nyquistHz
                uialert(fig, sprintf(['Enter a valid notch band with 0 < lower < upper < Nyquist.\n' ...
                    'For the current sampling rate, the upper value must be below %.3g Hz.'], nyquistHz), ...
                    'Invalid notch band');
                return;
            end
        end
        params.saveCleanBlocks = strcmp(ddOut.Value, 'Also save cleaned 30-min blocks (large!)');

        preprocLogFile = localStartRunLog(meeg_outdir(project,'preprocessing'), 'Preprocessing_log', params);
        localSetActiveRunLog(preprocLogFile);
        logmsg(['Pre-processing log file: ' char(preprocLogFile)]);

        stopFile = [tempname '.flag'];
        params.stopFile = stopFile;
        stopRequested = false;
        stopConfirmed = false;
        stopDlg = [];

        d = uiprogressdlg(fig, 'Title','Pre-processing', 'Message','Starting...', 'Indeterminate','off');
        d.Value = 0;
        try
            stopDlg = uifigure('Name','Stop pre-processing?', 'WindowStyle','alwaysontop', ...
                'Position',[max(100, fig.Position(1)+80), max(100, fig.Position(2)+80), 360, 110], ...
                'Resize','off');
            glStop = uigridlayout(stopDlg,[2 1]);
            glStop.RowHeight = {45, 45};
            glStop.ColumnWidth = {'1x'};
            glStop.Padding = [10 10 10 10];
            uilabel(glStop, 'Text','Need to interrupt pre-processing?', ...
                'HorizontalAlignment','center', 'FontWeight','bold');
            uibutton(glStop, 'Text','Stop pre-processing', 'ButtonPushedFcn', @(~,~) requestStopPreproc());
        catch
            stopDlg = [];
        end

        % NOTE: MATLAB does not allow nested function definitions inside
        % control-flow blocks (e.g., try/catch). We therefore create a
        % function handle that dispatches to a nested helper defined at the
        % end of this callback.
        doneAnimals = 0;
        handleEvent = @(ev) preprocHandleEvent(ev);

        try
            idxs = find(project.manifest.Include);
            n = numel(idxs);
            if n == 0
                close(d);
                try, if ~isempty(stopDlg) && isvalid(stopDlg), close(stopDlg); end, catch, end
                uialert(fig, 'No animals selected (Include=false).', 'Nothing to do');
                return;
            end

            qcSummaryCell = cell(n,1);
            qcHeatCell = cell(n,1);

            usePar = false;
            try
                usePar = logical(chkPreParallel.Value) && license('test','Distrib_Computing_Toolbox');
            catch
                usePar = false;
            end

            if usePar
                % Ensure a pool exists
                try
                    ppool = gcp('nocreate');
                    if isempty(ppool), parpool; end
                catch
                    % fall back to serial if parpool fails
                    usePar = false;
                end
            end

            if usePar
                dq = parallel.pool.DataQueue;
                afterEach(dq, @(ev) handleEvent(ev));

                parfor ii = 1:n
                    i = idxs(ii);
                    progressFcn = @(ev) send(dq, ev);
                    [qcS, qcH] = meeg_preprocess_10e(project, i, params, progressFcn);
                    qcSummaryCell{ii} = qcS;
                    qcHeatCell{ii} = qcH;
                end
            else
                for ii = 1:n
                    i = idxs(ii);
                    progressFcn = @(ev) handleEvent(ev);
                    [qcS, qcH] = meeg_preprocess_10e(project, i, params, progressFcn);
                    qcSummaryCell{ii} = qcS;
                    qcHeatCell{ii} = qcH;
                    if stopConfirmed || isfile(stopFile)
                        break;
                    end
                end
            end

            % Update preview controls
            try
                refreshPreprocPreviewItems();

                % Prefer the last processed animal's preprocessing folder if it exists.
                preRoot2 = getExistingPreprocRoot();
                if ~isempty(preRoot2) && isfolder(preRoot2)
                    lastPrefix = '';
                    try
                        lastPrefix = char(project.animals(idxs(last)).prefix);
                    catch
                    end
                    if ~isempty(lastPrefix)
                        candFolder = fullfile(preRoot2, lastPrefix);
                        if any(strcmp(ddPreprocPreview.ItemsData, candFolder))
                            ddPreprocPreview.Value = candFolder;
                        end
                    end
                end
            catch
                ddPreprocPreview.Items = {'(last run)'};
                ddPreprocPreview.ItemsData = {'(last run)'};
                ddPreprocPreview.Value = '(last run)';
            end
            onPreprocPreviewChanged();

            if stopConfirmed || isfile(stopFile)
                try, if isvalid(d), close(d); end, catch, end
                try, if ~isempty(stopDlg) && isvalid(stopDlg), close(stopDlg); end, catch, end
                try, if isfile(stopFile), delete(stopFile); end, catch, end
                logmsg('Pre-processing stopped by user.');
                localSetActiveRunLog('');
                uialert(fig, 'Pre-processing was stopped. Unfinished outputs were discarded.', 'Pre-processing stopped');
            else
                d.Value = 1;
                d.Message = 'Done.';
                pause(0.2);
                try, close(d); catch, end
                try, if ~isempty(stopDlg) && isvalid(stopDlg), close(stopDlg); end, catch, end
                try, if isfile(stopFile), delete(stopFile); end, catch, end
                logmsg('Pre-processing finished.');
                localSetActiveRunLog('');
            end
        catch ME
            try, if isfile(stopFile), delete(stopFile); end, catch, end
            try, close(d); catch, end
            try, if ~isempty(stopDlg) && isvalid(stopDlg), close(stopDlg); end, catch, end
            try, logmsg(['Pre-processing error: ' ME.message]); catch, end
            localSetActiveRunLog('');
            uialert(fig, ME.message, 'Pre-processing error'); rethrow(ME);
        end

        function requestStopPreproc()
            if stopConfirmed || stopRequested
                return;
            end
            stopRequested = true;
            choice = 'Cancel';
            try
                choice = uiconfirm(fig, ['Stop pre-processing now? Unfinished pre-processing data for animals still in progress ' ...
                    'will be discarded.'], 'Stop pre-processing', ...
                    'Options', {'Stop','Cancel'}, 'DefaultOption', 2, 'CancelOption', 2, 'Icon', 'warning');
            catch
                choice = 'Stop';
            end
            if strcmp(choice, 'Stop')
                stopConfirmed = true;
                try
                    fidStop = fopen(stopFile, 'w');
                    if fidStop ~= -1
                        fprintf(fidStop, 'stop requested %s\n', datestr(now));
                        fclose(fidStop);
                    end
                catch
                end
                if isvalid(d)
                    d.Message = 'Stopping after current work unit...';
                end
                logmsg('Stop requested for pre-processing.');
                try
                    if ~isempty(stopDlg) && isvalid(stopDlg)
                        stopDlg.Name = 'Stopping pre-processing...';
                    end
                catch
                end
            else
                stopRequested = false;
            end
        end

        % ---- nested helper (MUST be outside try/catch) ----
        function preprocHandleEvent(ev)
            if ~isstruct(ev) || ~isfield(ev,'type'), return; end
            if stopConfirmed && ~isfile(stopFile)
                try
                    fidStop = fopen(stopFile, 'w');
                    if fidStop ~= -1
                        fprintf(fidStop, 'stop requested %s\n', datestr(now));
                        fclose(fidStop);
                    end
                catch
                end
            end
            switch string(ev.type)
                case "coverage"
                    logmsg(sprintf('Coverage check: file length ~%.2f h, processing %.2f h (%d periods) [%s]', ...
                        ev.fileHours, ev.procHours, ev.recPeriods, ev.prefix));
                case "period"
                    logmsg(sprintf('Processing period %d/%d... [%s]', ev.period, ev.nPeriods, ev.prefix));
                    if isvalid(d)
                        if stopConfirmed
                            d.Message = sprintf('Stopping after current work unit... [%s %d/%d]', ev.prefix, ev.period, ev.nPeriods);
                        else
                            d.Message = sprintf('%s: period %d/%d', ev.prefix, ev.period, ev.nPeriods);
                        end
                    end
                    drawnow;
                case "done"
                    doneAnimals = doneAnimals + 1;
                    if isvalid(d)
                        d.Value = min(1, doneAnimals / max(1,n));
                        if stopConfirmed
                            d.Message = sprintf('Stopping... finished %d/%d: %s', doneAnimals, n, ev.prefix);
                        else
                            d.Message = sprintf('Finished %d/%d: %s', doneAnimals, n, ev.prefix);
                        end
                    end
                    logmsg(sprintf('Finished pre-processing: %s', ev.prefix));
                    drawnow;
            end
        end
    end


function onPreprocPreviewChanged()
    % Update the two preprocessing preview axes for the selected animal.
    % NOTE: When loading an existing project, project.animals may be empty
    % (older saved project.mat files). The preprocessing preview only needs
    % the manifest + profile + output folder, so do NOT depend on
    % project.animals here.
    if isempty(project) || ~isfield(project,'manifest') || isempty(project.manifest)
        return;
    end
    if ~isfield(project,'profile') || isempty(project.profile)
        return;
    end
	% The dropdown Value is the on-disk folder path (ItemsData).
	try
	    outBase = char(ddPreprocPreview.Value);
	catch
	    return;
	end
	if isempty(outBase) || ~isfolder(outBase)
	    return;
	end

	% Use the label (folder name) for titles.
	prefix = '(unknown)';
	try
	    idx = find(strcmp(ddPreprocPreview.ItemsData, ddPreprocPreview.Value), 1, 'first');
	    if ~isempty(idx)
	        prefix = ddPreprocPreview.Items{idx};
	    end
	catch
	end

	% Load the PNGs produced during preprocessing.
	tmp = dir(fullfile(outBase, 'qc_lowQEpochPercent_*.png')); if isempty(tmp), topPng=''; else, topPng=char(fullfile(outBase,tmp(1).name)); end
	tmp = dir(fullfile(outBase, 'qc_goodQChannelPct_*.png')); if isempty(tmp), goodPng=''; else, goodPng=char(fullfile(outBase,tmp(1).name)); end
	tmp = dir(fullfile(outBase, 'qc_badEpochHeatmap_*.png')); if isempty(tmp), heatPng=''; else, heatPng=char(fullfile(outBase,tmp(1).name)); end

	showPngOnAxes(axP1, goodPng, sprintf('Percentage of EEG recording that passed quality control\n(%% of 30 minute epochs that meet quality standards)\n%s', prefix));

	    % Lower plot: either % low quality epochs or low quality heatmap
	    showBadPct = true;
	    try
	        showBadPct = logical(tglGood.Value);
	    catch
	        showBadPct = true;
	    end
	if showBadPct
	    showPngOnAxes(axP2, topPng, sprintf('Percentage of 5 second epochs that do not pass quality control\n(%% of the high-quality channels that did not meet quality control standards)\n%s', prefix));
	else
	    showPngOnAxes(axP2, heatPng, sprintf('Poor quality 5 second epochs\n(visualization of poor-quality epochs for the entire EEG recording)\n%s', prefix));
	end

	    drawnow;
end

function showPngOnAxes(ax, pngPath, ttl)
    cla(ax);
    try
        pngPath = char(pngPath);
        if ~(isfile(pngPath) || exist(pngPath,'file')==2)
            % Fallback: sometimes filenames differ slightly; try wildcard in same folder
            [pdir, fname, ext] = fileparts(pngPath);
            if isfolder(pdir)
                cand = dir(fullfile(pdir, [fname(1:min(end,12)) '*', ext]));
                if ~isempty(cand)
                    pngPath = fullfile(pdir, cand(1).name);
                end
            end
        end

        if isfile(pngPath) || exist(pngPath,'file')==2
            I = imread(pngPath);
            image(ax, 'CData', I);
            ax.XLim = [0.5, size(I,2)+0.5];
            ax.YLim = [0.5, size(I,1)+0.5];
            ax.YDir = 'reverse';
            ax.DataAspectRatio = [1 1 1];
            ax.XTick = [];
            ax.YTick = [];
            ax.Box = 'on';
            title(ax, ttl, 'Interpreter','none');
        else
            ax.XTick = [];
            ax.YTick = [];
            ax.Box = 'on';
            title(ax, sprintf('%s (image not found)', ttl), 'Interpreter','none');
        end
    catch
        ax.XTick = [];
        ax.YTick = [];
        ax.Box = 'on';
        title(ax, ttl, 'Interpreter','none');
    end
end



function onExcludeCurrentPreprocAnimal()
    try
        syncProjectFromTable();
        idx = find(strcmp(ddPreprocPreview.ItemsData, ddPreprocPreview.Value), 1, 'first');
        if isempty(idx)
            uialert(fig, 'Select an animal in the preprocessing preview first.', 'No animal selected');
            return;
        end
        prefix = string(ddPreprocPreview.Items{idx});
        rowIdx = [];
        try
            if isfield(project, 'animals') && ~isempty(project.animals)
                pfx = string({project.animals.prefix});
                rowIdx = find(pfx == prefix, 1, 'first');
            end
        catch
        end
        if isempty(rowIdx)
            try
                mouseIds = string(project.manifest.MouseID);
                groups = string(project.manifest.TreatmentGroup);
                combo = groups + "_" + mouseIds;
                rowIdx = find(combo == prefix, 1, 'first');
            catch
            end
        end
        if isempty(rowIdx) || rowIdx < 1 || rowIdx > height(project.manifest)
            uialert(fig, sprintf('Could not map preview animal to manifest row:\n%s', char(prefix)), 'Animal not found');
            return;
        end
        project.manifest.Include(rowIdx) = false;
        tbl.Data.Include(rowIdx) = false;
        meeg_manifest_save(project);
        logmsg(sprintf('Excluded %s from subsequent analyses and saved project.', char(prefix)));
        refreshResultsMetadataDropdowns();
    catch ME
        uialert(fig, ME.message, 'Could not exclude animal');
    end
end

function onPreprocLowerToggle(src, ~)
    % Keep % Bad Epoch and BadEpoch heatmap mutually exclusive.
    try
        if src == tglGood
            if tglGood.Value
                tglHeat.Value = false;
            else
                % never allow both off
                tglGood.Value = true;
            end
        elseif src == tglHeat
            if tglHeat.Value
                tglGood.Value = false;
            else
                tglHeat.Value = true;
            end
        end
    catch
        % ignore
    end
    onPreprocPreviewChanged();
end


    function onRunqEEG(src,~)
        syncProjectFromTable();
        if isempty(project.animals)
            uialert(fig, 'Manifest is empty. Add animals first.', 'No animals'); return;
        end
        project.outdir = edtOut.Value;
        edtOutR.Value = project.outdir;
        try, edtOutPS.Value = project.outdir; catch, end
        if isempty(project.outdir) || ~isfolder(project.outdir)
            uialert(fig, 'Please select a valid project output folder.', 'No output folder'); return;
        end

        q.fs = edtFsQ.Value;
        q.corr_window_sec = edtCorrWin.Value;
        q.dayStart = edtDayStart.Value;
        q.dayEnd   = edtDayEnd.Value;
        try
            project.profile.dayStart = q.dayStart;
            project.profile.dayEnd = q.dayEnd;
        catch
        end
        q.runBand = logical(chkCore.Value);
        q.runPSD  = logical(chkCore.Value);
        q.runRatio= logical(chkCore.Value);
        q.runCorr = chkCorr.Value;
        q.runCoh  = chkCoh.Value;
        if ~any([q.runBand, q.runPSD, q.runCorr, q.runCoh])
            uialert(fig, 'Please select at least one qEEG analysis module to run.', 'No qEEG analysis selected');
            return;
        end
        q.saveCohSpec = logical(chkCohSpec.Value);
        q.coh_window_sec = edtCohWin.Value;
        q.coh_overlap = edtCohOv.Value;
        q.coh_fmax = edtCohFmax.Value;
        q.coh_resample_500 = logical(chkCohResample500.Value);
        q.coh_resample_target_hz = 500;
        q.bandPost = true;
        q.usePreprocMasks = chkUseMasks.Value;
        % Fallback notch values. Per-animal preprocessing parameters are
        % loaded by meeg_qeeg_runall_10e when available so the exact band
        % selected during preprocessing is also used for qEEG spectra.
        q.notchEnabled = logical(chkNotch.Value);
        q.notchF1 = double(edtF1.Value);
        q.notchF2 = double(edtF2.Value);
        if q.notchEnabled && (~all(isfinite([q.notchF1 q.notchF2])) || ...
                q.notchF1 <= 0 || q.notchF2 <= q.notchF1 || q.notchF2 >= q.fs/2)
            uialert(fig, sprintf(['Enter a valid notch band with 0 < lower < upper < Nyquist.\n' ...
                'For the current qEEG sampling rate, the upper value must be below %.3g Hz.'], q.fs/2), ...
                'Invalid notch band');
            return;
        end

        qeeGLogFile = localStartRunLog(meeg_outdir(project,'qeeg'), 'qEEG_log', q);
        localSetActiveRunLog(qeeGLogFile);

        stopFile = [tempname '.flag'];
        q.stopFile = stopFile;
        stopRequested = false;
        stopConfirmed = false;
        stopTriggered = false;
        stopDlg = [];

        figForDlg = [];
        try, figForDlg = ancestor(src, 'figure'); catch, end
        if isempty(figForDlg) || ~isgraphics(figForDlg, 'figure')
            figForDlg = fig;
        end
        if isempty(figForDlg) || ~isgraphics(figForDlg, 'figure')
            try
                figForDlg = uifigure('Visible','off');
            catch
                error('Could not create a valid figure for the qEEG progress dialog.');
            end
        end
        d = uiprogressdlg(figForDlg, 'Title','qEEG', 'Message','Starting...', 'Indeterminate','off');
        d.Value = 0;
        txtQLog.Value = {'qEEG run started.'};
        qlogmsg(sprintf('Output folder: %s', project.outdir));
        qlogmsg(sprintf('qEEG log file: %s', qeeGLogFile));

        try
            stopDlg = uifigure('Name','Stop qEEG?', 'WindowStyle','alwaysontop', ...
                'Position',[max(100, fig.Position(1)+100), max(100, fig.Position(2)+100), 340, 110], ...
                'Resize','off');
            glStop = uigridlayout(stopDlg,[2 1]);
            glStop.RowHeight = {45,45};
            glStop.ColumnWidth = {'1x'};
            glStop.Padding = [10 10 10 10];
            uilabel(glStop, 'Text','Need to interrupt qEEG?', ...
                'HorizontalAlignment','center', 'FontWeight','bold');
            uibutton(glStop, 'Text','Stop qEEG', 'ButtonPushedFcn', @(~,~) requestStopqEEG());
        catch
            stopDlg = [];
        end

        % Parallelization across animals (recommended).
        usePar = false;
        try
            usePar = logical(chkQParallel.Value) && license('test','Distrib_Computing_Toolbox');
        catch
            usePar = false;
        end

        if q.runCoh && ~q.runBand && ~q.runPSD && ~q.runCorr
            if q.saveCohSpec
                qlogmsg('qEEG: coherence-only run with pair-spectrum saving enabled; this may take longer.');
            else
                qlogmsg('qEEG: coherence-only run with pair-spectrum saving disabled; using faster matrix-only mode.');
            end
        end

        try
            idxs = find(project.manifest.Include);
            n = numel(idxs);
            if n==0
                close(d);
                try, if ~isempty(stopDlg) && isvalid(stopDlg), close(stopDlg); end, catch, end
                uialert(fig, 'No animals are currently included.', 'No animals');
                return;
            end

            completedQ = 0; %#ok<NASGU>
            dq = [];
            if usePar
                if q.runCoh && q.coh_resample_500
                    % MATLAB's anti-alias resample() path uses MEX-backed
                    % routines that are unavailable on thread workers.
                    % Use process workers for the whole qEEG run when the
                    % optional coherence-only 500 Hz mode is enabled. If a
                    % process pool cannot be started, run serially so the
                    % requested resampling is still honored rather than
                    % silently reverting to the original sampling rate.
                    [poolOK, actualWorkers] = meeg_ensure_process_pool(@qlogmsg);
                    if poolOK
                        qlogmsg(sprintf(['qEEG: coherence-only resampling requires process workers; ' ...
                            'using a process-based pool with %d worker(s).'], actualWorkers));
                    else
                        usePar = false;
                        qlogmsg(['qEEG: a process-based pool could not be started. ' ...
                            'Running serially so coherence-only anti-alias resampling remains enabled.']);
                    end
                else
                    if isempty(gcp('nocreate'))
                        try
                            parpool('threads');
                        catch
                            parpool;
                        end
                    end
                end
            end

            if usePar
                dq = parallel.pool.DataQueue;
                afterEach(dq, @qeegHandleEvent);
                qlogmsg(sprintf('qEEG: running in parallel across %d animals...', n));
            else
                qlogmsg(sprintf('qEEG: running serially across %d animals...', n));
            end
            if q.runCoh
                qlogmsg('qEEG: coherence uses the shared-FFT engine (each lead FFT is reused across all pairs).');
                qlogmsg(sprintf('qEEG: requested coherence fmax = %.1f Hz (minimum GUI value = 50 Hz).', q.coh_fmax));
                if q.coh_resample_500
                    qlogmsg('qEEG: optional coherence-only anti-alias resampling to 500 Hz is enabled; lower-rate recordings will remain at their original rate.');
                else
                    qlogmsg('qEEG: coherence-only resampling is disabled; coherence will use the original sampling rate.');
                end
                if q.saveCohSpec
                    qlogmsg('qEEG: coherence pair-spectrum saving is enabled; expect longer runtimes per animal.');
                else
                    qlogmsg('qEEG: coherence pair-spectrum saving is disabled; using faster matrix-only mode.');
                end
            end

            errMsgs = cell(n,1);

            if usePar
                parfor ii = 1:n
                    i = idxs(ii);
                    mouse = '';
                    try
                        mouse = char(project.manifest.MouseID{i});
                    catch
                        mouse = sprintf('animal_%d', i);
                    end
                    send(dq, struct('type','start','ii',ii,'n',n,'mouse',mouse));
                    try
                        meeg_qeeg_runall_10e(project, i, q);
                        send(dq, struct('type','done','ii',ii,'n',n,'mouse',mouse));
                    catch MEW
                        if strcmp(MEW.identifier, 'mEEG:StopRequested')
                            send(dq, struct('type','stopped','ii',ii,'n',n,'mouse',mouse));
                        else
                            errMsgs{ii} = sprintf('%s: %s', mouse, MEW.message);
                            send(dq, struct('type','error','ii',ii,'n',n,'mouse',mouse,'msg',MEW.message));
                        end
                    end
                end
            else
                for ii = 1:n
                    if stopConfirmed || isfile(stopFile)
                        stopTriggered = true;
                        break;
                    end
                    i = idxs(ii);
                    mouse = '';
                    try
                        mouse = char(project.manifest.MouseID{i});
                    catch
                        mouse = sprintf('animal_%d', i);
                    end
                    d.Message = sprintf('Animal %d/%d: %s', ii, n, mouse);
                    d.Value = (ii-1)/max(n,1); drawnow;
                    qlogmsg(sprintf('[qEEG] Starting %s (%d/%d)', mouse, ii, n));
                    try
                        meeg_qeeg_runall_10e(project, i, q);
                        qlogmsg(sprintf('[qEEG] Finished %s', mouse));
                    catch MEW
                        if strcmp(MEW.identifier, 'mEEG:StopRequested')
                            stopTriggered = true;
                            qlogmsg(sprintf('[qEEG] Stopped %s', mouse));
                            break;
                        else
                            errMsgs{ii} = sprintf('%s: %s', mouse, MEW.message);
                            qlogmsg(sprintf('[qEEG] ERROR %s: %s', mouse, MEW.message));
                        end
                    end
                end
            end

            if stopConfirmed || isfile(stopFile) || stopTriggered
                stopTriggered = true;
                qlogmsg('qEEG stop requested. Skipping remaining work and post-processing.');
            end

            bad = find(~cellfun(@isempty, errMsgs));
            if ~isempty(bad)
                msg = sprintf('qEEG failed for %d/%d animals:\n\n%s', numel(bad), n, strjoin(errMsgs(bad), '\n\n'));
                error(msg);
            end

            if ~stopTriggered
                if q.runBand && q.bandPost
                    d.Message = 'Band post-processing (tables + default figures)...'; drawnow;
                    try
                        [bandSummary, bandPerAnimal, paths] = meeg_band_postprocess_autosave(project, idxs, q.dayStart, q.dayEnd);
                        if ~isempty(bandSummary)
                            meeg_plot_band_summary_preview(axR, bandSummary, 'delta', 'day');
                        end
                        if isstruct(paths) && isfield(paths,'outDir')
                            qlogmsg(['BandAnalysis outputs saved to: ' char(paths.outDir)]);
                        end
                    catch ME_SUM
                        qlogmsg(['Band post-processing step failed: ' ME_SUM.message]);
                    end
                end

                if q.runPSD
                    d.Message = 'Power Spectral Analysis post-processing (AUC tables + PSD figures)...'; drawnow;
                    try
                        psPostOpts = struct('logFcn', @qlogmsg);
                        psPaths = meeg_ps_postprocess_autosave(project, idxs, q.dayStart, q.dayEnd, q.fs, psPostOpts);
                        if isstruct(psPaths) && isfield(psPaths,'outDir')
                            qlogmsg(['Power Spectral Analysis outputs saved to: ' char(psPaths.outDir)]);
                        end
                    catch ME_PS
                        qlogmsg(['PS post-processing step failed: ' ME_PS.message]);
                    end
                end
            end

            if stopTriggered
                if isvalid(d)
                    d.Message = 'Stopped.';
                    d.Value = min(d.Value, 1);
                end
                pause(0.1);
                try, if isvalid(d), close(d); end, catch, end
                try, if ~isempty(stopDlg) && isvalid(stopDlg), close(stopDlg); end, catch, end
                try, if isfile(stopFile), delete(stopFile); end, catch, end
                qlogmsg('qEEG stopped by user.');
                qlogmsg(sprintf('Partial qEEG outputs may remain under %s for animals finished before stopping.', meeg_outdir(project,'qeeg')));
                localSetActiveRunLog('');
                uialert(fig, 'qEEG was stopped. Outputs for animals still in progress were discarded.', 'qEEG stopped');
            else
                d.Value = 1; d.Message = 'Done.'; pause(0.2);
                try, close(d); catch, end
                try, if ~isempty(stopDlg) && isvalid(stopDlg), close(stopDlg); end, catch, end
                try, if isfile(stopFile), delete(stopFile); end, catch, end
                qlogmsg('qEEG finished.');
                qlogmsg(sprintf('Done. Your data is saved in %s', meeg_outdir(project,'qeeg')));
                if q.runRatio
                    qlogmsg('Power ratios are implemented in the Power Ratios subtab. Use Show plot and Save plot and data to generate Normalized Band Power or Power Spectra (AUC) ratios.');
                end
                localSetActiveRunLog('');
            end

        catch ME
            try, qlogmsg(['qEEG error: ' ME.message]); catch, end
            try, if isfile(stopFile), delete(stopFile); end, catch, end
            try, if isvalid(d), close(d); end, catch, end
            try, if ~isempty(stopDlg) && isvalid(stopDlg), close(stopDlg); end, catch, end
            localSetActiveRunLog('');
            uialert(fig, ME.message, 'qEEG error'); rethrow(ME);
        end

        function requestStopqEEG()
            if stopConfirmed || stopRequested
                return;
            end
            stopRequested = true;
            choice = 'Cancel';
            try
                choice = uiconfirm(fig, ['Stop qEEG now? Outputs for animals still in progress will be discarded. ' ...
                    'Animals that already finished will remain saved.'], 'Stop qEEG', ...
                    'Options', {'Stop','Cancel'}, 'DefaultOption', 2, 'CancelOption', 2, 'Icon', 'warning');
            catch
                choice = 'Stop';
            end
            if strcmp(choice, 'Stop')
                stopConfirmed = true;
                try
                    fidStop = fopen(stopFile, 'w');
                    if fidStop ~= -1
                        fprintf(fidStop, 'stop requested %s\n', datestr(now));
                        fclose(fidStop);
                    end
                catch
                end
                if isvalid(d)
                    d.Message = 'Stopping after current work unit...';
                end
                qlogmsg('Stop requested for qEEG.');
                try
                    if ~isempty(stopDlg) && isvalid(stopDlg)
                        stopDlg.Name = 'Stopping qEEG...';
                    end
                catch
                end
            else
                stopRequested = false;
            end
        end

        function qeegHandleEvent(ev)
            try
                if isempty(ev) || ~isstruct(ev) || ~isfield(ev,'type'); return; end
                switch lower(ev.type)
                    case 'start'
                        qlogmsg(sprintf('[qEEG] Starting %s (%d/%d)', ev.mouse, ev.ii, ev.n));
                    case 'done'
                        completedQ = completedQ + 1; %#ok<NASGU>
                        d.Value = min(1, completedQ/max(ev.n,1));
                        d.Message = sprintf('Finished %d/%d (last: %s)', completedQ, ev.n, ev.mouse);
                        qlogmsg(sprintf('[qEEG] Finished %s', ev.mouse));
                        drawnow limitrate;
                    case 'stopped'
                        completedQ = completedQ + 1; %#ok<NASGU>
                        stopTriggered = true;
                        d.Value = min(1, completedQ/max(ev.n,1));
                        d.Message = sprintf('Stopping... %d/%d reached checkpoint (last: %s)', completedQ, ev.n, ev.mouse);
                        qlogmsg(sprintf('[qEEG] Stopped %s', ev.mouse));
                        drawnow limitrate;
                    case 'error'
                        completedQ = completedQ + 1; %#ok<NASGU>
                        d.Value = min(1, completedQ/max(ev.n,1));
                        d.Message = sprintf('Error %d/%d (last: %s)', completedQ, ev.n, ev.mouse);
                        if isfield(ev,'msg')
                            qlogmsg(sprintf('[qEEG] ERROR %s: %s', ev.mouse, ev.msg));
                        else
                            qlogmsg(sprintf('[qEEG] ERROR %s', ev.mouse));
                        end
                        drawnow limitrate;
                end
            catch
            end
        end
    end

    function onRefreshBandTables(~,~)
        syncProjectFromTable();
        project.outdir = edtOut.Value;
        edtOutR.Value = project.outdir;
        try, edtOutPS.Value = project.outdir; catch, end

        if isempty(project.outdir) || ~isfolder(project.outdir)
            uialert(fig, 'Please select a valid project output folder.', 'No output folder'); return;
        end

        idxs = find(project.manifest.Include);
        if isempty(idxs)
            uialert(fig, 'No animals are currently included.', 'No animals'); return;
        end

        dayStart = edtDayStart.Value;
        dayEnd   = edtDayEnd.Value;

        [dlgFig, dlgFigTemp] = local_progress_parent();
        d = uiprogressdlg(dlgFig, 'Title','Results', 'Message','Refreshing band tables...', 'Indeterminate','on');
        try
            bandSourceMode = string(ddBandSource.Value);
            if bandSourceMode == "power_frac"
                [psFracSummary, psFracPerAnimal] = meeg_ps_fractional_band_tables(project, idxs, dayStart, dayEnd, edtFsQ.Value);
                bandSummary = psFracSummary;
                bandPerAnimal = psFracPerAnimal;
            else
                [bandSummary, bandPerAnimal, ~] = meeg_band_postprocess_autosave(project, idxs, dayStart, dayEnd, struct('saveFig', false, 'writeFiles', false));
            end

            close(d);
            local_cleanup_progress_parent(dlgFig, dlgFigTemp);
            logmsg('Results: loaded project data for band plots.');

            if ~isempty(bandSummary)
                meeg_plot_band_summary_preview(axR, bandSummary, ddBand.Value, ddTime.Value, bandPerAnimal, ddColorBy.Value);
            end
        catch ME
            close(d);
            local_cleanup_progress_parent(dlgFig, dlgFigTemp);
            uialert(fig, ME.message, 'Results error'); rethrow(ME);
        end
    end

    function onBandPreviewOptionsChanged(~,~)
        try
            persistent lastBandSourceMode
            currentMode = string(ddBandSource.Value);
            if isempty(lastBandSourceMode), lastBandSourceMode = currentMode; end
            if currentMode ~= lastBandSourceMode
                lastBandSourceMode = currentMode;
                bandSummary = table();
                bandPerAnimal = table();
            end
            if isempty(bandSummary) || height(bandSummary)==0
                cla(axR);
                title(axR, 'Normalized Band Power preview');
                text(axR, 0.5, 0.5, 'Click "Load project data" to build the preview.', 'HorizontalAlignment','center');
                return;
            end
            meeg_plot_band_summary_preview(axR, bandSummary, ddBand.Value, ddTime.Value, bandPerAnimal, ddColorBy.Value);
        catch ME
            logmsg(['Band preview update failed: ' ME.message]);
        end
    end

    function onOpenBandPlot(~,~)
        if isempty(bandPerAnimal) || height(bandPerAnimal)==0
            uialert(fig, 'No per-animal band table loaded. Click "Load project data" first (or run qEEG with Band post-processing).', 'No data');
            return;
        end
        if isempty(bandSummary) || height(bandSummary)==0
            uialert(fig, 'No band summary table loaded. Click "Load project data" first.', 'No data');
            return;
        end

        bandName = ddBand.Value;
        whichTime = ddTime.Value;
        colorBy = ddColorBy.Value;

        outGroup = meeg_outdir(project,'qeeg', 'BandAnalysis');
        if ~isfolder(outGroup), mkdir(outGroup); end

        meeg_plot_band_region_comparison_window(bandPerAnimal, bandSummary, bandName, whichTime, colorBy, outGroup);
        logmsg(sprintf('Opened band plot window: %s (%s), color by %s', bandName, whichTime, colorBy));
    end


    function onSaveBandPlotData(~,~)
        if isempty(bandPerAnimal) || height(bandPerAnimal)==0 || isempty(bandSummary) || height(bandSummary)==0
            uialert(fig, 'No band plot data is currently loaded. Click "Load project data" first.', 'No data');
            return;
        end

        bandName = string(ddBand.Value);
        whichTime = string(ddTime.Value);
        colorBy = string(ddColorBy.Value);
        if whichTime == "combined" || whichTime == "all"
            uialert(fig, 'Save plot and data is currently available for day or night band plots. Please choose day or night.', 'Choose day or night');
            return;
        end

        outDir = meeg_outdir(project,'qeeg','BandAnalysis');
        if ~isfolder(outDir), mkdir(outDir); end
        stamp = datestr(now, 'yyyymmdd_HHMMSS');
        stem = sprintf('band_%s_%s_%s', char(bandName), char(whichTime), stamp);

        pa = bandPerAnimal(lower(string(bandPerAnimal.Band)) == lower(bandName), :);
        sm = bandSummary(lower(string(bandSummary.Band)) == lower(bandName), :);

        try
            writetable(pa, fullfile(outDir, [stem '_per_animal.xlsx']), 'Sheet', 'PerAnimal');
            writetable(sm, fullfile(outDir, [stem '_summary.xlsx']), 'Sheet', 'Summary');
        catch
            writetable(pa, fullfile(outDir, [stem '_per_animal.csv']));
            writetable(sm, fullfile(outDir, [stem '_summary.csv']));
        end

        hFig = meeg_plot_band_region_comparison_window(bandPerAnimal, bandSummary, bandName, whichTime, colorBy, outDir);
        try
            meeg_save_png_svg(hFig, fullfile(outDir, [stem '.png']), 'Resolution', 200);
            savefig(hFig, fullfile(outDir, [stem '.fig']));
        catch
        end
        try, close(hFig); catch, end

        logmsg(sprintf('Saved band plot and data to %s', outDir));
        uialert(fig, sprintf('Saved current band plot and data into:\n%s', outDir), 'Saved');
    end

    function onShowRatioPlot(~,~)
        syncProjectFromTable();
        project.outdir = edtOut.Value;
        edtOutRatio.Value = meeg_outdir(project,'qeeg','Ratio Analysis');

        if strcmpi(ddRatioNum.Value, ddRatioDen.Value)
            uialert(fig, 'Please choose two different bands for the ratio.', 'Invalid ratio');
            return;
        end

        idxs = find(project.manifest.Include);
        if isempty(idxs)
            uialert(fig, 'No animals are currently included.', 'No animals');
            return;
        end

        sourceKind = string(ddRatioSource.Value);
        dayStart = edtDayStart.Value;
        dayEnd = edtDayEnd.Value;

        [dlgFig, dlgFigTemp] = local_progress_parent();
        d = uiprogressdlg(dlgFig, 'Title','Ratios', 'Message','Building ratio table...', 'Indeterminate','on');
        try
            ratioCurrent = meeg_ratio_build_table(project, sourceKind, string(ddRatioNum.Value), string(ddRatioDen.Value), ...
                string(ddRatioTime.Value), string(ddRatioRegion.Value), idxs, dayStart, dayEnd);
            if ~ismember('Ratio', ratioCurrent.Properties.VariableNames) || isempty(ratioCurrent) || height(ratioCurrent)==0
                error('No ratio values were found for the selected EDF/project settings.');
            end
            ratioCurrent = ratioCurrent(~isnan(ratioCurrent.Ratio) & isfinite(ratioCurrent.Ratio), :);
            if isempty(ratioCurrent) || height(ratioCurrent)==0
                error('No ratio values were found for the selected EDF/project settings.');
            end
            ratioCurrentSpec = struct('sourceKind',sourceKind,'numBand',string(ddRatioNum.Value), ...
                'denBand',string(ddRatioDen.Value),'timeMode',string(ddRatioTime.Value), ...
                'regionMode',string(ddRatioRegion.Value),'colorBy',string(ddRatioColorBy.Value));

            ttl = sprintf('%s ratio: %s / %s (%s, %s)', local_ratio_source_label(ddRatioSource.Value), local_band_label(ddRatioNum.Value), local_band_label(ddRatioDen.Value), local_time_label(ddRatioTime.Value), ddRatioRegion.Value);
            meeg_ratio_plot_grouped(ratioCurrent, ddRatioColorBy.Value, axRatio, ttl);
            title(axRatio, ttl, 'Interpreter','none');
            txtRatio.Value = {sprintf('Loaded %d per-animal values.', height(ratioCurrent)), ...
                              sprintf('Source: %s', local_ratio_source_label(ddRatioSource.Value)), ...
                              sprintf('Bands: %s / %s', local_band_label(ddRatioNum.Value), local_band_label(ddRatioDen.Value)), ...
                              sprintf('Color data points by: %s', ddRatioColorBy.Value)};
            close(d);
            local_cleanup_progress_parent(dlgFig, dlgFigTemp);
            logmsg(sprintf('Ratio plot updated: %s / %s (%s, %s)', local_band_label(ddRatioNum.Value), local_band_label(ddRatioDen.Value), local_time_label(ddRatioTime.Value), local_ratio_source_label(ddRatioSource.Value)));
        catch ME
            close(d);
            local_cleanup_progress_parent(dlgFig, dlgFigTemp);
            uialert(fig, ME.message, 'Ratio error');
        end
    end

    function onDownloadRatioPlotData(~,~)
        if isempty(ratioCurrent) || height(ratioCurrent)==0
            uialert(fig, 'No ratio plot is currently loaded. Click Show plot first.', 'No data');
            return;
        end

        outDirRatio = meeg_outdir(project,'qeeg','Ratio Analysis');
        if ~isfolder(outDirRatio), mkdir(outDirRatio); end

        numBand = char(ratioCurrentSpec.numBand);
        denBand = char(ratioCurrentSpec.denBand);
        timeMode = char(ratioCurrentSpec.timeMode);
        regionMode = regexprep(char(ratioCurrentSpec.regionMode), '[^A-Za-z0-9_\-]+', '_');
        sourceKind = char(ratioCurrentSpec.sourceKind);
        stamp = datestr(now, 'yyyymmdd_HHMMSS');
        stem = sprintf('%s_ratio_%s_over_%s_%s_%s_%s', sourceKind, numBand, denBand, timeMode, regionMode, stamp);

        dataFile = fullfile(outDirRatio, [stem '.xlsx']);
        plotFile = fullfile(outDirRatio, [stem '.png']);
        figFile  = fullfile(outDirRatio, [stem '.fig']);

        try
            writetable(ratioCurrent, dataFile, 'Sheet', 'RatioData');
        catch
            writetable(ratioCurrent, strrep(dataFile,'.xlsx','.csv'));
        end

        ttl = sprintf('%s ratio: %s / %s (%s, %s)', local_ratio_source_label(ddRatioSource.Value), local_band_label(ddRatioNum.Value), local_band_label(ddRatioDen.Value), local_time_label(ddRatioTime.Value), ddRatioRegion.Value);
        h = meeg_ratio_plot_grouped(ratioCurrent, ddRatioColorBy.Value, [], ttl);
        try
            meeg_save_png_svg(h.Figure, plotFile, 'Resolution', 200);
            savefig(h.Figure, figFile);
        catch
        end
        try, close(h.Figure); catch, end

        logmsg(sprintf('Saved ratio plot and data to %s', outDirRatio));
        uialert(fig, sprintf('Saved current ratio plot and data into:\n%s', outDirRatio), 'Saved');
    end

    function onPSDisplayOptionChanged(~,~)
        % Re-render from the in-memory PSD cache so toggling individual
        % animal overlays immediately adds/removes the SEM ribbons.
        if isempty(psPreviewSpec) || isempty(psPreviewFreq)
            return;
        end
        try
            renderPSPreviewFromCache();
        catch ME
            uialert(fig, ME.message, 'Results: PS display error');
        end
    end

    function renderPSPreviewFromCache()
        spec = psPreviewSpec;
        f = double(psPreviewFreq(:));
        meta = psPreviewMeta;
        whichTime = string(ddPSTime.Value);

        regionNames = cellstr(string(meta.RegionNames));
        if isempty(regionNames), regionNames = {'Hippocampus','Barrel','Motor','Visual','Auditory'}; end
        ddPSRegion.Items = regionNames;
        if ~any(strcmp(regionNames, ddPSRegion.Value)), ddPSRegion.Value = regionNames{1}; end
        r = find(strcmp(regionNames, ddPSRegion.Value), 1);
        if isempty(r), r = 1; end

        fmin = max(0.4, edtPSFmin.Value);
        edtPSFmin.Value = fmin;
        fmax = edtPSFmax.Value;
        if fmax <= fmin
            error('Max frequency to plot must be greater than min frequency to plot.');
        end

        if whichTime == "day"
            Yfull = squeeze(spec(:,r,1,:));
        elseif whichTime == "night"
            Yfull = squeeze(spec(:,r,2,:));
        else
            Yfull = squeeze(mean(spec(:,r,1:2,:), 3, 'omitnan'));
        end
        if isvector(Yfull), Yfull = Yfull(:); end

        keepFreq = isfinite(f) & f >= 0.4;
        if ~any(keepFreq)
            error('No PSD frequencies at or above 0.4 Hz were found.');
        end
        f = f(keepFreq);
        Yfull = Yfull(keepFreq,:);

        groups = string(meta.TreatmentGroup);
        uniqG = unique(groups, 'stable');
        C = meeg_get_group_colors(uniqG);
        if isfield(meta,'MouseID')
            animalIDs = string(meta.MouseID);
        else
            animalIDs = strings(0,1);
        end

        % Delete all graphics children explicitly. CLA can leave objects with
        % HandleVisibility='off' (including old SEM ribbons) in UI axes.
        try
            delete(allchild(axPS));
        catch
            cla(axPS, 'reset');
        end
        hold(axPS,'on');
        visibleFreq = f >= fmin & f <= fmax;
        if ~any(visibleFreq)
            error('No PSD frequencies fall within the selected plotting range.');
        end
        yl = nanmax(Yfull(visibleFreq,:), [], 'all');
        if isempty(yl) || ~isfinite(yl) || yl <= 0
            yl = 1;
        else
            yl = yl * 1.05;
        end
        patch(axPS, [0.4 4 4 0.4], [0 0 yl yl], [0.80 0.80 0.80], 'EdgeColor','none', 'FaceAlpha',0.28, 'HandleVisibility','off');
        patch(axPS, [4 8 8 4], [0 0 yl yl], [0.88 0.88 0.88], 'EdgeColor','none', 'FaceAlpha',0.28, 'HandleVisibility','off');
        patch(axPS, [8 13 13 8], [0 0 yl yl], [0.94 0.94 0.94], 'EdgeColor','none', 'FaceAlpha',0.28, 'HandleVisibility','off');
        patch(axPS, [13 30 30 13], [0 0 yl yl], [0.97 0.97 0.97], 'EdgeColor','none', 'FaceAlpha',0.28, 'HandleVisibility','off');

        h = meeg_ps_plot_group_curves(axPS, f, Yfull, groups, C, ...
            logical(chkPSIndividuals.Value), animalIDs, fmin, fmax);

        hold(axPS,'off');
        meeg_ps_apply_band_ticks(axPS, fmin, fmax);
        ylim(axPS, [0 yl]);
        xlabel(axPS, 'Frequency (Hz)');
        ylabel(axPS, 'Amplitude (\muV^2/Hz)');
        title(axPS, sprintf('%s (%s): group mean power spectral density', ...
            regionNames{r}, local_time_label(whichTime)), 'Interpreter','none');
        valid = isgraphics(h);
        if any(valid)
            legend(axPS, h(valid), cellstr(uniqG(valid)), 'Location','best');
        end
        grid(axPS,'on');
    end

    function onPreviewPS(~,~)
        syncProjectFromTable();
        project.outdir = edtOut.Value;
        edtOutPS.Value = project.outdir;

        if isempty(project.outdir) || ~isfolder(project.outdir)
            uialert(fig, 'Please select a valid project output folder.', 'No output folder'); return;
        end

        idxs = find(project.manifest.Include);
        if isempty(idxs)
            uialert(fig, 'No animals are currently included.', 'No animals'); return;
        end

        dayStart = edtDayStart.Value;
        dayEnd   = edtDayEnd.Value;
        fs = edtFsQ.Value;

        [dlgFig, dlgFigTemp] = local_progress_parent();
        d = uiprogressdlg(dlgFig, 'Title','Results: PS', 'Message','Loading PS files...', 'Indeterminate','on');
        try
            [spec, f, meta] = meeg_ps_collect_per_animal(project, idxs, dayStart, dayEnd, fs, 'avg');
            psPreviewSpec = spec;
            psPreviewFreq = f;
            psPreviewMeta = meta;
            close(d);
            local_cleanup_progress_parent(dlgFig, dlgFigTemp);
            renderPSPreviewFromCache();
        catch ME
            try, close(d); catch, end
            local_cleanup_progress_parent(dlgFig, dlgFigTemp);
            uialert(fig, ME.message, 'Results: PS error'); rethrow(ME);
        end
    end

    function onOpenPSPlot(~,~)
        syncProjectFromTable();
        project.outdir = edtOut.Value;
        edtOutPS.Value = project.outdir;

        if isempty(project.outdir) || ~isfolder(project.outdir)
            uialert(fig, 'Please select a valid project output folder.', 'No output folder'); return;
        end

        idxs = find(project.manifest.Include);
        if isempty(idxs)
            uialert(fig, 'No animals are currently included.', 'No animals'); return;
        end

        dayStart = edtDayStart.Value;
        dayEnd   = edtDayEnd.Value;
        fs = edtFsQ.Value;
        whichTime = ddPSTime.Value;

        opts = struct();
        opts.fmin = edtPSFmin.Value;
        opts.fmax = edtPSFmax.Value;
        opts.showIndividuals = chkPSIndividuals.Value;
        opts.colorIndividualsBy = "TreatmentGroup";
        opts.shadeBands = true;
        opts.outFolder = meeg_outdir(project,'qeeg', '_group_summary');

        [dlgFig, dlgFigTemp] = local_progress_parent();
        d = uiprogressdlg(dlgFig, 'Title','Results: PS', 'Message','Loading PS files...', 'Indeterminate','on');
        try
            [spec, f, meta] = meeg_ps_collect_per_animal(project, idxs, dayStart, dayEnd, fs, 'avg');
            close(d);
            local_cleanup_progress_parent(dlgFig, dlgFigTemp);
            meeg_plot_ps_comparison_window(spec, f, meta, whichTime, opts);
            logmsg(sprintf('Opened PS plot window (%s).', whichTime));
        catch ME
            close(d);
            local_cleanup_progress_parent(dlgFig, dlgFigTemp);
            uialert(fig, ME.message, 'Results: PS error'); rethrow(ME);
        end
    end


    function onSavePSPlotData(~,~)
        syncProjectFromTable();
        project.outdir = edtOut.Value;
        edtOutPS.Value = project.outdir;

        if isempty(project.outdir) || ~isfolder(project.outdir)
            uialert(fig, 'Please select a valid project output folder.', 'No output folder');
            return;
        end

        if isempty(psPreviewSpec) || isempty(psPreviewFreq)
            onPreviewPS([],[]);
            if isempty(psPreviewSpec) || isempty(psPreviewFreq)
                return;
            end
        end

        regionNames = cellstr(string(psPreviewMeta.RegionNames));
        if isempty(regionNames), regionNames = {'Hippocampus','Barrel','Motor','Visual','Auditory'}; end
        if ~any(strcmp(regionNames, ddPSRegion.Value)), ddPSRegion.Value = regionNames{1}; end
        r = find(strcmp(regionNames, ddPSRegion.Value), 1);
        if isempty(r), r = 1; end
        whichTime = string(ddPSTime.Value);

        if whichTime == "day"
            Yfull = squeeze(psPreviewSpec(:,r,1,:));
            timeLabel = repmat("day", numel(psPreviewMeta.TreatmentGroup), 1);
        elseif whichTime == "night"
            Yfull = squeeze(psPreviewSpec(:,r,2,:));
            timeLabel = repmat("night", numel(psPreviewMeta.TreatmentGroup), 1);
        else
            Yfull = squeeze(mean(psPreviewSpec(:,r,1:2,:), 3, 'omitnan'));
            timeLabel = repmat("combined (day and night)", numel(psPreviewMeta.TreatmentGroup), 1);
        end
        if isvector(Yfull), Yfull = Yfull(:); end

        nFreq = numel(psPreviewFreq);
        nAnimals = size(Yfull, 2);
        exportTbl = table();
        exportTbl.AnimalID = strings(nFreq*nAnimals, 1);
        exportTbl.TreatmentGroup = strings(nFreq*nAnimals, 1);
        exportTbl.Time = strings(nFreq*nAnimals, 1);
        exportTbl.Region = strings(nFreq*nAnimals, 1);
        exportTbl.FrequencyHz = zeros(nFreq*nAnimals, 1);
        exportTbl.Power = nan(nFreq*nAnimals, 1);
        k = 0;
        for a = 1:nAnimals
            for i = 1:nFreq
                k = k + 1;
                exportTbl.AnimalID(k) = string(psPreviewMeta.MouseID(a));
                exportTbl.TreatmentGroup(k) = string(psPreviewMeta.TreatmentGroup(a));
                exportTbl.Time(k) = timeLabel(a);
                exportTbl.Region(k) = string(regionNames{r});
                exportTbl.FrequencyHz(k) = psPreviewFreq(i);
                exportTbl.Power(k) = Yfull(i,a);
            end
        end

        outDir = meeg_outdir(project,'qeeg','Power Spectral Analysis');
        if ~isfolder(outDir), mkdir(outDir); end
        stamp = datestr(now, 'yyyymmdd_HHMMSS');
        regionStem = regexprep(regionNames{r}, '[^A-Za-z0-9_\-]+', '_');
        stem = sprintf('ps_preview_%s_%s_%s', lower(regionStem), char(whichTime), stamp);

        try
            writetable(exportTbl, fullfile(outDir, [stem '.xlsx']), 'Sheet', 'PSDData');
        catch
            writetable(exportTbl, fullfile(outDir, [stem '.csv']));
        end

        fmin = max(0.4, edtPSFmin.Value);
        fmax = edtPSFmax.Value;
        if fmax <= fmin
            error('Max frequency to plot must be greater than 0.4 Hz and the selected minimum.');
        end
        fPlot = double(psPreviewFreq(:));
        keepFreq = isfinite(fPlot) & fPlot >= 0.4;
        if ~any(keepFreq)
            error('No PSD frequencies at or above 0.4 Hz were found.');
        end
        fPlot = fPlot(keepFreq);
        Yplot = Yfull(keepFreq,:);

        groups = string(psPreviewMeta.TreatmentGroup);
        uniqG = unique(groups, 'stable');
        C = meeg_get_group_colors(uniqG);
        hFig = figure('Color','w', 'Name', sprintf('%s (%s) PSD', regionNames{r}, char(whichTime)));
        ax = axes(hFig); hold(ax,'on');
        visibleFreq = fPlot >= fmin & fPlot <= fmax;
        if ~any(visibleFreq)
            error('No PSD frequencies fall within the selected plotting range.');
        end
        yl = nanmax(Yplot(visibleFreq,:), [], 'all'); if isempty(yl) || ~isfinite(yl) || yl<=0, yl = 1; else, yl = yl*1.05; end
        patch(ax, [0.4 4 4 0.4], [0 0 yl yl], [0.80 0.80 0.80], 'EdgeColor','none', 'FaceAlpha',0.28, 'HandleVisibility','off');
        patch(ax, [4 8 8 4], [0 0 yl yl], [0.88 0.88 0.88], 'EdgeColor','none', 'FaceAlpha',0.28, 'HandleVisibility','off');
        patch(ax, [8 13 13 8], [0 0 yl yl], [0.94 0.94 0.94], 'EdgeColor','none', 'FaceAlpha',0.28, 'HandleVisibility','off');
        patch(ax, [13 30 30 13], [0 0 yl yl], [0.97 0.97 0.97], 'EdgeColor','none', 'FaceAlpha',0.28, 'HandleVisibility','off');
        if isfield(psPreviewMeta,'MouseID')
            animalIDs = string(psPreviewMeta.MouseID);
        else
            animalIDs = strings(0,1);
        end
        h = meeg_ps_plot_group_curves(ax, fPlot, Yplot, groups, C, ...
            logical(chkPSIndividuals.Value), animalIDs, fmin, fmax);
        hold(ax,'off');
        meeg_ps_apply_band_ticks(ax, fmin, fmax);
        ylim(ax, [0 yl]);
        xlabel(ax, 'Frequency (Hz)'); ylabel(ax, 'Amplitude (\muV^2/Hz)');
        title(ax, sprintf('%s (%s): group mean power spectral density', regionNames{r}, local_time_label(whichTime)), 'Interpreter','none');
        legend(ax, h(isgraphics(h)), cellstr(uniqG(isgraphics(h))), 'Location','best');
        grid(ax,'on');

        try
            meeg_save_png_svg(hFig, fullfile(outDir, [stem '.png']), 'Resolution', 200);
            savefig(hFig, fullfile(outDir, [stem '.fig']));
        catch
        end
        try, close(hFig); catch, end

        logmsg(sprintf('Saved PS plot and data to %s', outDir));
        uialert(fig, sprintf('Saved current PSD plot and data into:\n%s', outDir), 'Saved');
    end

    function swdlogmsg(msg)
        try
            line = sprintf('[%s] %s', datestr(now,'HH:MM:SS'), msg);
            txtSWD.Value = [txtSWD.Value; {line}];
            txtSWD.Value = txtSWD.Value(max(1,end-500):end);
        catch
        end
        logmsg(msg);
        drawnow limitrate;
    end

    function onRunSWD()
        swdlogmsg('=== Run SWD Identifier Lite ===');
        swdOpts = struct();
        swdOpts.fs = edtSWDFs.Value;
        swdOpts.bandBroad = [max(1, edtSWDFmin.Value-2), edtSWDFmax.Value+3];
        swdOpts.bandSWD = [edtSWDFmin.Value, edtSWDFmax.Value];
        swdOpts.notchHz = 60;
        swdOpts.useNotch = true;
        swdOpts.minDurSec = edtSWDMinDur.Value;
        swdOpts.mergeGapSec = 0.20;
        swdOpts.minFreqHz = edtSWDFmin.Value;
        swdOpts.maxFreqHz = edtSWDFmax.Value;
        swdOpts.minPeaks = edtSWDMinGap.Value;
        swdOpts.envWinSec = 0.20;
        swdOpts.envZ = edtSWDZ.Value;
        swdOpts.maxIPIcv = 0.25;
        swdOpts.minPromZ = 1.5;
        swdOpts.minRhythmScore = edtSWDMerge.Value;
        swdOpts.minHarmonicScore = edtSWDHarm.Value;
        swdOpts.maxArtifactScore = edtSWDArtifactScore.Value;
        swdOpts.calibrationMode = logical(chkSWDCalibration.Value);
        if swdOpts.calibrationMode
            % Broader candidate-generation limits only. The automatic SWD
            % decision is still scored using the user's thresholds above.
            swdOpts.candidateEnvZ = min(swdOpts.envZ, 2.0);
            swdOpts.candidateMinDurSec = min(swdOpts.minDurSec, 0.50);
            swdOpts.candidateMinPeaks = min(swdOpts.minPeaks, 2);
            swdOpts.candidateMinFreqHz = max(0.5, swdOpts.minFreqHz - 1.0);
            swdOpts.candidateMaxFreqHz = min(swdOpts.fs/2 - 1, swdOpts.maxFreqHz + 2.0);
        else
            swdOpts.candidateEnvZ = swdOpts.envZ;
            swdOpts.candidateMinDurSec = swdOpts.minDurSec;
            swdOpts.candidateMinPeaks = swdOpts.minPeaks;
            swdOpts.candidateMinFreqHz = swdOpts.minFreqHz;
            swdOpts.candidateMaxFreqHz = swdOpts.maxFreqHz;
        end
        swdOpts.multileadWinSec = 0.10;
        swdOpts.minLeads = 1 + (~chkSWDLegacy.Value);
        swdOpts.artifactMode = string(ddSWDArtifact.Value);
        swdOpts.dayStart = edtDayStart.Value;
        swdOpts.dayEnd = edtDayEnd.Value;
        % Memory-bounded SWD defaults. Each worker handles one animal and
        % reads one lead at a time in 30-minute windows with 60-s overlap.
        % Parallel execution starts at the maximum available process-worker
        % count and automatically retries at ~75%, ~50%, ~25%, then serial.
        swdOpts.chunkSec = 30 * 60;
        swdOpts.chunkOverlapSec = 60;
        swdOpts.keepDebug = false;
        swdOpts.adaptiveParallel = true;
        swdOpts.parallelFractions = [1.00 0.75 0.50 0.25];
        try, swdOpts.useParallel = license('test','Distrib_Computing_Toolbox'); catch, swdOpts.useParallel = false; end
        swdLogFile = localStartRunLog(meeg_outdir(project,'qeeg','SWD Analysis'), 'SWDAnalysis_log', swdOpts);
        localSetActiveRunLog(swdLogFile);
        swdlogmsg(['SWD Analysis log file: ' char(swdLogFile)]);
        swdlogmsg(sprintf('Settings: fs=%.1f, SWD band=[%.1f..%.1f] Hz, minDur=%.2f s, mergeGap=%.2f s, artifactMode=%s, calibrationMode=%d', ...
            swdOpts.fs, swdOpts.bandSWD(1), swdOpts.bandSWD(2), swdOpts.minDurSec, swdOpts.mergeGapSec, char(swdOpts.artifactMode), swdOpts.calibrationMode));
        if swdOpts.calibrationMode
            swdlogmsg(sprintf(['Discovery candidates: envelopeZ>=%.2f, duration>=%.2f s, cycles>=%d, frequency=[%.1f..%.1f] Hz. ' ...
                'Automatic classification still uses the displayed SWD thresholds.'], ...
                swdOpts.candidateEnvZ, swdOpts.candidateMinDurSec, swdOpts.candidateMinPeaks, ...
                swdOpts.candidateMinFreqHz, swdOpts.candidateMaxFreqHz));
        end
        swdlogmsg(sprintf(['Chunked processing: %.1f-min windows, %.1f-s overlap; ' ...
            'adaptive workers=max -> 75%% -> 50%% -> 25%% -> serial'], ...
            swdOpts.chunkSec/60, swdOpts.chunkOverlapSec));
        cleanupSWDUi = localAnalysisBusyLock('SWD Analysis'); %#ok<NASGU>
        try
            meeg_swd_runall(project, swdOpts, @(m) swdlogmsg(m));
            swdlogmsg('SWD analysis finished.');
            localSetActiveRunLog('');
            if swdOpts.calibrationMode
                try, ddSWDShow.Value = 'all'; catch, end
            end
            onSWDLoad();
            onSWDViewerLoad();
        catch ME
            swdlogmsg('SWD error: ' + string(ME.message));
            localSetActiveRunLog('');
            try, uialert(fig, ME.message, 'SWD error'); catch, end
        end
    end

    function onSWDLoad()
        cla(axSWD);
        T = meeg_swd_collect_per_animal(project, ddSWDTime.Value, edtDayStart.Value, edtDayEnd.Value);
        if isempty(T) || height(T)==0
            title(axSWD, 'SWD Analysis preview');
            text(axSWD, 0.5, 0.5, 'No SWD event files found. Run SWD analysis first.', 'HorizontalAlignment','center');
            return;
        end
        metric = string(ddSWDMetric.Value);
        scaleHours = double(ddSWDScale.Value);
        [y, ylab] = localSWDMetricValues(T, metric, scaleHours);
        groups = unique(string(T.TreatmentGroup), 'stable');
        groups(groups=="") = [];
        colorVar = string(ddSWDColorBy.Value);
        metaVals = string(T.(colorVar));
        dotCats = unique(metaVals, 'stable'); dotCats(dotCats=="") = [];
        if isempty(dotCats), dotCats = groups; metaVals = string(T.TreatmentGroup); colorVar = "TreatmentGroup"; end
        Cg = meeg_get_group_colors(groups);
        Cd = meeg_get_metadata_colors(max(1,numel(dotCats)));
        hold(axSWD,'on');
        mu = nan(numel(groups),1); se = mu;
        for gi = 1:numel(groups)
            idx = string(T.TreatmentGroup)==groups(gi);
            yg = y(idx);
            mu(gi) = mean(yg, 'omitnan');
            se(gi) = std(yg,0,'omitnan') / max(1, sqrt(sum(~isnan(yg))));
        end
        bh = bar(axSWD, 1:numel(groups), mu, 0.75, 'FaceColor','flat', 'HandleVisibility','off');
        for gi = 1:numel(groups), bh.CData(gi,:) = Cg(gi,:); end
        errorbar(axSWD, 1:numel(groups), mu, se, 'k', 'LineStyle','none', 'HandleVisibility','off');
        rng(0);
        for gi = 1:numel(groups)
            idx = string(T.TreatmentGroup)==groups(gi);
            yg = y(idx); cats = metaVals(idx);
            x = gi + (rand(sum(idx),1)-0.5)*0.18;
            for ci = 1:numel(dotCats)
                idc = cats==dotCats(ci);
                if any(idc)
                    scatter(axSWD, x(idc), yg(idc), 32, 'MarkerFaceColor', Cd(ci,:), ...
                        'MarkerEdgeColor','k', 'HandleVisibility','off');
                end
            end
        end
        axSWD.XTick = 1:numel(groups); axSWD.XTickLabel = cellstr(groups); axSWD.XTickLabelRotation = 20;
        ylabel(axSWD, ylab); title(axSWD, 'SWD Analysis preview');

        % Build a two-part legend: treatment-group bar colors and the
        % metadata colors used for individual animal data points.
        legendHandles = gobjects(0,1);
        legendLabels = strings(0,1);
        for gi = 1:numel(groups)
            hLeg = scatter(axSWD, nan, nan, 46, 's', 'MarkerFaceColor', Cg(gi,:), ...
                'MarkerEdgeColor','k', 'DisplayName', char("Treatment group: " + groups(gi)));
            legendHandles(end+1,1) = hLeg; %#ok<AGROW>
            legendLabels(end+1,1) = "Treatment group: " + groups(gi); %#ok<AGROW>
        end
        colorFieldLabel = char(colorVar);
        try
            colorIdx = find(string(ddSWDColorBy.ItemsData) == colorVar, 1, 'first');
            if ~isempty(colorIdx), colorFieldLabel = char(string(ddSWDColorBy.Items{colorIdx})); end
        catch
        end
        for ci = 1:numel(dotCats)
            hLeg = scatter(axSWD, nan, nan, 38, 'o', 'MarkerFaceColor', Cd(ci,:), ...
                'MarkerEdgeColor','k', 'DisplayName', sprintf('%s: %s', colorFieldLabel, char(dotCats(ci))));
            legendHandles(end+1,1) = hLeg; %#ok<AGROW>
            legendLabels(end+1,1) = string(colorFieldLabel) + ": " + dotCats(ci); %#ok<AGROW>
        end
        legend(axSWD, legendHandles, cellstr(legendLabels), 'Location','best', 'Interpreter','none');
        grid(axSWD,'on'); hold(axSWD,'off');
    end

    function onSWDOpenWindow()
        h = figure('Color','w','Name','SWD preview');
        ax = axes('Parent', h);
        copyobj(allchild(axSWD), ax);
        title(ax, axSWD.Title.String, 'Interpreter','none');
        ylabel(ax, axSWD.YLabel.String);
        set(ax, 'XTick', axSWD.XTick, 'XTickLabel', axSWD.XTickLabel, 'XTickLabelRotation', axSWD.XTickLabelRotation);
        grid(ax,'on');
        try, lgd = legend(ax, 'show'); lgd.Location = 'best'; lgd.Interpreter = 'none'; catch, end
    end

    function onSWDSavePlotData()
        outDir = meeg_outdir(project,'qeeg','SWD Analysis');
        if ~isfolder(outDir), mkdir(outDir); end
        f = figure('Visible','off','Color','w'); ax = axes('Parent', f);
        copyobj(allchild(axSWD), ax);
        title(ax, axSWD.Title.String, 'Interpreter','none');
        ylabel(ax, axSWD.YLabel.String);
        set(ax, 'XTick', axSWD.XTick, 'XTickLabel', axSWD.XTickLabel, 'XTickLabelRotation', axSWD.XTickLabelRotation); grid(ax,'on');
        try, lgd = legend(ax, 'show'); lgd.Location = 'best'; lgd.Interpreter = 'none'; catch, end
        stamp = datestr(now,'yyyymmdd_HHMMSS');
        outPng = fullfile(outDir, sprintf('SWD_%s_%s_%s.png', char(ddSWDMetric.Value), char(ddSWDTime.Value), stamp));
        meeg_save_png_svg(f, outPng, 'Resolution', 300); close(f);
        T = meeg_swd_collect_per_animal(project, ddSWDTime.Value, edtDayStart.Value, edtDayEnd.Value);
        try
            [displayValue, displayUnits] = localSWDMetricValues(T, string(ddSWDMetric.Value), double(ddSWDScale.Value));
            T.DisplayValue = displayValue;
            T.DisplayUnits = repmat(string(displayUnits), height(T), 1);
            writetable(T, fullfile(outDir, sprintf('SWD_%s_%s_data_%s.xlsx', char(ddSWDMetric.Value), char(ddSWDTime.Value), stamp)), 'FileType', 'spreadsheet');
        catch
        end
        swdlogmsg(['Saved SWD plot and data to ' outDir]);
    end

    function [y, ylab] = localSWDMetricValues(T, metric, scaleHours)
        % Convert raw per-animal totals to the selected equivalent rate.
        % Correct relationship: displayed value = observed total / actual
        % selected recording exposure * requested display interval.
        n = height(T);
        y = nan(n,1);
        metric = string(metric);
        scaleHours = double(scaleHours);
        if ~isfinite(scaleHours) || scaleHours <= 0
            scaleHours = 0.5;
        end

        exposureHours = nan(n,1);
        if ismember('ExposureHours', T.Properties.VariableNames)
            exposureHours = double(T.ExposureHours);
        elseif ismember('TotalHours', T.Properties.VariableNames)
            exposureHours = double(T.TotalHours);
        end
        validExposure = isfinite(exposureHours) & exposureHours > 0;

        switch metric
            case "count"
                raw = double(T.Count);
                y(validExposure) = raw(validExposure) ./ exposureHours(validExposure) .* scaleHours;
                ylab = sprintf('SWD count per %g h', scaleHours);
            case "duration"
                rawMin = double(T.DurationSec) ./ 60;
                y(validExposure) = rawMin(validExposure) ./ exposureHours(validExposure) .* scaleHours;
                ylab = sprintf('SWD duration (min) per %g h', scaleHours);
            case "meanduration"
                y = double(T.MeanDurationSec);
                ylab = 'Average SWD duration (sec)';
            case "meanfreq"
                y = double(T.MeanDominantFreqHz);
                ylab = 'Average SWD dominant frequency (Hz)';
            otherwise
                y = double(T.BurdenPct);
                ylab = 'SWD burden (%)';
        end
    end

    function onSWDViewerLoad()
        prefixes = strings(0,1); evDir = strings(0,1);
        try
            if isfield(project,'animals') && ~isempty(project.animals)
                prefixes = string({project.animals.prefix})';
            end
        catch
        end
        have = strings(0,1);
        for i = 1:numel(prefixes)
            f = fullfile(meeg_outdir(project,'qeeg', char(prefixes(i))), char(prefixes(i)) + "_swd_events.xlsx");
            if isfile(f), have(end+1,1) = prefixes(i); evDir(end+1,1) = string(f); end %#ok<AGROW>
        end
        if isempty(have)
            swdViewerTable = table(); swdViewerFile = ""; swdViewerRowMap = [];
            lbSWD.Items = {'No SWD events loaded yet'}; lbSWD.ItemsData = {};
            txtSWDInfo.Value = {'No SWD events found. Run SWD analysis first.'};
            cla(axSWDV); title(axSWDV, 'SWD event summary');
            return;
        end
        ddSWDAnimal.Items = cellstr(have);
        if ~ismember(string(ddSWDAnimal.Value), have), ddSWDAnimal.Value = ddSWDAnimal.Items{1}; end
        idx = find(have == string(ddSWDAnimal.Value), 1);
        swdViewerFile = evDir(idx);
        try
            T = readtable(swdViewerFile, 'TextType','string');
        catch
            T = readtable(swdViewerFile);
        end
        T = meeg_swd_normalize_review_columns(T);
        swdViewerTable = T;
        onSWDViewerSelectionChanged();
    end

    function onSWDViewerSelectionChanged()
        TAll = swdViewerTable;
        if isempty(TAll) || height(TAll)==0
            swdViewerRowMap = [];
            lbSWD.Items = {'No SWD events for selected animal'}; lbSWD.ItemsData = {};
            txtSWDInfo.Value = {'No SWD events for selected animal.'};
            cla(axSWDV); title(axSWDV, 'SWD event summary');
            return;
        end

        % Preserve the currently selected source-table row whenever it remains
        % visible after a refresh.
        previousSourceRow = NaN;
        try
            candidateValue = lbSWD.Value;
            if isnumeric(candidateValue) && isscalar(candidateValue)
                previousSourceRow = double(candidateValue);
            end
        catch
        end

        sourceRows = (1:height(TAll))';
        mask = true(height(TAll),1);
        if ismember('LeadLabel', TAll.Properties.VariableNames)
            leads = unique(["(all leads)"; string(TAll.LeadLabel)], 'stable');
            ddSWDLead.Items = cellstr(leads);
            if ~ismember(string(ddSWDLead.Value), leads), ddSWDLead.Value = ddSWDLead.Items{1}; end
            if string(ddSWDLead.Value) ~= "(all leads)"
                mask = mask & string(TAll.LeadLabel)==string(ddSWDLead.Value);
            end
        end
        if ismember('IsDay', TAll.Properties.VariableNames)
            switch char(string(ddSWDVTime.Value))
                case 'day', mask = mask & local_swd_logical_values(TAll.IsDay, false);
                case 'night', mask = mask & ~local_swd_logical_values(TAll.IsDay, false);
            end
        end
        switch char(string(ddSWDShow.Value))
            case 'included', mask = mask & logical(TAll.UserIncluded);
            case 'rejected', mask = mask & ~logical(TAll.UserIncluded);
        end

        T = TAll(mask,:);
        sourceRows = sourceRows(mask);
        swdViewerRowMap = sourceRows;
        if isempty(T)
            lbSWD.Items = {'No SWD events match current filter'}; lbSWD.ItemsData = {};
            txtSWDInfo.Value = {'No SWD events match current filter.'};
            cla(axSWDV); title(axSWDV, 'SWD event summary');
            return;
        end

        items = cell(height(T),1);
        for i = 1:height(T)
            manualReview = startsWith(lower(string(T.UserDecision(i))), "user-") || ...
                startsWith(lower(string(T.UserDecision(i))), "manual-");
            reviewSource = ternary(manualReview, 'manual', 'automatic');
            items{i} = sprintf('%d) %.2fs | %.2fs | auto: %s | review: %s (%s)', i, ...
                double(T.StartSec(i)), double(T.DurationSec(i)), ...
                ternary(logical(T.AutoIncluded(i)),'pass','reject'), ...
                ternary(logical(T.UserIncluded(i)),'KEEP','EXCLUDE'), reviewSource);
        end
        lbSWD.Items = items;
        lbSWD.ItemsData = num2cell(sourceRows(:)');
        if isfinite(previousSourceRow) && any(sourceRows==previousSourceRow)
            lbSWD.Value = previousSourceRow;
        else
            lbSWD.Value = sourceRows(1);
        end

        sourceRow = double(lbSWD.Value);
        if sourceRow < 1 || sourceRow > height(TAll), return; end
        row = TAll(sourceRow,:);
        txtSWDInfo.Value = {sprintf('Animal: %s', char(ddSWDAnimal.Value)), sprintf('Lead: %s', char(row.LeadLabel)), ...
            sprintf('Start: %.2f s | Duration: %.2f s | Frequency: %.2f Hz', row.StartSec, row.DurationSec, row.DominantFreqHz), ...
            sprintf('Amplitude (peak-to-peak): %.2f uV | Cycles: %.0f', local_swd_row_value(row,'PeakToPeak',NaN), local_swd_row_value(row,'PeakCount',NaN)), ...
            sprintf('Envelope z: %.3f | Rhythmicity: %.3f | Harmonic: %.3f | Artifact: %.3f', ...
                local_swd_row_value(row,'EnvelopeZ',NaN), local_swd_row_value(row,'RhythmicityScore',NaN), ...
                local_swd_row_value(row,'HarmonicScore',NaN), local_swd_row_value(row,'ArtifactScore',NaN)), ...
            sprintf('Automatic decision: %s (score %.0f)', ternary(logical(row.AutoIncluded),'PASS','REJECT'), local_swd_row_value(row,'ConfidenceScore',NaN)), ...
            sprintf('Manual/current decision: %s | %s', ternary(logical(row.UserIncluded),'KEEP','EXCLUDE'), char(string(row.UserDecision)))};
        local_plot_swd_viewer_snippet(row);
    end

    function local_plot_swd_viewer_snippet(row)
        cla(axSWDV);
        try
            prefix = char(ddSWDAnimal.Value);
            [a,~] = meeg_project_get_animal(project, prefix);
            if isempty(a) || ~isfield(a,'files') || isempty(a.files)
                error('Raw/cache files are not available for this animal.');
            end
            files = a.files;
            try, files = local_resolve_existing_files(files, prefix); catch, end
            if isfield(project,'profile')
                profile = project.profile;
            else
                profile = meeg_getSystemProfile(project.systemId);
            end
            fs = edtSWDFs.Value;
            ch = 1;
            if ismember('LeadIndex', row.Properties.VariableNames)
                ch = max(1, round(double(row.LeadIndex)));
            end
            winSec = max(double(edtSWDWin.Value), double(row.DurationSec) + 1);
            nSamp = max(10, round(winSec * fs));
            center = round((double(row.StartSample) + double(row.EndSample)) / 2);
            startSample = max(1, center - floor(nSamp/2));
            scale_uV = 1;
            try, scale_uV = profile.scale_uV; catch, end
            [tsec, Y] = meeg_spike_read_snippet(files, ch, startSample, nSamp, fs, scale_uV, false);
            yRaw = Y(1,:);
            t0 = (double(row.StartSample) - startSample) / fs;
            t1 = (double(row.EndSample) - startSample) / fs;
            relT = tsec;
            try
                f1 = max(0.1, edtSWDFmin.Value);
                f2 = min(fs/2-1, edtSWDFmax.Value);
                if f2 > f1
                    d = designfilt('bandpassiir','FilterOrder',4, ...
                        'HalfPowerFrequency1', f1, 'HalfPowerFrequency2', f2, ...
                        'DesignMethod','butter','SampleRate',fs);
                    yFilt = filtfilt(d, double(yRaw(:)));
                else
                    yFilt = double(yRaw(:));
                end
            catch
                yFilt = double(yRaw(:));
            end
            yFilt = yFilt(:)';
            hold(axSWDV,'on');
            plot(axSWDV, relT, yRaw, 'Color', [0.35 0.35 0.35], 'LineWidth', 0.8);
            offset = max(abs(yRaw), [], 'omitnan');
            if isempty(offset) || ~isfinite(offset) || offset==0, offset = 1; end
            plot(axSWDV, relT, yFilt + 1.25*offset, 'Color', [0.85 0.1 0.1], 'LineWidth', 1.1);
            yl = ylim(axSWDV);
            patch(axSWDV, [t0 t1 t1 t0], [yl(1) yl(1) yl(2) yl(2)], [1.0 0.86 0.35], ...
                'FaceAlpha', 0.18, 'EdgeColor', 'none');
            plot(axSWDV, relT, yRaw, 'Color', [0.35 0.35 0.35], 'LineWidth', 0.8);
            plot(axSWDV, relT, yFilt + 1.25*offset, 'Color', [0.85 0.1 0.1], 'LineWidth', 1.1);
            xline(axSWDV, t0, 'k--');
            xline(axSWDV, t1, 'k--');
            hold(axSWDV,'off');
            grid(axSWDV,'on');
            xlabel(axSWDV, 'Time from snippet start (sec)');
            ylabel(axSWDV, 'uV (filtered trace offset)');
            title(axSWDV, sprintf('%s — %s SWD %.2f–%.2f s', prefix, char(row.LeadLabel), row.StartSec, row.EndSec), 'Interpreter','none');
            legend(axSWDV, {'Raw','SWD-band filtered'}, 'Location','best');
        catch ME
            axis(axSWDV,'on');
            text(axSWDV, 0.5, 0.66, sprintf('SWD event at %.2f s', row.StartSec), 'Units','normalized', 'HorizontalAlignment','center');
            text(axSWDV, 0.5, 0.52, sprintf('Duration %.2f s | Freq %.2f Hz', row.DurationSec, row.DominantFreqHz), 'Units','normalized', 'HorizontalAlignment','center');
            text(axSWDV, 0.5, 0.38, sprintf('Status: %s', ternary(logical(row.UserIncluded),'included in analyses','rejected from analyses')), 'Units','normalized', 'HorizontalAlignment','center');
            text(axSWDV, 0.5, 0.24, ['Snippet unavailable: ' char(string(ME.message))], 'Units','normalized', 'HorizontalAlignment','center', 'Interpreter','none');
            title(axSWDV, 'SWD event summary'); grid(axSWDV,'on');
        end
    end

    function onSWDRejectCurrent()
        local_set_swd_current_inclusion(false, "user-excluded");
    end

    function onSWDRestoreCurrent()
        local_set_swd_current_inclusion(true, "user-kept");
    end

    function local_set_swd_current_inclusion(tf, decision)
        try
            if isempty(swdViewerTable) || isempty(lbSWD.ItemsData), return; end
            sourceRow = double(lbSWD.Value);
            if isempty(sourceRow) || ~isfinite(sourceRow), return; end

            T = meeg_swd_normalize_review_columns(swdViewerTable);
            sourceRow = round(sourceRow(1));
            if sourceRow < 1 || sourceRow > height(T), return; end

            T.UserIncluded(sourceRow) = logical(tf);
            T.UserDecision(sourceRow) = string(decision);
            T.ReviewTimestamp(sourceRow) = string(datestr(now, 'yyyy-mm-dd HH:MM:SS'));

            % Do not silently ignore save failures. SWD Analysis and the
            % Threshold Assistant both read this workbook, so persistence is
            % required before the in-memory state is accepted.
            try
                writetable(T, swdViewerFile, 'FileType', 'spreadsheet');
            catch saveME
                error('Could not save the SWD review update to %s. Close the workbook if it is open in Excel, then try again. %s', ...
                    char(swdViewerFile), saveME.message);
            end

            swdViewerTable = T;

            % If the new decision would remove the reviewed event from the
            % active Keep-only or Exclude-only filter, switch to All candidates
            % so the same event remains selected and its manual status is
            % immediately visible in the refreshed list.
            showMode = string(ddSWDShow.Value);
            if (~logical(tf) && showMode == "included") || (logical(tf) && showMode == "rejected")
                ddSWDShow.Value = 'all';
            end
            onSWDViewerSelectionChanged();
            onSWDLoad();

            swdlogmsg("SWD review updated: " + string(ddSWDAnimal.Value) + ...
                " candidate at " + string(double(T.StartSec(sourceRow))) + " sec -> " + string(decision));
        catch ME
            swdlogmsg('SWD review update error: ' + string(ME.message));
            try, uialert(fig, char(string(ME.message)), 'SWD review update error'); catch, end
        end
    end

    function tf = local_swd_logical_values(v, defaultValue)
        % Small viewer-side wrapper for legacy IsDay columns. The shared
        % review normalizer handles review-state fields; this keeps old Excel
        % files with text/numeric IsDay values filterable as well.
        if nargin < 2, defaultValue = false; end
        n = numel(v); tf = repmat(logical(defaultValue), n, 1);
        if islogical(v), tf = v(:); return; end
        if isnumeric(v), tf = isfinite(v(:)) & v(:) ~= 0; return; end
        s = lower(strtrim(string(v(:))));
        tf(ismember(s,["true","1","yes","y","day"])) = true;
        tf(ismember(s,["false","0","no","n","night"])) = false;
    end

    function onSWDExportFeatureList()
        try
            outDir = meeg_outdir(project,'qeeg','SWD Analysis');
            if ~isfolder(outDir), mkdir(outDir); end
            defaultFile = fullfile(outDir, "SWD_reviewed_feature_list_" + string(datestr(now,'yyyymmdd_HHMMSS')) + ".xlsx");
            [file,path] = uiputfile('*.xlsx','Export SWD feature list',defaultFile);
            if isequal(file,0), return; end
            outFile = meeg_swd_export_feature_list(project, fullfile(path,file));
            swdlogmsg("Exported SWD feature list: " + string(outFile));
            uialert(fig, "Saved SWD feature workbook:\n" + string(outFile), 'SWD feature export');
        catch ME
            swdlogmsg("SWD feature export error: " + string(ME.message));
            try, uialert(fig,ME.message,'SWD feature export error'); catch, end
        end
    end

    function onSWDThresholdAssistant()
        try
            current = local_current_swd_threshold_settings();
            meeg_swd_threshold_assistant(project,current,@local_apply_swd_threshold_suggestions);
        catch ME
            swdlogmsg("SWD Threshold Assistant error: " + string(ME.message));
            try, uialert(fig,ME.message,'SWD Threshold Assistant'); catch, end
        end
    end

    function S = local_current_swd_threshold_settings()
        S = struct();
        S.minDurSec = double(edtSWDMinDur.Value);
        S.minPeaks = double(edtSWDMinGap.Value);
        S.envZ = double(edtSWDZ.Value);
        S.minRhythmScore = double(edtSWDMerge.Value);
        S.minHarmonicScore = double(edtSWDHarm.Value);
        S.maxArtifactScore = double(edtSWDArtifactScore.Value);
    end

    function local_apply_swd_threshold_suggestions(R)
        if isempty(R), return; end
        applied = strings(0,1);
        for ri = 1:height(R)
            field = string(R.Field(ri));
            value = double(R.SuggestedThreshold(ri));
            if ~isfinite(value), continue; end
            switch field
                case "DurationSec"
                    edtSWDMinDur.Value = local_clamp_ui_value(edtSWDMinDur,value);
                    applied(end+1,1) = sprintf('Minimum duration = %.3g s',edtSWDMinDur.Value); %#ok<AGROW>
                case "PeakCount"
                    edtSWDMinGap.Value = local_clamp_ui_value(edtSWDMinGap,round(value));
                    applied(end+1,1) = sprintf('Minimum cycles = %.0f',edtSWDMinGap.Value); %#ok<AGROW>
                case "EnvelopeZ"
                    edtSWDZ.Value = local_clamp_ui_value(edtSWDZ,value);
                    applied(end+1,1) = sprintf('Envelope z = %.3g',edtSWDZ.Value); %#ok<AGROW>
                case "RhythmicityScore"
                    edtSWDMerge.Value = local_clamp_ui_value(edtSWDMerge,value);
                    applied(end+1,1) = sprintf('Rhythmicity = %.3g',edtSWDMerge.Value); %#ok<AGROW>
                case "HarmonicScore"
                    edtSWDHarm.Value = local_clamp_ui_value(edtSWDHarm,value);
                    applied(end+1,1) = sprintf('Harmonic score = %.3g',edtSWDHarm.Value); %#ok<AGROW>
                case "ArtifactScore"
                    edtSWDArtifactScore.Value = local_clamp_ui_value(edtSWDArtifactScore,value);
                    applied(end+1,1) = sprintf('Maximum artifact score = %.3g',edtSWDArtifactScore.Value); %#ok<AGROW>
            end
        end
        if ~isempty(applied)
            msg = "Applied suggested SWD settings controls only. No analysis was started.\n\n" + strjoin(applied,newline);
            swdlogmsg("Threshold Assistant applied settings: " + strjoin(applied,"; "));
            try, uialert(fig,msg,'SWD thresholds applied'); catch, end
        end
    end

    function v = local_clamp_ui_value(ctrl,v)
        try
            lim = double(ctrl.Limits);
            v = min(max(double(v),lim(1)),lim(2));
        catch
            v = double(v);
        end
    end

    function v = local_swd_row_value(row,name,defaultVal)
        v = defaultVal;
        try
            if ismember(name,row.Properties.VariableNames)
                v = double(row.(name)(1));
            end
        catch
            v = defaultVal;
        end
    end

    function out = ternary(tf, a, b)
        if tf, out = a; else, out = b; end
    end

    function onSWDViewerPrev()
        try
            vals = lbSWD.ItemsData; cur = lbSWD.Value; idx = find([vals{:}] == cur, 1); if isempty(idx), return; end
            idx = max(1, idx-1); lbSWD.Value = vals{idx}; onSWDViewerSelectionChanged();
        catch
        end
    end

    function onSWDViewerNext()
        try
            vals = lbSWD.ItemsData; cur = lbSWD.Value; idx = find([vals{:}] == cur, 1); if isempty(idx), return; end
            idx = min(numel(vals), idx+1); lbSWD.Value = vals{idx}; onSWDViewerSelectionChanged();
        catch
        end
    end


    function fs0 = localRawDefaultFs()
        fs0 = 2500;
        try
            if isfield(project,'profile') && isfield(project.profile,'defaultFs') && ~isempty(project.profile.defaultFs)
                fs0 = max(1, double(project.profile.defaultFs));
            elseif exist('edtFsQ','var') && isvalid(edtFsQ)
                fs0 = max(1, double(edtFsQ.Value));
            end
        catch
            fs0 = 2500;
        end
    end



    function appendEvtLog(msg)
        try
            txtEvtLog.Value = [txtEvtLog.Value; {char(string(msg))}];
            txtEvtLog.Value = txtEvtLog.Value(max(1,end-400):end);
            drawnow limitrate;
        catch
        end
        logmsg(msg);
    end

    function onRunEventDetect()
        try
            evtOpts = struct();
            evtOpts.fs = double(edtEvtFs.Value);
            evtOpts.baselineWinSec = double(edtEvtBase.Value);
            evtOpts.candidateWinSec = double(edtEvtCand.Value);
            evtOpts.overlapFrac = double(edtEvtOverlap.Value);
            evtOpts.detrend = logical(chkEvtDetrend.Value);
            evtOpts.rmsZ = double(edtEvtRMS.Value);
            evtOpts.lineZ = double(edtEvtLine.Value);
            evtOpts.spikeRateZ = double(edtEvtSpike.Value);
            evtOpts.rhythmZ = double(edtEvtRhythm.Value);
            evtOpts.peakPromZ = double(edtEvtPeakProm.Value);
            evtOpts.maxPhysP2P_uV = double(edtEvtMaxP2P.Value);
            evtOpts.mergeGapSec = double(edtEvtMerge.Value);
            evtOpts.minDurSec = double(edtEvtMinDur.Value);
            evtOpts.chunkSec = 30 * 60;
            evtOpts.chunkOverlapSec = evtOpts.baselineWinSec;
            evtOpts.dayStart = edtDayStart.Value;
            evtOpts.dayEnd = edtDayEnd.Value;
            try, evtOpts.useParallel = license('test','Distrib_Computing_Toolbox'); catch, evtOpts.useParallel = false; end
            txtEvtLog.Value = {'=== Run Event Detection (beta) ==='};
            evtLogFile = localStartRunLog(meeg_outdir(project,'qeeg','Event Detection (beta)'), 'EventDetection_log', evtOpts);
            localSetActiveRunLog(evtLogFile);
            appendEvtLog(['Event Detection log file: ' char(evtLogFile)]);
            appendEvtLog(sprintf('Options: fs=%.1f, baseline=%.1fs, candidate=%.2fs, overlap=%.2f, detrend=%d', evtOpts.fs, evtOpts.baselineWinSec, evtOpts.candidateWinSec, evtOpts.overlapFrac, evtOpts.detrend));
            appendEvtLog(sprintf('Speed mode: %.1f-min blocks with %.1f-s local-baseline overlap; vectorized time-domain features + block spectrogram.', evtOpts.chunkSec/60, evtOpts.chunkOverlapSec));
            cleanupEvtUi = localAnalysisBusyLock('Event Detection'); %#ok<NASGU>
            meeg_eventdetect_runall(project, evtOpts, @(m) appendEvtLog(m));
            appendEvtLog('Event Detection finished.');
            localSetActiveRunLog('');
            try, onEventViewerLoad(); catch, end
            try, onEventAnalysisRefresh(); catch, end
        catch ME
            appendEvtLog("Event Detection error: " + string(ME.message));
            localSetActiveRunLog('');
            try, uialert(fig, char("Event Detection error: " + string(ME.message)), 'Event Detection'); catch, end
        end
    end

    function onEventViewerLoad()
        try
            if ~isfield(project,'manifest') || isempty(project.manifest) || height(project.manifest)==0
                ddEvtAnimal.Items = {'(none)'}; ddEvtAnimal.Value = '(none)'; return;
            end
            [prefs, idxs0] = meeg_manifest_get_animal_prefixes(project.manifest);
            prefs = string(prefs(:)); idxs0 = idxs0(:);
            keepInc = true(size(prefs));
            try
                if ismember('Include', project.manifest.Properties.VariableNames)
                    keepInc = logical(project.manifest.Include(idxs0));
                end
            catch
            end
            prefs = prefs(keepInc);
            outDirEvt = meeg_outdir(project,'qeeg','Event Detection (beta)');
            hasFiles = false(size(prefs));
            for pp = 1:numel(prefs)
                safePrefix = regexprep(char(prefs(pp)), '[^a-zA-Z0-9_\-]', '_');
                hasFiles(pp) = isfile(fullfile(outDirEvt, sprintf('%s_event_detection_events.xlsx', safePrefix)));
            end
            prefs = prefs(hasFiles);
            prefs(prefs=="")=[];
            if isempty(prefs)
                ddEvtAnimal.Items={'(none)'}; ddEvtAnimal.Value='(none)';
                ddEvtLead.Items = {'(all leads)'}; ddEvtLead.Value = '(all leads)';
                lbEvt.Items = {'No events detected yet'}; lbEvt.ItemsData = 1; lbEvt.Value = 1;
                cla(axEvt); title(axEvt,'Event snippet');
                txtEvtInfo.Value = {'No events saved for any included animal yet.'};
                return;
            end
            ddEvtAnimal.Items = cellstr(prefs(:));
            if ~ismember(string(ddEvtAnimal.Value), prefs)
                ddEvtAnimal.Value = ddEvtAnimal.Items{1};
            end
            prefix = string(ddEvtAnimal.Value);
            if prefix=="(none)", return; end
            eventViewerFile = localEventEventFile(prefix);
            T = localReadEventTable(eventViewerFile);
            if isempty(T)
                eventViewerTable = localEmptyEventTable();
                lbEvt.Items = {'No events detected yet'}; lbEvt.ItemsData = 1; lbEvt.Value = 1;
                ddEvtLead.Items = {'(all leads)'}; ddEvtLead.Value = '(all leads)';
                cla(axEvt); title(axEvt,'Event snippet');
                txtEvtInfo.Value = {'No events saved for this animal yet.'};
                return;
            end
            eventViewerTable = T;
            leadItems = unique(cellstr(string(T.LeadLabel)), 'stable');
            ddEvtLead.Items = [{'(all leads)'} leadItems(:)'];
            if ~any(strcmp(ddEvtLead.Items, char(string(ddEvtLead.Value)))), ddEvtLead.Value='(all leads)'; end
            idx = true(height(T),1);
            if string(ddEvtLead.Value) ~= "(all leads)", idx = idx & string(T.LeadLabel)==string(ddEvtLead.Value); end
            switch string(ddEvtShow.Value)
                case "included", idx = idx & logical(T.UserIncluded);
                case "rejected", idx = idx & ~logical(T.UserIncluded);
            end
            if ismember('StartHour', T.Properties.VariableNames)
                hrs = double(T.StartHour);
                keep = localSelectHoursSimple(hrs, string(ddEvtTime.Value), edtDayStart.Value, edtDayEnd.Value);
                idx = idx & keep;
            end
            if exist('ddEvtVType','var') && string(ddEvtVType.Value) ~= "all" && ismember('Reason', T.Properties.VariableNames)
                evtFilter = string(ddEvtVType.Value);
                if evtFilter == "mixed abnormality"
                    idx = idx & localEventMixedMask(T);
                else
                    idx = idx & string(T.Reason)==evtFilter;
                end
            end
            eventViewerRowMap = find(idx);
            if isempty(eventViewerRowMap)
                lbEvt.Items = {'No events match current filter'}; lbEvt.ItemsData = 1; lbEvt.Value = 1; cla(axEvt); title(axEvt,'Event snippet'); return;
            end
            items = cell(numel(eventViewerRowMap),1);
            ids = 1:numel(eventViewerRowMap);
            for kk=1:numel(eventViewerRowMap)
                rr = eventViewerRowMap(kk);
                status = ternary(logical(T.UserIncluded(rr)), 'included', 'rejected');
                items{kk} = sprintf('#%d  %s  %.2f–%.2f s  [%s]  %s', rr, char(string(T.Reason(rr))), double(T.StartSec(rr)), double(T.EndSec(rr)), status, char(string(T.LeadLabel(rr))));
            end
            lbEvt.Items = items; lbEvt.ItemsData = ids; lbEvt.Value = ids(1);
            onEventViewerSelectionChanged();
        catch ME
            try, uialert(fig, sprintf('Could not load event viewer data:\n%s', ME.message), 'Event Viewer'); catch, end
        end
    end

    function onEventViewerSelectionChanged()
        try
            if isempty(eventViewerRowMap) || isempty(eventViewerTable) || ~istable(eventViewerTable), return; end
            idx = lbEvt.Value; if iscell(idx), idx = idx{1}; end
            if isempty(idx) || isnan(idx) || idx<1 || idx>numel(eventViewerRowMap), return; end
            rr = eventViewerRowMap(idx); T = eventViewerTable; prefix = string(ddEvtAnimal.Value);
            [a,~] = meeg_project_get_animal(project, prefix); if isempty(a), return; end
            files = local_resolve_existing_files(a.files, prefix);
            labels = localRawLabels(a); if isempty(labels), labels = cellstr("Ch" + string(1:numel(files))); end
            leadIdx = find(strcmp(labels, char(string(T.LeadLabel(rr)))),1); if isempty(leadIdx), leadIdx = 1; end
            if isfield(a,'fs') && ~isempty(a.fs) && isfinite(double(a.fs)), fs = double(a.fs); else, fs = double(edtEvtFs.Value); end
            if ~isfinite(fs) || fs<=0, fs = double(edtEvtFs.Value); end
            win = max(0.5, double(edtEvtViewWin.Value));
            s = double(T.StartSec(rr)); e = double(T.EndSec(rr));
            st = max(0, s - win/2); ns = round(win*fs); ss = floor(st*fs)+1;
            [t, Y] = meeg_spike_read_snippet(files, leadIdx, ss, ns, fs, project.profile.scale_uV, true);
            tAbs = t + (ss-1)/fs;
            y = Y(1,:);
            cla(axEvt); hold(axEvt,'on');
            hRaw = plot(axEvt, tAbs, y, 'k-', 'LineWidth',0.9);
            yl = ylim(axEvt); patch(axEvt,[s e e s],[yl(1) yl(1) yl(2) yl(2)],[1 .85 .3],'FaceAlpha',0.15,'EdgeColor',[.9 .5 0],'LineStyle','--');
            title(axEvt, sprintf('Event snippet: %s (%s)', char(string(T.Reason(rr))), char(string(T.LeadLabel(rr)))), 'Interpreter','none');
            xlabel(axEvt,'Time (sec)'); ylabel(axEvt,'µV'); grid(axEvt,'on'); legend(axEvt, hRaw, {'Raw trace'}, 'Location','best'); hold(axEvt,'off');
            txtEvtInfo.Value = {sprintf('Animal: %s', char(prefix)), sprintf('Lead: %s', char(string(T.LeadLabel(rr)))), sprintf('Time: %.2f–%.2f sec', s, e), sprintf('Reason: %s', char(string(T.Reason(rr)))), sprintf('Status: %s', ternary(logical(T.UserIncluded(rr)),'included','rejected')), 'Display trace: raw snippet only.', sprintf('RMS z=%.2f  Line z=%.2f  Spike z=%.2f  Rhythm z=%.2f', double(T.RMS_Z(rr)), double(T.Line_Z(rr)), double(T.SpikeRate_Z(rr)), double(T.Rhythm_Z(rr)))};
        catch ME
            cla(axEvt); title(axEvt,'Event snippet'); txtEvtInfo.Value = {sprintf('Could not plot event snippet: %s', ME.message)};
        end
    end

    function onEventViewerPrev()
        try
            if isempty(lbEvt.ItemsData), return; end
            idx = lbEvt.Value; if iscell(idx), idx=idx{1}; end
            idx = max(1, idx-1); lbEvt.Value = idx; onEventViewerSelectionChanged();
        catch
        end
    end
    function onEventViewerNext()
        try
            if isempty(lbEvt.ItemsData), return; end
            idx = lbEvt.Value; if iscell(idx), idx=idx{1}; end
            idx = min(numel(eventViewerRowMap), idx+1); lbEvt.Value = idx; onEventViewerSelectionChanged();
        catch
        end
    end
    function onEventRejectCurrent(), onEventToggleCurrent(false); end
    function onEventRestoreCurrent(), onEventToggleCurrent(true); end
    function onEventToggleCurrent(tf)
        try
            idx = lbEvt.Value; if iscell(idx), idx=idx{1}; end
            if isempty(idx) || isnan(idx) || idx<1 || idx>numel(eventViewerRowMap), return; end
            rr = eventViewerRowMap(idx);
            eventViewerTable.UserIncluded(rr) = logical(tf);
            eventViewerTable.UserDecision(rr) = string(ternary(tf,'included','rejected'));
            eventViewerTable.ReviewTimestamp(rr) = string(datestr(now,'yyyy-mm-dd HH:MM:SS'));
            localWriteEventTable(eventViewerFile, eventViewerTable);
            onEventViewerLoad();
            try, lbEvt.Value = min(idx, numel(eventViewerRowMap)); end
            onEventViewerSelectionChanged();
        catch ME
            try, uialert(fig, sprintf('Could not update event state:\n%s', ME.message), 'Event Viewer'); catch, end
        end
    end

    function onEventAnalysisRefresh()
        try
            evtThresh = localEventAnalysisThresholds();
            T = meeg_eventdetect_collect_per_animal(project, string(ddEvtATime.Value), string(ddEvtMetric.Value), double(ddEvtScale.Value), string(ddEvtType.Value), evtThresh);
            setappdata(fig, 'EVT_ANALYSIS_TABLE', T);
            localPlotEventAnalysis(axEvtA, T, string(ddEvtMetric.Value), double(ddEvtScale.Value), string(ddEvtColor.Value));
            txtEvtAInfo.Value = {sprintf('Animals summarized: %d', numel(unique(string(T.Prefix)))), sprintf('Rows: %d', height(T))};
        catch ME
            cla(axEvtA); title(axEvtA,'Event Analysis preview');
            txtEvtAInfo.Value = {sprintf('Could not build event analysis: %s', ME.message)};
        end
    end

    function onEventAnalysisOpenWindow()
        T = getappdata(fig,'EVT_ANALYSIS_TABLE');
        if isempty(T), onEventAnalysisRefresh(); T = getappdata(fig,'EVT_ANALYSIS_TABLE'); end
        ftmp = figure('Color','w','Name','Event Analysis'); ax=axes(ftmp); localPlotEventAnalysis(ax,T,string(ddEvtMetric.Value),double(ddEvtScale.Value),string(ddEvtColor.Value));
    end

    function onEventAnalysisSave()
        try
            T = getappdata(fig,'EVT_ANALYSIS_TABLE');
            if isempty(T), onEventAnalysisRefresh(); T = getappdata(fig,'EVT_ANALYSIS_TABLE'); end
            outDir = meeg_outdir(project,'qeeg','Event Detection (beta)'); if ~isfolder(outDir), mkdir(outDir); end
            base = fullfile(outDir, sprintf('EventAnalysis_%s_%s_%s', char(string(ddEvtMetric.Value)), char(string(ddEvtATime.Value)), datestr(now,'yyyymmdd_HHMMSS')));
            figTmp = figure('Color','w','Visible','off'); ax=axes(figTmp); localPlotEventAnalysis(ax,T,string(ddEvtMetric.Value),double(ddEvtScale.Value),string(ddEvtColor.Value));
            meeg_save_png_svg(figTmp, [base '.png']);
            close(figTmp);
            writetable(T, [base '.xlsx']);
            txtEvtAInfo.Value = [txtEvtAInfo.Value; {sprintf('Saved: %s.png / .xlsx', base)}];
        catch ME
            try, uialert(fig, sprintf('Could not save Event Analysis outputs:\n%s', ME.message), 'Event Analysis'); catch, end
        end
    end

    function localPlotEventAnalysis(ax, T, metricName, yScaleHours, colorBy)
        cla(ax);
        if isempty(T) || height(T)==0
            title(ax,'Event Analysis preview'); text(ax,0.5,0.5,'No event-detection summaries found.','HorizontalAlignment','center'); return;
        end
        groups = unique(string(T.TreatmentGroup),'stable'); groups(groups=='')=[];
        leads = unique(string(T.LeadLabel),'stable'); leads(leads=='')=[];
        if isempty(groups) || isempty(leads), title(ax,'Event Analysis preview'); return; end
        Cg = meeg_get_group_colors(groups);
        mu = nan(numel(groups), numel(leads)); se = mu;
        for gi=1:numel(groups)
            for li=1:numel(leads)
                idx = string(T.TreatmentGroup)==groups(gi) & string(T.LeadLabel)==leads(li);
                y = T.Value(idx);
                mu(gi,li)=mean(y,'omitnan'); se(gi,li)=std(y,0,'omitnan')./max(1,sqrt(sum(~isnan(y))));
            end
        end
        hold(ax,'on');
        [~, xPos] = meeg_grouped_bar_manual(ax, mu', Cg, 0.78);
        for gi=1:numel(groups)
            errorbar(ax,xPos(:,gi)',mu(gi,:),se(gi,:),'k','LineStyle','none');
        end
        colorVar = string(colorBy); useVar = ismember(char(colorVar), T.Properties.VariableNames); if ~useVar, colorVar='TreatmentGroup'; end
        dotCats = unique(string(T.(char(colorVar))),'stable'); dotCats(dotCats=='')=[]; if isempty(dotCats), dotCats=groups; end
        Cd = meeg_get_metadata_colors(max(1,numel(dotCats))); rng(0);
        for li=1:numel(leads)
            for gi=1:numel(groups)
                idx = string(T.LeadLabel)==leads(li) & string(T.TreatmentGroup)==groups(gi);
                if ~any(idx), continue; end
                y=T.Value(idx); x=xPos(li,gi)+(rand(size(y))-0.5)*0.12; cats=string(T.(char(colorVar))(idx));
                for ci=1:numel(dotCats)
                    m = cats==dotCats(ci); if ~any(m), continue; end
                    scatter(ax,x(m),y(m),30,'MarkerFaceColor',Cd(ci,:),'MarkerEdgeColor','k');
                end
            end
        end
        ax.XLim=[0.5, numel(leads)+0.5]; ax.XTick=1:numel(leads); ax.XTickLabel=cellstr(leads); ax.XTickLabelRotation=25; grid(ax,'on');
        ylabel(ax, localEventMetricLabel(metricName, yScaleHours)); title(ax,'Event Analysis preview');
        dummyBar = gobjects(numel(groups),1);
        for gi=1:numel(groups)
            dummyBar(gi)=scatter(ax,nan,nan,40,'s','MarkerFaceColor',Cg(gi,:),'MarkerEdgeColor','k');
        end
        legend(ax, dummyBar, cellstr(groups), 'Location','best', 'Interpreter','none');
        hold(ax,'off');
    end

    function thresh = localEventAnalysisThresholds()
        thresh = struct('rmsZ',3.5,'lineZ',3.0,'spikeRateZ',3.0,'rhythmZ',2.5);
        try, thresh.rmsZ = double(edtEvtRMS.Value); catch, end
        try, thresh.lineZ = double(edtEvtLine.Value); catch, end
        try, thresh.spikeRateZ = double(edtEvtSpike.Value); catch, end
        try, thresh.rhythmZ = double(edtEvtRhythm.Value); catch, end
    end

    function tf = localEventMixedMask(T)
        tf = false(height(T),1);
        if height(T)==0, return; end
        thresh = localEventAnalysisThresholds();
        need = {'RMS_Z','Line_Z','SpikeRate_Z','Rhythm_Z'};
        if ~all(ismember(need, T.Properties.VariableNames))
            if ismember('Reason', T.Properties.VariableNames)
                tf = string(T.Reason)=="mixed abnormality" | string(T.Reason)=="mixed anomaly";
            end
            return;
        end
        M = [double(T.RMS_Z) >= thresh.rmsZ, double(T.Line_Z) >= thresh.lineZ, double(T.SpikeRate_Z) >= thresh.spikeRateZ, double(T.Rhythm_Z) >= thresh.rhythmZ];
        M(~isfinite(M)) = false;
        tf = sum(M,2) >= 2;
        if ismember('Reason', T.Properties.VariableNames)
            tf = tf | string(T.Reason)=="mixed abnormality" | string(T.Reason)=="mixed anomaly";
        end
    end

    function lbl = localEventMetricLabel(metricName, yScaleHours)
        switch char(metricName)
            case 'count', lbl = sprintf('Events per %.0f h', yScaleHours);
            case 'duration', lbl = sprintf('Event duration (sec) per %.0f h', yScaleHours);
            otherwise, lbl = 'Average event duration (sec)';
        end
    end

    function outDir = localEventDir()
        outDir = meeg_outdir(project,'qeeg','Event Detection (beta)');
        if ~isfolder(outDir), mkdir(outDir); end
    end
    function f = localEventEventFile(prefix)
        outDir = localEventDir();
        safePrefix = regexprep(char(string(prefix)), '[^a-zA-Z0-9_\-]', '_');
        f = string(fullfile(outDir, sprintf('%s_event_detection_events.xlsx', safePrefix)));
    end
    function T = localEmptyEventTable()
        T = table(string.empty(0,1), string.empty(0,1), zeros(0,1), zeros(0,1), zeros(0,1), zeros(0,1), zeros(0,1), zeros(0,1), zeros(0,1), zeros(0,1), zeros(0,1), true(0,1), string.empty(0,1), string.empty(0,1), string.empty(0,1), zeros(0,1), string.empty(0,1), ...
            'VariableNames', {'Prefix','LeadLabel','StartSec','EndSec','DurationSec','StartHour','RMS_Z','Line_Z','SpikeRate_Z','Rhythm_Z','PeakToPeak_uV','UserIncluded','UserDecision','Reason','PrimaryReason','FeatureCount','ReviewTimestamp'});
    end
    function T = localReadEventTable(f)
        if strlength(string(f)) == 0 || ~isfile(char(f)), T = localEmptyEventTable(); return; end
        try, T = readtable(char(f), 'TextType','string'); catch, T = localEmptyEventTable(); end
        req = localEmptyEventTable();
        for vn = string(req.Properties.VariableNames)
            if ~ismember(vn, string(T.Properties.VariableNames))
                switch char(vn)
                    case {'Prefix','LeadLabel','UserDecision','Reason','PrimaryReason','ReviewTimestamp'}
                        T.(char(vn)) = strings(height(T),1);
                    case 'UserIncluded'
                        T.(char(vn)) = true(height(T),1);
                    otherwise
                        T.(char(vn)) = nan(height(T),1);
                end
            end
        end
    end
    function localWriteEventTable(f,T)
        writetable(T, char(f));
    end
    function keep = localSelectHoursSimple(hours, timePoint, dayStart, dayEnd)
        keep = true(size(hours));
        tp = string(timePoint);
        if tp == "all", return; end
        isDay = false(size(hours));
        if dayStart < dayEnd
            isDay = hours >= dayStart & hours < dayEnd;
        else
            isDay = hours >= dayStart | hours < dayEnd;
        end
        if tp == "day", keep = isDay; elseif tp == "night", keep = ~isDay; end
    end
    function onRawLoadProject()
        try
            if ~isfield(project,'animals') || isempty(project.animals)
                ddRawAnimal.Items = {'(none)'};
                ddRawAnimal.Value = '(none)';
                txtRawInfo.Value = {'No animals with raw/cache files are loaded in this project.'};
                return;
            end
            prefixes = string({project.animals.prefix});
            prefixes(prefixes=="") = [];
            if isempty(prefixes)
                ddRawAnimal.Items = {'(none)'};
                ddRawAnimal.Value = '(none)';
                return;
            end
            ddRawAnimal.Items = cellstr(prefixes(:));
            ddRawAnimal.Value = ddRawAnimal.Items{1};
            onRawAnimalChanged();
        catch ME
            uialert(fig, sprintf('Could not load raw viewer project data:\n%s', ME.message), 'Raw Viewer');
        end
    end

    function onRawAnimalChanged()
        prefix = string(ddRawAnimal.Value);
        if prefix == "(none)", return; end
        [a,~] = meeg_project_get_animal(project, prefix);
        if isempty(a)
            txtRawInfo.Value = {'Selected animal could not be found in project.animals.'};
            return;
        end
        labels = localRawLabels(a);
        if isempty(labels)
            labels = cellstr("Ch" + string(1:numel(a.files)));
        end
        lbRawLeads.Items = labels;
        lbRawLeads.ItemsData = num2cell(1:numel(labels));
        lbRawLeads.Value = lbRawLeads.ItemsData(1:min(numel(labels), min(4,numel(labels))));
        ddRawAnnLead.Items = [{'(visible/all)'} labels(:)'];
        ddRawAnnLead.Value = '(visible/all)';
        if isfield(a,'fs') && ~isempty(a.fs) && isfinite(double(a.fs))
            edtRawFs.Value = double(a.fs);
        elseif isfield(project,'profile') && isfield(project.profile,'defaultFs') && ~isempty(project.profile.defaultFs)
            edtRawFs.Value = double(project.profile.defaultFs);
        end
        rawAnnotationFile = localRawAnnotationFile(prefix);
        rawAnnotations = localReadRawAnnotations(rawAnnotationFile);
        refreshRawAnnotationList();
        onRawPlot();
    end

    function labels = localRawLabels(a)
        labels = {};
        try
            if isfield(a,'fileOrder') && ~isempty(a.fileOrder)
                labels = cellstr(string(a.fileOrder(:))');
            elseif isfield(a,'assignedLabels') && ~isempty(a.assignedLabels)
                labels = cellstr(string(a.assignedLabels(:))');
            elseif isfield(project,'profile') && isfield(project.profile,'channelLabels')
                labels = cellstr(string(project.profile.channelLabels(:))');
            end
        catch
            labels = {};
        end
    end

    function onRawStep(direction)
        winSec = max(0.1, double(edtRawWin.Value));
        cur = max(0, double(edtRawStart.Value));
        edtRawStart.Value = max(0, cur + double(direction) * winSec * 0.80);
        onRawPlot();
    end

    function onRawPlot()
        try
            if strcmp(string(ddRawAnimal.Value), "(none)")
                cla(axRaw); title(axRaw, 'Raw Data Viewer'); return;
            end
            prefix = char(string(ddRawAnimal.Value));
            [a,~] = meeg_project_get_animal(project, prefix);
            if isempty(a) || ~isfield(a,'files') || isempty(a.files)
                txtRawInfo.Value = {'No raw/cache files found for selected animal.'};
                return;
            end
            files = local_resolve_existing_files(a.files, prefix);
            labels = localRawLabels(a);
            if isempty(labels), labels = cellstr("Ch" + string(1:numel(files))); end
            fs = double(edtRawFs.Value);
            if isfield(a,'fs') && ~isempty(a.fs) && isfinite(double(a.fs)), fs = double(a.fs); end
            if ~isfinite(fs) || fs <= 0, fs = 2500; end
            startSec = max(0, double(edtRawStart.Value));
            winSec = max(0.1, double(edtRawWin.Value));
            startSample = max(1, floor(startSec * fs) + 1);
            nSamp = max(10, round(winSec * fs));
            chVal = lbRawLeads.Value;
            if isempty(chVal), return; end
            if iscell(chVal)
                chIdx = cell2mat(chVal);
            else
                chIdx = chVal;
            end
            chIdx = double(chIdx(:)');
            chIdx = chIdx(chIdx>=1 & chIdx<=numel(files));
            if isempty(chIdx), return; end
            [t, Y] = meeg_spike_read_snippet(files, chIdx, startSample, nSamp, fs, project.profile.scale_uV, chkRawNotch.Value);
            tAbs = t + (startSample-1)/fs;
            maxPts = max(500, round(double(edtRawMaxPts.Value)));
            stride = max(1, ceil(numel(tAbs)/maxPts));
            tPlot = tAbs(1:stride:end);
            Yp = Y(:,1:stride:end);
            cla(axRaw); hold(axRaw,'on');
            nLead = size(Yp,1);
            amp = prctile(abs(Yp(:)), 95);
            if isempty(amp) || ~isfinite(amp) || amp <= 0, amp = max(abs(Yp(:))); end
            if isempty(amp) || ~isfinite(amp) || amp <= 0, amp = 1; end
            sep = max(1, 3*amp);
            cols = lines(max(1,nLead));
            for ii = 1:nLead
                yy = Yp(ii,:) + (nLead-ii)*sep;
                plot(axRaw, tPlot, yy, 'LineWidth', 0.8, 'Color', cols(ii,:));
                text(axRaw, tPlot(1), (nLead-ii)*sep, labels{chIdx(ii)}, 'Interpreter','none', ...
                    'VerticalAlignment','bottom', 'FontSize', 10, 'Color', cols(ii,:));
            end
            xlabel(axRaw, 'Time from recording start (sec)');
            ylabel(axRaw, 'Signal (µV, vertically offset)');
            title(axRaw, sprintf('Raw viewer: %s   %.2f–%.2f sec', prefix, startSec, startSec+winSec), 'Interpreter','none');
            grid(axRaw,'on');
            xlim(axRaw, [startSec startSec+winSec]);
            localRawOverlayAnnotations(prefix, startSec, startSec+winSec, labels(chIdx));
            hold(axRaw,'off');
            txtRawInfo.Value = {sprintf('Animal: %s', prefix), sprintf('Displayed leads: %s', strjoin(labels(chIdx), ', ')), ...
                sprintf('Window: %.2f to %.2f sec | fs=%.1f Hz | displayed every %d sample(s)', startSec, startSec+winSec, fs, stride), ...
                sprintf('Annotation file: %s', char(rawAnnotationFile))};
        catch ME
            cla(axRaw);
            title(axRaw, 'Raw Data Viewer');
            txtRawInfo.Value = {sprintf('Could not plot raw traces: %s', ME.message), ...
                'If raw files were moved, reopen the project from its original folder or copy the raw/cache files back into the project.'};
        end
    end

    function localRawOverlayAnnotations(prefix, t0, t1, visibleLabels)
        try
            if isempty(rawAnnotations) || height(rawAnnotations)==0, return; end
            T = rawAnnotations;
            if ismember('UserIncluded', T.Properties.VariableNames)
                % Show both included and excluded, with excluded lighter.
            else
                T.UserIncluded = true(height(T),1);
            end
            yl = ylim(axRaw);
            for rr = 1:height(T)
                if string(T.Prefix(rr)) ~= string(prefix), continue; end
                s = double(T.StartSec(rr)); e = double(T.EndSec(rr));
                if ~isfinite(s) || ~isfinite(e) || e < t0 || s > t1, continue; end
                lead = string(T.LeadLabel(rr));
                if lead ~= "(visible/all)" && ~any(string(visibleLabels) == lead), continue; end
                inc = true;
                if ismember('UserIncluded', T.Properties.VariableNames), inc = logical(T.UserIncluded(rr)); end
                if inc
                    fc = [1.0 0.70 0.20]; alpha = 0.13; lc = [0.85 0.40 0.00];
                else
                    fc = [0.8 0.8 0.8]; alpha = 0.10; lc = [0.45 0.45 0.45];
                end
                patch(axRaw, [max(s,t0) min(e,t1) min(e,t1) max(s,t0)], [yl(1) yl(1) yl(2) yl(2)], fc, ...
                    'FaceAlpha', alpha, 'EdgeColor', lc, 'LineStyle','--', 'HitTest','off');
                text(axRaw, max(s,t0), yl(2), char(string(T.EventType(rr))), 'Interpreter','none', ...
                    'VerticalAlignment','top', 'FontSize', 9, 'Color', lc, 'BackgroundColor','w', 'Margin', 1);
            end
        catch
        end
    end

    function onRawUseWindowForAnnotation()
        edtRawAnnStart.Value = max(0, double(edtRawStart.Value));
        edtRawAnnEnd.Value = max(edtRawAnnStart.Value + 0.001, double(edtRawStart.Value) + double(edtRawWin.Value));
    end

    function onRawAddAnnotation()
        try
            if strcmp(string(ddRawAnimal.Value), "(none)")
                uialert(fig, 'Select an animal first.', 'Raw Annotation'); return;
            end
            prefix = string(ddRawAnimal.Value);
            rawAnnotationFile = localRawAnnotationFile(prefix);
            rawAnnotations = localReadRawAnnotations(rawAnnotationFile);
            s = double(edtRawAnnStart.Value); e = double(edtRawAnnEnd.Value);
            if ~isfinite(s) || ~isfinite(e) || e <= s
                uialert(fig, 'Event end time must be greater than event start time.', 'Raw Annotation'); return;
            end
            if isempty(rawAnnotations)
                rawAnnotations = localEmptyRawAnnotationTable();
            end
            eventID = height(rawAnnotations) + 1;
            newRow = table(prefix, eventID, string(edtRawEventType.Value), string(ddRawAnnLead.Value), s, e, e-s, ...
                true, string(edtRawNotes.Value), string(datestr(now,'yyyy-mm-dd HH:MM:SS')), ...
                'VariableNames', {'Prefix','EventID','EventType','LeadLabel','StartSec','EndSec','DurationSec','UserIncluded','Notes','CreatedAt'});
            rawAnnotations = [rawAnnotations; newRow];
            localWriteRawAnnotations(rawAnnotationFile, rawAnnotations);
            refreshRawAnnotationList();
            onRawPlot();
        catch ME
            uialert(fig, sprintf('Could not save annotation:\n%s', ME.message), 'Raw Annotation');
        end
    end

    function onRawAnnotationSelection()
        try
            if isempty(rawAnnotations) || height(rawAnnotations)==0, return; end
            vals = lbRawAnn.ItemsData;
            if isempty(vals), return; end
            sel = lbRawAnn.Value;
            if iscell(sel), idx = sel{1}; else, idx = sel; end
            if isempty(idx) || isnan(idx) || idx < 1 || idx > height(rawAnnotations), return; end
            edtRawAnnStart.Value = double(rawAnnotations.StartSec(idx));
            edtRawAnnEnd.Value = double(rawAnnotations.EndSec(idx));
            edtRawEventType.Value = char(string(rawAnnotations.EventType(idx)));
            if any(strcmp(ddRawAnnLead.Items, char(string(rawAnnotations.LeadLabel(idx)))))
                ddRawAnnLead.Value = char(string(rawAnnotations.LeadLabel(idx)));
            end
            edtRawNotes.Value = char(string(rawAnnotations.Notes(idx)));
            edtRawStart.Value = max(0, double(rawAnnotations.StartSec(idx)) - 0.5*double(edtRawWin.Value));
            onRawPlot();
        catch
        end
    end

    function onRawToggleAnnotation(tf)
        try
            if isempty(rawAnnotations) || height(rawAnnotations)==0, return; end
            vals = lbRawAnn.ItemsData;
            if isempty(vals), return; end
            idx = lbRawAnn.Value;
            if iscell(idx), idx = idx{1}; end
            if isempty(idx) || idx < 1 || idx > height(rawAnnotations), return; end
            rawAnnotations.UserIncluded(idx) = logical(tf);
            localWriteRawAnnotations(rawAnnotationFile, rawAnnotations);
            refreshRawAnnotationList();
            try, lbRawAnn.Value = idx; catch, end
            onRawPlot();
        catch ME
            uialert(fig, sprintf('Could not update annotation:\n%s', ME.message), 'Raw Annotation');
        end
    end

    function refreshRawAnnotationList()
        try
            if isempty(rawAnnotations) || height(rawAnnotations)==0
                lbRawAnn.Items = {'(none)'};
                lbRawAnn.ItemsData = {nan};
                lbRawAnn.Value = nan;
                return;
            end
            items = cell(height(rawAnnotations),1);
            ids = num2cell(1:height(rawAnnotations));
            for rr = 1:height(rawAnnotations)
                inc = logical(rawAnnotations.UserIncluded(rr));
                status = 'included'; if ~inc, status = 'excluded'; end
                items{rr} = sprintf('#%d %s %.2f–%.2f sec [%s] %s', rr, char(string(rawAnnotations.EventType(rr))), ...
                    double(rawAnnotations.StartSec(rr)), double(rawAnnotations.EndSec(rr)), status, char(string(rawAnnotations.LeadLabel(rr))));
            end
            lbRawAnn.Items = items;
            lbRawAnn.ItemsData = ids;
            lbRawAnn.Value = ids{1};
        catch
        end
    end

    function onRawOpenAnnotationFolder()
        try
            outDir = localRawAnnotationDir();
            if ~isfolder(outDir), mkdir(outDir); end
            if ispc
                winopen(outDir);
            elseif ismac
                system(sprintf('open "%s"', outDir));
            else
                system(sprintf('xdg-open "%s"', outDir));
            end
        catch ME
            uialert(fig, sprintf('Could not open folder:\n%s', ME.message), 'Raw Annotation');
        end
    end

    function outDir = localRawAnnotationDir()
        outDir = meeg_outdir(project,'qeeg','Raw Data Viewer');
        if ~isfolder(outDir), mkdir(outDir); end
    end

    function f = localRawAnnotationFile(prefix)
        outDir = localRawAnnotationDir();
        safePrefix = regexprep(char(string(prefix)), '[^a-zA-Z0-9_\-]', '_');
        f = string(fullfile(outDir, sprintf('%s_manual_annotations.xlsx', safePrefix)));
    end

    function T = localReadRawAnnotations(f)
        if strlength(string(f)) == 0 || ~isfile(char(f))
            T = localEmptyRawAnnotationTable();
            return;
        end
        try
            T = readtable(char(f));
            req = localEmptyRawAnnotationTable();
            for vn = string(req.Properties.VariableNames)
                if ~ismember(char(vn), T.Properties.VariableNames)
                    T.(char(vn)) = req.(char(vn));
                end
            end
            T = T(:, req.Properties.VariableNames);
        catch
            T = localEmptyRawAnnotationTable();
        end
    end

    function localWriteRawAnnotations(f, T)
        outDir = fileparts(char(f));
        if ~isfolder(outDir), mkdir(outDir); end
        writetable(T, char(f), 'FileType','spreadsheet');
        try, writetable(T, strrep(char(f), '.xlsx', '.csv')); catch, end
    end

    function T = localEmptyRawAnnotationTable()
        T = table(string.empty(0,1), zeros(0,1), string.empty(0,1), string.empty(0,1), ...
            zeros(0,1), zeros(0,1), zeros(0,1), true(0,1), string.empty(0,1), string.empty(0,1), ...
            'VariableNames', {'Prefix','EventID','EventType','LeadLabel','StartSec','EndSec','DurationSec','UserIncluded','Notes','CreatedAt'});
    end


    function P = localSanitizeProjectLabels(P)
        % Backward-compatible migration for projects saved with dot/dash labels
        % such as auditory.R or motor-L. qEEG/PSD use labels as struct fields,
        % so every project-facing lead label must be MATLAB-safe.
        try
            if isfield(P, 'profile') && isfield(P.profile, 'channelLabels') && ~isempty(P.profile.channelLabels)
                lab = string(meeg_sanitize_lead_label(P.profile.channelLabels(:)));
                P.profile.channelLabels = cellstr(lab(:)');
                P.profile.nChannels = numel(P.profile.channelLabels);
            end
        catch
        end

        try
            if isfield(P, 'animals') && ~isempty(P.animals)
                labelFields = {'fileOrder','assignedLabels','assignedRegionLabels'};
                for aa = 1:numel(P.animals)
                    for lf = 1:numel(labelFields)
                        fn = labelFields{lf};
                        if isfield(P.animals, fn) && ~isempty(P.animals(aa).(fn))
                            lab = string(meeg_sanitize_lead_label(P.animals(aa).(fn)(:)));
                            P.animals(aa).(fn) = cellstr(lab(:));
                        end
                    end
                    if isfield(P.animals, 'assignCfg') && isstruct(P.animals(aa).assignCfg) && ...
                            isfield(P.animals(aa).assignCfg, 'assignedRegionLabels') && ~isempty(P.animals(aa).assignCfg.assignedRegionLabels)
                        lab = string(meeg_sanitize_lead_label(P.animals(aa).assignCfg.assignedRegionLabels(:)));
                        P.animals(aa).assignCfg.assignedRegionLabels = cellstr(lab(:));
                    end
                end
            end
        catch
        end
    end

    function showMainSection(section, selectedSubtab)
        if nargin < 2, selectedSubtab = []; end

        panelManifest.Visible = 'off';
        panelPreproc.Visible = 'off';
        panelQEEG.Visible = 'off';
        panelSpikes.Visible = 'off';
        panelSWD.Visible = 'off';
        panelEvent.Visible = 'off';
        panelRaw.Visible = 'off';

        inactiveBg = [0.92 0.95 0.99];
        activeBg   = [0.24 0.52 0.96];
        inactiveFg = [0.16 0.22 0.30];
        activeFg   = [1 1 1];
        btns = [btnNavProject, btnNavPreproc, btnNavQEEG, btnNavSpikes, btnNavSWD, btnNavEvent, btnNavRaw];
        for b = 1:numel(btns)
            btns(b).BackgroundColor = inactiveBg;
            btns(b).FontColor = inactiveFg;
            btns(b).FontWeight = 'bold';
        end

        switch lower(string(section))
            case "project"
                panelManifest.Visible = 'on';
                btnNavProject.BackgroundColor = activeBg;
                btnNavProject.FontColor = activeFg;
            case "preproc"
                panelPreproc.Visible = 'on';
                btnNavPreproc.BackgroundColor = activeBg;
                btnNavPreproc.FontColor = activeFg;
            case "qeeg"
                panelQEEG.Visible = 'on';
                btnNavQEEG.BackgroundColor = activeBg;
                btnNavQEEG.FontColor = activeFg;
                if ~isempty(selectedSubtab)
                    tgQ.SelectedTab = selectedSubtab;
                end
                % Do not auto-load band tables here. Normalized Band Power loads only when
                % the user clicks its "Load project data" button.
            case "spikes"
                panelSpikes.Visible = 'on';
                btnNavSpikes.BackgroundColor = activeBg;
                btnNavSpikes.FontColor = activeFg;
                if ~isempty(selectedSubtab)
                    tgS.SelectedTab = selectedSubtab;
                end
            case "swd"
                panelSWD.Visible = 'on';
                btnNavSWD.BackgroundColor = activeBg;
                btnNavSWD.FontColor = activeFg;
                if ~isempty(selectedSubtab)
                    tgSWD.SelectedTab = selectedSubtab;
                end
            case {"events","event","eventdetection"}
                panelEvent.Visible = 'on';
                btnNavEvent.BackgroundColor = activeBg;
                btnNavEvent.FontColor = activeFg;
                if ~isempty(selectedSubtab)
                    tgEV.SelectedTab = selectedSubtab;
                end
            case {"rawviewer","raw","annotator"}
                panelRaw.Visible = 'on';
                btnNavRaw.BackgroundColor = activeBg;
                btnNavRaw.FontColor = activeFg;
        end
    end


end