function profile = meeg_getSystemProfile(systemName)
% Return a system profile struct that defines the instrument-specific defaults.

    switch systemName
        case {'10-electrode system','10-electrode Intan RHX (.dat)'}
            profile.name = '10-electrode Intan RHX (.dat)';
            profile.systemId = '10-electrode system';
            profile.nChannels = 10;

            % Canonical 10e labels (edit to match your lab conventions)
            profile.channelLabels = {'auditory_R','visual_R','hippocampus_R','barrel_R','motor_R','auditory_L','visual_L','hippocampus_L','barrel_L','motor_L'};

            % Defaults (editable in GUI later)
            profile.defaultFs = 2500;
            profile.bytesPerSample = 2;     % int16
            profile.scale_uV = 0.195;       % preserve legacy scaling
            profile.fileType = 'dat';

            % Preprocessing defaults (from your current script)
            profile.preproc.windowSec = 30*60;   % 30 minutes
            profile.preproc.rmsBinSec = 1;       % per-second RMS
            profile.preproc.epochSec = 5;        % artifact epoch size
            profile.preproc.zThresh = 3;
            profile.preproc.rmsLow = 30;
            profile.preproc.rmsHigh = 200;
            profile.preproc.skwHigh = 0.4;

            % Notch (60 Hz)
            profile.preproc.notch.enabled = true;
            profile.preproc.notch.f1 = 59;
            profile.preproc.notch.f2 = 61;

            % qEEG defaults
            profile.qeeg.dayStart = 6.5;
            profile.qeeg.dayEnd = 18.5;
            profile.qeeg.corr_window_sec = 30;


        case {'1-10 electrode Standard (.edf)','standard-edf'}
            profile.name = '1-10 electrode Standard (.edf)';
            profile.systemId = 'standard-edf';
            profile.nChannels = 0;
            profile.channelLabels = {};
            profile.defaultFs = 2500;
            profile.bytesPerSample = 2;
            profile.scale_uV = 0.195;
            profile.fileType = 'edf';
            profile.allowDynamicChannels = true;
            profile.allowAverageSameRegion = true;

            profile.preproc.windowSec = 30*60;
            profile.preproc.rmsBinSec = 1;
            profile.preproc.epochSec = 5;
            profile.preproc.zThresh = 3;
            profile.preproc.rmsLow = 30;
            profile.preproc.rmsHigh = 200;
            profile.preproc.skwHigh = 0.4;
            profile.preproc.notch.enabled = true;
            profile.preproc.notch.f1 = 59;
            profile.preproc.notch.f2 = 61;

            profile.qeeg.dayStart = 6.5;
            profile.qeeg.dayEnd = 18.5;
            profile.qeeg.corr_window_sec = 30;

        otherwise
            error('Unknown system profile: %s', systemName);
    end
end
