function meeg_pathcheck()
% Diagnose name conflicts that prevent launching mEEG.
% Run:
%   >> meeg_pathcheck

    fprintf('--- MATLAB "meeg" resolution (conflicts) ---\n');
    try
        disp(which('meeg','-all'));
    catch
        disp(which('meeg'));
    end
    fprintf('\n--- MATLAB "mEEG" resolution (this launcher) ---\n');
    try
        disp(which('mEEG','-all'));
    catch
        disp(which('mEEG'));
    end

    fprintf('\nIf typing "meeg" constructs an SPM M/EEG object, that is expected.\n');
    fprintf('Use "mEEG" to launch this tool.\n');
end
